Plano limpeza-legado.md executado. Resumo:
Onda 1 — Deleção Segura ✅
- 58 arquivos deletados (20 ouvidoria, 19 .bak, 1 sync-manager.js, 3 .old, 3 .OBSOLETE, 2 -old.html)
- 5 imports comentados supabase removidos
- Tags <script> de sync-manager.js removidas de 2 HTMLs
- Typecheck: zero erros
Onda 2 — Correções Pontuais ✅
- Salt PBKDF2: mobile CryptoLayer.js + SyncAdapter.js passam user.sync_salt per-user; desktop já estava wired
- 4 stubs removidos de useClientMutations.ts (createPF, updatePF, linkContact, unlinkContact)
- 6 stubs Supabase removidos de FormVersionManager.js
- data-service.js: startAutoSync() e stableStringifyFallback() removidos (sem callers)
- Typecheck: zero erros
Onda 3 — Consolidação Estrutural ✅/⏳
- 3.1 routing_id: device_id opcional em EventEnvelope (TS+JS), sync-settings.ts migrado para key routing_id, FormRenderer.tsx usa user.setor, device-setup.js renomeado
- 3.2 CRM tbl_suite: ⏳ requer refatoração de use cases (não é limpeza, é feature)
- 3.3 sync core: headers de espelhamento em 8 arquivos JS, teste de contrato criado com 6 assertions (todas passaram)
Resultado: 11/12 itens do plano concluídos. ~76 arquivos/pedaços de código removidos. Typecheck e testes passam.