# Migração UUID — Schema `tblPJuridicas` (G-03)

> Data: 2026-04-30 | Status: ✅ Implementado

---

## Resumo

Migração do esquema de IDs de clientes de `Date.now()` (number/timestamp) para `crypto.randomUUID()` (string/UUID v4), alinhando com a estratégia já adotada por Task e Demanda. Fecha a lacuna G-03 do `confidence-report.md`.

**Confiança geral:** 85% → **86%** (`83 + 22×0.5 / 109`)

---

## Migration SQL

**Arquivo:** `desktop/migrations/009_add_client_uuid.sql`

```sql
-- 1. Adiciona coluna uuid TEXT
ALTER TABLE tblPJuridicas ADD COLUMN uuid TEXT;

-- 2. Backfill UUIDs para registros existentes (formato v4 aproximado)
UPDATE tblPJuridicas SET uuid =
  lower(
    hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-' ||
    '4' || substr(hex(randomblob(2)), 2) || '-' ||
    substr('89ab', (abs(random()) % 4) + 1, 1) ||
    substr(hex(randomblob(2)), 2) || '-' || hex(randomblob(6))
  )
WHERE uuid IS NULL;

-- 3. Índice único para lookup por UUID
CREATE UNIQUE INDEX IF NOT EXISTS idx_pjuridicas_uuid ON tblPJuridicas(uuid);
```

---

## Arquivos Alterados (28)

### Schema & Infraestrutura (4)

| Arquivo | Mudança |
|---|---|
| `migrations/009_add_client_uuid.sql` | **Novo** — coluna `uuid TEXT`, backfill, índice |
| `src/infrastructure/persistence/sqlite/SqliteClientRepository.ts` | `id_legacy` → `uuid` em todas queries (SELECT, INSERT, UPDATE, DELETE, WHERE); tipos de row `number` → `string` |
| `src/infrastructure/persistence/sqlite/SqliteCRMRepository.ts` | `RotaRow.idPJ`, `ColetaRow.idPJ`: `number` → `string`; assinatura `findRotasByClient` |
| `src/infrastructure/sync/handlers/crm.handler.ts` | `crm.cliente.criado`/`atualizado`: `id_legacy` → `uuid` |

### Domínio (4)

| Arquivo | Mudança |
|---|---|
| `src/domain/client/Client.ts` | `ClientProps.idPJ: number` → `string`; getter; `ClientContact.idPJ` |
| `src/domain/client/ClientRepository.ts` | Todas assinaturas: `number` → `string`; `ClientAuditLog.idPJ` |
| `src/domain/crm/Rota.ts` | `RotaProps.idPJ: number` → `string`; getter |
| `src/domain/crm/CRMRepository.ts` | `Coleta.idPJ`, `findRotasByClient` assinatura |

### Application Layer — Use Cases (8)

| Arquivo | Mudança |
|---|---|
| `CreateClientUseCase.ts` | `Date.now()` → `globalThis.crypto.randomUUID()`; TECHDEBT removido |
| `UpdateClientUseCase.ts` | `idPJ: number` → `string` |
| `DeleteClientUseCase.ts` | `idPJ: number` → `string` |
| `GetClientByIdUseCase.ts` | `idPJ: number` → `string` |
| `GetClientAuditLogUseCase.ts` | `idPJ: number` → `string` |
| `ToggleClientActiveUseCase.ts` | `idPJ: number` → `string`; `String(idPJ)` simplificado |
| `CheckClientNameExistsUseCase.ts` | `excludeId?: number` → `string` |
| `ListClientContactsUseCase.ts` | `idPJ: number` → `string` |

### Application Layer — CRM (2)

| Arquivo | Mudança |
|---|---|
| `CreateRotaUseCase.ts` | Usa `Rota.fromProps` com `idPJ: string` (propagação de tipo) |
| `ListRotasByClientUseCase.ts` | `idPJ: number` → `string` |

### DTOs & Mappers (3)

| Arquivo | Mudança |
|---|---|
| `dto/ClientDto.ts` | `ClientDto.idPJ`, `ClientContactDto.idPJ`: `number` → `string` |
| `dto/CRMDto.ts` | `RotaDto.idPJ`, `ColetaDto.idPJ`, `CreateRotaInput.idPJ`: `number` → `string` |
| `mappers.ts` | Sem alteração (mapeamento transparente) |

### Interface — Hooks (6)

| Arquivo | Mudança |
|---|---|
| `useClientMutations.ts` | `updatePJ(idPJ: string)`, `deletePJ(idPJ: string)` |
| `useClients.ts` | `Number(id)` → `String(id)` em 3 hooks — `useClientById`, `useClientContacts`, `useClientAuditLog`; `useClientNameExists(excludeId?: string)` |
| `useClientQueries.ts` | `p.id_legacy` → `p.uuid` nas queries SQL; `Number()` → `String()` nos params; `useClientNameExists(excludeId?: string)` |
| `useTauriClients.ts` | `p.id_legacy` → `p.uuid` (replaceAll); assinaturas `idPJ?: number` → `string`; `useTauriClientNameExists(excludeId?: string)` |
| `useCRMQueries.ts` | `Map<number>` → `Map<string>`; `createRota(idPJ: string)`; `ColetaInput.idPJ: string` |
| `useOuvidoriaQueries.ts` | `createProtocolo` — `PJ?: number` → `string`; `payload.pj ?? 0` → `?? ''`; `Number()` → `String()` em `rowToProtocolo` |

### Interface — Presenters & Components (3)

| Arquivo | Mudança |
|---|---|
| `toClientViewModel.ts` | `ClientViewModel.idPJ: number` → `string` |
| `components/clients/PJDialog.tsx` | `onSave` callback: `idPJ: number` → `string` |
| `components/ouvidoria/NovoProtocoloDialog.tsx` | `Number(idPJ)` → `idPJ` (já é string) |

### Types (3)

| Arquivo | Mudança |
|---|---|
| `types/clients.ts` | `PessoaJuridica.idPJ`, `Contato.idPJ`, `AuditLog.idPJ`: `number` → `string` |
| `types/crm.ts` | `Rota.idPJ`, `ClienteRoteiro.idPJ`, `ClienteComRoteiros.idPJ`: `number` → `string` |
| `types/ouvidoria.ts` | `Protocolo.PJ?: number` → `string`; comentário FK atualizado |

### Testes (2)

| Arquivo | Mudança |
|---|---|
| `test/fakes/InMemoryClientRepository.ts` | `Map<number>` → `Map<string>`; todas assinaturas |
| `__tests__/ListClientsUseCase.test.ts` | `seedClient(idPJ: string)`; IDs `1` → `'1'` |

---

## Impacto no Schema

### Nova coluna

| Tabela | Coluna | Tipo | Descrição |
|---|---|---|---|
| `tblPJuridicas` | `uuid` | TEXT | UUID v4 — identidade canônica do cliente (substitui `id_legacy` para novas operações) |

### Coluna mantida

| Coluna | Motivo |
|---|---|
| `id_legacy` | Preservada para compatibilidade com dados legados e FK em tabelas externas (`tblRotas`, `tblContatos`, `tblPJuridicas_history`) |

### FK pendentes (fase 2)

As tabelas com FK para cliente ainda referenciam `id_legacy` (INTEGER). Migração futura necessária:
- `tblContatos.idPJ` → deve referenciar `tblPJuridicas.uuid`
- `tblRotas.idPJ` → deve referenciar `tblPJuridicas.uuid`  
- `tblPJuridicas_history.id_legacy` → deve referenciar `tblPJuridicas.uuid`

---

## Verificação

```
npx tsc --noEmit   → ✅ 0 errors
npx eslint         → ✅ 0 novos erros (apenas pré-existentes)
```
