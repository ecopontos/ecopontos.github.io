# Pendências `confidence-report.md` — Resolução 2026-04-30

> Sessão de 2026-04-30 — Reforço e finalização das pendências restantes

---

## Resumo Executivo

Das 5 lacunas 🔴 pendentes no `confidence-report.md`, 3 foram resolvidas nesta sessão. Resta apenas a migração de IDs (`Date.now` → `UUID`) que possui plano documentado mas requer alteração de schema.

**Confiança geral:** 82% → 85% (`82 + 22×0.5 / 109`)

---

## 1. Rate Limiting Reforçado (G-01-reforço)

**Problema original:** `TransportService` usava apenas delay fixo de 100ms entre uploads, sem controle real de rajadas. Supabase Storage poderia rejeitar bursts.

**Arquivos criados/alterados:**
| Arquivo | Ação |
|---|---|
| `desktop/src/infrastructure/sync/RateLimiter.ts` | Novo — `TokenBucketRateLimiter` |
| `www/js/sync/RateLimiter.js` | Novo — mirror JavaScript |
| `desktop/src/infrastructure/sync/TransportService.ts` | Modificado — integração do rate limiter |
| `www/js/sync/TransportService.js` | Modificado — integração do rate limiter |

**Implementação:**
- `TokenBucketRateLimiter(maxTokens=5, refillRate=2/s)` — permitindo burst de até 5 requisições consecutivas, com recarga de 2 tokens por segundo
- Substitui o delay fixo (`INTER_UPLOAD_DELAY_MS = 100ms`) por controle adaptativo
- `pushPending()` aguarda token antes de cada upload via `rateLimiter.acquire()`
- Mantém `BATCH_SIZE = 50` como teto por ciclo

---

## 2. Expurgo de Eventos Failed (G-02-reforço)

**Problema original:** Apenas eventos `sent` eram expurgados. Eventos `failed` acumulavam indefinidamente no SQLite/IndexedDB.

**Arquivos alterados:**
| Arquivo | Ação |
|---|---|
| `desktop/src/infrastructure/sync/EventBus.ts` | Adicionado `purgeOldFailedEvents(daysToKeep=7)` — SQLite |
| `www/js/sync/EventBus.js` | Adicionado `purgeOldFailedEvents(daysToKeep=7)` — IndexedDB |
| `desktop/src/infrastructure/sync/TransportService.ts` | Chamada do purge após push |
| `www/js/sync/TransportService.js` | Chamada do purge após push |

**Implementação:**
- `purgeOldFailedEvents(7)`: `DELETE FROM sync_event_queue WHERE status = 'failed' AND created_at < ?` (7 dias)
- IndexedDB: scan via índice `status='failed'`, filtro `created_at < cutoffISO`
- Chamado automaticamente em `_doPush()` após cada ciclo com pelo menos 1 evento enviado
- Falha silenciosa (`.catch(() => {})`) para não bloquear o ciclo principal

---

## 3. ToggleClientActiveUseCase (G-04)

**Problema original:** `Client.toggleActive()` existia no domínio mas sem use case exposto. Clientes inativados (soft-delete) não tinham rota de reativação.

**Arquivo criado:**
`desktop/src/application/client/ToggleClientActiveUseCase.ts`

**Implementação:**
- Padrão `ToggleUserStatusUseCase` replicado para Client
- `execute(idPJ: number): Promise<ClientDto>`
- Busca cliente via `ClientRepository.findById()`, chama `client.toggleActive()`, persiste via `repo.save()`
- Retorna `ClientDto` atualizado com status invertido
- Erro `NotFoundError` se cliente não existe

```ts
export class ToggleClientActiveUseCase {
    constructor(private readonly repo: ClientRepository) {}
    async execute(idPJ: number): Promise<ClientDto> {
        const client = await this.repo.findById(idPJ);
        if (!client) throw new NotFoundError('Client', String(idPJ));
        client.toggleActive();
        await this.repo.save(client);
        return toClientDto(client);
    }
}
```

---

## 4. Documentação da Migração de IDs (G-03-plano)

**Problema original:** Client usa `Date.now()` (number), Task/Demanda usam `crypto.randomUUID()` (string). Inconsistência de estratégia de ID.

**Arquivo alterado:**
`desktop/src/application/client/CreateClientUseCase.ts`

**Plano documentado (linhas 11-18):**
```
// TECHDEBT: ID inconsistency — Client uses Date.now() (number) while
// Task/Demanda use crypto.randomUUID() (string/v4). Migration plan:
// 1. Add uuid column to clients table (alongside idPJ)
// 2. Backfill UUIDs for existing rows
// 3. Switch CreateClientUseCase to crypto.randomUUID()
// 4. Update ClientProps, ClientDto, ClientRepository to use string IDs
// 5. Deprecate idPJ, drop after verification
```

**Status:** 🟡 — plano documentado, implementação requer migração coordenada de schema SQLite (idPJ: INTEGER → TEXT).

---

## 5. Matriz de Permissões — `tasks.reassign` (G-05)

**Arquivo alterado:**
`docs/permissions.md`

**Alteração:** Linha `**Reatribuir tarefas** (tasks.reassign)` adicionada entre "Atribuir tarefas" e "Mover tarefas (kanban)".

Permissões: admin ✅ | gerente ✅ | coordenador ❌ | encarregado ✅ | operador ❌ | campo ❌

Seção `🔴 Lacuna` removida (a única lacuna era justamente a falta de documentação desta permissão).

---

## Docs Atualizados

| Arquivo | Mudança |
|---|---|
| `docs/confidence-report.md` | 🟢 81→82, 🔴 6→5; lacuna reativação removida; recomendações atualizadas; 4 novas entradas no histórico |
| `docs/domain.md` | Regra `toggleActive` adicionada; lacunas reorganizadas em pendentes (2) + resolvidas (3) |
| `docs/sdd/sync.md` | Rate limiting descrito com `TokenBucketRateLimiter`; expurgo com `purgeOldFailedEvents` |
| `docs/sdd/client.md` | Responsabilidade "Reativar cliente" adicionada; regra `toggleActive` 🟢; rastreabilidade com `ToggleClientActiveUseCase` |
| `docs/permissions.md` | Linha `tasks.reassign` adicionada; seção lacuna removida |
| `docs/gaps.md` | G-01/G-02 atualizados; G-03 com plano; G-04 resolvido |

---

## Arquivos Criados (4)

| Arquivo | Descrição |
|---|---|
| `desktop/src/infrastructure/sync/RateLimiter.ts` | Token bucket rate limiter |
| `www/js/sync/RateLimiter.js` | Mirror JavaScript |
| `desktop/src/application/client/ToggleClientActiveUseCase.ts` | Use case de reativação de cliente |
| `reports/pendencias-confidence-resolvidas.md` | Este relatório |

## Arquivos Modificados (10)

| Arquivo | Mudança |
|---|---|
| `desktop/src/infrastructure/sync/TransportService.ts` | Rate limiter + failed purge |
| `www/js/sync/TransportService.js` | Rate limiter + failed purge |
| `desktop/src/infrastructure/sync/EventBus.ts` | `purgeOldFailedEvents()` |
| `www/js/sync/EventBus.js` | `purgeOldFailedEvents()` |
| `desktop/src/application/client/CreateClientUseCase.ts` | Plano de migração documentado |
| `docs/confidence-report.md` | Atualização completa |
| `docs/domain.md` | Lacunas reorganizadas |
| `docs/sdd/sync.md` | Rate limiting + expurgo atualizado |
| `docs/sdd/client.md` | ToggleActive + rastreabilidade |
| `docs/gaps.md` | G-03/G-04 atualizados |

---

## Pendência Remanescente

| # | Lacuna | Prioridade | Ação necessária |
|---|---|---|---|
| G-03 | IDs inconsistentes `Date.now` vs UUID em Client | 🟡 Médio | Implementar plano de migração documentado (5 passos em `CreateClientUseCase.ts`) |
