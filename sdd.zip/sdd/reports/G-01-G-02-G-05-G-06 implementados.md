# Gaps G-01, G-02, G-05, G-06 — Implementação Concluída

> Data: 2026-04-30

---

## Resumo Executivo

4 gaps do `confidence-report.md` foram implementados e fechados nesta sessão.
O projeto sobe de **82% → 85%** de confiança geral, e elimina todas as lacunas críticas (🔴).

---

## G-01 — Rate Limiting no TransportService

**Arquivos alterados:**
- `desktop/src/infrastructure/sync/TransportService.ts`
- `www/js/sync/TransportService.js`

**O que foi feito:**
- `BATCH_SIZE = 50` — cada ciclo de push processa no máximo 50 eventos; filas maiores são drenadas progressivamente
- `INTER_UPLOAD_DELAY_MS = 100` — pausa de 100ms entre uploads individuais (≤10 req/s para Supabase Storage)
- Retry em `pushSingle`: 2 tentativas com backoff exponencial (300ms → 600ms); erros não-recuperáveis (4xx) abortam sem retry via `isRetryableError` — usa `retry-logic.ts` já existente mas até então inativo
- JS mirror: mesmo comportamento via `_uploadWithRetry()` inline (sem dependência TypeScript)

---

## G-02 — Expurgo Automático do Outbox

**Arquivos alterados:**
- `desktop/src/infrastructure/sync/EventBus.ts`
- `www/js/sync/EventBus.js`
- `desktop/src/infrastructure/sync/TransportService.ts` (chamada do purge)
- `www/js/sync/TransportService.js` (chamada do purge)

**O que foi feito:**
- `EventBus.purgeOldSentEvents(daysToKeep = 30)` — novo método em ambas as implementações
  - Desktop (SQLite): `DELETE FROM sync_event_queue WHERE status = 'sent' AND sent_at < ?`
  - Mobile (IndexedDB): scan via índice `status='sent'`, filtra `sent_at < cutoffISO`, deleta cada registro
- Chamado automaticamente em `_doPush()` após cada ciclo com pelo menos 1 evento enviado
- Falha silenciosa (`.catch(() => {})`) para não bloquear o ciclo principal em caso de erro de DB

**Garantia:** eventos `pending` e `failed` nunca são removidos pelo expurgo — apenas `sent` com `sent_at` anterior a 30 dias.

---

## G-05 — Permissão `tasks.reassign` Documentada

**Arquivos alterados:**
- `docs/permissions.md`
- `_reversa_sdd/permissions.md`

**O que foi feito:**
- Nova linha na Matriz de Permissões: `Reatribuir tarefas (tasks.reassign)`
  - admin ✅ | gerente ✅ | coordenador ❌ | encarregado ✅ | operador ❌ | campo ❌
- Seção `🔴 Lacuna` removida de ambos os arquivos
- Nota: coordenador pode *atribuir* tarefas mas não *reatribuir* — distinção preservada na matriz

**Evidência de conformidade (pré-existente no código):**
- `AuthManager.js:820` — `'tasks.reassign': ['admin', 'superadmin', 'gerente', 'encarregado']`
- `setup.rs:157` — seed DB: `('admin','tasks.reassign'), ('gerente','tasks.reassign'), ('encarregado','tasks.reassign')`
- `usePermissions.ts:89` — `["admin", "gerente", "encarregado"]`
- `tests/usePermissions.reassign.test.ts` — já existia, validava encarregado

---

## G-06 — Cobertura de Testes AuthManager + DataService

**Arquivos criados:**
- `tests/auth-manager.test.js` — 19 testes
- `tests/data-service.test.js` — 10 testes

**Resultado:** 29/29 ✅ — `npx vitest run`

### auth-manager.test.js — cobertura

| Suite | Testes | Comportamentos cobertos |
|---|---|---|
| Sessão | 7 | `isLoggedIn`, `saveSession`, `loadSession` (válida + expirada), `logout` |
| Perfis e permissões | 12 | `isAdmin/isManager/isOperator`, `hasPermission` (todos os perfis para `tasks.reassign`), `canEditUser` |

### data-service.test.js — cobertura

| Suite | Testes | Comportamentos cobertos |
|---|---|---|
| LWW | 5 | no_remote, local wins, remote wins, idêntico, hash tiebreak |
| _quickHash | 3 | determinismo, diferenciação, formato hex |
| updateSyncStatus | 1 | mutação de campo |
| getPendingSync | 1 | filtro por status |

---

## Docs Atualizados

| Arquivo | Mudança |
|---|---|
| `docs/gaps.md` | G-01, G-02, G-05, G-06, G-07, G-08 movidos para seção ✅ Resolvidas; G-04 permanece 🟡 |
| `docs/confidence-report.md` | 🔴 cai de 9→6; 🟢 sobe de 78→81; confiança 82%→85%; 3 recomendações marcadas ✅; 4 entradas adicionadas ao histórico |
| `docs/permissions.md` | Linha `tasks.reassign` adicionada; seção 🔴 Lacuna removida |
| `docs/sdd/sync.md` | Responsabilidades + regras de negócio + NFRs + prioridade atualizados com rate limiting e expurgo |
| `_reversa_sdd/gaps.md` | Espelho de `docs/gaps.md` |
| `_reversa_sdd/permissions.md` | Espelho de `docs/permissions.md` |

---

## Lacunas Remanescentes

| # | Gap | Prioridade |
|---|---|---|
| G-03 | IDs inconsistentes `Date.now` vs UUID em Client | 🟡 Médio — migração de dados necessária |
| G-04 | `Client.toggleActive()` sem use case na UI | 🟡 Médio — feature confirmada pelo stakeholder |
| G-09 | Tailwind v3 (mobile) + v4 (desktop) | 🟢 Cosmético |
