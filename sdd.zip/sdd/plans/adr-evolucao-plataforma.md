# Decisões Arquiteturais — Evolução da Plataforma EcoForms

**Data:** 2026-04-30
**Contexto:** Sessão de análise arquitetural que revisou o sistema completo e definiu a direção estratégica da evolução do EcoForms para uma plataforma genérica de gestão operacional baseada em fluxos.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `adr.md` | Decisões arquiteturais anteriores (AD-001 a AD-008) |
| `arquitetura.md` | Visão geral da arquitetura atual |
| `database.md` | Schema de banco de dados |
| `modules.md` | Inventário de módulos |
| `action-widget-system.md` | ActionRegistry e WidgetRegistry |
| `form-builder.md` | FormBuilder e FieldFactory |
| `event-protocol.md` | Protocolo de eventos v2 — envelope, tipos, criptografia |
| `data-flow.md` | Fluxos de dados — push/pull, sync, storage paths |
| `supabase-integration.md` | Status da integração Supabase Auth/Storage/RLS |
| `fields.md` | Sistema de campos — BaseField, 15 tipos, getValue/setValue |

---

## Auditoria do Estado Atual (2026-04-30)

Levantamento do codebase antes da implementação, para validar premissas do ADR.

| Premissa | Realidade encontrada | Impacto na implementação |
|---|---|---|
| `tbl_suite` como backbone | Existe — 18 colunas (20 após AD-017) | Fundação sólida |
| `entity_id` / `entity_type` em tbl_suite | **Ausentes** | Migration necessária (AD-017) |
| `form_registry` com slug | Existe (slug, conteudo, versao) | Boa base para builders |
| `decision_registry` / `view_registry` | **Não existem** | Implementação do zero |
| `CryptoLayer` aceita salt externo | **Não** — salt hardcoded como `"ecoforms-sync-salt-v1"` | Refatoração necessária (AD-022) |
| `InboundService` recupera gaps | **Não** — apenas detecta e para | Implementação necessária (AD-021) |
| Tabelas legadas da Ouvidoria | 7 tabelas (formato MS Access) | Migração viável — sem dados de produção |
| `ActionRegistry.expandPanel` | **Ausente** — só `requiresInput` existe | Extensão não-breaking da interface (AD-018) |
| `tbl_setores` colunas completas | descricao, criado_em, atualizado_em presentes | Nenhuma ação necessária |

---

## Índice (ordem de implementação por sprint)

**Sprint 1 — Fundação** (sem risco, alto valor imediato)
1. [AD-022: Salt PBKDF2 por Usuário](#ad-022-salt-pbkdf2-por-usuário)
2. [AD-017: entity_id + entity_type em tbl_suite](#ad-017-entity_id--entity_type-em-tbl_suite)
3. [AD-021: Gap Recovery Automático no Sync](#ad-021-gap-recovery-automático-no-sync)

**Sprint 2 — Refatoração de módulos** (elimina código legado, libera sync)
4. [AD-014: Ouvidoria como Setor e module_type](#ad-014-ouvidoria-como-setor-e-module_type)
5. [AD-015: CRM como Entity Registry da Plataforma](#ad-015-crm-como-entity-registry-da-plataforma)
6. [AD-020: dataSource do CRM para Campos de Formulário](#ad-020-datasource-do-crm-para-campos-de-formulário)

**Sprint 3 — UX e visualização** (ReadOnlyFormRenderer desbloqueia tudo abaixo)
7. [AD-019: ReadOnlyFormRenderer como Base de Visualização](#ad-019-readonlyformrenderer-como-base-de-visualização)
8. [AD-018: ActionBar com Dois Modos de Interação](#ad-018-actionbar-com-dois-modos-de-interação)
9. [AD-023: Página de Tarefa como Evolução do Modal](#ad-023-página-de-tarefa-como-evolução-do-modal)

**Sprint 4 — Ações universais** (formaliza vocabulário e novos eventos)
10. [AD-016: Sete Ações Universais de Decisão](#ad-016-sete-ações-universais-de-decisão)
11. [AD-024: Encaminhar e Reencaminhar como Novos Eventos de Domínio](#ad-024-encaminhar-e-reencaminhar-como-novos-eventos-de-domínio)

**Sprint 5 — Builders** (após validar sprints anteriores)
12. [AD-010: Entity Registry como Camada de Infraestrutura](#ad-010-entity-registry-como-camada-de-infraestrutura)
13. [AD-011: view_registry — DashBuilder Configurável](#ad-011-view_registry--dashbuilder-configurável) *(escopo inicial: 4 tipos)*
14. [AD-012: decision_registry — DecisionBuilder Configurável](#ad-012-decision_registry--decisionbuilder-configurável)

**Sprint 6 — Plataforma (v2)** (diferir; avaliar após Sprint 5)
15. [AD-013: ModuleBuilder — Quarto Builder Orquestrador](#ad-013-modulebuilder--quarto-builder-orquestrador)

**Visão de plataforma** (referência, sem sprint definido)
16. [AD-009: EcoForms como Plataforma de Fluxos Operacionais](#ad-009-ecoforms-como-plataforma-de-fluxos-operacionais)

---

## AD-009: EcoForms como Plataforma de Fluxos Operacionais

**Decisão:** O EcoForms evolui de um produto específico de gestão de resíduos para uma **plataforma genérica de fluxos operacionais**, onde qualquer processo baseado em registrar, acompanhar e decidir sobre eventos do mundo real é implementável por configuração — sem código novo.

### Contexto

O sistema acumulou módulos específicos (Ouvidoria, CRM, Ecopontos, Kanban) que resolvem o mesmo problema de formas diferentes. A análise revelou que todos seguem o mesmo padrão fundamental:

```
Entidade + Formulário + Fluxo + Decisão = Módulo operacional
```

### Análise

**Equação unificadora:**

```
Entity Registry    →  quem existe no mundo real
form_registry      →  o que se registra sobre eventos
tbl_suite          →  todos os registros, de todos os módulos
tbl_tarefas        →  toda obrigação gerada, de todos os setores
view_registry      →  como cada setor vê seus dados
decision_registry  →  o que cada setor pode decidir
org_config         →  quais setores existem
kanban             →  onde todo setor trabalha (caixa de entrada universal)
```

Oito configurações. Um sistema. Qualquer nova operação — fiscalização, licenciamento, monitoramento — entra como configuração, não como código.

**Analogia de mercado:** O WordPress resolveu "quero um site sem depender de desenvolvimento para cada mudança". O EcoForms resolve "quero um sistema de gestão operacional sem depender de desenvolvimento para cada novo processo".

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Novos módulos por configuração, sem deploy | Requer formalizar os três builders (Dash, Decision, Module) |
| Redução drástica de código duplicado | Refatoração direta dos módulos existentes (sem dados de produção) |
| Plataforma vendável para múltiplos contextos | Abstração maior exige documentação mais rigorosa |
| Equipe foca em infraestrutura, não em módulos | — |

### Referências

- `arquitetura.md` — visão geral dos módulos existentes
- `action-widget-system.md` — ActionRegistry e WidgetRegistry (embrião da plataforma)
- `modules.md` — inventário de módulos a serem unificados

---

## AD-010: Entity Registry como Camada de Infraestrutura

**Decisão:** Formalizar uma camada de **Entity Registry** separada dos módulos e dos dados de referência. Entidades são objetos do mundo real com existência própria, ciclo de vida de cadastro e que são referenciados por múltiplos módulos via `entity_picker`.

### Contexto

O sistema tinha três categorias de dado confladas:
- `tbl_suite` para eventos e registros
- `data_registry` para listas de referência
- Tabelas específicas por módulo para entidades

A distinção não estava formalizada, gerando inconsistência sobre onde cadastrar cada tipo de dado.

### Análise

**Critérios que definem uma entidade:**

```
1. Existe independentemente de eventos
2. É referenciada por múltiplos módulos
3. Tem dados estruturados próprios
4. Tem ciclo de vida de cadastro (criar, atualizar, desativar)
5. Pode ser vinculada via entity_picker
```

**Exemplos:**

```
Entity Registry (tabelas dedicadas, permanentes)
├── tblPJuridicas    → clientes, cooperativas, galpões
├── tblPFisicas      → pessoas físicas, catadores, contatos
├── tbl_ecopontos    → pontos de coleta
└── tblCEP           → logradouros

NÃO são entidades (ficam em data_registry)
├── tipos de problema
├── assuntos de ouvidoria
├── roteiros de coleta
└── categorias e listas de seleção

NÃO são entidades (ficam em tbl_suite)
├── registros de formulários
├── ocorrências
├── protocolos
└── coletas
```

**Distinção entity vs. data_registry:**

| Característica | Entidade | data_registry |
|---|---|---|
| Tem ciclo de vida próprio | Sim | Não |
| Referenciada por FK | Sim | Por valor |
| FTS5 para busca | Sim | Não necessário |
| Auditoria de alterações | Sim | Versão simples |
| Usada no entity_picker | Sim | Não |

### entity_picker como Campo do form_registry

O `entity_picker` é um tipo de campo do `form_registry` que vincula registros a entidades do Entity Registry. Schema implementado:

```json
{
  "type": "entity_picker",
  "config": { "entityType": "pj" },
  "label": "Cliente",
  "required": true
}
```

**Propriedades:**
- `config.entityType`: `"pj"` | `"pf"` | `"ecoponto"` — determina qual resolver CRM usar
- `label`, `required`: propriedades padrão de campo

**Mapeamento entityType → dataSource (implementado em EntityPickerRenderer):**
```
pj       → clientes_crm      (tblPJuridicas)
pf       → pessoas_fisicas_crm (tblPFisicas)
ecoponto → ecopontos_crm     (tbl_ecopontos)
```

**Exibição:** `nome — documento` no dropdown; armazena `id` da entidade selecionada.

**ReadOnlyFormRenderer:** exibe o ID da entidade com badge monoespaçado.

**Preenchimento automático:** Quando um formulário com `entity_picker` é submetido, o `SubmitSuiteUseCase` extrai o `id` da entidade selecionada e popula `entity_id` + `entity_type` em `tbl_suite` automaticamente (ver AD-017).

> **Nota de implementação:** `searchFields` e `displayTemplate` do schema original foram simplificados — o renderer hardcodeia busca por nome/documento e exibe `{nome} — {documento}` com base no `entityType`. Generalizar esses campos é uma evolução futura, não um gap atual.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Distinção clara entre tipos de dado | Requer formalização explícita de cada entidade |
| entity_picker unificado para todas as entidades | Tabelas dedicadas continuam existindo |
| Queries eficientes com índices próprios | — |
| Auditoria nativa por entidade | — |

### Referências

- `database.md` — tblPJuridicas, tblPFisicas, tblCEP
- `fields.md` — TextInputField com dataSource para autocomplete
- AD-017 — entity_id + entity_type em tbl_suite

---

## AD-011: view_registry — DashBuilder Configurável

**Decisão:** Criar um `view_registry` como fonte de configuração de dashboards e painéis, seguindo o mesmo padrão do `form_registry`. Cada view é um schema JSON interpretado por um `ViewRenderer` que suporta múltiplos tipos de visualização.

### Contexto

O `WidgetRegistry` atual é hardcoded em código (`builtin/initializeWidgets.ts`). Para que módulos sejam configuráveis sem deploy, os dashboards precisam ser dados, não código.

### Análise

**Schema de exemplo:**

```json
{
  "id": "painel-ouvidoria",
  "titulo": "Painel de Ouvidoria",
  "perfis": ["atendente", "coordenador-ouvidoria"],
  "layout": "grid-2",
  "widgets": [
    {
      "id": "w1",
      "type": "kpi_card",
      "titulo": "Protocolos abertos",
      "dataSource": { "query": "suite_count_active", "filter": { "module_type": "ouvidoria" } }
    },
    {
      "id": "w2",
      "type": "record_list",
      "titulo": "Registros pendentes",
      "dataSource": { "query": "suite_active", "filter": { "module_type": "ouvidoria" } }
    },
    {
      "id": "w3",
      "type": "map_markers",
      "titulo": "Ocorrências no mapa",
      "dataSource": { "query": "suite_geolocated", "filter": { "module_type": "ouvidoria" } }
    }
  ]
}
```

**Tipos de visualização suportados:**

```
Registros:     record_view, record_list, record_timeline, record_diff
Quantitativos: kpi_card, bar_chart, line_chart, pie_chart, gauge, heatmap
Geoespaciais:  map_markers, map_clusters, map_route
Qualitativos:  checklist_summary, photo_gallery, status_board, text_feed
```

**Princípio dos dados quentes:** Widgets mostram apenas dados de ações ainda não finalizadas. O `empty_state` é tão importante quanto o dado — quando tudo está resolvido, o widget comunica isso explicitamente.

**Renderer tolerante:** Tipo desconhecido → fallback visual, nunca exceção. Mesmo princípio do `FieldFactory`.

**O registro é o rei:** O `ReadOnlyFormRenderer` é o tipo de visualização mais fundamental — antes de gráficos, o gestor precisa ler o que o operador registrou em campo. Gráficos e mapas são abstrações do registro, não o contrário.

### Escopo da Sprint 5 (restrição de viabilidade)

Construir todos os 16 tipos de widget simultaneamente é o principal risco desta AD. A implementação inicial se limita a quatro tipos que cobrem a maioria dos casos operacionais:

```
record_view    → ReadOnlyFormRenderer (já implementado na Sprint 3)
record_list    → lista paginada com filtro por module_type
kpi_card       → contagem de registros ativos com filtro
status_board   → quadro de status (aberto / em andamento / encerrado)
```

Tipos restantes (map_markers, bar_chart, line_chart, etc.) são adicionados apenas quando um módulo real os requisitar, não por antecipação.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Dashboards configuráveis sem deploy | ViewRenderer precisa ser construído |
| Sync distribui novos dashboards automaticamente | — |
| Mesmo padrão de incremento seguro do form_registry | — |
| empty_state explícito melhora UX operacional | — |

### Referências

- `action-widget-system.md` §3 — WidgetRegistry atual (embrião)
- `ui-flow.md` §3.9 — Dashboard atual
- AD-019 — ReadOnlyFormRenderer como base de visualização

---

## AD-012: decision_registry — DecisionBuilder Configurável

**Decisão:** Criar um `decision_registry` como fonte de configuração de fluxos de decisão, seguindo o mesmo padrão do `form_registry`. Cada decisão é um schema JSON com `targetType`, condições de visibilidade, steps de contexto e `consequence` que descreve o efeito no sistema.

### Contexto

O `ActionRegistry` atual é hardcoded em `builtin/*.actions.ts`. Para que módulos sejam configuráveis sem deploy e para que operadores possam ajustar fluxos de decisão conforme a operação evolui, as ações precisam ser dados.

### Análise

**Critério de migração para dados:**

> "Quem precisa mudar isso — desenvolvedor ou operador?"
>
> Operador → `decision_registry`
> Desenvolvedor (mudança estrutural) → código

**As sete ações universais identificadas:**

| Ação | Efeito no registro | Propriedade |
|---|---|---|
| **Aceitar** | `current → locked` | Permanece |
| **Rejeitar** | `current → closed` | Encerrada |
| **Devolver** | `current → refuted` | Volta à origem |
| **Reencaminhar** | `dispatched` + transfer | Transferência total |
| **Encaminhar** | `dispatched` + share | Origem mantém |
| **Solicitar** | novo `tbl_suite` com `ref_package_id` | Gera derivado |
| **Criar Tarefa** | nova `tbl_tarefas` com `tbl_suite_id` | Gera tarefa |

**Dois padrões fundamentais:**

```
Terminal:  Aceitar, Rejeitar, Devolver
           → encerram o ciclo de vida do registro

Gerador:   Reencaminhar, Encaminhar, Solicitar, Criar Tarefa
           → usam o registro como base para criar algo novo
```

**Schema de exemplo:**

```json
{
  "id": "decision-remocao-ecoponto",
  "targetType": "ecoponto",
  "perfis": ["gerente", "coordenador"],
  "enabledWhen": [{ "field": "ocupacaoMaxima", "operator": "gte", "value": 80 }],
  "steps": [
    { "id": "s1", "type": "record_view", "source": "latest_submission" },
    { "id": "s2", "type": "select_field", "label": "Setor de remoção", "dataSource": "setores_ativos" }
  ],
  "action": "encaminhar",
  "params": { "setor_destino": "setor-campo" },
  "consequence": { "type": "generator", "pattern": "derive", "creates": "task" }
}
```

**Coexistência com código:** Decisões hardcoded permanecem válidas para módulos estáveis. O `decision_registry` é opcional — usado onde o operador precisa configurar, não onde é suficiente o desenvolvedor decidir.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Fluxos de decisão ajustáveis sem deploy | DecisionBuilder precisa ser construído |
| Vocabulário de 7 ações cobre todos os casos | Handlers continuam em código |
| Sync distribui novos fluxos automaticamente | — |
| Auditoria em `action_log` é automática para qualquer ação | — |

### Referências

- `action-widget-system.md` §2 — ActionRegistry atual
- AD-018 — ActionBar com dois modos de interação
- AD-016 — Sete ações universais de decisão

---

## AD-013: ModuleBuilder — Quarto Builder Orquestrador

**Decisão:** Criar o **ModuleBuilder** como quarto builder que orquestra os outros três (FormBuilder, DashBuilder, DecisionBuilder), permitindo que administradores criem módulos operacionais completos através de um canvas de composição de blocos — sem código, sem deploy.

### Contexto

Com FormBuilder, DashBuilder e DecisionBuilder existindo separadamente, um administrador que queria criar um novo módulo precisaria configurar cada peça manualmente e sem visão do conjunto. O ModuleBuilder resolve isso unificando a experiência.

### Análise

**Analogia com WordPress:** Como o editor de blocos do WordPress recebe blocos ou templates para compor uma página, o ModuleBuilder recebe blocos para compor um módulo operacional.

**Blocos disponíveis:**

```
Estruturais:
  📋 Formulário     → FormBuilder (o que se registra)
  👥 Setor          → org_config (quem trabalha)
  ⚡ Decisões       → DecisionBuilder (o que se decide)
  📊 Dashboard      → DashBuilder (o que se visualiza)
  🔗 Vínculo        → entity_picker (entidades relacionadas)
  📁 Listas         → data_registry (assuntos, tipos, opções de seleção)

Fluxo:
  🔄 Andamento      → formulários intermediários
  📍 Roteamento     → assunto → setor destino automático
  ✅ Conclusão      → o que fecha o ciclo
```

**Templates de partida:**

```
📦 Módulo simples       → form único + decisões básicas
🔄 Módulo com fluxo     → abertura + andamentos + encerramento
📡 Módulo de campo      → ad_hoc + ghost task + mapa
🏛️ Módulo de atendimento → entity_picker + roteamento por assunto
```

**Ciclo de vida do módulo:**

```
rascunho → publicado → arquivado
```

Publicar dispara `org.config.atualizado` — o módulo aparece em todos os dispositivos no próximo ciclo de pull sem deploy ou reinicialização.

**Documento gerado pelo ModuleBuilder:**

```json
{
  "id": "modulo-fiscalizacao",
  "versao": 1,
  "blocos": {
    "setor":      { "id": "setor-fiscalizacao" },
    "formulario": { "form_slug": "auto_infracao", "ad_hoc": true },
    "decisoes":   { "actions": ["aceitar", "encaminhar", "criar_tarefa"] },
    "dashboard":  { "widgets": ["kpi_abertos", "map_ocorrencias"] }
  }
}
```

Armazenado em `module_registry` — nova tabela que sincroniza via `EventSyncAdapter` igual ao `form_registry`.

### Critério de entrada na Sprint 6

Esta AD é diferida para v2. Os pré-requisitos obrigatórios antes de iniciar:

1. `view_registry` (AD-011) estável em pelo menos um módulo real em produção
2. `decision_registry` (AD-012) estável em pelo menos um módulo real em produção
3. Equipe com capacidade dedicada para UX complexa — canvas de composição de blocos requer iteração longa com usuário administrador

Sem esses sinais, o risco de construir a abstração errada é alto. Editores no-code de composição são consistentemente subestimados: o editor de blocos do WordPress levou anos de iteração antes de ser funcional. O valor real da plataforma está nas Sprints 1-4; o ModuleBuilder é a cereja, não o bolo.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Admin cria módulos sem desenvolvimento | module_registry precisa ser implementado |
| Time de dev foca em plataforma, não módulos | Wizard de composição é UX complexo — risco alto |
| Novos processos em dias, não meses | JSON de configuração sem tipagem é difícil de debugar |
| Zero dependência de sprint para novos módulos | Requer AD-011 e AD-012 validados em produção |

### Referências

- AD-009 — EcoForms como plataforma
- AD-011 — view_registry
- AD-012 — decision_registry
- `action-widget-system.md` — padrões de registry existentes

---

## AD-014: Ouvidoria como Setor e module_type

**Decisão:** Eliminar o módulo dedicado de Ouvidoria. Protocolos, eventos e atendimentos passam a ser registros `tbl_suite` com `module_type = 'ouvidoria'`, operados pelo setor `setor-ouvidoria` no Kanban e na caixa de entrada padrão.

### Contexto

O módulo de Ouvidoria mantém 6 tabelas dedicadas, 13 use cases, 1 repository e hooks próprios — sem sync entre dispositivos. A análise revelou que toda sua funcionalidade já existe na infraestrutura genérica do sistema.

### Análise

**Mapeamento completo:**

```
Antes                          Depois
─────────────────────────────────────────────────────
tblProtocolo              →  tbl_suite (form abertura, ad_hoc: 1)
tblProtocoloEventos       →  tbl_suite (registros vinculados via ref_package_id)
Atendimento               →  tbl_suite (formulário de atendimento)
tblProtocoloAssunto       →  data_registry (tipo: 'ouvidoria_assuntos')
tblProtocoloSubtema       →  data_registry (tipo: 'ouvidoria_subtemas')
tblMensagens              →  data_registry (tipo: 'mensagens_template')
idProtocolo (YYYY-NNNN)   →  campo computado no SubmitSuiteUseCase
13 use cases              →  0 (SubmitSuiteUseCase + decision_registry)
OuvidoriaRepository       →  0 (SqliteSuiteRepository)
useOuvidoriaQueries       →  0 (useSolicitacoesList filtrado)
Sync: ❌ local-only        →  Sync: ✅ completo via EventSyncAdapter
```

**Roteamento automático por assunto:**

```json
{
  "type": "ouvidoria_assuntos",
  "items": [
    { "value": "coleta_irregular", "label": "Coleta Irregular", "setor_id": "setor-campo" },
    { "value": "nova_rota",        "label": "Nova Rota",         "setor_id": "setor-crm"   },
    { "value": "informacao",       "label": "Informação",        "setor_id": "setor-ouvidoria" }
  ]
}
```

O `SubmitSuiteUseCase` lê `setor_id` do assunto selecionado e cria a ghost task no setor correto automaticamente.

**Evento efêmero vs. persistente:**

```
ad_hoc: 0  → consulta/informação (resolve no ato, sem ghost task)
ad_hoc: 1  → solicitação/reclamação (gera tarefa para setor responsável)
```

**Migração:** Direta. Sem dados de produção, o módulo é refatorado in-place — tabelas legadas são dropadas e a lógica migra integralmente para `tbl_suite` + `data_registry`.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| -6 tabelas, -13 use cases, -1 repository, -hooks | — |
| Sync completo como subproduto | Geração do idProtocolo precisa de lógica no use case |
| Ouvidoria no mesmo Kanban dos demais setores | — |
| Formulários configuráveis no FormBuilder | — |

### Referências

- `modules.md` §3.7 — Ouvidoria Module atual
- `database.md` — tblProtocolo e tabelas relacionadas
- AD-009 — Plataforma de fluxos

---

## AD-015: CRM como Entity Registry da Plataforma

**Decisão:** Separar o CRM em duas camadas distintas: (1) **Entity Registry** — `tblPJuridicas`, `tblPFisicas`, `tblContatos` permanecem como infraestrutura de plataforma referenciada por todos os módulos; (2) **Módulo Coletas** — `tblColetas` e `tblDetalhesSatelite` migram para `tbl_suite` como módulo operacional configurável.

### Contexto

O CRM tinha duas responsabilidades diferentes tratadas como um único módulo: cadastro de entidades do mundo real (clientes, cooperativas, catadores) e registro de operações de campo (coletas, detalhes).

### Análise

**Catadores e Cooperativas no Entity Registry:**

```
tblPJuridicas + tblPJtipo:
  tipo: 'cliente_residencial'
  tipo: 'cliente_comercial'
  tipo: 'cooperativa'         ← novo tipo via data_registry
  tipo: 'galpao_triagem'      ← novo tipo via data_registry

tblPFisicas + tblContatos:
  TipoContato: 'responsavel'
  TipoContato: 'cooperado'    ← catador vinculado à cooperativa
  TipoContato: 'gestor_galpao'
```

Zero tabelas novas. Cooperativa é uma PJ. Catador é uma PF vinculada via `tblContatos`.

**Módulo Coletas:**

```
tblColetas + tblDetalhesSatelite  →  tbl_suite
  module_type:  'coleta'
  entity_id:    idPJ (cliente)
  entity_type:  'pj'
  payload_json: { idRoteiro, data, contentores, problema, rejeito }

tblRoteiros  →  data_registry
  tipo: 'roteiros'

tblRotas     →  campo no formulário (entity_picker + roteiro selecionado)
```

**Sync do CRM:**

```
Antes: ❌ local-only (coletas não sincronizam)
Depois: ✅ completo (tbl_suite sincroniza via EventSyncAdapter)
```

**Chamadas de catadores:** Seguem o mesmo padrão dos roteiros de clientes. Uma chamada é um registro `tbl_suite` com `module_type = 'chamada_catador'` e `entity_id = idPF` do catador.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Catadores e cooperativas sem código novo | — |
| Coletas com sync completo | — |
| Histórico de coletas por cliente via entity_id | — |
| Chamadas de catadores como módulo configurável | — |

### Referências

- `database.md` — tblPJuridicas, tblPFisicas, tblRoteiros, tblColetas
- `modules.md` §3.3, §3.6 — Client e CRM modules
- AD-010 — Entity Registry
- AD-017 — entity_id + entity_type em tbl_suite

---

## AD-016: Sete Ações Universais de Decisão

**Decisão:** Formalizar um vocabulário de **sete ações universais** que cobrem todos os pontos de decisão do sistema, independente de módulo ou contexto. Cada ação tem semântica clara sobre o efeito no registro e na propriedade.

### Análise

| Ação | Status resultante | Padrão | Propriedade |
|---|---|---|---|
| **Aceitar** | `locked` | Terminal | Permanece |
| **Rejeitar** | `closed` | Terminal | Encerrada |
| **Devolver** | `refuted` | Terminal | Volta à origem |
| **Reencaminhar** | `dispatched` + transfer | Gerador | Transferência total |
| **Encaminhar** | `dispatched` + share | Gerador | Origem mantém |
| **Solicitar** | novo `tbl_suite` | Gerador | Gera derivado |
| **Criar Tarefa** | nova `tbl_tarefas` | Gerador | Gera tarefa |

**Gaps na máquina de estados atual identificados:**

1. `closed` não tem transição direta a partir de `current` — só via `dispatched`
2. `dispatched` não distingue transferência de compartilhamento — resolver com `transfer_type` em `tbl_suite_historico`
3. Solicitar e Criar Tarefa não transitam o status — o registro permanece `current` e gera derivado via `ref_package_id`

**Dois novos eventos de domínio necessários:**

```
demanda.encaminhada    → compartilhamento (origem mantém propriedade)
demanda.reencaminhada  → transferência (origem perde propriedade)
```

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Vocabulário único para todos os módulos | Três gaps na máquina de estados precisam ser corrigidos |
| decision_registry usa as mesmas 7 ações | Dois novos eventos precisam de handlers |
| UI consistente em qualquer contexto | — |

### Referências

- `database.md` — Status machine de tbl_suite
- `action-widget-system.md` §2.4 — Ações built-in atuais
- `event-protocol.md` — Tipos de evento registrados
- AD-024 — Encaminhar e Reencaminhar como novos eventos

---

## AD-017: entity_id + entity_type em tbl_suite

**Decisão:** Adicionar colunas `entity_id` e `entity_type` em `tbl_suite` para vincular registros a entidades do Entity Registry de forma indexável — sem `JSON_EXTRACT` no `payload_json`.

### Contexto

Para queries como "todos os protocolos de um cidadão" ou "todas as coletas de um cliente", o sistema precisaria de `JSON_EXTRACT(payload_json, '$.solicitante_id')` — lento e não indexável. As colunas dedicadas resolvem isso.

### Análise

**Migration:**

```sql
ALTER TABLE tbl_suite ADD COLUMN entity_id   TEXT;
ALTER TABLE tbl_suite ADD COLUMN entity_type TEXT;
-- 'pj' | 'pf' | 'ecoponto' | null

CREATE INDEX idx_suite_entity ON tbl_suite(entity_type, entity_id);
```

**Preenchimento automático:** O `SubmitSuiteUseCase` lê o campo `entity_picker` do payload (quando presente) e popula `entity_id` e `entity_type` automaticamente. Não requer mudança nos formulários existentes.

**Queries habilitadas:**

```sql
-- Todos os protocolos de um cidadão
SELECT * FROM tbl_suite
WHERE entity_id = 'pf-uuid-001' AND module_type = 'ouvidoria'

-- Histórico completo de um cliente (coletas + ouvidoria)
SELECT * FROM tbl_suite
WHERE entity_id = 'pj-uuid-042' AND is_current = 1
ORDER BY created_at DESC
```

**correlation_id no envelope:** Todos os eventos subsequentes a um registro carregam o mesmo `correlation_id`. `entity_id` + `correlation_id` juntos permitem rastrear o ciclo completo de qualquer caso, do atendimento inicial à resolução.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Queries eficientes por entidade | Migration necessária em tbl_suite |
| Padrão genérico para todos os módulos | SubmitSuiteUseCase precisa de lógica de preenchimento |
| Histórico unificado por entidade sem JSON_EXTRACT | — |

### Referências

- `database.md` — tbl_suite schema atual
- `api-contract.md` §1.2 — SubmitSuiteUseCase
- AD-010 — Entity Registry

---

## AD-018: ActionBar com Dois Modos de Interação

**Decisão:** O `ActionBar` passa a suportar dois modos distintos de interação baseados na natureza da decisão: **confirmação** (mini-modal sobre o contexto) e **decisão** (painel expandido que mantém o contexto visível).

### Contexto

Hoje o `ActionBar` trata todos os tipos de ação com `requiresInput` (mini-modal), cobrindo o contexto que o usuário precisa ver para decidir. Ações como "Encaminhar para Setor" e "Reencaminhar" exigem que o gestor avalie registros, histórico e dados antes de agir.

### Análise

**Dois tipos de ação identificados:**

```
Ação de confirmação:
  Usuário já sabe o que fazer, precisa confirmar
  Exemplos: Aprovar, Rejeitar
  UI: mini-modal flutua sobre o contexto (context pode sumir)
  Config: confirmationRequired ou requiresInput (existente)

Ação de decisão:
  Usuário precisa avaliar antes de agir
  Exemplos: Encaminhar, Reencaminhar
  UI: painel desliza dentro do modal, mantendo contexto visível
  Config: expandPanel (novo)
```

**Extensão do ActionButtonConfig:**

```typescript
interface ActionButtonConfig {
  // ...existente
  requiresInput?: { fields: FormFieldConfig[] }  // confirmação
  expandPanel?: {                                  // decisão
    panel: string         // 'encaminhar' | 'reencaminhar'
    queryParam?: string   // para rota de página completa
  }
}
```

**Sinalização visual:** Botões de decisão exibem chevron `›` indicando expansão. Botões de confirmação não exibem chevron.

**Integração com página completa (AD-023):** Ações de decisão podem alternativamente navegar para `/tarefas/[id]?action=encaminhar`, onde o contexto completo está disponível em layout de duas colunas.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Contexto visível durante decisões complexas | ActionBar.tsx precisa suportar novo modo |
| UX mais adequada para cada tipo de ação | — |
| Painel de decisão pode mostrar registros que embasam a decisão | — |

### Referências

- `action-widget-system.md` §4.1 — ActionBar atual
- `ui-flow.md` §3.1 — TaskDialog atual
- AD-023 — Página de tarefa como evolução do modal

---

## AD-019: ReadOnlyFormRenderer como Base de Visualização

**Decisão:** O `ReadOnlyFormRenderer` — que usa `form_registry.conteudo` como schema e `tbl_suite.payload_json` como valores — é a visualização primária de qualquer registro. Gráficos, mapas e tabelas são abstrações do registro; o registro é a fonte.

### Contexto

O modal da tarefa exibia `payload_json` como JSON bruto, tornando registros ilegíveis. A solução natural — usar o schema do formulário para renderizar os valores com labels corretos — revelou que o mesmo mecanismo serve como tipo de visualização no `view_registry`.

### Análise

**Interface:**

```typescript
interface ReadOnlyFormRendererProps {
  schema: FormContent                    // form_registry.conteudo
  values: Record<string, unknown>        // tbl_suite.payload_json
  formSnapshot?: FormContent             // tbl_tarefa_formularios.form_snapshot (prioridade)
}
```

**Mapa de renderização por tipo:**

```
text, textarea, email     → texto simples
date, time               → formatado pt-BR
select, radio            → label da opção (não o value bruto)
checkbox                 → Sim / Não
chips                    → tags em linha
camera, photo            → thumbnail com link
geolocation, gps         → coordenadas + link Google Maps
group                    → bloco indentado com subcampos
repeatable_group         → mini-tabela colapsável
checklist               → lista com status marcado/não marcado
hidden                   → não renderiza
```

**Prioridade do schema:** `form_snapshot` em `tbl_tarefa_formularios` tem prioridade sobre `form_registry.conteudo` atual — garante fidelidade histórica. O formulário é renderizado como estava quando foi preenchido, não como está hoje.

**Incremento seguro:** Tipos novos adicionados ao `FieldFactory` ficam automaticamente disponíveis no `ReadOnlyFormRenderer`. Registros antigos com tipos que não existem mais exibem fallback — nunca quebram.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Qualquer formulário renderizável sem código por tipo | ReadOnlyFormRenderer precisa ser implementado |
| Novos tipos de campo funcionam automaticamente | — |
| Base para record_view no view_registry | — |
| Fidelidade histórica via form_snapshot | — |

### Referências

- `fields.md` — todos os tipos de campo documentados
- `form-builder.md` — FieldFactory e FormRenderer
- `database.md` — tbl_suite, form_registry, tbl_tarefa_formularios
- AD-011 — view_registry

---

## AD-020: dataSource do CRM para Campos de Formulário

**Decisão:** Registrar resolvers no `smartCache` que expõem entidades do Entity Registry como fontes `dataSource` para qualquer campo de formulário. O mecanismo é idêntico ao `data_registry` — a fonte muda, o pipeline permanece.

### Contexto

O `PresenceField` carregava catadores de um arquivo JSON estático (`catadores.json`), desatualizado a cada alteração no cadastro. A solução natural é conectar diretamente ao `tblPFisicas` via CRM.

### Análise

**Resolvers a registrar no boot:**

```typescript
smartCache.registerResolver('catadores_crm', async () =>
  db.query(`SELECT pf.idPF AS id, pf.Nome AS nome, pj.Cliente AS nome_galpao
            FROM tblPFisicas pf
            JOIN tblContatos c ON c.idPF = pf.idPF
            JOIN tblPJuridicas pj ON pj.idPJ = c.idPJ
            WHERE c.TipoContato = 'cooperado'`));

smartCache.registerResolver('galpoes_crm', async () =>
  db.query(`SELECT idPJ AS id, Cliente AS nome FROM tblPJuridicas
            WHERE idPJtipo = 'galpao_triagem' AND ativo = 1`));

smartCache.registerResolver('clientes_crm', async () =>
  db.query(`SELECT idPJ AS id, Cliente AS nome FROM tblPJuridicas
            WHERE ativo = 1`));

smartCache.registerResolver('cooperativas_crm', async () =>
  db.query(`SELECT idPJ AS id, Cliente AS nome FROM tblPJuridicas
            WHERE idPJtipo = 'cooperativa' AND ativo = 1`));

smartCache.registerResolver('setores_ativos', async () =>
  db.query(`SELECT id, nome FROM tbl_setores WHERE ativo = 1`));
```

**Funcionamento:**

```
enrichFormWithData() encontra dataSource: 'catadores_crm'
  → smartCache.loadDataSource('catadores_crm')
  → resolver registrado executa query
  → campo._loadedData = [{ id, nome, nome_galpao }]
  → PresenceField recebe participantes atualizados
```

**Atualização automática:** Catador cadastrado hoje aparece na lista de presença amanhã. Catador desativado some na próxima abertura do formulário. Zero manutenção de JSON.

**Generalização:** O admin digita `catadores_crm` no campo `dataSource` do FormBuilder — qualquer formulário passa a ter acesso à lista de catadores sem código adicional.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Lista de presença sempre sincronizada com cadastro | Resolvers precisam ser registrados no boot |
| Qualquer campo pode usar entidades do CRM | — |
| Mesmo mecanismo do data_registry — zero aprendizado | — |
| Admin configura no FormBuilder sem código | — |

### Referências

- `form-builder.md` — enrichFormWithData(), smartCache
- `fields.md` §15 — PresenceField, groupField, hideUntilGroup
- AD-010 — Entity Registry

---

## AD-021: Gap Recovery Automático no Sync

**Decisão:** Implementar recovery automático de gaps de sequência no `InboundService`, usando listagem direta dos arquivos `.enc` no Storage em vez de intervenção manual. Máximo de 3 tentativas por gap antes de marcar como irrecuperável.

### Contexto

O `event-protocol.md` documenta explicitamente: "Gap de sequência detectado → requer intervenção manual". Em ambiente offline-first de campo, gaps são comuns (upload parcial, perda de conectividade). Parar o sync de um setor inteiro é inaceitável operacionalmente.

### Análise

**Nova tabela:**

```sql
CREATE TABLE IF NOT EXISTS sync_gap_log (
  id          TEXT PRIMARY KEY,
  routing_id  TEXT NOT NULL,
  missing_seq INTEGER NOT NULL,
  detected_at TEXT NOT NULL,
  resolved_at TEXT,
  status      TEXT DEFAULT 'pending',
  attempts    INTEGER DEFAULT 0,
  UNIQUE(routing_id, missing_seq)
);
```

**Algoritmo:**

```
Gap detectado: seq esperado = 3, recebido = 5
  ↓
Para cada seq faltante (3, 4):
  ├── Listar arquivos em orgs/{orgId}/eventos/{routingId}/ (com fallback para path legado eventos/{routingId}/)
  ├── Buscar arquivo com nome evt_{seq}_*.enc
  ├── Se encontrado: baixar, descriptografar, dispatch
  ├── Se não encontrado: incrementar attempts
  └── Se attempts > 3: marcar como 'unresolvable', continuar sem bloquear
```

**Por que funciona:** O seq está embutido no nome do arquivo (`evt_{seq}_{id}.enc`). Handlers são idempotentes (`INSERT OR IGNORE`). Processar fora de ordem não corrompe dados — gera estado temporariamente incompleto até o gap ser resolvido.

**Escopo:** SQLite local do desktop. Não tem equivalente no mobile (IndexedDB) — seria implementado separadamente se necessário.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Sync não para por gap de sequência | Lógica de recovery adiciona ~80 linhas |
| Gap log permite diagnóstico de problemas de rede | Gap irrecuperável pode causar estado incompleto temporário |
| Compatível com handlers idempotentes existentes | — |

### Referências

- `event-protocol.md` — Gap detection atual
- `data-system.md` §4 — InboundService
- `database.md` — sync_event_queue, sync_device_log

---

## AD-022: Salt PBKDF2 por Usuário

**Decisão:** Substituir o salt PBKDF2 fixo e hardcoded (`"ecoforms-sync-salt-v1"`) por um salt aleatório de 32 bytes gerado por usuário, armazenado em `tbl_usuarios.sync_salt`.

### Contexto

O salt fixo elimina a proteção contra ataques de dicionário pré-computados. Com salt fixo, a mesma senha gera a mesma chave para todos os usuários — um atacante com o salt (que está no código-fonte) pode atacar todos os usuários com o mesmo dicionário.

### Análise

**Migration retroativa:**

```sql
ALTER TABLE tbl_usuarios ADD COLUMN sync_salt TEXT;
UPDATE tbl_usuarios
SET sync_salt = lower(hex(randomblob(32)))
WHERE sync_salt IS NULL;
```

**Geração em Rust (novo usuário):**

```rust
let salt: [u8; 32] = rand::thread_rng().gen();
let sync_salt = hex::encode(salt);
```

**Derivação no login:**

```typescript
const { sync_salt } = await db.get(
  'SELECT sync_salt FROM tbl_usuarios WHERE id = ?', [user.id]
);
await cryptoLayer.deriveAndStoreKey(password, sync_salt);
```

**Requer API estendida:** `CryptoLayer.deriveAndStoreKey()` atualmente só aceita `password`. Precisa ser estendido para aceitar parâmetro `salt` opcional. Quando `salt` é fornecido, usa-o na derivação PBKDF2 em vez do salt fixo `"ecoforms-sync-salt-v1"`.

**Por que funciona offline:** O salt não é secret — só garante unicidade por usuário. Armazenado em `tbl_usuarios` local, disponível sem conexão. A migration retroativa garante que usuários existentes recebem salt automático na próxima execução do `ensureColumns()`.

**Sem eventos criptografados em produção, a migration é limpa — todos os eventos usarão o novo salt desde o primeiro push.**

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Ataque de dicionário pré-computado eliminado | Migration necessária em tbl_usuarios |
| Funciona 100% offline | — |
| Mudança cirúrgica — ~20 linhas | — |
| Nenhuma dependência de Supabase | — |

### Referências

- `event-protocol.md` — PBKDF2 Key Derivation atual
- `data-system.md` §4 — CryptoLayer
- `database.md` — tbl_usuarios

---

## AD-023: Página de Tarefa como Evolução do Modal

**Decisão:** Criar a rota `/tarefas/[id]` como página completa de tarefa, coexistindo com o modal existente. O modal continua como entrada rápida pelo Kanban; a página serve para trabalho detalhado e decisões que exigem contexto completo.

### Contexto

O modal do Kanban tem espaço restrito e exibe conteúdo em abas, forçando o usuário a alternar entre contexto e ação. Ações de decisão (encaminhar, reencaminhar) precisam de contexto visível enquanto a decisão é tomada.

### Análise

**Três camadas de profundidade:**

```
Card (hover)      → contexto mínimo, sem clique
Modal (clique)    → contexto médio, abas, 80% dos casos
Página (/tarefas/[id]) → contexto total, duas colunas, 20% dos casos
```

**Layout da página:**

```
Coluna esquerda (60%)         Coluna direita (40%)
──────────────────────        ──────────────────
Breadcrumb completo           Histórico contínuo (scroll)
Metadados                     Comentários no rodapé
Formulários vinculados        ActionBar fixo no rodapé
ReadOnlyFormRenderer inline
Registros enviados
Anexos
```

**Navegação de volta:** Breadcrumb usa `tbl_tarefas.projeto_id` para reconstruir o caminho. `router.back()` funciona se veio do modal.

**Convergência com view_registry:** A página de tarefa é uma instância do `view_registry` — o mesmo schema que configura o painel da ouvidoria configura o layout da página de tarefa de vistoria de Ecoponto. O layout de duas colunas, as seções e os widgets são configuráveis por `module_type`.

**Acesso:** Link `[⤢ Abrir página completa]` no rodapé do modal.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Contexto completo para decisões complexas | Nova rota para implementar |
| Modal continua para casos simples | Breadcrumb precisa de lógica de reconstituição |
| Mesmos hooks — zero duplicação de lógica | — |
| ReadOnlyFormRenderer inline (sem drawer) | — |

### Referências

- `ui-flow.md` §3.1 — TaskDialog atual
- AD-018 — ActionBar com dois modos
- AD-011 — view_registry
- AD-019 — ReadOnlyFormRenderer

---

## AD-024: Encaminhar e Reencaminhar como Novos Eventos de Domínio

**Decisão:** Adicionar `demanda.encaminhada` e `demanda.reencaminhada` ao union type `EcoFormsEventType`, com handlers dedicados que copiam `tbl_suite` para o setor destino e criam ghost task via `ensureRetroactiveTask()`.

### Contexto

A ação `encaminhar_para_setor` publicava `demanda.criada` — evento genérico que não carregava o registro original nem distinguia compartilhamento de transferência. Reencaminhar não tinha evento próprio.

### Análise

**Semântica distinta:**

```
demanda.encaminhada    → compartilhamento (share)
  origem mantém propriedade
  destino recebe cópia com ref_package_id
  status origem: dispatched
  status destino: current (novo dono pode trabalhar)

demanda.reencaminhada  → transferência completa (transfer)
  origem perde propriedade
  destino recebe registro com mesmo package_id
  motivo obrigatório (rastreabilidade)
  histórico de encaminhamentos visível no painel de decisão
```

**Payload dos eventos:**

```typescript
// demanda.encaminhada
{
  demandaId, packageId,
  setorOrigem, setorDestino,
  instrucoes?: string
}

// demanda.reencaminhada
{
  demandaId,   packageId: string,                // registro sendo transferido
  setorOrigem, setorDestino,
  motivo: string,                     // obrigatório
  historicoEncaminhamentos: Array<{ de, para, data }>
}
```

**Handler no setor destino:**

```
demanda.encaminhada recebido:
  1. INSERT tbl_suite (cópia com ref_package_id = packageId original)
  2. ensureRetroactiveTask() → ghost task no setor destino
  3. task herda titulo, setor_id = setorDestino, tbl_suite_id

demanda.reencaminhada recebido:
  1. Copia tbl_suite para o setor destino com ref_package_id preservado
  2. ensureRetroactiveTask() com histórico no payload da tarefa
```

**`ref_package_id` como trilha de auditoria:** P2 referencia P1, P3 referencia P2. Qualquer setor pode reconstituir a história completa do caso via cadeia de `ref_package_id`.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Semântica clara entre compartilhamento e transferência | Dois novos eventos + handlers |
| Registro acompanha o encaminhamento | `encaminhar_para_setor` precisa ser atualizado |
| Histórico completo reconstituível via ref_package_id | — |
| Sync distribui registros junto com a demanda | — |

### Referências

- `event-protocol.md` — EcoFormsEventType atual
- `data-system.md` §4 — HandlerRegistry
- `action-widget-system.md` §2.6 — Eventos publicados atuais
- AD-016 — Sete ações universais

---

## Resumo das Decisões

| Sprint | AD | Decisão | Risco | Esforço |
|--------|----|---------|-------|---------|
| 1 ✅ | AD-022 | Salt PBKDF2 por usuário | Baixo | `deriveAndStoreKey(password, userSalt?)`, migration sync_salt, AuthContext |
| 1 ✅ | AD-017 | entity_id + entity_type em tbl_suite | Baixo | Colunas + idx_suite_entity + SubmitSuiteUseCase |
| 1 ✅ | AD-021 | Gap recovery automático no sync | Baixo | sync_gap_log, attemptGapRecovery(), MAX_GAP_ATTEMPTS=3 |
| 2 ✅ | AD-014 | Ouvidoria como setor e module_type | Baixo | useOuvidoriaQueries lê tbl_suite WHERE module_type='ouvidoria'; seed 14 entradas data_registry (assuntos, subtemas, mensagens_template) |
| 2 ✅ | AD-015 | CRM como Entity Registry + Módulo Coletas | Baixo | useColetaMutations().registerColeta() grava tbl_suite module_type='coleta' + entity_id=idPJ; handler crm.coleta.registrada |
| 2 ✅ | AD-020 | dataSource do CRM para campos de formulário | Baixo | 5 resolvers em crm-datasources.ts, registerCrmDataSources() no boot |
| 3 ✅ | AD-019 | ReadOnlyFormRenderer como base de visualização | Baixo | ReadOnlyFormRenderer.tsx, 10+ tipos, formSnapshot com prioridade |
| 3 ✅ | AD-018 | ActionBar com dois modos de interação | Baixo | expandPanel? em ActionButtonConfig, chevron ›, redirect queryParam |
| 3 ✅ | AD-023 | Página de tarefa /tarefas/[id] | Médio | Layout duas colunas, integrado ao ActionBar via queryParam |
| 4 ✅ | AD-016 | Sete ações universais de decisão | Médio | UNIVERSAL_ACTIONS com 7 canônicas; current→closed; transfer_type |
| 4 ✅ | AD-024 | Encaminhar e Reencaminhar como eventos | Médio | demanda.encaminhada + demanda.reencaminhada no EventEnvelope + handlers |
| 5 ✅ | AD-010 | Entity Registry como camada de infraestrutura | Médio | EntityPickerRenderer + 3 resolvers (clientes_crm, pessoas_fisicas_crm, ecopontos_crm); config.entityType→dataSource; ReadOnlyFormRenderer badge |
| 5 | AD-011 | view_registry — DashBuilder (4 tipos iniciais) | Médio | ViewRenderer + 4 widgets |
| 5 | AD-012 | decision_registry — DecisionBuilder | Médio | DecisionBuilder + handlers |
| 6 (v2) | AD-013 | ModuleBuilder — quarto builder orquestrador | **Alto** | Canvas no-code complexo |
| ref. | AD-009 | EcoForms como plataforma de fluxos | — | Visão, sem implementação direta |

---

## Sequência de Implementação por Sprint

A ordem é determinada por: (1) pré-requisitos técnicos, (2) risco, (3) valor entregue ao usuário.

```
Sprint 1 — Fundação (sem risco, alto valor imediato)
  AD-022  CryptoLayer.deriveAndStoreKey(password, salt?)
          ├── migration: ALTER TABLE tbl_usuarios ADD COLUMN sync_salt TEXT
          └── ~20 linhas

  AD-017  entity_id + entity_type em tbl_suite
          ├── 2x ALTER TABLE + CREATE INDEX
          └── SubmitSuiteUseCase: extrai entity_picker do payload

  AD-021  InboundService: gap recovery automático
          ├── nova tabela sync_gap_log
          ├── lista arquivos no Storage pelo nome (evt_{seq}_*.enc)
          └── máx. 3 tentativas → 'unresolvable', sem bloquear

Sprint 2 — Refatoração de módulos (elimina legado, libera sync)
  AD-017 (pré-req.) ─┬─ AD-014  Ouvidoria → tbl_suite
                     │          ├── drop: tblProtocolo, tblProtocoloEventos,
                     │          │        tblProtocoloAssunto, tblProtocoloSubtema,
                     │          │        Atendimento, tblMensagens, tblSetor (legado)
                     │          └── data_registry: ouvidoria_assuntos, subtemas
                     │
                     ├─ AD-015  CRM → Entity Registry + Módulo Coletas
                     │          ├── tblPJuridicas: + tipo 'cooperativa', 'galpao_triagem'
                     │          ├── tblContatos: + TipoContato 'cooperado'
                     │          └── tblColetas → tbl_suite (module_type: 'coleta')
                     │
                     └─ AD-020  smartCache resolvers (CRM → dataSource)
                                ├── catadores_crm, galpoes_crm, clientes_crm
                                ├── cooperativas_crm, setores_ativos
                                └── ~50 linhas no boot

Sprint 3 — UX e visualização
  AD-019  ReadOnlyFormRenderer                    ← desbloqueia AD-011, AD-023
          ├── schema: form_registry.conteudo
          ├── values: tbl_suite.payload_json
          ├── prioridade: form_snapshot > form_registry atual
          └── 12 tipos de campo mapeados (hidden não renderiza)

  AD-018  ActionBar: modo confirmação + modo decisão
          ├── ActionButtonConfig + expandPanel?: { panel, queryParam? }
          └── sinal visual: chevron › em botões de decisão

  AD-023  Rota /tarefas/[id] — página completa
          ├── layout duas colunas (60% contexto / 40% histórico+ação)
          └── link "Abrir página completa" no rodapé do modal existente

Sprint 4 — Ações universais
  AD-016  Sete ações — corrigir state machine
          ├── closed: transição direta a partir de current (Rejeitar)
          ├── dispatched: distinguir transfer vs. share via transfer_type
          └── Solicitar/Criar Tarefa: não transitam status, geram derivado

  AD-024  demanda.encaminhada + demanda.reencaminhada
          ├── handler encaminhada: INSERT cópia + ref_package_id + ghost task
          └── handler reencaminhada: preserva package_id + histórico no payload

Sprint 5 — Builders (após validar sprints 1-4)
  AD-010  Entity Registry formalizado ✅
          ├── EntityPickerRenderer: busca textual + dropdown, config.entityType→dataSource
          ├── ReadOnlyFormRenderer: case "entity_picker" com badge monoespaçado
          ├── Resolvers adicionados: pessoas_fisicas_crm, ecopontos_crm (+ 2 em AD-020)
          └── 3 tipos suportados: pj → clientes_crm, pf → pessoas_fisicas_crm, ecoponto → ecopontos_crm

  AD-011  view_registry — 4 tipos iniciais (escopo reduzido)
          ├── record_view      → ReadOnlyFormRenderer
          ├── record_list      → lista paginada de registros
          ├── kpi_card         → contagem com filtro
          └── status_board     → quadro por status
          (tipos restantes — map_markers, bar_chart, etc. — adicionados sob demanda)

  AD-012  decision_registry
          └── DecisionBuilder: targetType + enabledWhen + steps + consequence

Sprint 6 — Plataforma v2 (diferir; avaliar após Sprint 5)
  AD-013  ModuleBuilder
          ├── RISCO ALTO: editores no-code de composição são consistentemente
          │   subestimados — o WordPress levou anos para ter o Block Editor
          ├── Sprints 1-4 entregam o valor real; AD-013 é a cereja, não o bolo
          └── Pré-requisito obrigatório: AD-011 e AD-012 estáveis em produção
```

**Regra de escopo para AD-011:** Não construir todos os 16 tipos de widget na Sprint 5. Começar com os 4 listados acima e expandir conforme demanda real, não antecipada.

**Critério de avanço para Sprint 6:** AD-013 só começa quando AD-011 e AD-012 tiverem sido usados por pelo menos um módulo real em produção. Sem esse sinal, o risco de construir a abstração errada é alto.
