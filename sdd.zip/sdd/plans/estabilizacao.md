# Plano de Estabilização — ecoformsnext

> Derivado de `docs/confidence-report.md` — Recomendações (linhas 71-76)
> Data: 2026-04-30

---

## Contexto

O `confidence-report.md` identificou **5 recomendações** que não foram cobertas por nenhum dos planos existentes (`limpeza-legado.md`, `implementacao-fases-3-6.md`, `adr-evolucao-plataforma.md`). Estas recomendações são pré-condições para que as fases 3-6 do ADR possam ser implementadas com segurança.

---

## EC-01: Testes para AuthManager e DataService

**Prioridade:** 🔴 Crítica — 3.900 linhas sem cobertura
**Confiança atual:** `sdd/auth-mobile.md` 92%, `sdd/data-service.md` 92% — mas sem testes automatizados, essa confiança é teórica.

### AuthManager (1520 linhas)

| Cenário | Tipo |
|---|---|
| Login com Supabase Auth (online, credenciais válidas) | Integração |
| Login com fallback JSON local (offline) | Unitário |
| Session heartbeat — renova após >60s de inatividade | Unitário |
| Sessão expirada — redireciona para login | Unitário |
| Sincronização periódica de usuários | Unitário |
| Carregamento de sessão do localStorage | Unitário |
| Logout limpa sessão e heartbeat | Unitário |

**Setup:** `happy-dom` + mock do `globalSupabaseClient` + mock do `localStorage` + mock do `fetch` para `usuarios.json`.

### DataService (2378 linhas)

| Cenário | Tipo |
|---|---|
| Salvar submissão no IndexedDB (formSubmissions v3) | Unitário |
| Deduplicação por UUID (mesmo UUID → ignora) | Unitário |
| Sync lock — segundo sync aguarda primeiro | Unitário |
| Compressão de imagem (>1MB → qualidade 0.8, max 1920px) | Unitário |
| Upload para Supabase tbl_suite | Integração |
| Falha de rede — submissão permanece na fila | Unitário |
| Reconexão — sync automático da fila | Unitário |

**Setup:** `fake-indexeddb` + mock do Supabase client.

### Tarefas

- [ ] Criar `tests/auth-manager.test.js` — 7 cenários
- [ ] Criar `tests/data-service.test.js` — 7 cenários
- [ ] Adicionar `fake-indexeddb` ao `package.json` (devDependency)
- [ ] Rodar `npm run test:coverage` — meta: >70% em ambos
- [ ] Atualizar `confidence-report.md`: 92% → confirmado com testes

---

## EC-02: Rate Limiting e Expurgo no Sync

**Prioridade:** 🟠 Alta — risco de acúmulo e rejeição
**Confiança atual:** `sdd/sync.md` 80% (1 🔴: rate limiting)

### Rate Limiting

**Problema:** `TransportService` envia rajadas ao Supabase Storage sem controle de taxa.

**Solução:** Adicionar throttle configurável no `TransportService`:

```typescript
// TransportService.ts — novo campo
private rateLimiter = new RateLimiter({
  maxRequests: 10,     // 10 uploads por janela
  windowMs: 60_000,    // janela de 1 minuto
  strategy: 'queue'    // enfileirar, não descartar
});
```

### Expurgo de Eventos

**Problema:** `tbl_suite` e `sync_event_queue` acumulam registros indefinidamente.

**Solução:** Adicionar política de retenção:

| Entidade | Política | Gatilho |
|---|---|---|
| `sync_event_queue` | Deletar eventos com `processed_at > 30 dias` | Diário, no startup |
| `tbl_suite` (status `closed`/`superseded`) | Arquivar após 90 dias | Semanal |
| `sync_gap_log` | Deletar `resolved` após 7 dias | Diário |

```typescript
// Novo: RetentionService.ts
class RetentionService {
  async purgeOldEvents(): Promise<void> {
    await this.db.execute(
      `DELETE FROM sync_event_queue WHERE processed_at < ?`,
      [thirtyDaysAgo]
    );
  }
}
```

### Tarefas

- [ ] Criar `RateLimiter` no `TransportService.ts` — ~30 linhas
- [ ] Criar `RetentionService.ts` com 3 políticas — ~60 linhas
- [ ] Wire `RetentionService.purgeOldEvents()` no startup
- [ ] Testes: throttle não perde eventos (enfileira), expurgo não remove eventos ativos
- [ ] Atualizar `sdd/sync.md`: 🔴 rate limiting → 🟢

---

## EC-03: Reativação de Cliente (toggleActive)

**Prioridade:** 🟡 Média — funcionalidade planejada, não implementada
**Confiança atual:** `sdd/client.md` 90%

**Problema:** `Client.toggleActive()` existe no domínio mas não há use case exposto nem rota na UI.

**Solução:** Criar `ToggleClientActiveUseCase` e expor no `useClientMutations`:

```typescript
// application/client/ToggleClientActiveUseCase.ts
class ToggleClientActiveUseCase {
  async execute(idPJ: number): Promise<ClientDto> {
    const client = await this.repo.findById(idPJ);
    if (!client) throw new NotFoundError('Client', String(idPJ));
    client.toggleActive();
    await this.repo.save(client);
    return toClientDto(client);
  }
}
```

### Tarefas

- [ ] Criar `ToggleClientActiveUseCase.ts`
- [ ] Adicionar ao `container.ts` → `clients.toggleActive`
- [ ] Expor no `useClientMutations`: `toggleActive(idPJ)`
- [ ] Adicionar botão "Reativar" / "Inativar" na UI de cliente
- [ ] Atualizar `sdd/client.md`: 🟡 reativação → 🟢

---

## EC-04: Migração de IDs (Date.now → UUID)

**Prioridade:** 🟡 Média — débito técnico reconhecido
**Confiança atual:** `domain.md` 75% (1 🔴: IDs inconsistentes)

**Problema:** `Client` usa `Date.now()` como ID. `Task`, `Demanda`, `Suite` usam `crypto.randomUUID()`. Risco de colisão em alta concorrência.

**Solução:** Plano de migração em 2 fases:

### Fase A — Suporte a UUID sem quebrar existentes

```sql
-- Adicionar coluna UUID sem remover id_legacy
ALTER TABLE tblPJuridicas ADD COLUMN uuid TEXT;
CREATE UNIQUE INDEX idx_pj_uuid ON tblPJuridicas(uuid);

-- Backfill: gerar UUID para registros existentes
UPDATE tblPJuridicas SET uuid = lower(hex(randomblob(16))) WHERE uuid IS NULL;
```

### Fase B — Migrar use cases para UUID

```typescript
// CreateClientUseCase.ts — nova linha
const idPJ = Date.now();          // legado (manter compatibilidade)
const uuid = crypto.randomUUID();  // novo
```

### Tarefas

- [ ] ADR: documentar decisão de migração de IDs
- [ ] Migration `tblPJuridicas.uuid` — coluna + índice
- [ ] `CreateClientUseCase`: gerar UUID além do id_legacy
- [ ] `entity_id` em `tbl_suite` passa a referenciar UUID, não id_legacy
- [ ] Período de transição: queries aceitam ambos (UUID prioritário)
- [ ] Atualizar `domain.md`: 🔴 IDs → 🟡 (em migração)

---

## EC-05: Documentar tasks.reassign na Matriz RBAC

**Prioridade:** 🟢 Baixa — documentação
**Confiança atual:** `permissions.md` 64%

**Problema:** Permissão `tasks.reassign` existe no código (commit `9bedc83`) mas não está na matriz de permissões.

**Solução:** Atualizar `permissions.md`:

| Perfil | tasks.reassign |
|---|---|
| admin | ✅ |
| gerente | ✅ |
| coordenador | ✅ |
| encarregado | ✅ |
| operador | ❌ |
| campo | ❌ |

### Tarefas

- [ ] Atualizar `permissions.md` — adicionar linha `tasks.reassign`
- [ ] Atualizar `sdd/access-rbac.md` — incluir na spec
- [ ] Verificar UI de gestão de usuários exibe essa permissão
- [ ] Atualizar `confidence-report.md`: `permissions.md` 64% → 80%+

---

## EC-06: Atualizar confidence-report.md

Após conclusão de EC-01 a EC-05, regerar o relatório:

| Spec | Antes | Depois |
|---|---|---|
| `sdd/sync.md` | 80% (1 🔴) | ~90% (0 🔴) |
| `sdd/client.md` | 90% | ~95% |
| `domain.md` | 75% (5 🔴) | ~88% (2 🔴) |
| `permissions.md` | 64% (1 🔴) | ~82% (0 🔴) |
| `sdd/auth-mobile.md` | 92% (sem testes) | 95% (com testes) |
| `sdd/data-service.md` | 92% (sem testes) | 95% (com testes) |

**Confiança geral projetada:** 82% → ~88%

---

## Ordem de Execução

```
EC-05 (permissoes)     → 30 min, só documentação, sem risco
EC-03 (toggleActive)    → 2h, use case simples, sem dependências
EC-02 (rate+expurgo)    → 4h, depende de EC-01 para ter testes de regressão
EC-01 (testes)          → 6h, maior esforço, desbloqueia EC-02
EC-04 (migração IDs)    → 1 sprint, requer migration + transição
EC-06 (relatório)       → 30 min, após todos acima
```

---

## Dependências com Outros Planos

```
limpeza-legado.md (Onda 1)
  └── EC-03 (toggleActive) — limpo o useClientMutations primeiro
  └── EC-05 (permissoes)    — sem dependência, pode ser paralelo

implementacao-fases-3-6.md (Fase 3 — ReadOnlyFormRenderer)
  └── EC-01 (testes) — AuthManager/DataService testados antes de mexer no sync
  └── EC-02 (rate+expurgo) — sync estável antes do ReadOnlyFormRenderer

adr-evolucao-plataforma.md (AD-017 — entity_id)
  └── EC-04 (UUID migration) — entity_id depende de IDs estáveis
```
