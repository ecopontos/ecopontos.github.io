# Plano de Implementação — Fases 3 a 6

> Derivado de `adr-evolucao-plataforma.md` + auditoria do código atual (2026-04-30)
> Contexto: Análise Reversa concluída (82% confiança). 8 ADs das fases 3-6 ainda sem evidência no código.

---

## Pré-requisitos concluídos

- [x] Sprint 1 (Fundação): AD-022 (salt PBKDF2), AD-017 (entity_id/entity_type), AD-021 (gap recovery)
- [x] Sprint 2 (Refatoração): AD-014 (Ouvidoria → suite), AD-015 (CRM → entity registry), AD-020 (dataSource CRM)

---

## Fase 3 — UX e Visualização

### 3.1 — AD-019: ReadOnlyFormRenderer

**Objetivo:** Renderizar qualquer registro `tbl_suite` usando o schema do `form_registry` como template e `payload_json` como dados.

**Arquivo:** `desktop/src/interface/components/ReadOnlyFormRenderer.tsx`

```typescript
interface ReadOnlyFormRendererProps {
  schema: FormContent                    // form_registry.conteudo
  values: Record<string, unknown>        // tbl_suite.payload_json
  formSnapshot?: FormContent             // prioridade (fidelidade histórica)
}
```

**Mapa de renderização por tipo:**

| Tipo de campo | Renderização |
|---|---|
| text, textarea, email, tel, url | texto simples |
| date, time | formatado pt-BR |
| number | número formatado |
| select, radio | label da opção (não o value bruto) |
| checkbox | Sim / Não |
| chips | tags em linha |
| camera, photo, gallery | thumbnail com link |
| geolocation, gps | coordenadas + link Google Maps |
| group | bloco indentado com subcampos |
| repeatable_group | mini-tabela colapsável |
| checklist | lista com status ✔/✘ |
| hidden | não renderiza |
| tipo desconhecido | fallback JSON (nunca quebra) |

**Regras:**
- `formSnapshot` tem prioridade sobre `schema` — garante fidelidade ao momento do preenchimento
- Incremento seguro: novos tipos no FieldFactory funcionam automaticamente
- Tipos removidos exibem fallback — nunca exceção

**Tarefas:**
- [ ] Criar `ReadOnlyFormRenderer.tsx`
- [ ] Implementar mapa de renderização para 15+ tipos
- [ ] Prioridade formSnapshot > form_registry
- [ ] Fallback para tipos desconhecidos
- [ ] Testes com snapshots de formulários reais (vistoria, checklist, caixas)

---

### 3.2 — AD-018: ActionBar com Dois Modos

**Objetivo:** Suportar ações de confirmação (mini-modal) e decisão (painel expandido com contexto visível).

**Arquivo a modificar:** `desktop/src/interface/components/ActionBar.tsx`

**Extensão da interface:**

```typescript
interface ActionButtonConfig {
  requiresInput?: { fields: FormFieldConfig[] }  // existente: confirmação
  expandPanel?: {                                  // novo: decisão
    panel: 'encaminhar' | 'reencaminhar'
    queryParam?: string   // link para página completa
  }
}
```

**Comportamento:**
| Modo | UI | Quando usar |
|---|---|---|
| Confirmação | Mini-modal sobre o contexto (pode ocultar) | Aprovar, Rejeitar, Devolver |
| Decisão | Painel desliza dentro do modal, contexto visível | Encaminhar, Reencaminhar |

**Sinalização visual:** Botões de decisão → chevron `›`. Botões de confirmação → sem chevron.

**Tarefas:**
- [ ] Adicionar `expandPanel?` à interface `ActionButtonConfig`
- [ ] Implementar painel expansível no modal
- [ ] Chevron `›` condicional nos botões
- [ ] Redirecionamento para página completa via `queryParam`
- [ ] Testes: confirmação vs decisão

---

### 3.3 — AD-023: Página de Tarefa `/tarefas/[id]`

**Objetivo:** Página completa para trabalho detalhado em tarefas, coexistindo com o modal do kanban.

**Arquivo:** `desktop/src/app/tarefas/[id]/page.tsx` (Next.js App Router)

**Layout — duas colunas:**

```
┌──────────────────────────┬──────────────────────┐
│ Coluna esquerda (60%)    │ Coluna direita (40%) │
├──────────────────────────┼──────────────────────┤
│ Breadcrumb completo      │ Histórico contínuo   │
│ Metadados (status,       │ (scroll)             │
│   prioridade, prazo)     │                      │
│ Formulários vinculados   │ Comentários          │
│ ReadOnlyFormRenderer     │ ActionBar fixo       │
│ Registros enviados       │                      │
│ Anexos                   │                      │
└──────────────────────────┴──────────────────────┘
```

**Navegação:**
- Link `[⤢ Abrir página completa]` no rodapé do modal do kanban
- Breadcrumb reconstrói caminho via `tbl_tarefas.projeto_id`
- `router.back()` funciona se veio do modal

**Tarefas:**
- [ ] Criar rota `/tarefas/[id]`
- [ ] Layout duas colunas responsivo
- [ ] Integrar ReadOnlyFormRenderer para formulários vinculados
- [ ] Breadcrumb com reconstituição de caminho
- [ ] ActionBar integrado (modo expandPanel quando `?action=encaminhar`)
- [ ] Link de acesso no modal do kanban
- [ ] Reutilizar hooks existentes (useTaskUseCases, useKanbanData)

---

## Fase 4 — Ações Universais

### 4.1 — AD-016: Sete Ações Universais de Decisão

**Objetivo:** Formalizar vocabulário de 7 ações que cobrem todos os pontos de decisão do sistema.

**Arquivo:** `desktop/src/domain/shared/universal-actions.ts`

| Ação | Status resultante | Padrão | Propriedade |
|---|---|---|---|
| **Aceitar** | `locked` | Terminal | Permanece |
| **Rejeitar** | `closed` | Terminal | Encerrada |
| **Devolver** | `refuted` | Terminal | Volta à origem |
| **Reencaminhar** | `dispatched` + transfer | Gerador | Transferência total |
| **Encaminhar** | `dispatched` + share | Gerador | Origem mantém |
| **Solicitar** | novo `tbl_suite` | Gerador | Gera derivado |
| **Criar Tarefa** | nova `tbl_tarefas` | Gerador | Gera tarefa |

**3 gaps na máquina de estados a corrigir:**

1. `current → closed` — transição direta (hoje só existe via `dispatched`)
2. `dispatched` não distingue share de transfer → adicionar `transfer_type` em `tbl_suite_historico`
3. Solicitar e Criar Tarefa não transitam status → documentar como geradores

**Tarefas:**
- [ ] Criar `universal-actions.ts` com constantes e tipos
- [ ] Adicionar transição `current → closed` em `SuiteStatus.ts`
- [ ] Adicionar coluna `transfer_type` em `tbl_suite_historico` (share | transfer)
- [ ] Migrar ações built-in para usar constantes do vocabulário universal
- [ ] Testes de transição `current → closed`

---

### 4.2 — AD-024: Encaminhar e Reencaminhar como Eventos

**Objetivo:** Adicionar `demanda.encaminhada` e `demanda.reencaminhada` ao protocolo de eventos com handlers dedicados.

**Arquivos:**
- `desktop/src/infrastructure/sync/EventEnvelope.ts` — union type
- `desktop/src/infrastructure/sync/handlers/encaminhamento.handler.ts` — novo handler

**Payloads:**

```typescript
// demanda.encaminhada (share)
{
  demandaId: string
  packageId: string
  setorOrigem: string
  setorDestino: string
  instrucoes?: string
}

// demanda.reencaminhada (transfer)
{
  demandaId: string
  packageId: string
  setorOrigem: string
  setorDestino: string
  motivo: string                     // obrigatório
  historicoEncaminhamentos: Array<{ de: string, para: string, data: string }>
}
```

**Comportamento do handler no setor destino:**
1. `INSERT tbl_suite` (cópia com `ref_package_id`)
2. `ensureRetroactiveTask()` → ghost task no setor destino
3. Task herda título, `setor_id`, `tbl_suite_id`

**Tarefas:**
- [ ] Adicionar `demanda.encaminhada` e `demanda.reencaminhada` ao `EcoFormsEventType`
- [ ] Criar `encaminhamento.handler.ts` com ambos os handlers
- [ ] Registrar no `HandlerRegistry`
- [ ] `ensureRetroactiveTask()` — criar ghost task automaticamente
- [ ] Atualizar `encaminhamento.actions.ts` para publicar eventos corretos
- [ ] Testes de handler: share vs transfer

---

## Fase 5 — Builders Configuráveis

### 5.1 — AD-010: Entity Picker como Campo de Formulário

**Objetivo:** Campo `entity_picker` no FieldFactory que vincula formulários a entidades do CRM.

**Schema do campo no form_registry:**

```json
{
  "type": "entity_picker",
  "config": { "entityType": "pj" },
  "label": "Cliente",
  "required": true
}
```

**Mapeamento entityType → dataSource:**

| entityType | dataSource | Tabela |
|---|---|---|
| `pj` | clientes_crm | tblPJuridicas |
| `pf` | pessoas_fisicas_crm | tblPFisicas |
| `ecoponto` | ecopontos_crm | tbl_ecopontos |

**Arquivos:**
- `www/js/fields/types/EntityPickerField.js` — campo mobile
- `desktop/src/interface/components/EntityPickerRenderer.tsx` — renderizador

**Comportamento:**
- Dropdown busca por nome/documento
- Exibe `{nome} — {documento}`
- ReadOnlyFormRenderer exibe ID com badge monoespaçado
- SubmitSuiteUseCase extrai entity_id/entity_type automaticamente

**Tarefas:**
- [ ] Criar `EntityPickerField.js` no mobile (FieldFactory + FIELD_TYPE_MAP)
- [ ] Registrar resolvers no smartCache: `clientes_crm`, `pessoas_fisicas_crm`, `ecopontos_crm`
- [ ] Criar `EntityPickerRenderer.tsx` no desktop (ReadOnlyFormRenderer)
- [ ] SubmitSuiteUseCase: extrair entity_id/entity_type do payload
- [ ] Testes: seleção, preenchimento automático, renderização readonly

---

### 5.2 — AD-011: view_registry — DashBuilder (4 widgets)

**Objetivo:** Criar tabela `view_registry` + `ViewRenderer` para dashboards configuráveis sem deploy.

**Migration:**

```sql
CREATE TABLE IF NOT EXISTS view_registry (
  id          TEXT PRIMARY KEY,
  titulo      TEXT NOT NULL,
  perfis      TEXT NOT NULL,     -- JSON array
  layout      TEXT DEFAULT 'grid-1',
  widgets     TEXT NOT NULL,     -- JSON array
  versao      INTEGER DEFAULT 1,
  criado_em   TEXT,
  atualizado_em TEXT
);
```

**4 tipos iniciais de widget:**

| Tipo | Descrição | Fonte de dados |
|---|---|---|
| `record_view` | ReadOnlyFormRenderer inline | `tbl_suite` por `module_type` |
| `record_list` | Lista paginada com filtro | SQLite query com `WHERE module_type = ?` |
| `kpi_card` | Contagem de registros ativos | `COUNT(*) WHERE status != 'closed'` |
| `status_board` | Quadro de status | Agrupamento por status |

**Arquivos:**
- `desktop/src/infrastructure/persistence/sqlite/SqliteViewRegistryRepository.ts`
- `desktop/src/interface/components/ViewRenderer.tsx`
- `desktop/src/application/view-registry/` — use cases

**Princípios:**
- Tipo desconhecido → fallback visual, nunca exceção
- `empty_state` explícito: "Nenhum registro pendente" em vez de tela vazia
- Sync distribui views automaticamente

**Tarefas:**
- [ ] Migration `view_registry`
- [ ] `ViewRenderer` com suporte a 4 tipos
- [ ] `record_view` usando ReadOnlyFormRenderer
- [ ] `record_list` com paginação e filtro
- [ ] `kpi_card` com formatação de número
- [ ] `status_board` com colunas por status
- [ ] Fallback para tipo desconhecido
- [ ] Integração com sync (handler `view_registry`)

---

### 5.3 — AD-012: decision_registry — DecisionBuilder

**Objetivo:** Criar tabela `decision_registry` para fluxos de decisão configuráveis.

**Migration:**

```sql
CREATE TABLE IF NOT EXISTS decision_registry (
  id            TEXT PRIMARY KEY,
  target_type   TEXT NOT NULL,       -- module_type alvo
  perfis        TEXT NOT NULL,        -- JSON array
  enabled_when  TEXT,                 -- JSON: condições de visibilidade
  steps         TEXT,                 -- JSON: passos de contexto
  action        TEXT NOT NULL,        -- uma das 7 ações universais
  params        TEXT,                 -- JSON: parâmetros da ação
  consequence   TEXT NOT NULL,        -- JSON: efeito no sistema
  versao        INTEGER DEFAULT 1,
  criado_em     TEXT,
  atualizado_em TEXT
);
```

**Coexistência com código:** Decisões hardcoded permanecem. `decision_registry` é opcional — usado onde operador precisa configurar.

**Tarefas:**
- [ ] Migration `decision_registry`
- [ ] `DecisionBuilder` — leitura e validação de schema
- [ ] `DecisionRenderer` — renderização condicional (enabledWhen)
- [ ] `executeDecision()` — dispatcher que aplica consequence
- [ ] Handler `decision_registry` para sync
- [ ] Testes: decisão configurada vs hardcoded

---

## Fase 6 — Plataforma v2

### 6.1 — AD-013: ModuleBuilder (DIFERIR)

**Pré-requisitos obrigatórios antes de iniciar:**
1. `view_registry` (AD-011) estável em pelo menos 1 módulo real em produção
2. `decision_registry` (AD-012) estável em pelo menos 1 módulo real em produção
3. Capacidade dedicada para UX complexa de canvas de composição

**Risco:** Alto. Editores no-code de composição são consistentemente subestimados. O valor real está nas Fases 3-5.

**Não iniciar antes da validação dos pré-requisitos.**

---

## Ordem de Execução

```
Fase 3 (UX)
  ├─ 3.1 ReadOnlyFormRenderer     ← sem dependências, desbloqueia tudo abaixo
  ├─ 3.2 expandPanel              ← depende de 3.1 (mostra registros)
  └─ 3.3 Página /tarefas/[id]     ← depende de 3.1 + 3.2

Fase 4 (Ações)
  ├─ 4.1 7 ações universais       ← sem dependências de código, formaliza vocabulário
  └─ 4.2 eventos encaminhamento   ← depende de 4.1 (usa ações canônicas)

Fase 5 (Builders)
  ├─ 5.1 entity_picker            ← depende de resolvers CRM (já existem)
  ├─ 5.2 view_registry            ← depende de 3.1 (record_view usa ReadOnlyFormRenderer)
  └─ 5.3 decision_registry        ← depende de 4.1 (usa 7 ações universais)

Fase 6 (Plataforma)
  └─ 6.1 ModuleBuilder            ← BLOQUEADO até 5.2 + 5.3 em produção
```

---

## Estimativa de Esforço

| Fase | ADs | Complexidade | Estimativa |
|---|---|---|---|
| 3 — UX | 3 | Média | ~2 sprints |
| 4 — Ações | 2 | Média | ~1 sprint |
| 5 — Builders | 3 | Média-Alta | ~3 sprints |
| 6 — Plataforma | 1 | Alta | Diferido |
| **Total** | **9** | | **~6 sprints** |
