# Fluxograma — Módulo `task`

> Archaeologist — 2026-04-30

---

## Fluxo Geral

```mermaid
flowchart TD
    UI[React Component] -->|useTaskUseCases / useKanban| UC[Use Cases]
    UC -->|CreateTaskUseCase| CREATE[Create]
    UC -->|MoveTaskUseCase| MOVE[Move Status]
    UC -->|AssignTaskUseCase| ASSIGN[Assign]
    UC -->|ArchiveTaskUseCase| ARCHIVE[Archive]
    UC -->|DeleteTaskUseCase| DELETE[Soft Delete]
    UC -->|ListTasksByProjectUseCase| LIST[List]
    
    CREATE --> SM[State Machine: TaskStatus]
    MOVE --> SM
    SM --> VALID{isValidTransition?}
    VALID -->|Sim| REPO[SqliteTaskRepository]
    VALID -->|Não| ERR[InvalidTransitionError]
    REPO --> DB[(SQLite: tbl_tarefas)]
```

---

## Fluxo: Criação de Tarefa

```mermaid
flowchart TD
    A[CreateTaskUseCase.execute] --> B[clock.nowIso]
    B --> C[status = a_fazer]
    C --> D[nextOrder projectId, a_fazer]
    D --> E["SELECT COALESCE(MAX(ordem),0)<br/>WHERE projeto_id = ? AND status = ?"]
    E --> F["ordem = MAX + 1000"]
    F --> G["Task.fromProps<br/>(id: crypto.randomUUID())"]
    G --> H{titulo.trim() não vazio?}
    H -->|Não| ERR[Error: Título obrigatório]
    H -->|Sim| I[tasks.save]
    I --> J{UPSERT<br/>SELECT id LIMIT 1}
    J -->|Novo| K["INSERT INTO tbl_tarefas<br/>(19 colunas)"]
    J -->|Existente| L["UPDATE tbl_tarefas<br/>(15 colunas + updated_at)"]
    K --> M[✅ Retorna TaskDto]
    L --> M
```

---

## Fluxo: Transição de Status (Kanban Move)

```mermaid
flowchart TD
    A[MoveTaskUseCase.execute] --> B[repo.findById]
    B --> C{Task existe?}
    C -->|Não| D[NotFoundError]
    C -->|Sim| E[task.transitionTo newStatus]
    E --> F{isValidTransition?}
    F -->|Não| G[InvalidTransitionError<br/>com descrição detalhada]
    F -->|Sim| H[Status atualizado]
    H --> I{ordem fornecida?}
    I -->|Sim| J[task.reorder ordem]
    I -->|Não| K[Mantém ordem atual]
    J --> L[tasks.save]
    K --> L
    L --> M[✅ TaskDto]
```

---

## Máquina de Estados

```mermaid
stateDiagram-v2
    [*] --> a_fazer
    a_fazer --> em_progresso: Start
    a_fazer --> cancelado: Cancel
    em_progresso --> a_fazer: Reopen
    em_progresso --> concluido: Complete
    em_progresso --> cancelado: Cancel
    concluido --> [*]: Terminal
    cancelado --> [*]: Terminal
```

---

## Fluxo: Cálculo de Recorrência

```mermaid
flowchart TD
    A[calculateNextOccurrence] --> B{config existe?}
    B -->|Não| C[null]
    B -->|Sim| D{Qual frequencia?}
    D -->|diaria| E["next.setDate(current + intervalo)"]
    D -->|semanal| F{dias_semana?}
    F -->|Sim| G["Itera próximos 7*intervalo dias<br/>busca próximo dayOfWeek"]
    F -->|Não| H["next.setDate(current + 7*intervalo)"]
    D -->|mensal| I["next.setMonth(current + intervalo)"]
    D -->|anual| J["next.setFullYear(current + intervalo)"]
    E --> K{fim_recorrencia?}
    G --> K
    H --> K
    I --> K
    J --> K
    K --> L{next > fim?}
    L -->|Sim| C
    L -->|Não| M[next.toISOString]
    K -->|Sem fim| M
```

---

## Fluxo: Soft-Delete

```mermaid
flowchart LR
    A[DeleteTaskUseCase] --> B["UPDATE tbl_tarefas<br/>SET deletado_em = datetime('now')<br/>updated_at = datetime('now')<br/>WHERE id = ?"]
    B --> C[✅ Registro marcado como deletado]
    C --> D[Queries futuras:<br/>WHERE deletado_em IS NULL]
```
