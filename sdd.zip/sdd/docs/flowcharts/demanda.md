# Fluxograma — Módulo `demanda`

---

## Workflow de Estados

```mermaid
stateDiagram-v2
    [*] --> aberta: CreateDemanda (ouvidoria/interno)
    [*] --> aceita: CreateDemanda (origem='proprio')
    aberta --> aceita: AcceptDemanda
    aceita --> em_campo: (ativo implícito)
    em_campo --> concluida: CloseDemanda
    
    note right of aberta: Auto-aceite quando<br/>origemTipo === 'proprio'
```

---

## Fluxo: AcceptDemanda (Transacional)

```mermaid
flowchart TD
    A[AcceptDemandaUseCase] --> B[repo.findById]
    B --> C{status === aberta?}
    C -->|Não| ERR[Error: status inválido]
    C -->|Sim| TX["repo.transaction()"]
    
    subgraph "Transação Atômica"
        TX --> D[repo.updateStatus → aceita]
        D --> E[Para cada tarefa input]
        E --> F[Task.fromProps UUID]
        F --> G[taskRepo.nextOrder]
        G --> H[taskRepo.save]
        H --> I[Para cada formulário]
        I --> J[repo.saveTarefaFormulario]
        J --> K[repo.saveEvento tarefa.criada]
        K --> L[repo.saveEvento demanda.aceita]
    end
    
    L --> M[✅ Transação commit]
    ERR --> N[❌ Rollback]
```

---

## Fluxo: CloseDemanda (Política)

```mermaid
flowchart TD
    A[CloseDemandaUseCase] --> B[repo.findById]
    B --> C{status === concluida?}
    C -->|Sim| ERR[Error: já concluída]
    C -->|Não| D{politicaConclusao?}
    D -->|todas| E[allTarefasObrigatoriasConcluidas]
    E --> F{Todas concluídas?}
    F -->|Não| G[Error: tarefas pendentes]
    F -->|Sim| TX["repo.transaction()"]
    D -->|declarado| TX
    TX --> H[repo.updateStatus → concluida]
    H --> I[archiveStatus = pending]
    I --> J[repo.saveEvento demanda.encerrada]
    J --> K[✅ Commit]
```

---

## Fluxo: CreateDemanda (Auto-Aceite)

```mermaid
flowchart TD
    A[CreateDemandaUseCase] --> B{origemTipo === proprio?}
    B -->|Sim| C[autoAceite = true]
    B -->|Não| D[autoAceite = false]
    C --> E["status = aceita<br/>aceitoPor = solicitante<br/>aceitoEm = agora"]
    D --> F["status = aberta<br/>aceitoPor = null<br/>aceitoEm = null"]
    E --> G[Demanda.fromProps UUID]
    F --> G
    G --> H[repo.save]
    H --> I[repo.saveEvento demanda.criada]
    I --> J{autoAceite?}
    J -->|Sim| K[repo.saveEvento demanda.aceita]
    J -->|Não| L[✅ Fim]
    K --> L
```
