# Fluxograma — Módulo `client`

> Archaeologist — 2026-04-30

---

## Fluxo Geral: CRUD de Clientes

```mermaid
flowchart TD
    UI[React Component / Hook] -->|createPJ| MUT[useClientMutations]
    UI -->|useClients / useClientById| QUERY[useClients / useClientQueries]
    
    MUT -->|nameExists| NC[CheckClientNameExistsUseCase]
    NC -->|nameExists| REPO[SqliteClientRepository]
    
    MUT -->|create| CC[CreateClientUseCase]
    MUT -->|update| UC[UpdateClientUseCase]
    MUT -->|delete| DC[DeleteClientUseCase]
    
    QUERY -->|list| LC[ListClientsUseCase]
    QUERY -->|getById| GC[GetClientByIdUseCase]
    QUERY -->|contacts| CO[ListClientContactsUseCase]
    QUERY -->|types| CT[ListClientTypesUseCase]
    QUERY -->|audit| AL[GetClientAuditLogUseCase]
    QUERY -->|search| FTS[FTS5 Search]
    
    CC --> REPO
    UC --> REPO
    DC --> REPO
    LC --> REPO
    GC --> REPO
    CO --> REPO
    CT --> REPO
    AL --> REPO
    NC --> REPO
    
    REPO --> DB[(SQLite)]
    FTS --> DB
```

---

## Fluxo: Criação de Cliente

```mermaid
flowchart TD
    A[Formulário React] -->|submit| B[useClientMutations.createPJ]
    B --> C{nameExists?}
    C -->|Sim| D[🛑 Erro: Duplicado]
    C -->|Não| E[CreateClientUseCase.execute]
    E --> F[Client.fromProps]
    F --> G[repo.save]
    G --> H{SELECT id_legacy}
    H -->|Existe| I[UPDATE tblPJuridicas]
    H -->|Não existe| J[INSERT INTO tblPJuridicas]
    I --> K[✅ Retorna ClientDto]
    J --> K
    D --> L[setValidationError]
    K --> M[UI: Cliente criado]
```

---

## Fluxo: Atualização de Cliente

```mermaid
flowchart TD
    A[Formulário React] -->|submit| B[useClientMutations.updatePJ]
    B --> C{nome alterado?}
    C -->|Sim, nome mudou| D{nameExists com excludeId?}
    C -->|Não, mesmo nome| E[UpdateClientUseCase.execute]
    D -->|Duplicado| F[🛑 Erro: Nome em uso]
    D -->|Não duplicado| E
    E --> G[repo.findById]
    G -->|null| H[🛑 Erro: Cliente não encontrado]
    G -->|found| I[existing.update partialProps]
    I --> J[atualizadoEm = now]
    J --> K[repo.save]
    K --> L[✅ Retorna ClientDto]
```

---

## Fluxo: Soft-Delete

```mermaid
flowchart LR
    A[UI: Botão Excluir] -->|confirm| B[useClientMutations.deletePJ]
    B --> C[DeleteClientUseCase.execute]
    C --> D[repo.delete idPJ]
    D --> E[(UPDATE tblPJuridicas<br/>SET Inativo = 1<br/>WHERE id_legacy = ?)]
    E --> F[✅ Registro marcado como inativo]
```

---

## Fluxo: Listagem com Filtro

```mermaid
flowchart TD
    A[useClients ativoOnly?] --> B{ativoOnly?}
    B -->|true default| C[WHERE Inativo IS NULL<br/>OR Inativo = 0<br/>OR Inativo = '']
    B -->|false| D[sem filtro Inativo]
    C --> E[LEFT JOIN tblPJtipo]
    D --> E
    E --> F[ORDER BY Cliente ASC]
    F --> G[rowToClient mapeamento]
    G --> H[toClientDto transformação]
    H --> I[✅ ClientDto[]]
```

---

## Fluxo: Busca FTS5

```mermaid
flowchart TD
    A[useClientSearch termo] -->|len >= 2| B[Prepara query FTS5]
    B --> C["termo → 'termo* OR busca*'"]
    C --> D[SELECT FROM tbl_pjuridicas_fts<br/>WHERE MATCH ?<br/>ORDER BY rank<br/>LIMIT 50]
    D --> E[JOIN tblPJuridicas<br/>JOIN tblPJtipo]
    E --> F[✅ Resultados ordenados por relevância]
```
