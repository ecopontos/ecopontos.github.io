# ActionRegistry & WidgetRegistry — EcoForms Desktop

> Documento unificado que descreve o sistema de ações configuráveis (ActionRegistry) e widgets de dashboard (WidgetRegistry) implementados nas Fases 1–4.
>
> **Arquivos de implementação:**
> - `src/application/actions/ActionRegistry.ts`
> - `src/application/actions/builtin/*.actions.ts`
> - `src/application/actions/initializeActions.ts`
> - `src/application/widgets/WidgetRegistry.ts`
> - `src/application/widgets/builtin/initializeWidgets.ts`
> - `components/ActionBar.tsx`
> - `components/DynamicDashboard.tsx`
> - `src/interface/hooks/useWorkflowActions.ts`
> - `src/interface/hooks/useDashboardWidgets.ts`

---

## Relação com Outros Documentos

| Documento | Como este documento se relaciona |
|-----------|----------------------------------|
| `arquitetura.md` | Contexto da camada Application; boot com `initializeActions()` |
| `modules.md` | Inventário detalhado dos arquivos novos na aplicação e interface |
| `database.md` | Schema da tabela `action_log` |
| `hooks.md` | Hooks `useWorkflowActions` e `useDashboardWidgets` |
| `event-envelope-v2.md` | Eventos publicados pelos handlers das ações |
| `data-flow.md` | Fluxos de dados das ações e widgets |
| `ui-flow.md` | Jornadas do usuário no ActionBar e DynamicDashboard |

---

## Índice

1. [Visão Geral](#1-visão-geral)
2. [ActionRegistry](#2-actionregistry)
   - 2.1 [Conceito](#21-conceito)
   - 2.2 [Tipos Fundamentais](#22-tipos-fundamentais)
   - 2.3 [Registro e Descoberta](#23-registro-e-descoberta)
   - 2.4 [Ações Built-in](#24-ações-built-in)
   - 2.5 [Mapeamento de Campos](#25-mapeamento-de-campos)
   - 2.6 [Eventos Publicados](#26-eventos-publicados)
3. [WidgetRegistry](#3-widgetregistry)
   - 3.1 [Conceito](#31-conceito)
   - 3.2 [Tipos Fundamentais](#32-tipos-fundamentais)
   - 3.3 [Registro e Descoberta](#33-registro-e-descoberta)
   - 3.4 [Widgets Built-in](#34-widgets-built-in)
4. [Integração com a UI](#4-integração-com-a-ui)
   - 4.1 [ActionBar](#41-actionbar)
   - 4.2 [DynamicDashboard](#42-dynamicdashboard)
5. [Fluxo de Dados](#5-fluxo-de-dados)
   - 5.1 [Ação Completa](#51-ação-completa)
   - 5.2 [Widget Completo](#52-widget-completo)
6. [Auditoria — action_log](#6-auditoria--action_log)
7. [Padrões e Regras](#7-padrões-e-regras)

---

## 1. Visão Geral

O sistema possui dois subsistemas simétricos na camada Application:

| Subsistema | Responsabilidade | Analogia |
|------------|-------------------|----------|
| **ActionRegistry** | Decisões de negócio configuráveis por contexto | Botões dinâmicos com orquestração de use cases |
| **WidgetRegistry** | Indicadores de dashboard configuráveis por perfil | Cards, gráficos e tabelas que leem via use cases |

Ambos reutilizam:
- **`VisibilityRule`** (13 operadores) — do sistema de campos dinâmicos do `form_registry`
- **`UserRole`** (strings) — do RBAC via `usePermissions.ts`
- **`Container`** — agrupamento real de use cases em `src/infrastructure/container.ts`

---

## 2. ActionRegistry

### 2.1 Conceito

Uma **ação** é uma decisão de negócio que um usuário pode tomar sobre um objeto do sistema. Ela não é um botão — o botão é apenas a representação visual. A lógica está no `handler`, que orquestra use cases e publica eventos.

Pré-condições de uma ação:
1. **Visibilidade** — `enabledWhen` (VisibilityRule)
2. **Permissão** — `requiredRoles` (UserRole)
3. **Contexto** — dados do objeto, formulário e usuário logado

### 2.2 Tipos Fundamentais

```typescript
// src/application/actions/ActionRegistry.ts

interface ActionButtonConfig {
  id: string;                       // ex: 'demanda_aceitar'
  label: string;                    // 'Aceitar Demanda'
  icon?: string;                    // nome do ícone Lucide
  color?: string;                   // cor do botão (tailwind)
  confirmationRequired?: boolean;
  confirmationMessage?: string;
  enabledWhen?: VisibilityRule[];   // 13 operadores
  requiredRoles?: UserRole[];       // strings: 'admin', 'gerente'...
  requiresInput?: {
    fields: FormFieldConfig[];      // mini-formulário de entrada
  };
  fieldMapping?: Record<string, {
    from?: string;                  // caminho no contexto
    value?: unknown;                // valor fixo
    transform?: (value, ctx) => unknown;
  }>;
  handler: ActionHandler;
}

type ActionHandler = (ctx: ActionContext) => Promise<ActionResult>;

interface ActionContext {
  targetType: 'task' | 'suite_package' | 'demand' | 'ecoponto';
  targetId: string;
  task?: unknown;
  suitePackage?: unknown;
  demand?: unknown;
  ecoponto?: unknown;
  formData: Record<string, unknown>;
  userId: string;
  input?: Record<string, unknown>;
  container: Container;
  eventBus: EventBus;
  syncNow: () => Promise<void>;
}

interface ActionResult {
  success: boolean;
  message: string;
  redirect?: string;
}
```

### 2.3 Registro e Descoberta

```typescript
const actionRegistry = new Map<string, ActionButtonConfig>();

export function registerAction(config: ActionButtonConfig): void
export function getAvailableActions(
  targetType: string,
  formData: Record<string, unknown>,
  userRole: UserRole
): ActionButtonConfig[]
export function aplicarMapeamento(
  mapping: ActionButtonConfig['fieldMapping'],
  ctx: ActionContext
): Record<string, unknown>
```

**Boot:** `initializeActions()` é chamada após `getContainerAsync()` em `components/ClientLayout.tsx`. Cada módulo de ações chama `registerAction()` via side-effect ou função exportada.

**Descoberta:** `useWorkflowActions(targetType, formData)` usa `getAvailableActions()` filtrando por `userRole` do `AuthContext`.

### 2.4 Ações Built-in

| ID | Label | Contexto | Quem pode | Evento publicado |
|---|---|---|---|---|
| `demanda_aceitar` | Aceitar Demanda | Demanda `aberta` | admin, gerente, coordenador | `demanda.aceita` |
| `demanda_encerrar` | Encerrar Demanda | Demanda `aceita` | admin, gerente, coordenador | `demanda.encerrada` |
| `suite_aprovar` | Aprovar | Suite `pending_review` | admin, gerente | `suite.aprovada` |
| `suite_rejeitar` | Rejeitar | Suite `pending_review` | admin, gerente | `suite.rejeitada` |
| `ecoponto_encaminhar_remocao` | Encaminhar Remoção | Tarefa com `ecopontoId` | admin, gerente, coordenador | `ecoponto.remocao.agendada` |
| `encaminhar_para_setor` | Encaminhar para Setor | Tarefa não concluída | admin, gerente, coordenador, operador | `demanda.criada`* |

\* O evento `demanda.criada` é publicado automaticamente pelo `CreateDemandaUseCase`.

### 2.5 Mapeamento de Campos

O `ActionBar` chama `aplicarMapeamento(action.fieldMapping, ctx)` antes de invocar o handler. O resultado é injetado em `ctx.input`.

Exemplo de mapeamento:
```typescript
fieldMapping: {
  ecopontoId: { from: "formData.ecopontoId" },
  setorRemocao: { from: "input.setorRemocao" },
}
```

Caminhos suportados em `from`: notação ponto (ex: `formData.status`, `input.destinatarioId`).

### 2.6 Eventos Publicados

| Ação | Evento | `data` obrigatório | Destinatário |
|---|---|---|---|
| `demanda_aceitar` | `demanda.aceita` | `{ demandaId, aceitoPor }` | Setor solicitante |
| `demanda_encerrar` | `demanda.encerrada` | `{ demandaId, encerradoPor }` | Setor solicitante |
| `suite_aprovar` | `suite.aprovada` | `{ suiteId, aprovadoPor }` | Setor de origem |
| `suite_rejeitar` | `suite.rejeitada` | `{ suiteId, rejeitadoPor, motivo }` | Setor de origem |
| `ecoponto_encaminhar_remocao` | `ecoponto.remocao.agendada` | `{ ecopontoId, taskId, setorRemocao }` | Setor de remoção |
| `encaminhar_para_setor` | `demanda.criada` | `{ demandaId, origemTipo, destinatarioId }` | Setor destino |

**Roteamento:** Todos os eventos passam pela pasta do produtor (`eventos/{routingId}/`) e são consumidos no próximo ciclo de pull do setor destino.

---

## 3. WidgetRegistry

### 3.1 Conceito

Um **widget** é um indicador de dashboard que carrega dados via use case e se renderiza dinamicamente. Widgets são configuráveis por perfil — diferentes roles veem diferentes conjuntos de indicadores.

### 3.2 Tipos Fundamentais

```typescript
// src/application/widgets/WidgetRegistry.ts

export type WidgetType =
  | 'kpi_card'
  | 'bar_chart'
  | 'pie_chart'
  | 'line_chart'
  | 'table'
  | 'recent_activity';

interface WidgetConfig {
  id: string;
  type: WidgetType;
  title: string;
  dataSource: {
    useCaseGroup: string;   // ex: 'tasks', 'demandas', 'ouvidoria'
    method: string;         // ex: 'listByProject', 'countAbertos'
    params?: Record<string, unknown>;
  };
  refreshInterval?: number;  // segundos
  options?: Record<string, unknown>;
  visibility?: VisibilityRule[];
  requiredRoles?: UserRole[];
}
```

### 3.3 Registro e Descoberta

```typescript
const widgetRegistry = new Map<string, WidgetConfig>();

export function registerWidget(config: WidgetConfig): void
export function getAvailableWidgets(userRole: UserRole): WidgetConfig[]
```

**Boot:** `registerBuiltinWidgets()` é chamada dentro de `initializeActions()`.

**Descoberta:** `useDashboardWidgets()` usa `getAvailableWidgets(userRole)` com o perfil do `AuthContext`.

### 3.4 Widgets Built-in

| ID | Tipo | Título | Fonte de dados | Perfis |
|---|---|---|---|---|
| `tarefas_abertas` | `kpi_card` | Tarefas Abertas | `tasks.listByProject` | todos |
| `protocolos_abertos` | `kpi_card` | Protocolos Abertos | `ouvidoria.countAbertos` | admin, gerente, coordenador |
| `tarefas_por_status` | `bar_chart` | Tarefas por Status | `tasks.listByProject` | admin, gerente, coordenador |
| `atividade_recente` | `recent_activity` | Atividade Recente | `tasks.listByProject` | todos |
| `ultimas_demandas` | `table` | Últimas Demandas | `demandas.getStatus` | admin, gerente, coordenador |

---

## 4. Integração com a UI

### 4.1 ActionBar

**Arquivo:** `components/ActionBar.tsx`

- Renderiza botões dinâmicos a partir de `ActionButtonConfig[]`
- Suporta variantes de cor (`default`, `destructive`, `outline`, cores customizadas)
- Ícones dinâmicos via `lucide-react` por nome
- Estados de loading com spinner
- **Modal de confirmação** — para `confirmationRequired`
- **Mini-modal de input** — para `requiresInput` (campos `text`, `select`, obrigatórios validados)
- Mapeamento de campos via `aplicarMapeamento` antes de chamar o handler
- Integração com `toast` (sucesso/erro) e `router.push` para redirects

**Uso no TaskDialog:**
```tsx
const workflowActions = useWorkflowActions('task', taskFormData);

<ActionBar
  actions={workflowActions}
  context={buildActionContext('task', task, userId, container)}
/>
```

### 4.2 DynamicDashboard

**Arquivo:** `components/DynamicDashboard.tsx`

- Grid responsivo (`grid-cols-1 md:grid-cols-2 xl:grid-cols-3`)
- Mapeia `WidgetType` → componente React:
  - `kpi_card` → `KpiCard`
  - `bar_chart` → `SimpleBarChart`
  - `recent_activity` → `RecentActivityList`
  - `table` → `TableWidget`
- Busca dados chamando `container[widget.dataSource.useCaseGroup][widget.dataSource.method]`
- Respeita `refreshInterval` com `setInterval`
- Estados: loading (spinner), erro (mensagem), conteúdo

**Uso na página inicial:**
```tsx
const dashboardWidgets = useDashboardWidgets();

{dashboardWidgets.length > 0 && (
  <DynamicDashboard widgets={dashboardWidgets} />
)}
```

---

## 5. Fluxo de Dados

### 5.1 Ação Completa

```
Usuário abre TaskDialog
    │
    ▼
useWorkflowActions('task', formData)
    │
    ▼
getAvailableActions('task', formData, userRole)
    │
    ├── evaluateVisibilityRules(enabledWhen, formData)
    └── filter por requiredRoles
    │
    ▼
ActionBar renderiza botões
    │
    ▼
Usuário clica em "Encaminhar para Setor"
    │
    ▼
ActionBar exibe mini-modal (requiresInput)
    │
    ▼
Usuário preenche e confirma
    │
    ▼
aplicarMapeamento(fieldMapping, ctx) → ctx.input
    │
    ▼
handler(ctx) executa:
    ├── invoke('command_dedicado', ...)  // ex: suite_approve, demanda_aceitar (valida sessão + RBAC no Rust)
    ├── eventBus.publish('demanda.criada', data)
    └── action_log INSERT (opcional, para debug de workflow)
    │
    ▼
ActionResult → toast.success / toast.error
```

### 5.2 Widget Completo

```
Página inicial monta
    │
    ▼
useDashboardWidgets() → getAvailableWidgets(userRole)
    │
    ▼
DynamicDashboard recebe WidgetConfig[]
    │
    ▼
Para cada widget:
    ├── WidgetRenderer monta
    ├── fetchData() → container[useCaseGroup][method](params)
    ├── setData(result)
    └── setInterval(refreshInterval)
    │
    ▼
Renderiza componente específico por type
```

---

## 6. Auditoria

### 6.1 `action_log` (Workflow / Operacional)

Toda ação do ActionRegistry (sucesso ou erro) pode gravar em `action_log`:

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `id` | TEXT | UUID |
| `action_id` | TEXT | ID da ação (ex: `demanda_aceitar`) |
| `target_type` | TEXT | Tipo do alvo (`task`, `demand`, etc.) |
| `target_id` | TEXT | UUID do alvo |
| `user_id` | TEXT | UUID do usuário |
| `resultado` | TEXT | JSON com resultado (sucesso) |
| `erro` | TEXT | Mensagem de erro (falha) |
| `created_at` | TEXT | `datetime('now')` |

**Índices:**
- `(target_type, target_id)` — buscar ações de um objeto
- `(user_id)` — buscar ações de um usuário

**Atenção:** Não há Foreign Keys — `action_log` referencia qualquer tabela via `target_type` + `target_id` (referência loose).

### 6.2 `tbl_audit_log` (Segurança / Compliance)

Log de segurança imutável, populado pelos **commands Rust dedicados** (não pelo ActionRegistry):

| Campo | Descrição |
|-------|-----------|
| `actor_id` / `actor_perfil` | Quem executou |
| `action` | Nome da ação (ex: `suite.approve`) |
| `target_table` / `target_id` | O que foi afetado |
| `old_value` / `new_value` | Valores antes/depois |

Cada inserção gera um evento `audit.registro` na `sync_event_queue`, enviado criptografado à nuvem pelo `TransportService`.

---

## 7. Padrões e Regras

1. **`aplicarMapeamento` é função pura exportada** — não é método, não é chamada dentro do handler
2. **`handler` não usa `this`** — é arrow function sem acesso ao `ActionButtonConfig` pai
3. **O `ActionBar` chama `aplicarMapeamento` e injeta em `ctx.input` antes de chamar o handler**
4. **`initializeActions()` existe e é chamada no boot** após `getContainerAsync()`
5. **`action_log` é criado na migration** — não adiado
6. **`dataSource` no widget usa `useCaseGroup` + `method`** — não `keyof UseCasesContainer`
7. **Ações não fazem mutações diretas no SQLite** — delegam a commands Rust dedicados (`suite_approve`, `demanda_aceitar`, etc.) que validam sessão + RBAC
8. **Widgets não publicam eventos** — apenas leem dados via use case
9. **Nenhum componente React importa diretamente um use case** — sempre via hook
10. **Eventos publicados seguem nomes canônicos** — sem variações
11. **`requiredRoles` usa strings (`UserRole`), não números**
12. **`evaluateVisibilityRules` é a função real (13 operadores)**

---

*Documento criado em 2026-04-29. Atualizado conforme implementação real em `src/application/actions/` e `src/application/widgets/`.*
