# EcoSuite (ecoformsnext) — Documentação

> Gerada por engenharia reversa (Reversa) em 2026-04-30 + curadoria manual.
> Confiança geral: **82%** (ver `confidence-report.md`).

---

## Visão Geral

**EcoSuite** é um sistema de formulários ecológicos offline-first para a Prefeitura de Florianópolis, composto por dois aplicativos:

| App | Stack | Público |
|---|---|---|
| **Mobile PWA** | Vanilla JS + Alpine.js + Capacitor 8 | Fiscais de campo |
| **Desktop Admin** | Next.js 16 + React 19 + Tauri 2 | Gerentes / administradores |

**Backend cloud:** Supabase (Auth, PostgreSQL, Storage, Realtime)
**Bancos locais:** SQLite (Tauri/rusqlite) e IndexedDB (browser)

---

## Índice da Documentação

### Arquitetura e Visão Geral

| Documento | Conteúdo |
|---|---|
| [`inventory.md`](inventory.md) | Inventário completo — estrutura, linguagens, frameworks, entry points |
| [`dependencies.md`](dependencies.md) | Dependências com versões (3 package.json + Cargo.toml) |
| [`architecture.md`](architecture.md) | Visão arquitetural, containers, padrões, dívidas técnicas |
| [`c4-context.md`](c4-context.md) | Diagrama C4 — Nível 1 (Contexto) |
| [`c4-containers.md`](c4-containers.md) | Diagrama C4 — Nível 2 (Containers) |
| [`c4-components.md`](c4-components.md) | Diagrama C4 — Nível 3 (Componentes do Desktop) |

### Domínio e Regras de Negócio

| Documento | Conteúdo |
|---|---|
| [`domain.md`](domain.md) | Glossário, regras de negócio, decisões arquiteturais, lacunas 🔴 |
| [`state-machines.md`](state-machines.md) | Máquinas de estado (Task 4 estados, Suite 11 estados, Demanda 4 estados) |
| [`permissions.md`](permissions.md) | Matriz RBAC — 6 perfis hierárquicos, filtros SQL por perfil |
| [`code-analysis.md`](code-analysis.md) | Análise profunda de 11 módulos (client, task, demanda, suite, sync, etc.) |
| [`data-dictionary.md`](data-dictionary.md) | Schema completo — tabelas SQLite, colunas, tipos, DTOs |
| [`erd-complete.md`](erd-complete.md) | Diagrama Entidade-Relacionamento em Mermaid |

### Especificações Executáveis (SDD)

| Documento | Módulo |
|---|---|
| [`sdd/client.md`](sdd/client.md) | Gestão de clientes PJ — CRUD, soft-delete, auditoria, FTS5 |
| [`sdd/task.md`](sdd/task.md) | Tarefas kanban — state machine, recorrência, ordenação |
| [`sdd/demanda.md`](sdd/demanda.md) | Demandas — workflow, auto-aceite, event sourcing, transações |
| [`sdd/suite.md`](sdd/suite.md) | Suite Package — 11 estados, versionamento, lock/unlock |
| [`sdd/sync.md`](sdd/sync.md) | Sync engine — offline-first, EventBus, 8 handlers, crypto |
| [`sdd/auth-mobile.md`](sdd/auth-mobile.md) | AuthManager mobile — Supabase + fallback JSON, bcrypt, heartbeat |
| [`sdd/data-service.md`](sdd/data-service.md) | DataService mobile — IndexedDB, compressão, sync lock |
| [`sdd/access-rbac.md`](sdd/access-rbac.md) | Controle de acesso — hierarquia, filtros SQL dinâmicos |
| [`sdd/field-system.md`](sdd/field-system.md) | Sistema de campos — FieldFactory, 53+ tipos, ciclo de vida |

### Fluxogramas

| Documento | Conteúdo |
|---|---|
| [`flowcharts/client.md`](flowcharts/client.md) | Fluxos CRUD, upsert, FTS5, soft-delete |
| [`flowcharts/task.md`](flowcharts/task.md) | Criação, transição, recorrência, soft-delete |
| [`flowcharts/demanda.md`](flowcharts/demanda.md) | Auto-aceite, AcceptDemanda transacional, Close com política |

### User Stories e Rastreabilidade

| Documento | Conteúdo |
|---|---|
| [`user-stories/principais-fluxos.md`](user-stories/principais-fluxos.md) | 7 fluxos de usuário com critérios Gherkin |
| [`traceability/code-spec-matrix.md`](traceability/code-spec-matrix.md) | Matriz código × spec — ~60% de cobertura |
| [`traceability/spec-impact-matrix.md`](traceability/spec-impact-matrix.md) | Matriz de impacto entre módulos |

### Revisão e Qualidade

| Documento | Conteúdo |
|---|---|
| [`confidence-report.md`](confidence-report.md) | Relatório de confiança — 82% geral, por spec, reclassificações |
| [`gaps.md`](gaps.md) | Lacunas — 2 críticas, 5 moderadas, 2 cosméticas |
| [`questions.md`](questions.md) | 6 perguntas validadas com stakeholder |

### ADRs (Architecture Decision Records)

| Documento | Conteúdo |
|---|---|
| [`adrs/001-unificacao-ecoponto.md`](adrs/001-unificacao-ecoponto.md) | Unificação EcoForms + Ecoponto App |
| [`adrs/002-tauri-migration.md`](adrs/002-tauri-migration.md) | Migração Electron → Tauri 2 |
| [`adrs/003-sync-phases.md`](adrs/003-sync-phases.md) | Sincronização offline-first em 5 fases |
| [`../plans/adr-evolucao-plataforma.md`](../plans/adr-evolucao-plataforma.md) | AD-009 a AD-024 — evolução para plataforma |
| [`../plans/implementacao-fases-3-6.md`](../plans/implementacao-fases-3-6.md) | Plano de implementação das fases 3 a 6 |

### Documentos Artesanais (mantidos)

| Documento | Conteúdo |
|---|---|
| [`action-widget-system.md`](action-widget-system.md) | ActionRegistry + WidgetRegistry (embrião da plataforma) |
| [`deployment.md`](deployment.md) | Build Android (Capacitor) e Tauri desktop |
| [`test-strategy.md`](test-strategy.md) | Estratégia de testes — Vitest, cobertura, benchmarks |

### Documentos Legados

Documentação artesanal pré-Reversa, substituída pelos arquivos acima.

[`legacy/obsoleto-2026-04-30/`](legacy/obsoleto-2026-04-30/)

Contém: `adr.md`, `api-contract.md`, `arquitetura.md`, `data-flow.md`, `data-system.md`, `database.md`, `diagrams.md`, `error-handling.md`, `event-envelope-v2.md`, `event-protocol.md`, `fields.md`, `form-builder.md`, `hooks.md`, `modules.md`, `performance-limits.md`, `security.md`, `supabase-integration.md`, `sync-bucket-audit.md`, `ui-flow.md` e outros.

---

## Guia de Navegação por Perfil

### Sou desenvolvedor (backend ou frontend)
1. [`inventory.md`](inventory.md) — entenda o que existe
2. [`architecture.md`](architecture.md) + [`c4-containers.md`](c4-containers.md) — visão arquitetural
3. [`code-analysis.md`](code-analysis.md) — mergulhe nos 11 módulos
4. [`sdd/`](sdd/) — specs executáveis de cada módulo
5. [`data-dictionary.md`](data-dictionary.md) — schema do banco
6. [`erd-complete.md`](erd-complete.md) — relacionamentos

### Sou QA / Testador
1. [`test-strategy.md`](test-strategy.md) — estratégia atual
2. [`sdd/`](sdd/) — critérios de aceitação Gherkin por módulo
3. [`gaps.md`](gaps.md) — lacunas conhecidas
4. [`user-stories/principais-fluxos.md`](user-stories/principais-fluxos.md) — fluxos de teste

### Sou Arquiteto / Tech Lead
1. [`adrs/`](adrs/) + [`../plans/adr-evolucao-plataforma.md`](../plans/adr-evolucao-plataforma.md) — decisões arquiteturais
2. [`c4-context.md`](c4-context.md) → [`c4-containers.md`](c4-containers.md) → [`c4-components.md`](c4-components.md)
3. [`state-machines.md`](state-machines.md) — máquinas de estado
4. [`permissions.md`](permissions.md) — matriz RBAC
5. [`confidence-report.md`](confidence-report.md) — qualidade das specs
6. [`traceability/`](traceability/) — rastreabilidade código × spec

### Sou DevOps
1. [`deployment.md`](deployment.md) — build e distribuição
2. [`dependencies.md`](dependencies.md) — versões de todos os pacotes
3. [`gaps.md`](gaps.md) — dívidas técnicas operacionais

---

## Glossário Rápido

| Termo | Significado |
|---|---|
| **Suite Package** | Formulário submetido versionado (`tbl_suite`) — unidade central de dados |
| **Ghost Task** | Tarefa criada automaticamente a partir de submissão ad hoc |
| **Demanda** | Solicitação de trabalho entre setores com workflow e event sourcing |
| **Ecoponto** | Local de coleta/descarte de resíduos |
| **Inbox** | Caixa de entrada — formulários pendentes de revisão |
| **Sync Bucket** | Bucket Supabase Storage (`sync-bucket`) usado como canal de sincronização |
| **EventBus** | Barramento de eventos que gerencia `sync_event_queue` |
| **CryptoLayer** | Criptografia AES-256-GCM + PBKDF2 para envelopes de sync |
| **RLS** | Row Level Security — políticas Supabase dual-auth (anon + authenticated) |
| **RBAC** | Role-Based Access Control — 6 perfis hierárquicos |
| **Clean Architecture** | Domain → Application → Infrastructure → Interface |
| **LWW + Hash** | Last-Write-Wins com checksum — resolução de conflitos |

---

## Changelog

| Data | Evento |
|---|---|
| 2026-04-30 | Documentação gerada por engenharia reversa (Reversa 1.2.14). 20+ arquivos em 5 fases. Confiança 82%. |
| 2026-04-30 | `_reversa_sdd/` unificado em `docs/`. Documentos artesanais obsoletos movidos para `legacy/obsoleto-2026-04-30/`. |
| 2026-04-30 | README reescrito para refletir nova estrutura unificada. |

---

**EcoSuite** — Gestão operacional offline-first para Prefeitura de Florianópolis.
