# C4 — Diagrama de Componentes (Nível 3) — Desktop Admin

> Architect — 2026-04-30 | 🟢 CONFIRMADO

```mermaid
C4Component
    title Componentes — Desktop Admin

    Container_Boundary(desktop, "Desktop Admin (Next.js + Tauri)") {
        
        Component(ui, "React UI", "Next.js Pages, Radix UI, Tailwind 4", "Interface do usuário: dashboards, kanban, formulários, gestão")
        
        Component(hooks, "React Hooks", "useQuery, useMutation, useSQLiteQuery", "Camada de interface: conecta UI aos use cases via TanStack Query")
        
        Component(usecases, "Use Cases", "58+ classes TypeScript", "Lógica de aplicação: CreateClient, AcceptDemanda, MoveTask, etc.")
        
        Component(domain, "Domain", "Entidades + Value Objects + Repository Interfaces", "Client, Task, Demanda, SuitePackage, Protocolo + máquinas de estado")
        
        Component(repos, "Repositories (SQLite)", "Sqlite*Repository", "Implementações concretas de persistência em SQLite via SqlitePort")
        
        Component(sync, "Sync Engine", "EventBus, EventEnvelope, HandlerRegistry, TransportService, InboundService, CryptoLayer", "Sincronização offline-first com Supabase Storage. 8 handlers registrados.")
        
        Component(access, "Access Control", "AccessPolicy + AccessFilterBuilder", "RBAC: geração de cláusulas SQL por perfil. 6 níveis hierárquicos.")
        
        Component(tauri_rs, "Tauri Rust Backend", "main.rs, rusqlite, plugins", "Shell nativo: SQLite bundado, bcrypt, AES-GCM, file system")
        
        Component(container, "DI Container", "buildContainer()", "Injeção de dependências. Suporta overrides para testes com fakes InMemory.")
    }

    System_Ext(supabase, "Supabase")
    
    Rel(ui, hooks, "Chama hooks", "React")
    Rel(hooks, usecases, "Invoca use cases", "TS")
    Rel(usecases, domain, "Usa entidades", "TS")
    Rel(usecases, repos, "Persiste via interface", "TS")
    Rel(repos, tauri_rs, "SqlitePort.query/execute", "IPC Tauri")
    Rel(sync, supabase, "pushPending/pull", "HTTPS/REST")
    Rel(sync, repos, "Lê/escreve eventos", "EventBus")
    Rel(access, repos, "Filtros SQL por perfil", "TS")
    Rel(container, usecases, "Instancia", "DI")
```
