# ERD Completo — ecoformsnext

> Architect — 2026-04-30 | 🟢 CONFIRMADO

---

## Banco de Dados: SQLite (Desktop / Tauri)

```mermaid
erDiagram
    tblPJuridicas ||--o{ tblContatos : "idPJ"
    tblPJuridicas }o--|| tblPJtipo : "idPJtipo"
    tblContatos }o--|| tblPFisicas : "idPF"
    tblPJuridicas ||--o{ tblRotas : "idPJ"
    tblRotas }o--|| tblRoteiros : "idRoteiro"
    tblRoteiros ||--o{ tblColetas : "idRoteiro"
    tblColetas }o--|| tblPJuridicas : "idPJ"
    tbl_demandas ||--o{ tbl_tarefas : "demanda_id FK"
    tbl_demandas ||--o{ tbl_demanda_eventos : "demanda_id"
    tbl_tarefas ||--o{ tbl_tarefa_formularios : "tarefa_id"
    tbl_tarefas }o--o{ tbl_suite : "tbl_suite_id"
    tbl_suite ||--o{ tbl_suite_history : "package_id"
    tbl_usuarios ||--o{ tbl_tarefas : "criado_por / atribuido_para"
    tbl_usuarios ||--o{ tbl_usuarios_setores : "usuario_id"

    tblPJuridicas {
        int id_legacy PK
        text Cliente
        text CNPJ
        text Inativo
        int idPJtipo FK
    }

    tblPJtipo {
        int idPJtipo PK
        text Tipo_de_PJ
    }

    tblPFisicas {
        int idPF PK
        text Nome
    }

    tblContatos {
        int idContato PK
        int idPJ FK
        int idPF FK
        text Cargo
    }

    tblRoteiros {
        int idRoteiro PK
        text nome
        text tipoResiduo
        text periodicidade
    }

    tblRotas {
        int idRota PK
        int idPJ FK
        int idRoteiro FK
        int ordem
    }

    tblColetas {
        int idColeta PK
        int idRoteiro FK
        int idPJ FK
        text dataColeta
        text status
    }

    tbl_demandas {
        text id PK "UUID"
        text origem_tipo
        text solicitante_id
        text destinatario_id
        text status
        text politica_conclusao
        boolean auto_aceite
    }

    tbl_demanda_eventos {
        text id PK
        text demanda_id FK
        text type
        text correlation_id
        text causation_id
        text payload "JSON"
    }

    tbl_tarefas {
        text id PK "UUID"
        text projeto_id
        text titulo
        text status
        text prioridade
        text atribuido_para
        int ordem
        text demanda_id FK
        text tbl_suite_id FK
        text deletado_em
    }

    tbl_tarefa_formularios {
        text id PK
        text tarefa_id FK
        text form_registry_id
        int form_version
        text form_snapshot "JSON"
        int ordem
        boolean obrigatorio
        boolean concluido
    }

    tbl_suite {
        text package_id PK
        int version_no
        text status
        text owner_id
        boolean is_current
        text locked_by
        text payload_json
    }

    tbl_suite_history {
        text package_id FK
        int version_from
        int version_to
        text status_anterior
        text status_novo
        text alterado_por
    }

    tbl_usuarios {
        text id PK
        text nome
        text username
        text perfil
        boolean ativo
    }

    tbl_usuarios_setores {
        text usuario_id FK
        text setor_id FK
    }
```

---

## Banco de Dados: IndexedDB (Mobile / Browser)

| Store | Versão | Índices | Propósito |
|---|---|---|---|
| `formSubmissions` | v3 | `uuid` (unique), `status`, `timestamp` | Submissões offline de formulários |
| `sync-events` | — | `id`, `status` | Eventos pendentes de sincronização |

---

## Banco de Dados: Supabase PostgreSQL (Cloud)

| Schema | Tabela | Propósito |
|---|---|---|
| `auth` | `users` | Autenticação Supabase (email/senha) |
| `public` | `profiles` | Perfis de usuário (espelho de auth.users via trigger) |
| `storage` | `objects` (bucket: `sync-bucket`) | Arquivos JSON de sincronização (eventos, forms, dados) |
| `storage` | `policies` | RLS dual-auth (anon + authenticated) |
