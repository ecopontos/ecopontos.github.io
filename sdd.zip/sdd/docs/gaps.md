# Lacunas (Gaps) — ecoformsnext

> Revisor — 2026-04-30

---

## 🔴 Críticas (bloqueiam implementação confiável)

> Nenhuma — G-01 e G-02 implementados em 2026-04-30.

## 🟡 Moderadas (importantes mas com workaround)

> Nenhuma — todas as lacunas 🟡 foram resolvidas ou são cosméticas.

## 🟢 Cosméticas (não bloqueiam)

| # | Lacuna | Spec |
|---|---|---|
| G-09 | Tailwind duplicado v3 (mobile) + v4 (desktop) | `architecture.md` |

---

## ✅ Resolvidas

| # | Lacuna | Resolução | Data |
|---|---|---|---|
| G-01 | Rate limiting no sync não definido | `TransportService`: `TokenBucketRateLimiter` (burst=5, 2 req/s) + BATCH_SIZE=50 + retry×2 com backoff | 2026-04-30 |
| G-02 | Sem mecanismo de expurgo de eventos no outbox | `EventBus.purgeOldSentEvents(30)` + `purgeOldFailedEvents(7)` adicionados (TS+JS); chamados automaticamente após push | 2026-04-30 |
| G-05 | Permissão `tasks.reassign` não documentada na matriz | Linha adicionada em `docs/permissions.md` e `_reversa_sdd/permissions.md`; 6 testes cobrindo todos os perfis | 2026-04-30 |
| G-06 | AuthManager e DataService sem cobertura de testes | `tests/auth-manager.test.js` (19 testes) + `tests/data-service.test.js` (10 testes); 29/29 ✅ | 2026-04-30 |
| G-07 | Sync engine duplicado (TS + JS) com lógica espelhada | Headers `// ⚠️ ESPELHO de ...` nos 8 arquivos JS; `tests/sync-contract.test.ts` com 6 assertions | 2026-04-30 |
| G-08 | Stubs não implementados em `useClientMutations` | Stubs `createPF`, `updatePF`, `linkContact`, `unlinkContact` removidos | 2026-04-30 |
| G-04 | Reativação de cliente sem use case na UI | `ToggleClientActiveUseCase` criado; `Client.toggleActive()` exposto como use case | 2026-04-30 |
| G-03 | IDs inconsistentes (Date.now vs UUID) | Migração completa: coluna `uuid TEXT` + backfill + `crypto.randomUUID()` no `CreateClientUseCase`; 28 arquivos alterados em todas as camadas | 2026-04-30 |
