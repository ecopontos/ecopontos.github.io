# Sistema de Dados — EcoForms Desktop

Este documento descreve a arquitetura de dados do EcoForms Desktop, incluindo tipos, modelos de domínio, portas de aplicação, serviços de sincronização e schemas de sincronização.

---

## Índice

1. [Modelo de Dados (Tipos)](#1-modelo-de-dados-tipos)
2. [Portas de Aplicação (Contracts)](#2-portas-de-aplicação-contracts)
3. [Camada de Normalização / Wrappers](#3-camada-de-normalização--wrappers)
4. [Serviço de Sincronização Supabase](#4-serviço-de-sincronização-supabase)
5. [Storages e Managers Auxiliares](#5-storages-e-managers-auxiliares)
6. [Tabelas Dimensão (dim_*)](#6-tabelas-dimensão-dim_)
7. [Sistema Offline](#7-sistema-offline)
8. [Controle de Acesso](#8-controle-de-acesso)
9. [Utilitários de Dados](#9-utilitários-de-dados)

---

## 1. Modelo de Dados (Tipos)

### `types/index.ts` — Tipos Canônicos

**`SuiteStatus`** — Status de pacote na `tbl_suite` (contrato v2):
```
draft → current → edit → locked → dispatched → pending_review → refuted → superseded → closed
                                     ↘ approved → rejected ↗
```

**`TblSuitePackage`** — Registro canônico da tbl_suite v2:
```ts
interface TblSuitePackage {
    package_id: string
    version_no: number
    module_type: string       // tipo do formulário (ex: 'ecopontoCaixasForm')
    resource_type: string     // 'form' | 'solicitacao' | ...
    status: SuiteStatus
    owner_id: string | null
    is_current: number       // 1 = vigente, 0 = histórico
    locked_by: string | null
    locked_at: string | null
    ref_package_id: string | null
    ref_package_ver: number | null
    payload_json: string      // JSON serializado
    created_at: string
    closed_at: string | null
}
```

**`FormContent`** — Estrutura de template de formulário:
```ts
interface FormContent {
    id: string
    titulo: string
    campos: FormField[]
    layout?: { columns: 1|2|3|4, gap?: 'sm'|'md'|'lg' }
}
```

**`FormField`** — Campo de formulário com suporte a:
- Visibilidade condicional (`visibility?: VisibilityRule[]`)
- Habilitação condicional (`enabled?: VisibilityRule[]`)
- Variantes de tipo (`typeVariants?: TypeVariantRule[]`)
- Campos aninhados (`campos?: FormField[]`) para grupos/repeatable groups
- Dependência entre campos (`dependency?: { fieldId, filterProperty }`)

**`KanbanTask`** — Tarefa do Kanban com:
- Hierarquia: `parent_task_id`, `container_task_id`, `cycle_id`, `depends_on_task_id`
- Snapshot freeze: `snap_version`, `snap_hash`, `snap_frozen_at`
- Payload flexível com `dateConfig` para configuração de prazos

**`UnifiedTaskView`** — View unificada para display no Kanban (estende KanbanTask com dados de JOIN)

**`VisibilityOperator`** — Operadores de regra de visibilidade:
```
eq | neq | gt | gte | lt | lte | contains | startsWith | endsWith | in | notIn | empty | notEmpty
```

---

### `types/clients.ts` — Módulo de Clientes

| Tipo | Descrição |
|------|-----------|
| `PessoaJuridica` | Registro PJ (tblPJuridicas) |
| `PessoaFisica` | Registro PF (tblPFisicas) |
| `PessoaJuridicaDetalhada` | PJ com JOINs de tipo, CEP e contatos |
| `ContatoDetalhado` | Pessoa física vinculada como contato |
| `PJTipo` | Tipo de pessoa jurídica (tblPJtipo) |
| `CEPData` | Dados de CEP (tblCEP) |
| `AuditLog` | Histórico de alterações de PJ |

---

### `types/crm.ts` — Módulo CRM

| Tipo | Descrição |
|------|-----------|
| `Roteiro` | definitions de roteiro (tblRoteiros) |
| `Rota` | Vinculação roteiro ↔ cliente (tblRotas) |
| `Coleta` | Registro de coleta (tblColetas) |
| `DetalheSatelite` | Detalhes da coleta (tblDetalhesSatelite) |
| `ClienteComRoteiros` | PJ agrupada com roteiros |
| `RotaDetalhada` | Rota com dados do roteiro expandidos |
| `ColetaDetalhada` | Coleta com detalhes e tipo de problema |

---

### `types/ouvidoria.ts` — Módulo Ouvidoria

| Tipo | Descrição |
|------|-----------|
| `Protocolo` | Registro de protocolo (tblProtocolo) |
| `ProtocoloEvento` | Evento/andamento (tblProtocoloEventos) |
| `Atendimento` | Atendimento do protocolo (Atendimento) |
| `ProtocoloAssunto` | Tema (tblProtocoloAssunto) |
| `ProtocoloSubtema` | Subtema (tblProtocoloSubtema) |
| `Mensagem` | Template de mensagem (tblMensagens) |

---

## 2. Portas de Aplicação (Contracts)

### `SqlitePort`
```ts
interface SqlitePort {
    query<T>(sql: string, params?: unknown[]): Promise<T[]>
    execute(sql: string, params?: unknown[]): Promise<void>
    transaction<T>(callback: () => Promise<T>): Promise<T>
}
```
**Implementação:** `src/infrastructure/persistence/` → `SQLiteDBWrapper`

---

### `SyncPort`
```ts
interface SyncPort {
    syncAll(options?: { forcePush?: boolean }): Promise<SyncResult>
    pushTasks(): Promise<void>
    pullTasks(): Promise<void>
    getOfflineQueueSize(): Promise<number>
    processOfflineQueue(): Promise<{ processed: number; failed: number }>
}
```

**SyncResult** retorna contagem por tabela:
```ts
synced: {
    form_registry, data_registry, tbl_suite_push, tbl_suite_pull,
    tbl_usuarios, projects_push, projects_pull,
    tasks_push, tasks_pull, task_snaps_push, ecoponto_state_push
}
```

---

### `StorageSyncPort`
```ts
interface StorageSyncPort {
    push(data, syncType, filenameBase?, folder?, compress?): Promise<void>
    pull(customPath?): Promise<PulledSnapshot[]>
    downloadFile(path): Promise<Blob | null>
    listFiles(prefix): Promise<StoredFileEntry[]>
    moveToArchive(filename, sourcePath?): Promise<void>
    movePath(fromPath, toPath): Promise<void>
    validateSnapshot(blob, options?): Promise<SyncSnapshot>
}
```
**Implementação legada:** `src/infrastructure/sync/StorageSync.ts` — não instanciado atualmente. O sync ativo usa `EventSyncAdapter`.

**Mobile / PWA (www/):** O pipeline de eventos é idêntico ao desktop, implementado em `www/js/sync/`:
- `CryptoLayer.js` — PBKDF2 key derivation + AES-GCM via Web Crypto API
- `EventBus.js` — IndexedDB-backed (SyncEventDB)
- `TransportService.js`, `InboundService.js`, `Manifest.js`, `SyncBootstrap.js`, `HandlerRegistry.js`, `SyncAdapter.js`
- Integração: `AuthManager.login()` inicia `SyncAdapter`, `DataService.saveFormData()` publica eventos via `_publishFormEvent()`

---

### `FileStoragePort`
```ts
interface FileStoragePort {
    upload(bucket, path, data, contentType?): Promise<StoredFile>
    download(bucket, path): Promise<Blob>
    remove(bucket, paths): Promise<void>
    list(bucket, prefix?): Promise<string[]>
    getPublicUrl(bucket, path): string
}
```

---

### `LoggerPort` e `ClockPort`
Contratos minimalistas para injeção de dependência (logging e tempo).

---

## 3. Camada de Normalização / Wrappers

### `SQLiteDBWrapper`
Wrapper adaptável que abstrai diferentes adaptadores de SQLite (Tauri, mobile, etc.).

```ts
class SQLiteDBWrapper {
    exec(sql, params?): Promise<void>
    all<T>(sql, params?): Promise<T[]>
    execute(sql, params?): Promise<void>     // alias
    query<T>(sql, params?): Promise<T[]>     // alias
    get<T>(sql, params?): Promise<T | undefined>
    beginTransaction(): Promise<void>
    commit(): Promise<void>
    rollback(): Promise<void>
    transaction<T>(callback): Promise<T>     // automático: BEGIN + COMMIT / ROLLBACK
}
```

**Driver adapter:**
```ts
interface DBAdapter {
    exec(sql: string, params?: any[]): Promise<any>
    all<T = any>(sql: string, params?: any[]): Promise<T[]>
}
```

---

## 4. Serviço de Sincronização Supabase (Event-Driven v2)

### `EventSyncAdapter` (`src/infrastructure/sync/EventSyncAdapter.ts`)

**Arquitetura:** Pure Storage Mode — sem dependência de tabelas Supabase, apenas Supabase Storage (arquivos criptografados no bucket `sync-bucket`). Eventos são publicados via `EventBus`, persistidos em `sync_event_queue` (SQLite), e transmitidos via `TransportService`/`InboundService` com criptografia AES-256-GCM.

> **REGRA FUNDAMENTAL**: Todo o trânsito de dados entre dispositivos ocorre exclusivamente via Supabase Storage. Nunca acessar tabelas PostgreSQL diretamente via `supabase.from()`.

```
Setor A (SQLite) ──push──▶ Supabase Storage ──pull──▶ Setor B (SQLite)
                 eventos/{routingId}/...enc
```

**Paths no Supabase Storage (sync-bucket):**
| Path | Conteúdo |
|------|----------|
| `eventos/{routingId}/evt_{seq}_{id}.enc` | Envelope criptografado (AES-256-GCM) |
| `eventos/{routingId}/lote_{id}.tgz.enc` | Lote compactado criptografado |
| `shared/manifests/manifest_{routingId}.json` | Manifesto individual por setor |
| `shared/org_config.json` | Configuração da organização (sem criptografia) |

### Identidade de Roteamento

**Separação entre identidade de auditoria e identidade de roteamento:**

| Contexto | Roteamento (pasta) | Auditoria (envelope) |
|----------|---------------------|----------------------|
| Desktop | `setor_id` (estável) | `device_id` (UUID instalação) |
| Mobile  | `user_id` (estável) | `device_id` (UUID instalação) |

O `routingId` é o `setor_id` do usuário autenticado — não é gerado localmente. Isso garante que uma reinstalação do app (novo `device_id`) não cria pasta órfã no Storage.

**Tabelas SQLite de suporte:**

| Tabela | Propósito |
|--------|-----------|
| `sync_event_queue` | Fila de eventos pendentes (id, type, payload JSON, seq, status) |
| `sync_device_log` | Log de sequência por routing_id (device_id=setor_id, seq, event_id, acked) |

**Fluxo `syncAll()`:**
1. Push: `TransportService.pushPending()` — envia pending events em ordem de seq
2. Pull: `InboundService.pull(knownRoutingIds)` — baixa e dispatcheia eventos de outros setores
3. Manifest: Atualizado com último seq após push bem-sucedido

### Componentes da Camada de Sync

| Componente | Arquivo | Responsabilidade |
|------------|---------|------------------|
| `EventBus` | `sync/EventBus.ts` | Publicação de eventos, registro de handlers inbound, dispatch |
| `EventEnvelope` | `sync/EventEnvelope.ts` | Tipo do envelope v2 (source com routing_id, checksum SHA-256) |
| `TransportService` | `sync/TransportService.ts` | Push de envelopes para Storage (path por routingId) |
| `InboundService` | `sync/InboundService.ts` | Pull de envelopes de outros setores, dispatch local |
| `Manifest` | `sync/Manifest.ts` | Manifesto por routing_id para tracking de sequência |
| `CryptoLayer` | `sync/CryptoLayer.ts` | AES-256-GCM via Tauri Rust (chave no State, sem IPC) |
| `OrgConfigService` | `sync/OrgConfigService.ts` | Carrega/cacheia shared/org_config.json |
| `HandlerRegistry` | `sync/HandlerRegistry.ts` | Registra handlers de todos os módulos no EventBus |

### Handlers Inbound

Cada tipo de evento tem um handler idempotente registrado:

| Módulo | Eventos |
|--------|---------|
| **Demanda** | `demanda.criada`, `demanda.aceita`, `demanda.encerrada`, `demanda.tarefa.criada` |
| **CRM** | `crm.cliente.criado`, `crm.cliente.atualizado`, `crm.coleta.registrada` |
| **Ouvidoria** | `ouvidoria.protocolo.aberto`, `.encaminhado`, `.encerrado`, `.evento.adicionado` |
| **Form Registry** | `form_registry.atualizado` |
| **Data Registry** | `data_registry.atualizado` |
| **Usuário** | `usuario.criado`, `usuario.atualizado` |
| **Org Config** | `org.config.atualizado` |

Handlers usam `INSERT OR IGNORE` / `INSERT OR REPLACE` para idempotência — eventos podem chegar fora de ordem devido a gaps de rede.

### Pré-requisito: org_config.json

O arquivo `shared/org_config.json` deve existir no Supabase Storage antes do primeiro boot. Ele define os setores ativos da organização e é a única fonte de verdade para roteamento entre setores. Sem ele, apenas o push local funciona — o pull de outros setores não estará disponível.

```json
{
  "org_id": "ecoforms-org-001",
  "org_nome": "Secretaria de Meio Ambiente",
  "setores": [
    { "id": "setor-coleta", "nome": "Coleta de Resíduos", "ativo": true },
    { "id": "setor-edu-ambiental", "nome": "Educação Ambiental", "ativo": true }
  ],
  "updated_at": "2026-04-27T10:00:00Z"
}
```

---

---

## 5. Storages e Managers Auxiliares

### `StorageSync` (`src/infrastructure/sync/StorageSync.ts`)

> **Legado — não instanciado atualmente.** O sistema ativo usa `EventSyncAdapter` com envelopes criptografados (`.enc`).

**Métodos principais (quando ativo):**

| Método | Descrição |
|--------|-----------|
| `createSnapshot()` | Cria snapshot com checksum SHA-256 e metadata |
| `validateSnapshot()` | Valida checksum e contagem, tenta recovery em caso de falha |
| `push()` | Upload de snapshot para Supabase Storage |
| `pull()` | Download + validação de todos os snapshots da inbox |
| `syncShared()` | Baixa arquivos compartilhados (form_registry, data_registry, etc.) |
| `moveToArchive()` | Move arquivo processado para `archive/YYYY-MM/` (com verificação) |
| `cleanupArchive()` | Remove arquivos com mais de N dias do archive |

**Paths legados no Supabase Storage (sync-bucket):**
```
shared/form_registry.json          — Formulários compartilhados
shared/form_field_registry.json    — Campos dos formulários
shared/data_registry.json          — Dados de referência
shared/users.json                  — Usuários compartilhados
shared/tbl_suite.json              — Submissões de formulários
shared/ecoponto_caixas.json        — Dados de ocupação das caixas
users/{deviceId}/outbox/           — Desktop envia aqui
users/{deviceId}/inbox/            — Runtime baixa daqui
archive/YYYY-MM/                   — Arquivo mensal
```

> **IMPORTANTE**: O sistema ativo usa Event Envelope v2 criptografado (AES-256-GCM), não JSON puro. Os paths legados acima são mantidos para referência futura (sync mobile).

---

### `ColumnSchemaManager` (`src/infrastructure/sync/ColumnSchemaManager.ts`)

Helpers para migrações de schema SQLite. O mecanismo principal de migração runtime está em `scripts/ensure-columns.ts` (web/PWA fallback) e em `database.rs` (migrações Rust no boot do Tauri).

```ts
// Helpers existentes (uso parcial)
detectMissingColumns(table)   // verifica colunas ausentes via PRAGMA table_info
addColumn(table, column, type) // executa ALTER TABLE ADD COLUMN
```

Cache em memória por tabela para evitar consultas repetidas a `PRAGMA table_info`.

---

## 6. Tabelas Dimensão (dim_*)

### `DimensionSyncService`

> **Não implementado.** Não existe arquivo correspondente no código.
>
> O sync de dados de referência (`data_registry`) é feito via `EventSyncAdapter` (eventos de domínio `data_registry.criado`, `data_registry.atualizado`) ou diretamente via `SupabaseFileStorage` para arquivos compartilhados.

---

## 7. Sistema Offline

### `OfflineQueue` (`src/infrastructure/sync/OfflineQueue.ts`)

Fila de mutações pendentes em `localStorage`.

```ts
class OfflineQueue {
    enqueue(sql: string, params: any[], label?: string): void
    size(): number
    processAll(execFn): Promise<{ processed: number; failed: QueuedMutation[] }>
    clear(): void
    peek(): QueuedMutation[]
}
```

**Características:**
- Armazenada no `localStorage` (chave `ecosuite-offline-queue`)
- Máximo de 3 tentativas por mutação
- Ordenação cronológica (FIFO)
- Quebra em falha (não processa o restante da fila)

**Schema IndexedDB:**
```ts
interface QueuedMutation {
    id: string
    sql: string
    params: any[]
    timestamp: number
    retryCount: number
    label?: string
}
```

---

## 8. Controle de Acesso

### `src/infrastructure/persistence/AccessFilterBuilder.ts`

Camada de filtros de acesso SQL que delega para `src/domain/access/AccessPolicy.ts`.

**Helpers SQL:**

| Função | Retorno |
|--------|--------|
| `getAccessiblePerfis(perfil)` | Perfis acessíveis a partir de um perfil |
| `isAdmin(perfil)` | Boolean |
| `isManagerOrAbove(perfil)` | Boolean |
| `canAccessUserData(userId, perfil, targetUserId)` | Boolean |
| `buildTaskAccessFilter(userId, perfil)` | `{ clause, params }` |
| `buildRecordAccessFilter(userId, perfil)` | `{ clause, params }` |
| `buildInboxAccessFilter(userId, perfil)` | `{ clause, params }` |

**Filtros geram WHERE clauses SQL parametrizadas para:
- Tarefas: `criado_por = ? OR atribuido_para = ? OR u_criador.perfil IN (...)`
- Registros suite: `owner_id = ? OR u.perfil IN (...)`
- Inbox: filtro por departmento para gerentes

---

## 9. Utilitários de Dados

### `src/domain/task/TaskRecurrence.ts`
- `calculateNextOccurrence()` — calcula próxima ocorrência de tarefa recorrente
- `normalizeStatus()` — normaliza strings de status para forma canônica

### `src/lib/registry-schema.ts`
- `detectSchemaFromItems()` — infere schema de campo a partir de itens existentes do data_registry
- `flattenRegistryItems()` — achata objetos conteudo para colunas de export/tabela
- `similarityScore()` — similaridade entre strings para auto-mapping CSV→schema

---

## Resumo da Arquitetura de Dados

```
┌─────────────────────────────────────────────────────────────┐
│                     Frontend (React)                        │
│  useTauriQuery / useSQLiteQuery / useDataRegistry / etc.   │
└──────────────────────┬──────────────────────────────────────┘
                       │ invoke('db_query') / useSqlite
┌──────────────────────▼──────────────────────────────────────┐
│                    Tauri Backend (Rust)                      │
│                  SQLite local (ecoforms_local_desktop.db)  │
└────────┬─────────────────────────────────────┬──────────────┘
         │                                     │
         ▼                                     ▼
┌─────────────────┐                    ┌─────────────────────┐
│  StorageSync   │                    │ DimensionSyncService│
│  (Supabase     │                    │  (dim_* tables)     │
│   Storage)     │                    └─────────────────────┘
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│                  Supabase Storage (sync-bucket)              │
│                                                             │
│  shared/form_registry.json       — Formulários              │
│  shared/form_field_registry.json — Campos                   │
│  shared/data_registry.json       — Dados referência        │
│  shared/users.json               — Usuários                │
│  shared/tbl_suite.json           — Submissões              │
│  shared/ecoponto_caixas.json     — Caixas ecoponto         │
│  users/{deviceId}/outbox/        — Push do desktop         │
│  users/{deviceId}/inbox/         — Pull do mobile          │
│  archive/YYYY-MM/                — Arquivo mensal          │
│                                                             │
│  ⚠️ NUNCA acessar tabelas PostgreSQL diretamente            │
│  ✅ SEMPRE usar Storage para trânsito de dados              │
└─────────────────────────────────────────────────────────────┘
```

**Dual query layer:**
- `useTauriQuery` → bypass direto do SQLite via Rust (`invoke('db_query')`)
- `useSQLiteQuery` → usa wrapper reativo (`useSqlite` do contexto)
- `useTauriClients` vs `useClients` coexistence para queries complexas

**Evento `audit.registro`:**
- Cada command Rust protegido (`suite_approve`, `demanda_aceitar`, etc.) insere em `tbl_audit_log` e publica um envelope `audit.registro` na `sync_event_queue`
- O `TransportService.pushPending()` envia automaticamente para `eventos/{routingId}/...enc` criptografado
- Diferente de `action_log` (log operacional do ActionRegistry), `tbl_audit_log` é imutável e destinado a compliance/forense

**Versionamento append-only (tbl_suite v2):**
- Nunca se faz UPDATE em tbl_suite — sempre INSERT com `is_current=0` para a versão anterior
- Views como `vw_ouvidoria_current` filtram `is_current=1` para ocultar histórico

**Schema legacy detection:**
- Hooks verificam existência de colunas canônicas (`idPJtipo`, `idProtocolo`) vs `id_legacy`
- SQL é adaptado dinamicamente via `useSQLiteColumnExists`

**Snapshot freeze:**
- Tarefas atribuídas a operadores mobile podem ser "congeladas" (`snap_frozen_at`)
- Campo `snap_hash` (FNV-1a) identifica conflitos de edição offline
- Patches são consolidados via `unfreezeTask()` antes de liberar edição
