# Diagrama de Fluxo de Dados — EcoForms Desktop

Este documento apresenta os fluxos de dados do sistema EcoForms Desktop, desde a entrada até o armazenamento e sincronização.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `data-system.md` | Tipos, portas, wrappers, serviços de sync (StorageSync, SyncService, UseCases) |
| `hooks.md` | Catálogo de 47 hooks React |
| `modules.md` | Inventário de módulos, entidades, repositories e use cases |

---

## Índice

1. [Arquitetura de Camadas](#1-arquitetura-de-camadas)
2. [Pontos de Entrada de Dados](#2-pontos-de-entrada-de-dados)
3. [Fluxo por Módulo](#3-fluxo-por-módulo)
4. [Ciclo Completo de Sincronização](#4-ciclo-completo-de-sincronização)
5. [Fluxo de Armazenamento Offline](#5-fluxo-de-armazenamento-offline)
6. [Padrões de Processamento](#6-padrões-de-processamento)
7. [Diagrama de Fluxo Simplificado](#7-diagrama-de-fluxo-simplificado)

---

## 1. Arquitetura de Camadas

```
┌─────────────────────────────────────────────────────────────┐
│                 PRESENTATION LAYER                            │
│         Pages (Next.js App Router) + Components               │
│                   + React Hooks                               │
├─────────────────────────────────────────────────────────────┤
│                  APPLICATION LAYER                            │
│           Use Cases (CreateTask, SubmitSuite...)              │
├─────────────────────────────────────────────────────────────┤
│                    DOMAIN LAYER                               │
│     Entities (Task, SuitePackage) + Repository Interfaces     │
├─────────────────────────────────────────────────────────────┤
│                  INFRASTRUCTURE LAYER                         │
│    SQLite Adapter (Tauri) │ Supabase Storage │ File Storage   │
└─────────────────────────────────────────────────────────────┘
```

**Coexistência legacy:**
- `hooks/` — migrado para `src/interface/hooks/`
- `lib/sync/` — migrado para `src/infrastructure/sync/`
- `contexts/` — `SyncContext`, `AuthContext` (Presentation)

---

## 2. Pontos de Entrada de Dados

### 2.1 Submissão de Formulários → `tbl_suite`

```
Usuário preenche formulário
        │
        ▼
useFormTemplate(slug)           ← busca schema do form
        │
        ▼
SubmitSuiteUseCase.execute()
        │
        ├──▶ SuitePackage (v2 entity)
        │         │
        │         ▼
        │   SqliteSuiteRepository.save()
        │         │
        │         ▼
        │   TauriSqliteAdapter.execute()
        │         │
        │         ▼
        │   invoke('db_execute', { sql, params })
        │         │
        │         ▼
        └──────▶ SQLite: INSERT tbl_suite (is_current=1)
                            │
                            ▼
                    SyncContext: syncNow()  (dispara sync)
```

**Campos críticos do registro:**
- `package_id` — UUID
- `payload_json` — JSON serializado (dados do formulário)
- `module_type` — tipo do formulário (ex: `ecopontoCaixasForm`)
- `is_current` — 1 = vigente, 0 = histórico

---

### 2.2 Criação de Tarefas → `tbl_tarefas`

```
UI (Kanban): criar tarefa
        │
        ▼
CreateTaskUseCase.execute()
        │
        ├──▶ Task entity (com snap_hash, snap_version)
        │         │
        │         ▼
        │   SqliteTaskRepository.save()
        │         │
        │         ▼
        │   INSERT tbl_tarefas
        │         │
        │    ┌────┴──────────┐
        │    ▼              ▼
        │ INSERT            INSERT tbl_tarefas_interessados
        │ tbl_tarefas_eventos (criacao)
        │
        ▼
syncNow()  ────▶ SyncContext → EventSyncAdapter
```

---

### 2.3 Comandos Tauri (Desktop)

| Comando | Função |
|---------|--------|
| `db_query` | SELECT → `{ columns: string[], rows: any[][] }` |
| `db_execute` | INSERT/UPDATE/DELETE → `rows_affected: number` |
| `db_execute_batch` | Múltiplos SQLs em transação |
| `db_last_insert_id` | Retorna último ID inserido |
| `network_probe_path` | Testa acessibilidade de caminho |
| `network_list_parquet` | Lista arquivos `.parquet` |
| `supabase_admin_query` | Operações admin Supabase |

---

## 3. Fluxo por Módulo

### 3.1 Task Module

```
┌─────────────────────────────────────────────────────────────────┐
│ INPUTS                                                           │
│   • UI Kanban (drag-drop, task dialog)                          │
│   • Mobile (task patches via Supabase Storage)                 │
│   • Sync (incoming task snapshots de outros devices)          │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ USE CASES                                                        │
│   CreateTaskUseCase                                             │
│   MoveTaskUseCase      (assertValidTransition)                  │
│   AssignTaskUseCase                                             │
│   ArchiveTaskUseCase                                            │
│   DeleteTaskUseCase    (soft-delete: deletado_em)                │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ STORAGE                                                          │
│   SqliteTaskRepository  ──▶  tbl_tarefas                        │
│   Associated:                                                 │
│     tbl_tarefas_interessados  (muitos-pára-muitos)            │
│     tbl_tarefas_eventos       (audit trail)                    │
│     tbl_projetos_interessados                                  │
│   Linked tables:                                                 │
│     tbl_projetos (projeto_id)                                   │
│     tbl_suite (tbl_suite_id) — pacote de formulário vinculado │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ OUTPUT                                                           │
│   React UI re-render via hooks                                   │
│   insertTaskEvent() ──▶ tbl_tarefas_eventos                    │
│   syncNow() ──▶ SyncContext → EventSyncAdapter                │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.2 Suite Module (Form Packages)

```
┌─────────────────────────────────────────────────────────────────┐
│ INPUTS                                                           │
│   • Form submissions (UI)                                       │
│   • Mobile submissions (pulled from inbox)                    │
│   • Edit operations via EditSuiteUseCase                      │
│   • Status transitions via ReviewSuiteUseCase                  │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ USE CASES                                                        │
│   SubmitSuiteUseCase    (cria novo pacote, status: 'current') │
│   EditSuiteUseCase      (edita payload de pacote existente)   │
│   ReviewSuiteUseCase    (approve/reject: locked/refuted)       │
│   ListInboxUseCase      (query por status/owner/module)        │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ STORAGE                                                          │
│   SqliteSuiteRepository  ──▶  tbl_suite (v2 append-only)      │
│     Nunca usa UPDATE — sempre INSERT nova versão               │
│     is_current=0 marca versão anterior                         │
│                                                                 │
│   History: tbl_suite_historico                                  │
│     (version_from, version_to, status_anterior, status_novo,   │
│      alterado_por, alterado_em, motivo)                         │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ SPECIAL BEHAVIORS                                                 │
│   Auto-approval: se form_registry.auto_aprovacao=1             │
│                   → status 'locked' direto                      │
│   Ghost tasks: Ad Hoc submissions criam tarefas em tbl_tarefas│
│                via ensureRetroactiveTask()                      │
│   Status flow: current → locked (approved)                      │
│                current → refuted (rejected)                     │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ OUTPUT                                                           │
│   pushTblSuite()  ──▶  users/{deviceId}/outbox/               │
│   upsertTblSuite() (do mobile) atualiza status locally         │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.3 Form Registry & Data Registry

```
┌─────────────────────────────────────────────────────────────────┐
│ INPUTS                                                           │
│   • Admin UI (criar/editar formulários e dados de referência)   │
│   • Sync de outros devices (mobile baixa compartilhamentos)     │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ form_registry                                                   │
│   Tabela: form_registry                                         │
│   Campos: form_id, slug, conteudo (JSON schema), versao,         │
│           ativo, autor, titulo, situacao (draft/published),      │
│           auto_aprovacao, ad_hoc                                 │
│                                                                 │
│ data_registry                                                   │
│   Tabela: data_registry                                         │
│   Campos: id, tipo, chave, conteudo (JSON), versao             │
│   Exemplo de tipos: 'bairro', 'rua', 'categorias', 'clientes'   │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ ENRICHMENT (FormSyncManager.enrichDataWithSource)              │
│   Antes: { "bairro_id": "neighborhood_123" }                   │
│   Depois: { "bairro_id": { "raw": "...", "source": {...} } }  │
│   Dados do data_registry enriquecem campos do formulário        │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ OUTPUT                                                           │
│   pushSharedData()  ──▶  shared/form_registry.json              │
│                        shared/data_registry.json                 │
│   Hooks: useFormTemplate, useDataRegistry, useDataRegistryTypes │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.4 User Module

```
┌─────────────────────────────────────────────────────────────────┐
│ INPUTS                                                           │
│   • Admin UI (user management)                                   │
│   • Sync (compartilhado com mobile)                             │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ STORAGE                                                          │
│   SqliteUserRepository  ──▶  tbl_usuarios                       │
│   setores: tbl_usuarios_setores (usuario_id → setor_id)         │
│   Campos: id, nome, email, perfil, ativo,                         │
│           formularios_permitidos (JSON), setores (JSON)          │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ OUTPUT                                                           │
│   Evento 'usuario.criado/atualizado' → EventBus → sync ativo   │
│   [futuro] shared/users.json (StorageSync legado)               │
│   Hooks: useAdminUsers, useAllUsers, useUsersByForm            │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.5 Client Module

```
┌─────────────────────────────────────────────────────────────────┐
│ INPUTS                                                           │
│   • UI de clientes (forms CRUD)                                 │
│   • Busca FTS5 (useClientSearch)                               │
│   • Importação (CSV/Excel)                                     │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ STORAGE                                                          │
│   tblPJuridicas  ──▶  id_legacy, Cliente, idPJtipo, CEP...     │
│   tblPJtipo      ──▶  tipos de pessoa jurídica                 │
│   tblContatos     ──▶  vínculo PJ ↔ PF (contatos)              │
│   tblPFisicas     ──▶  dados de pessoas físicas (contatos)      │
│   tblCEP         ──▶  logradouro, bairro, cidade, estado        │
│   tblPJuridicas_history  ──▶  auditoria de alterações          │
│                                                                 │
│   Schema legacy detection: verifica id_legacy vs idPJtipo      │
│   para adaptar SQLs dinamicamente                               │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ HOOKS                                                            │
│   useClients, useTauriClients     (queries)                     │
│   useClientMutations             (CRUD)                         │
│   useClientSearch (FTS5)                                           │
│   useClientExport (Excel/PDF)                                    │
│   useClientAuditLog                                               │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.6 CRM Module (Roteiros/Rotas)

```
┌─────────────────────────────────────────────────────────────────┐
│ INPUTS                                                           │
│   • UI CRM (gerenciar roteiros, vinculação a clientes)           │
│   • Registro de coletas                                        │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ STORAGE                                                          │
│   tblRoteiros    ──▶  roteiro (nome, tipo residuo, periodicidade)│
│   tblRotas       ──▶  vínculo roteiro ↔ cliente PJ             │
│                      (idPJ, idRoteiro, Ordem, Inativo)           │
│   tblColetas     ──▶  registro de coleta (idRoteiro, Data)     │
│   tblDetalhesSatelite ──▶  detalhes da coleta (contentores,      │
│                             problema, rejeito, etc.)             │
│   tblTipoProblema ──▶  tipos de problema                       │
│                                                                 │
│   View: vw_clientes_roteiros  (JOIN PJ + roteiros)             │
│   Schema legacy: verifica id_legacy vs idPJtipo                 │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ HOOKS                                                            │
│   useCRM                 (useCRMMutations: createRota,         │
│                                          createColeta,          │
│                                          createDetalheSatelite) │
│   useClientesComRoteiros (agrupamento no frontend)             │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.7 Ouvidoria Module

```
┌─────────────────────────────────────────────────────────────────┐
│ INPUTS                                                           │
│   • UI Ouvidoria (protocolos, eventos, atendimentos)           │
│   • Geração automática de ID (YYYY-NNNN) via gerarIdProtocolo() │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ STORAGE                                                          │
│   tblProtocolo       ──▶  idProtocolo, Telefone, PJ, Status     │
│                      (legacy: id + id_legacy)                    │
│   tblProtocoloEventos ──▶  idProtocolo, Detalhe, Setor, Motivo  │
│   tblProtocoloAssunto  ──▶  Tema                               │
│   tblProtocoloSubtema ──▶  Subtema por tema                   │
│   Atendimento         ──▶  Solicitação do Cliente, Encaminhamento│
│   tblMensagens       ──▶  templates de mensagem                │
│                                                                 │
│   View: vw_ouvidoria_current  (filtra is_current=1)             │
│   Schema legacy: verifica id_legacy vs idProtocolo             │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ HOOKS                                                            │
│   useOuvidoria (useProtocolos, useProtocoloById,                 │
│                  useProtocoloEventos, useAtendimentoByProtocolo)│
│   useOuvidoriaMutations (createProtocolo, addEvento,            │
│                          upsertAtendimento, encerrarProtocolo)   │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.8 ActionRegistry Module

```
Contexto (task, formData, userId, container, eventBus)
    │
    ▼
useWorkflowActions('task', formData)
    │
    ▼
getAvailableActions('task', formData, userRole)
    │
    ├── evaluateVisibilityRules(enabledWhen, formData)  → true/false
    └── filter por requiredRoles.includes(userRole)
    │
    ▼
ActionBar renderiza botões dinâmicos
    │
    ▼
Usuário clica em uma ação
    │
    ▼
[Se confirmationRequired] → Modal de confirmação
[Se requiresInput]        → Mini-modal com formulário
    │
    ▼
aplicarMapeamento(fieldMapping, ctx) → ctx.input
    │
    ▼
handler(ctx) executa:
    ├── container.useCase.execute(input)   → mutação no domínio
    ├── eventBus.publish(type, data)       → sync cross-setor
    └── sqlite.execute(action_log INSERT)  → auditoria
    │
    ▼
ActionResult → toast.success / toast.error
    │
    ▼
[Se redirect] → router.push(redirect)
```

**Pontos de entrada:**
- `components/ActionBar.tsx` — renderização e orquestração
- `components/kanban/EditTaskModal.tsx` — ponto de montagem no TaskDialog
- `src/application/actions/builtin/*.actions.ts` — handlers de ações

---

### 3.9 WidgetRegistry Module

```
Página inicial monta (page.tsx)
    │
    ▼
useDashboardWidgets() → getAvailableWidgets(userRole)
    │
    ▼
DynamicDashboard recebe WidgetConfig[]
    │
    ▼
Para cada widget:
    ├── WidgetRenderer monta
    ├── fetchData():
    │     container = getContainer()
    │     group = container[widget.dataSource.useCaseGroup]
    │     method = group[widget.dataSource.method]
    │     result = await method(widget.dataSource.params)
    ├── setData(result)
    └── [Se refreshInterval > 0] → setInterval(fetchData, interval * 1000)
    │
    ▼
Renderiza componente por tipo:
    ├── kpi_card        → KpiCard (valor, subtítulo, trend)
    ├── bar_chart       → SimpleBarChart (label, value, color)
    ├── recent_activity → RecentActivityList (itens com timestamp)
    └── table           → TableWidget (colunas, rows)
```

**Pontos de entrada:**
- `components/DynamicDashboard.tsx` — grid e orquestração
- `components/widgets/*.tsx` — renderizadores por tipo
- `src/application/widgets/builtin/initializeWidgets.ts` — registro

---

## 4. Ciclo Completo de Sincronização

### 4.1 Trigger Sources

```
SyncContext (contexts/SyncContext.tsx)
        │
        ├── Intervalo ──────────────────▶ setInterval (default 5min)
        ├── online event ───────────────▶ navigator.onLine = true
        ├── Window focus ───────────────▶ visibilitychange (após 1min)
        └── Manual ─────────────────────▶ syncNow(forcePush?)
```

### 4.2 Ciclo de Sync (sistema ativo — EventSyncAdapter)

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. BOOTSTRAP (inicialização, uma vez por sessão online)        │
│    StorageBootstrapService.bootstrapIfNeeded()                  │
│    • ensureBucket('sync-bucket')  → cria bucket se possível    │
│    • download shared/org_config.json                            │
│        ├── existe  → cacheia no data_registry local             │
│        └── não existe → cria default + upload                   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. PUSH — TransportService.pushPending()                       │
│                                                                  │
│    SELECT * FROM sync_event_queue WHERE status = 'pending'      │
│    ORDER BY seq ASC                                             │
│                                                                  │
│    Para cada envelope:                                          │
│      CryptoLayer.encryptJson(envelope)   → Uint8Array (.enc)   │
│      storage.upload(                                            │
│        'orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc'   │
│      )                                                          │
│      → markAsSent() no sync_event_queue                         │
│                                                                  │
│    Após todos enviados:                                         │
│      Manifest.update(routingId, type, lastSeq, lastEventId)    │
│      → upload 'orgs/{orgId}/manifests/manifest_{routingId}.json'│
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  3. PULL — InboundService.pull(knownRoutingIds)                 │
│                                                                  │
│    OrgConfigService.load() → lista setores ativos              │
│                                                                  │
│    Para cada setor (exceto o local):                            │
│      Manifest.hasNewEvents(remoteRoutingId)?                    │
│        → NÃO  → skipped                                         │
│        → SIM  →                                                 │
│            storage.list('orgs/{orgId}/eventos/{remoteRoutingId}/')│
│            (com fallback para path legado 'eventos/...')        │
│            Para cada .enc:                                      │
│              download + CryptoLayer.decryptJson()               │
│              EventBus.dispatch(envelope)                        │
│                → handler por tipo (demanda, crm, ouvidoria...)  │
│                → aplica no SQLite local                         │
│              INSERT sync_device_log (acked=1)                  │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. RESULTADO                                                    │
│    SyncContext: atualiza stats (pushed, pulled, errors)        │
│    Toast de sucesso/erro para o usuário                         │
└─────────────────────────────────────────────────────────────────┘
```

> **Sistema legado (StorageSync)** — As operações `pushSharedData()`, `pushTblSuite()`, `pullSharedData()`, `pushTaskSnaps()`, `archive/`, `users/{id}/` existem em `StorageSync.ts` mas **não são instanciadas atualmente**. Serão integradas em versão futura para sync mobile de snapshots.

### 4.3 Storage Paths (Supabase Storage — sync-bucket)

> O sistema NÃO utiliza tabelas PostgreSQL no Supabase. Todo o trânsito de dados ocorre via **Supabase Storage**.

**Paths ativos:**

| Path | Conteúdo | Sistema | Direção |
|------|----------|---------|---------|
| `shared/org_config.json` | Setores da organização | Bootstrap | Push/Pull |
| `orgs/{orgId}/manifests/manifest_{routingId}.json` | Sequência do setor | EventSync | Push |
| `orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc` | Envelope criptografado | EventSync | Push |
| `orgs/{orgId}/eventos/{routingId}/lote_{id}.tgz.enc` | Lote compactado criptografado | EventSync | Push |

**Paths legados (StorageSync — arquivado em `_deprecated/`):**

| Path | Conteúdo | Status |
|------|----------|--------|
| `shared/users.json` | Snapshot de usuários | Legado / Planejado |
| `shared/form_registry.json` | Snapshot de formulários | Legado / Planejado |
| `shared/data_registry.json` | Dados de referência | Legado / Planejado |
| `shared/tasks.json` | Snapshot de tarefas | Legado / Planejado |
| `users/{deviceId}/outbox/` | Snapshots de saída | Legado / Planejado |
| `users/{deviceId}/inbox/` | Snapshots de entrada | Legado / Planejado |
| `archive/YYYY-MM/` | Arquivo mensal | Legado / Planejado |

**Regras de Acesso:**
1. **NUNCA** acessar tabelas PostgreSQL para trânsito de dados operacionais (exceção: `public.profiles`)
2. **SEMPRE** usar Storage para trânsito de dados entre dispositivos
3. O cliente Supabase no desktop opera com sessão authenticated (Fase 1); mobile mantém anon key

---

## 5. Fluxo de Armazenamento Offline

```
┌─────────────────────────────────────────────────────────────────┐
│ DISPOSITIVO SEM CONEXÃO                                          │
│                                                                     │
│ Mutation发生时:                                                    │
│         │                                                         │
│         ▼                                                         │
│ offlineQueue.enqueue(sql, params, label)  ──▶ localStorage       │
│                                          (ecosuite-offline-queue)│
│                                                                     │
│ console.log(`📦 Offline queue: enqueued "..."`)                 │
└─────────────────────────────────────────────────────────────────┘
                             │
                             │  volta online (navigator.onLine)
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ SyncContext: detectou online                                    │
│         │                                                         │
│         ▼                                                         │
│ offlineQueue.processAll(execFn)                                 │
│         │                                                         │
│         ├──▶ Replay FIFO: mutation.sql → db.execute()           │
│         │    (até falhar ou esgotar)                            │
│         │                                                         │
│         └──▶ 3 retries por mutation                             │
│              em caso de falha:                                   │
│                   retryCount++                                   │
│                   se retryCount >= 3: descarte + logging        │
└─────────────────────────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ SyncContext: syncNow()                                          │
│         │                                                         │
│         ▼                                                         │
│ EventSyncAdapter.syncAll()                                      │
│         │                                                         │
│         ▼                                                         │
│ StorageSync.push()  ──▶  Supabase Storage                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 6. Padrões de Processamento

### 6.1 Detecção de Mudanças (Hash Cache)

```ts
// SyncService.hasChanged()
hasChanged(table: string, data: any): boolean {
    const json = stableStringify(data);     // JSON determinístico
    const hash = sha256(json);              // SHA-256
    const previous = this.sharedHashCache.get(`shared_hash_${table}`);
    if (previous === hash) return false;    // Sem mudanças → skip push
    this.sharedHashCache.set(`shared_hash_${table}`, hash);
    return true;
}
```

### 6.2 Upserts Idempotentes

```ts
// INSERT ... ON CONFLICT DO UPDATE + comparação de timestamp
if (existing.length === 0) {
    await db.exec(`INSERT INTO ...`);      // Novo
} else if (remote.updated_at > local.updated_at) {
    await db.exec(`UPDATE ...`);            // Atualiza se mais recente
}
```

### 6.3 Auto-approval

```ts
// SyncService -> SqliteSyncRepository.upsertTblSuite()
const registryInfo = await db.all(
    `SELECT auto_aprovacao FROM form_registry WHERE form_id = ?`,
    [formType]
);
if (isAutoAprovable && record.status === 'current') {
    finalStatus = 'locked';                // Aprovação automática
}
```

### 6.4 Versionamento Append-Only (tbl_suite v2)

```ts
// Regra: NUNCA usa UPDATE em tbl_suite
// Sempre: INSERT nova versão + UPDATE is_current=0 na anterior

await db.exec(`UPDATE tbl_suite SET is_current = 0 WHERE package_id = ? AND is_current = 1`);
await db.exec(`INSERT INTO tbl_suite (package_id, version_no, ..., status, is_current, payload_json, created_at)
               VALUES (?, ?, ?, 'current', 1, ?, ?)`,
    [packageId, newVersionNo, moduleType, newPayload, now]);
```

### 6.5 Ghost Task Creation (Retroativa)

```ts
// ensureRetroactiveTask(): Ad Hoc submissions criam tarefa
// Apenas se activity_id/task_id não foi fornecido
// Usa UNIQUE INDEX em tbl_tarefas(tbl_suite_id) para idempotência
await db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_tbl_tarefas_suite_id_unique
    ON tbl_tarefas(tbl_suite_id)
    WHERE tbl_suite_id IS NOT NULL
`);
```

### 6.6 Schema Migration on Startup

```ts
// ColumnSchemaManager (column-schema.ts)
ensureArquivadoColumn()          // ALTER TABLE tbl_tarefas ADD COLUMN arquivado
ensureTaskContextColumns()       // setor_id, parent_task_id, container_task_id,
                                 // cycle_id, depends_on_task_id,
                                 // snap_version, snap_hash, snap_frozen_at
```

---

## 7. Diagrama de Fluxo Simplificado

```
┌─────────────┐     ┌─────────────────┐     ┌──────────────────┐
│   Forms     │     │   Use Cases    │     │   Repositories   │
│  (UI)       │────▶│  (Application)  │────▶│  (Infrastructure)│
└─────────────┘     └─────────────────┘     └────────┬─────────┘
                                                       │
                         ┌──────────────────────────────┘
                         │
              ┌──────────┴──────────┐
              │                     │
              ▼                     ▼
┌─────────────────────┐   ┌─────────────────────┐
│   SQLite Local      │   │  Supabase Storage    │
│  (ecoforms.db)       │   │   (sync-bucket)      │
│                     │   │                     │
│  tbl_tarefas        │   │  shared/             │
│  tbl_suite          │◀──│  - form_registry.json│
│  tbl_projetos       │   │  - data_registry.json│
│  tbl_usuarios       │   │  - users.json        │
│  form_registry      │   │  - tbl_suite.json    │
│  data_registry      │   │  - ecoponto_caixas   │
│  tbl_* (módulos)   │   │  outbox/             │
└─────────────────────┘   │  inbox/              │
        ▲                  │  archive/            │
        │                  └─────────────────────┘
        │                         ▲
        │          ┌──────────────┘
        │          │
        │          │  SyncService (implementa SyncPort)
        │          │  (src/infrastructure/sync/SyncService.ts)
        │          │          │
        │          │  ┌──────┴──────┐
        │          │  │             │
        │          ▼  ▼             ▼
        │   ┌───────────────┐ ┌────────────┐
        │   │StorageSync   │ │PushTasks   │
        │   │(SHA-256)     │ │PullTasks   │
        │   └───────┬──────┘ └─────┬──────┘
        │           │              │
        │           ▼              │
        │   ┌───────────────┐      │
        │   │ OfflineQueue  │      │
        │   │ (IndexedDB)   │      │
        │   └───────────────┘      │
        │           │              │
        │           └──────────────┘
        │                     │
        └─────────────────────┘
```

---

## Resumo: Ciclo de Vida dos Dados

| Dado | Entrada | Processamento | Storage Local | Sync (Supabase Storage) |
|------|---------|--------------|---------------|------------------------|
| **Task** | UI Kanban | CreateTaskUseCase / MoveTaskUseCase | tbl_tarefas | EventBus → `eventos/{setor}/` |
| **Suite** | Form submission | SubmitSuiteUseCase | tbl_suite (append-only) | EventBus → `eventos/{setor}/` |
| **Form Schema** | Admin UI | useFormTemplate | form_registry | EventBus → `eventos/{setor}/` |
| **Reference Data** | Admin UI | useDataRegistryMutations | data_registry | EventBus → `eventos/{setor}/` |
| **Users** | Admin UI | CreateUserUseCase | tbl_usuarios | EventBus → `eventos/{setor}/` |
| **Org Config** | Bootstrap | StorageBootstrapService | data_registry (cache) | `shared/org_config.json` |
| **Clients** | UI Clients | useClientMutations | tblPJuridicas | local only |
| **Roteiros/Rotas** | UI CRM | useCRMMutations | tblRoteiros/Rotas | local only |
| **Protocolos** | UI Ouvidoria | useOuvidoriaMutations | tblProtocolo | local only |
