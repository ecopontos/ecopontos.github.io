# FieldFactory — Interpreter de Schema

## Visão Geral

`FieldFactory` é o **coração do interpretador de schema** — é quem transforma um objeto de configuração (`{ type: 'select', id: 'cidade', ... }`) em uma instância real de campo com DOM renderizado e estado reativo.

Existem duas implementações:

| Arquivo | Classe | Uso |
|---------|--------|-----|
| `www/js/fields/FieldFactory.js` | `FieldFactory` (legacy) | Sistema original com todos os tipos |
| `www/js/fields/FieldFactory.v2.js` | `FieldFactoryV2` | Versão modernizada, menor |

Ambas compartilham o mesmo padrão: **mapeamento tipo → classe + factory method**.

---

## FieldFactory (Legacy) — Mapeamento Tipo → Classe

**Arquivo:** `www/js/fields/FieldFactory.js`

### Mapa Completo

```javascript
const FIELD_TYPE_MAP = {
  // Textos básicos
  text: TextField,
  email: TextField,
  tel: TextField,
  url: TextField,
  date: TextField,
  time: TextField,
  textarea: TextAreaField,
  input: InputFieldBase,

  // Numéricos
  number: NumberField,
  password: PasswordField,

  // Seleção
  select: SelectField,
  'select-field': SelectField,
  'ecoponto_select': SelectField,
  radio: RadioField,

  // Checkbox (usa BaseField direto)
  checkbox: BaseField,

  // Ocultos e arquivos
  hidden: HiddenField,
  file: FileField,

  // Câmera e galeria
  camera: CameraField,
  photo: CameraField,           // alias
  gallery: GalleryField,

  // Presença
  presence: PresenceField,
  'presence-list': PresenceField,
  'presence_list': PresenceField,
  'presence_compact': PresenceField,
  'presence-selector': PresenceField,
  // ... todas as variantes de presence convergem para PresenceField

  // Chips/Tags
  chips: ChipsField,
  chipsmultiple: ChipsField,
  'chips-multiple': ChipsField,
  'chips_multiple': ChipsField,

  // Geolocalização
  geolocation: GeolocationField,
  geolocalizacao: GeolocationField,
  gps: GeolocationField,         // alias

  // Caixas Avançado
  'caixas_avancado': CaixasAvancadoField,
  'caixas-avancado': CaixasAvancadoField,

  // Cards Radio
  'cards-radio': CardsRadioField,
  cardsradio: CardsRadioField,
  cards_radio: CardsRadioField,

  // Selector Modal
  'selector-modal': SelectorModalField,
  selectormodal: SelectorModalField,
  selector_modal: SelectorModalField,

  // Checklists
  checklist: ChecklistField,
  'inspection_checklist': ChecklistField,
  'inspection-checklist': ChecklistField,
  'vistoria_checklist': VistoriaChecklistField,  // moderno
  'vistoria-checklist': VistoriaChecklistField,
  'unified_checklist': ChecklistField,

  // Occupation
  occupation: OccupationField,
  'occupation-selector': OccupationField,
  ocupacao: OccupationField,

  // Grupos
  repeatable_group: RepeatableGroupField,
  repeatable: RepeatableGroupField,
  group: GroupField,

  // Esqueleto / User
  skeleton: FieldSkeleton,
  user: TextField,

  // Fallback
  default: BaseField
};
```

### normalizeTypeKey() — Como o tipo é resolvido

Antes de buscar no mapa, o tipopassa por normalização agressiva:

```javascript
function normalizeTypeKey(rawType = 'default') {
  const base = rawType.toString().trim();

  // Gera variantes em ordem de prioridade:
  // 1. original: "chipsmultiple"
  // 2. lowercase: "chipsmultiple"
  // 3. camelCase→kebab: "chipsMultiple" → "chips-multiple"
  // 4. sem prefixo "campo-": "campo-chips" → "chips"
  // 5. underscore↔hyphen: "chips_multiple" ↔ "chips-multiple"
  // 6. datetime→datetime-local
  // 7. default como último recurso

  return ordered; // array de candidatos em ordem de tentativa
}
```

**Exemplo:** `chipsmultiple` gera:
```
['chipsmultiple', 'chipsmultiple', 'chips-multiple', 'chips_multiple', 'chipsmultiple', 'chips-multiple', 'chips_multiple', 'default']
```

O primeiro match no `FIELD_TYPE_MAP` vence.

### create() — Instanciação

```javascript
static create(config = {}, formData = {}, Alpine = undefined) {
  const fieldId = config.id || config.name;
  const typeCandidates = normalizeTypeKey(config.type || config.tipo || 'default');

  // 1. Tenta resolver tipo dinâmico primeiro
  for (const key of typeCandidates) {
    if (DYNAMIC_TYPE_ALIASES.has(key)) {
      return FieldFactory.createDynamicField(config, formData, alpineInstance, dynamicType);
    }
    if (FIELD_TYPE_MAP[key]) {
      const FieldClass = FIELD_TYPE_MAP[key];
      // 2. Instancia com merge de config + formData value
      return new FieldClass({
        ...config,
        value: formData && fieldId ? formData[fieldId] : config.value,
        formData,
        Alpine: alpineInstance
      });
    }
  }

  // 3. Fallback: BaseField
  return new FIELD_TYPE_MAP.default({ ... });
}
```

**Pré-população via formData:** Se `formData[fieldId]` existir, ele **sobrescreve** `config.value`. Isso é o mecanismo de pré-preenchimento — o `formData` externo (do IndexedDB, Supabase, ou URL params) tem prioridade sobre defaults inline.

### createDynamicField() — Carga Tardia

```javascript
static async createDynamicField(config, formData, Alpine, fieldType = '') {
  // Import dinâmico para campos que causam conflitos de módulo
  if (fieldType === 'dynamic-toggle-list') {
    const module = await import('./types/DynamicToggleListField.js');
    FieldClass = module.default;
  }
  return new FieldClass({ ...config, value: formData[fieldId] ?? config.value, formData, Alpine });
}
```

---

## FieldFactoryV2 — Versão Modernizada

**Arquivo:** `www/js/fields/FieldFactory.v2.js`

Mapa mais enxuto, focado em campos reescritos:

```javascript
const FIELD_CLASSES_V2 = {
  // Básicos
  select: SelectFieldV2,
  radio: RadioFieldV2,
  checkbox: CheckboxFieldV2,
  text: TextInputFieldV2,
  number: NumberInputFieldV2,
  date: DateFieldV2,
  time: TimeFieldV2,
  textarea: TextareaFieldV2,

  // Complexos
  chips: ChipsFieldV2,
  gps: GPSFieldV2,
  camera: CameraFieldV2,
  photo: CameraFieldV2,
  gallery: GalleryFieldV2,

  // Grupos
  repeatable_group: RepeatableGroupField,
  repeatable: RepeatableGroupField,
  group: GroupField
};
```

**Diferença clave:** V2 não recebe `formData` nem `Alpine` no construtor. Campos V2 leem/escrevem via `Alpine.store('form')`.

```javascript
static create(config, useV2 = true) {
  const FieldClass = classMap[config.type];
  if (!FieldClass) {
    // Tenta fallback legacy
    return new LegacyClass(config);
  }
  return new FieldClass(config);
}
```

---

## Resumo da Instanciação

| Aspecto | Legacy (FieldFactory) | V2 (FieldFactoryV2) |
|---------|----------------------|---------------------|
| Fonte de valor | `formData[fieldId] ?? config.value` | `Alpine.store('form')` |
| Alpine | Injetado via construtor | Lido do store dentro de `init()` |
| Tipos disponíveis | ~40+ | ~18 |
| Subcampos (Group) | `FieldFactory.create()` | `FieldFactory.create()` |
| Dinamic loading | `createDynamicField()` async | Não |

---

# FormRenderer — Ciclo de Vida Completo

> **Relacionamento com `fields.md`:** Este documento cobre a **orquestração** (FieldFactory + lifecycle). O documento [fields.md](fields.md) cobre a **implementação individual** de cada tipo de campo (15 tipos, params, getValue/setValue, dependências entre campos).

## Visão Geral

`FormRenderer` (`www/js/forms/form-renderer.js`) é o **orquestrador** que recebe um JSON de `form_registry.conteudo` e produz um formulário funcionando no DOM. Ele combina:

- **SmartCache** — carregamento com cache em múltiplas camadas
- **FieldFactory** — instanciação de campos
- **applyFormHandlers** — validação, dependências, visibilidade condicional
- **defaultToNow updater** — relógio vivo para campos de data/hora

---

## Estrutura do form_registry.conteudo

```javascript
{
  "id": "vistoria_ecoponto",
  "titulo": "Vistoria de Ecoponto",
  "descricao": "Formulário de vistoria técnica",
  "version": "1.0.0",
  "campos": [
    {
      "id": "galpao",
      "type": "select",
      "label": "Galpão",
      "required": true,
      "dataSource": "galpoes",
      "optionValue": "id",
      "optionLabel": "nome"
    },
    {
      "id": "data_visita",
      "type": "date",
      "label": "Data da Visita",
      "defaultToNow": true
    },
    {
      "id": "resultado",
      "type": "radio",
      "label": "Resultado",
      "options": [
        { "value": "aprovado", "label": "Aprovado" },
        { "value": "reprovado", "label": "Reprovado" }
      ]
    }
  ]
}
```

Campos especiais (não renderizam input):
- `hidden` — renderiza `<input type="hidden">` com `value`
- `repeatable_group` — contém subcampos em `campos[]`
- `group` — agrupa subcampos

---

## Ciclo de Vida Completo

### 1. loadForm(formId, containerId)

```
┌─────────────────────────────────────────────────────────┐
│  FormRenderer.loadForm(formId, containerId)             │
└─────────────────────┬───────────────────────────────────┘
                      │
          ┌───────────▼───────────┐
          │ smartCache.loadForm() │  ← 3 camadas: setup cache → local → storage
          └───────────┬───────────┘
                      │ formConfig (JSON do form_registry.conteudo)
          ┌───────────▼───────────┐
          │ enrichFormWithData()  │  ← para cada campo com dataSource,
          │ (Promise.all parallel) │    carrega dados via smartCache.loadDataSource()
          └───────────┬───────────┘
                      │ enrichedConfig (campos com _loadedData)
          ┌───────────▼───────────┐
          │ renderForm()          │  ← gera HTML e aplica handlers
          └───────────────────────┘
```

**Carregamento de dados (enrichment):**

```javascript
async enrichFormWithData(formConfig) {
  const enrichedConfig = JSON.parse(JSON.stringify(formConfig));

  await Promise.all(enrichedConfig.campos.map(async (campo) => {
    if (campo.dataSource) {
      const data = await smartCache.loadDataSource(campo.dataSource);
      campo._loadedData = data;       // injetado no campo
      campo._dataLoadedAt = timestamp;
    }
  }));

  return enrichedConfig;
}
```

### 2. generateFormHTML(formConfig)

```javascript
generateFormHTML(formConfig) {
  let html = `<form id="form-${formConfig.id}" ...>`;
  html += `<div class="form-header"><h2>${formConfig.titulo}</h2>...</div>`;
  html += `<div class="form-body">`;

  for (const campo of formConfig.campos) {
    html += generateFieldHTML(campo);  // switch por tipo
  }

  html += `</div><div class="form-actions">...</div></form>`;
  return html;
}
```

Para campos `select`, `generateSelectField()` usa `_loadedData`:

```javascript
generateSelectField(campo) {
  let options = campo._loadedData || [];

  // Ordenação alfabética por padrão
  if (campo.sort !== false) {
    options.sort((a, b) => {
      const aVal = a[campo.optionLabel] || a.label || a.nome;
      const bVal = b[campo.optionLabel] || b.label || b.nome;
      return String(aVal).localeCompare(String(bVal), 'pt-BR');
    });
  }

  for (const option of options) {
    // valor vem de optionValue ou fallback: value → id → codigo
    // label vem de optionLabel ou fallback: label → nome → name → descricao
    html += `<option value="${escapeHtml(value)}">${escapeHtml(label)}</option>`;
  }
}
```

### 3. applyFormHandlers(formConfig, containerId)

Quatro responsabilidades:

```javascript
async applyFormHandlers(formConfig, containerId) {
  // 3.1 Submit handler
  form.addEventListener('submit', handleFormSubmit);

  // 3.2 Validações pattern
  applyValidations(formConfig);

  // 3.3 Dependências entre campos (cascata select)
  applyFieldDependencies(formConfig);

  // 3.4 Visibilidade condicional
  applyVisibilityRules(formConfig, form);

  // 3.5 defaultToNow updater (intervalo 60s)
  startDefaultToNowUpdater();
}
```

### 4. Dependências entre Campos (cascata)

```javascript
applyFieldDependencies(formConfig) {
  // Para cada campo com "dependency"
  if (campo.dependency && campo.type === 'select') {
    const parentId = campo.dependency.fieldId;
    const childId = campo.id;

    parentElement.addEventListener('change', () => {
      // Filtra _loadedData pelo valor do pai
      let filtered = campo._loadedData.filter(opt =>
        String(opt[filterProp]) == String(parentValue)
      );
      // Regenera <option> do filho
      childElement.innerHTML = filtered.map(opt => ...).join('');
      childElement.value = '';
    });
  }
}
```

**Exemplo de config:**
```javascript
{
  id: "bairro",
  type: "select",
  dependency: {
    fieldId: "cidade",      // campo pai
    filterProperty: "cidade" // propriedade no _loadedData para filtrar
  }
}
```

### 5. Visibilidade Condicional

```javascript
applyVisibilityRules(formConfig, form) {
  // Regra: { fieldId, operator, value, negate, logic }
  // Operadores: eq, neq, gt, gte, lt, lte, contains, in, notIn, empty, notEmpty

  evaluateVisibilityRules(rules, formData) {
    return rules.reduce((result, rule, index) => {
      const fieldValue = formData[rule.fieldId];
      let conditionMet = evaluateCondition(fieldValue, rule);
      if (rule.negate) conditionMet = !conditionMet;

      const logic = rule.logic || 'AND';
      return index === 0 ? conditionMet : (logic === 'AND' ? result && conditionMet : result || conditionMet);
    }, true);
  }
}
```

**Exemplo de config:**
```javascript
{
  id: "observacoes",
  visibility: [
    { fieldId: "resultado", operator: "eq", value: "reprovado" }
  ]
}
```

### 6. handleFormSubmit — Coleta e Persistência

```javascript
async handleFormSubmit(formConfig, form) {
  // 1. Coleta FormData HTML
  const htmlData = Object.fromEntries(new FormData(form));

  // 2. Merge com Alpine formData (HTML vence)
  const data = { ...window.formData, ...htmlData };

  // 3. Force defaultToNow fields para "agora" no instante do submit
  formConfig.campos.forEach(campo => {
    if (campo.autoCurrent && isDateTimeField(campo)) {
      data[campo.id] = computeDefaultValue(campo, new Date());
    }
  });

  // 4. Monta submission envelope
  const submission = {
    formId: formConfig.id,
    formTitle: formConfig.titulo,
    data,
    submittedAt: new Date().toISOString(),
    userId: dataService?.userId
  };

  // 5. Salva via DataService (IndexedDB)
  const recordId = await dataService.saveFormData(submission);

  // 6. Tenta sync com Supabase
  await dataService.syncSingleRecord(recordId);

  // 7. Reset UI
  form.reset();
  delete window.formData[campo.id] for each campo;
}
```

---

## SmartCache — Camadas de Carregamento

```
loadForm(formId)
│
├─► 1. Setup Cache (localStorage durante device-setup)
│     key: ecoforms_cache_forms_{formId}.json
│
├─► 2. Local Cache (IndexedDB)
│     key: forms_{formId}
│
└─► 3. Supabase Storage
      bucket: sync-bucket
      path: shared/form_registry.json
      (contém array form_registry[], cada um com .conteudo)
```

---

## ProgressiveFormRenderer — Renderização Otimizada

**Arquivo:** `www/js/core/ProgressiveFormRenderer.js`

Para formulários grandes, usa estratégias progressivas:

| Estratégia | Comportamento |
|------------|---------------|
| `critical-first` (default) | Required + visíveis primeiro (bloqueante), resto em background (requestIdleCallback) |
| `priority` | Ordena por prioridade e renderiza todos (não bloqueante) |
| `sequential` | Na ordem do array (não bloqueante) |
| `virtual` | Usa VirtualScroller para renderizar só visíveis |

**Cálculo de prioridade:**

```javascript
calculateFieldPriority(field) {
  let priority = 50;
  if (field.required) priority += 50;
  if (!field.hidden) priority += 30;
  if (field.order < 10) priority += 20;
  if (['basic-info', 'identification'].includes(field.section)) priority += 40;
  if (['text', 'email', 'tel', 'number', 'date'].includes(field.type)) priority += 10;
  if (['signature', 'camera', 'checklist'].includes(field.type)) priority -= 20;
  if (field.priority !== undefined) priority = field.priority;
  return Math.max(0, Math.min(200, priority));
}
```

---

## Fluxo: JSON → DOM Renderizado

```
form_registry.conteudo (JSON)
  │
  ▼
SmartCache.loadForm(formId)
  │  ├─ localStorage (setup)
  │  ├─ IndexedDB (cache)
  │  └─ Supabase Storage (shared/form_registry.json)
  │
  ▼
enrichFormWithData() — Promise.all parallel para dataSources
  │
  ▼
renderForm() — generateFormHTML() + innerHTML
  │
  ▼
applyFormHandlers()
  │  ├─ submit handler → handleFormSubmit()
  │  ├─ applyValidations() — pattern regex
  │  ├─ applyFieldDependencies() — select cascata
  │  ├─ applyVisibilityRules() — show/hide/disabled
  │  └─ startDefaultToNowUpdater() — setInterval 60s
  │
  ▼
DOM handler listener para change/input
  │
  ▼
FormRenderer.getSystemStatus() — métricas
```
