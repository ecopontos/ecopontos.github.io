-- ============================================
-- BACKUP DAS POLÍTICAS RLS ATUAIS (sync-bucket)
-- Execute no SQL Editor do Supabase antes de qualquer mudança
-- ============================================

-- 1. Listar políticas existentes (para registro manual)
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE schemaname = 'storage' AND tablename = 'objects';

-- 2. Backup: dropar políticas anon existentes (comente se quiser manter)
DROP POLICY IF EXISTS "anon_read"   ON storage.objects;
DROP POLICY IF EXISTS "anon_insert" ON storage.objects;
DROP POLICY IF EXISTS "anon_update" ON storage.objects;
DROP POLICY IF EXISTS "anon_delete" ON storage.objects;

-- 3. Rollback: recriar políticas anon (descomente se precisar voltar atrás)
-- CREATE POLICY "anon_read"   ON storage.objects FOR SELECT  TO anon USING (bucket_id = 'sync-bucket');
-- CREATE POLICY "anon_insert" ON storage.objects FOR INSERT  TO anon WITH CHECK (bucket_id = 'sync-bucket');
-- CREATE POLICY "anon_update" ON storage.objects FOR UPDATE  TO anon USING (bucket_id = 'sync-bucket') WITH CHECK (bucket_id = 'sync-bucket');
-- CREATE POLICY "anon_delete" ON storage.objects FOR DELETE  TO anon USING (bucket_id = 'sync-bucket');

-- ============================================
-- POLÍTICAS RECOMENDADAS (Opção C1 — Auth paralela desktop apenas)
-- Desktop usa authenticated; mobile mantém anon
-- ============================================

-- Políticas authenticated para paths do desktop
CREATE POLICY "auth_read_desktop"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
));

CREATE POLICY "auth_insert_desktop"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
));

CREATE POLICY "auth_update_desktop"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
))
WITH CHECK (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
));

CREATE POLICY "auth_delete_desktop"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
));

-- Políticas anon para paths do mobile (manter compatibilidade)
CREATE POLICY "anon_read_mobile"
ON storage.objects FOR SELECT
TO anon
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/users.json' OR
  name LIKE 'shared/form_%' OR
  name LIKE 'shared/data_%' OR
  name LIKE 'shared/tasks.json' OR
  name LIKE 'shared/ecoponto_%' OR
  name LIKE 'shared/app-version.json' OR
  name LIKE 'shared/inbox/%' OR
  name LIKE 'shared/adhoc/%' OR
  name LIKE 'users/%' OR
  name LIKE 'archive/%' OR
  name LIKE 'forms/%' OR
  name LIKE 'data/%'
));

CREATE POLICY "anon_insert_mobile"
ON storage.objects FOR INSERT
TO anon
WITH CHECK (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/inbox/%' OR
  name LIKE 'users/%/images/%' OR
  name LIKE 'archive/%'
));

CREATE POLICY "anon_update_mobile"
ON storage.objects FOR UPDATE
TO anon
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/inbox/%' OR
  name LIKE 'users/%/images/%' OR
  name LIKE 'archive/%'
))
WITH CHECK (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/inbox/%' OR
  name LIKE 'users/%/images/%' OR
  name LIKE 'archive/%'
));

CREATE POLICY "anon_delete_mobile"
ON storage.objects FOR DELETE
TO anon
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/inbox/%' OR
  name LIKE 'users/%/images/%' OR
  name LIKE 'archive/%'
));
