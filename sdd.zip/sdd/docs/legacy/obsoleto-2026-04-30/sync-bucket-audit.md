# Auditoria do Supabase Storage — `sync-bucket`

**Última atualização:** 2026-04-29

> **Nota (2026-04-29):** O mobile (`www/`) foi migrado para o pipeline de eventos unificado. Agora usa `www/js/sync/SyncAdapter` com eventos criptografados (`eventos/{routingId}/evt_*.enc`), idêntico ao desktop. Os paths legados (`shared/inbox/`, `users/{id}/images/`) foram depreciados mas ainda funcionam como fallback.

**Aplicativos envolvidos:** `desktop/` (Tauri + Next.js) e `www/` (Mobile/PWA)

---

## 1. Resumo Executivo

Ambos os aplicativos compartilham o bucket `sync-bucket`, mas usam **conjuntos de paths quase disjuntos**. O desktop opera via eventos criptografados (`eventos/`, `shared/manifests/`), enquanto o mobile opera via snapshots JSON e arquivos compartilhados (`shared/users.json`, `shared/inbox/`, `users/{id}/images/`).

**Risco identificado:** O mobile (`www/js/device-setup.js` e `smart-preloader.js`) declara `bucketName = 'suite'` como padrão, mas em alguns fluxos usa hardcoded `'sync-bucket'`. Isso pode indicar migração parcial ou configuração inconsistente.

---

## 2. Paths por Aplicativo

### 2.1 Desktop (`desktop/`)

| Path | Operação | Arquivo de origem | Descrição |
|------|----------|-------------------|-----------|
| `orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc` | **UPLOAD** | `TransportService.ts` | Evento individual criptografado (AES-256-GCM) |
| `orgs/{orgId}/eventos/{routingId}/lote_{demandaId}.tgz.enc` | **UPLOAD** | `TransportService.ts` | Lote de eventos criptografado |
| `orgs/{orgId}/manifests/manifest_{routingId}.json` | **UPLOAD/DOWNLOAD** | `Manifest.ts` | Controle de sequência e ack |
| `shared/org_config.json` | **UPLOAD/DOWNLOAD** | `StorageBootstrapService.ts`, `OrgConfigService.ts` | Config da org no primeiro boot |

**Nota:** Com a Fase 3 implementada, os paths agora usam prefixo `orgs/{orgId}/`. O `InboundService` e `Manifest` incluem fallback para paths legados (`eventos/...`, `shared/manifests/...`) durante o período de transição.

**Características do desktop:**
- Todos os uploads usam `SupabaseFileStorage` (wrapper sobre `@supabase/supabase-js`)
- Dados são criptografados antes do upload (chave nunca sai do Rust)
- Nenhum download de paths legados do mobile

### 2.2 Mobile (`www/`)

| Path | Operação | Arquivo de origem | Descrição |
|------|----------|-------------------|-----------|
| `shared/users.json` | **DOWNLOAD** | `auth-manager.js` | Cache de usuários para login offline |
| `shared/form_field_registry.json` | **DOWNLOAD** | `normalization-service.js`, `data-service.js` | Schema de campos de formulários |
| `shared/data_registry.json` | **DOWNLOAD** | `smart-cache.v2.js`, `device-setup.js` | Dados mestres (ecopontos, etc.) |
| `shared/tasks.json` | **DOWNLOAD** | `ActivityService.js` | Tarefas/activities atribuídas |
| `shared/ecoponto_caixas.json` | **DOWNLOAD** | `dashboard-service.js` | Dashboard de caixas |
| `shared/app-version.json` | **DOWNLOAD** | `system-config.js` | Controle de versão do app |
| `users/{userId}/inbox/` | **DOWNLOAD/LIST** | `ActivityService.js` | Tarefas atribuídas ao operador (snapshots) |
| `users/{userId}/inbox/{taskId}/` | **DOWNLOAD/LIST** | `ActivityService.js` | Patches de tarefa específica |
| `shared/adhoc/` | **DOWNLOAD/LIST** | `ActivityService.js` | Formulários ad-hoc disponíveis |
| `shared/inbox/users/{userId}/{filename}` | **UPLOAD** | `data-service.js` | Fallback de snapshot de formulário |
| `shared/inbox/{filename}` | **UPLOAD** | `data-service.js` | Update de status de tarefa |
| `users/{userId}/images/{filename}` | **UPLOAD** | `data-service.js` | Imagens/anexos dos formulários |
| `archive/{YYYY-MM}/{filename}` | **UPLOAD (move)** | `ActivityService.js` | Arquivamento de snaps processados |
| `forms/{formFile}` | **DOWNLOAD** | `device-setup.js`, `smart-preloader.js` | Definições de formulários |
| `data/{dataFile}` | **DOWNLOAD** | `device-setup.js`, `smart-preloader.js` | Dados estáticos |

**Nota sobre buckets no mobile:**
- `device-setup.js` e `smart-preloader.js` definem `this.bucketName = 'suite'`
- Porém, em vários pontos usam hardcoded `.from('sync-bucket')`
- Isso sugere que o bucket `suite` pode ser um resquício de configuração antiga

---

## 3. Conflitos e Sobreposições

| Path | Desktop | Mobile | Conflito? |
|------|---------|--------|-----------|
| `shared/org_config.json` | ✅ (cria/baixa) | ❌ | **Nenhum** |
| `shared/manifests/` | ✅ (cria/baixa) | ❌ | **Nenhum** |
| `eventos/` | ✅ (upload) | ❌ | **Nenhum** |
| `shared/users.json` | ✅ (mantém via bootstrap) | ✅ (baixa) | **Potencial** — ambos tocam, mas desktop mantém, mobile só lê |
| `shared/inbox/` | ❌ | ✅ (upload) | **Nenhum** — desktop não lê este path |
| `users/{id}/inbox/` | ❌ | ✅ (baixa) | **Nenhum** |
| `users/{id}/images/` | ❌ | ✅ (upload) | **Nenhum** |
| `shared/adhoc/` | ❌ | ✅ (baixa) | **Nenhum** |
| `archive/` | ❌ | ✅ (move) | **Nenhum** — desktop não usa archive |
| `forms/` | ❌ | ✅ (baixa) | **Nenhum** |
| `data/` | ❌ | ✅ (baixa) | **Nenhum** |

**Avaliação:** Não há conflitos de escrita entre desktop e mobile nos paths atuais. O único path compartilhado em escrita é `shared/users.json` (desktop escreve, mobile lê).

---

## 4. Políticas RLS

### 4.1 Políticas Atuais (v2 — Fases 2/3)

Com a Fase 2 (RLS authenticated) e Fase 3 (paths org-scoped), o bucket `sync-bucket` agora é protegido por **8 políticas dual-auth**:

**Políticas authenticated — Desktop (paths org-scoped):**
- `auth_read_desktop`, `auth_insert_desktop`, `auth_update_desktop`, `auth_delete_desktop`
- Paths: `orgs/%/eventos/%`, `orgs/%/manifests/%`, `shared/org_config.json`, `shared/.bootstrap_marker`, + legados

**Políticas anon — Mobile (paths restritos):**
- `anon_read_mobile`, `anon_insert_mobile`, `anon_update_mobile`, `anon_delete_mobile`
- Paths: `shared/users.json`, `shared/form_%`, `shared/data_%`, `shared/tasks.json`, `shared/inbox/%`, `shared/adhoc/%`, `users/%/images/%`, `archive/%`

As políticas completas estão em `desktop/supabase/migrations/01-storage-rls-v2.sql`.

### 4.2 Políticas Anteriores (v1 — substituídas)

As 4 políticas anon abertas anteriores foram removidas:
```sql
-- REMOVIDAS:
DROP POLICY IF EXISTS "anon_read"   ON storage.objects;
DROP POLICY IF EXISTS "anon_insert" ON storage.objects;
DROP POLICY IF EXISTS "anon_update" ON storage.objects;
DROP POLICY IF EXISTS "anon_delete" ON storage.objects;
```

**Status:** Dual-auth implementado no código (paths org-scoped) e script de migração pronto para execução no Supabase.

---

## 5. Script de Backup / Rollback das Políticas

Arquivo: `docs/sync-bucket-policies-backup.sql`

```sql
-- ============================================
-- BACKUP DAS POLÍTICAS RLS ATUAIS (sync-bucket)
-- Execute no SQL Editor do Supabase antes de qualquer mudança
-- ============================================

-- 1. Listar políticas existentes (para registro manual)
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE schemaname = 'storage' AND tablename = 'objects';

-- 2. Backup: dropar políticas anon existentes (comente se quiser manter)
DROP POLICY IF EXISTS "anon_read"   ON storage.objects;
DROP POLICY IF EXISTS "anon_insert" ON storage.objects;
DROP POLICY IF EXISTS "anon_update" ON storage.objects;
DROP POLICY IF EXISTS "anon_delete" ON storage.objects;

-- 3. Rollback: recriar políticas anon (descomente se precisar voltar atrás)
-- CREATE POLICY "anon_read"   ON storage.objects FOR SELECT  TO anon USING (bucket_id = 'sync-bucket');
-- CREATE POLICY "anon_insert" ON storage.objects FOR INSERT  TO anon WITH CHECK (bucket_id = 'sync-bucket');
-- CREATE POLICY "anon_update" ON storage.objects FOR UPDATE  TO anon USING (bucket_id = 'sync-bucket') WITH CHECK (bucket_id = 'sync-bucket');
-- CREATE POLICY "anon_delete" ON storage.objects FOR DELETE  TO anon USING (bucket_id = 'sync-bucket');

-- ============================================
-- POLÍTICAS RECOMENDADAS (Opção C1 — Auth paralela desktop apenas)
-- Desktop usa authenticated; mobile mantém anon
-- ============================================

-- Políticas authenticated para paths do desktop
CREATE POLICY "auth_read_desktop"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
));

CREATE POLICY "auth_insert_desktop"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
));

CREATE POLICY "auth_update_desktop"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
))
WITH CHECK (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
));

CREATE POLICY "auth_delete_desktop"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'eventos/%' OR
  name LIKE 'shared/manifests/%' OR
  name = 'shared/org_config.json'
));

-- Políticas anon para paths do mobile (manter compatibilidade)
CREATE POLICY "anon_read_mobile"
ON storage.objects FOR SELECT
TO anon
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/users.json' OR
  name LIKE 'shared/form_%' OR
  name LIKE 'shared/data_%' OR
  name LIKE 'shared/tasks.json' OR
  name LIKE 'shared/ecoponto_%' OR
  name LIKE 'shared/app-version.json' OR
  name LIKE 'shared/inbox/%' OR
  name LIKE 'shared/adhoc/%' OR
  name LIKE 'users/%' OR
  name LIKE 'archive/%' OR
  name LIKE 'forms/%' OR
  name LIKE 'data/%'
));

CREATE POLICY "anon_insert_mobile"
ON storage.objects FOR INSERT
TO anon
WITH CHECK (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/inbox/%' OR
  name LIKE 'users/%/images/%' OR
  name LIKE 'archive/%'
));

CREATE POLICY "anon_update_mobile"
ON storage.objects FOR UPDATE
TO anon
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/inbox/%' OR
  name LIKE 'users/%/images/%' OR
  name LIKE 'archive/%'
))
WITH CHECK (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/inbox/%' OR
  name LIKE 'users/%/images/%' OR
  name LIKE 'archive/%'
));

CREATE POLICY "anon_delete_mobile"
ON storage.objects FOR DELETE
TO anon
USING (bucket_id = 'sync-bucket' AND (
  name LIKE 'shared/inbox/%' OR
  name LIKE 'users/%/images/%' OR
  name LIKE 'archive/%'
));
```

---

## 6. Recomendações

1. **Corrigir bucket inconsistente no mobile:** `device-setup.js` e `smart-preloader.js` usam `bucketName = 'suite'` em alguns lugares e `'sync-bucket'` em outros. Padronizar para `'sync-bucket'`.

2. **Monitorar `shared/users.json`:** É o único path com escrita do desktop e leitura do mobile. Se o desktop parar de mantê-lo, o mobile perde autenticação offline.

3. **Isolamento por org (Fase 3):** Implementado. Os paths do desktop usam `orgs/{orgId}/eventos/...` e `orgs/{orgId}/manifests/...`. O mobile mantém acesso a paths na raiz (`shared/...`). `shared/users.json` ainda é compartilhado — migração para `public.profiles` planejada na Fase 5.

4. **Testes de validação (B5):**
   - [ ] Desktop online: `ensureBucket()` retorna `{ ok: true }`
   - [ ] Desktop: primeiro boot cria `shared/org_config.json`
   - [ ] Desktop: push de evento cria arquivo em `eventos/{routingId}/`
   - [ ] Mobile: login offline funciona (baixa `shared/users.json`)
   - [ ] Mobile: envio de formulário cria snapshot em `shared/inbox/users/{userId}/`
   - [ ] Mobile: upload de imagem cria arquivo em `users/{userId}/images/`
   - [ ] Mobile: sincronização de activities baixa de `users/{userId}/inbox/`

---

## 7. Referências

- `desktop/src/infrastructure/sync/TransportService.ts`
- `desktop/src/infrastructure/sync/InboundService.ts`
- `desktop/src/infrastructure/sync/Manifest.ts`
- `desktop/src/infrastructure/sync/StorageBootstrapService.ts`
- `www/js/data-service.js`
- `www/js/services/ActivityService.js`
- `www/js/auth-manager.js`
- `plans/supabase-integration.md`
- `plans/transicao-backend-consolidado.md`
