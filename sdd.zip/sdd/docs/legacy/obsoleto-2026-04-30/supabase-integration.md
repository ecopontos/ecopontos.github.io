# Plano de Integração: Backend Local → Supabase

> **Status: Atualizado — 2026-04-29**
>
> Fase 1 (Auth paralela), Fase 3 (paths org-scoped) e Fase 5 (Users central) concluídas. Fase 2 com script SQL pronto para execução manual. Fase 4 substituída por EventSyncAdapter.

**Contexto:** O sistema usa autenticação local (SQLite + bcrypt via Tauri Rust) totalmente separada do Supabase Auth. O Supabase é usado como Storage e Auth paralela. Este plano descreve as fases para conectar progressivamente o backend local com o Supabase sem quebrar o fluxo atual.

---

## Status de implementação

| Fase | Descrição | Status | Evidência |
|---|---|---|---|
| 1 | Supabase Auth paralela ao login local | ✅ Concluída | `AuthContext.tsx:42-59` — `syncSupabaseAuth()` com `signInWithPassword`/`signUp` |
| 2 | Storage RLS authenticated | ⚠️ Script pronto | `desktop/supabase/migrations/01-storage-rls-v2.sql` — executar no SQL Editor do Supabase |
| 3 | Isolamento por `orgs/{orgId}/` nos paths | ✅ Concluída | `TransportService.ts:71`, `InboundService.ts:35`, `Manifest.ts:20`, `lazy-sync.ts:31` |
| 4 | Ativar StorageSync (mobile/PWA) | ❌ Substituída | Arquitetura migrou para EventSyncAdapter; mobile usa `www/js/sync/` (13 arquivos, event pipeline) |
| 5 | Usuários Supabase como source of truth | ✅ Concluída | Auto-sync no login (`AuthContext.tsx:22-40`), hook `useSupabaseAdmin`, botão "Sincronizar Supabase" no painel admin |

---

## Situação atual

| Componente | Estado atual |
|---|---|
| Auth | Local (SQLite + bcrypt) com Supabase Auth paralela (Fase C1) |
| Supabase Auth | `signInWithPassword`/`signUp` chamados em background com email sintético `{username}@ecoforms.local` |
| Storage RLS | Políticas anon (todos podem ler/escrever `sync-bucket`) — migração para dual-auth pronta |
| Sync ativo | EventSyncAdapter: push/pull criptografado com paths `orgs/{orgId}/` |
| Sync legado | StorageSync.ts — arquivado em `_deprecated/`, não instanciado |
| Isolamento de dados | Por `orgId` no path (`orgs/{orgId}/eventos/...`) + `routingId` do setor |
| User sync Supabase | `syncUsersFromSupabase()` em `AuthContext` — auto-sync de `public.profiles` pós-login; manual via hook `useSupabaseAdmin` |
| Admin API Rust | `supabase_admin.rs` — CRUD de usuários Supabase via `ureq` HTTP; acessível via `useSupabaseAdmin` hook |

---

## Fase 1 — Supabase Auth paralela ao login local ✅

**Status: Concluída.** Implementada como "Fase C1".

### O que foi feito

1. **`desktop/contexts/AuthContext.tsx:22-39`**
   - `syncSupabaseAuth()` chama `supabase.auth.signInWithPassword({ email, password })`
   - Se falhar, chama `supabase.auth.signUp({ email, password })` para auto-provisionar
   - Email sintético: `{username}@ecoforms.local`
   - Todas as falhas são non-fatal (não bloqueiam login local)

2. **`desktop/contexts/AuthContext.tsx:183-193`**
   - Suporte offline: credenciais armazenadas em `pendingSupabaseAuthRef` e retry ao reconectar

3. **`desktop/contexts/AuthContext.tsx:72`**
   - Logout chama `supabase.auth.signOut()` além de limpar localStorage

4. **`desktop/src/infrastructure/persistence/supabase/supabaseClient.ts`**
   - Cliente configurado com `persistSession: true` e `autoRefreshToken: true`

---

## Fase 2 — Storage RLS baseada em usuário autenticado ⚠️

**Status: Script SQL pronto. Executar no SQL Editor do Supabase.**

### O que foi feito

1. **`desktop/supabase/migrations/01-storage-rls-v2.sql`**
   - Remove políticas `anon_read/insert/update/delete` abertas
   - Cria políticas `auth_*_desktop` para paths org-scoped + legados (acesso authenticated)
   - Mantém políticas `anon_*_mobile` para paths do mobile/PWA (compatibilidade)
   - Inclui rollback script comentado para emergências

### O que fazer (manual)

1. Abrir o SQL Editor no painel do Supabase
2. Executar `desktop/supabase/migrations/01-storage-rls-v2.sql`
3. Verificar com a query de verificação ao final do script

### Critério de conclusão
- Tentativa de acesso sem sessão retorna 401 para paths desktop
- Upload com sessão válida retorna 200
- Mobile PWA continua funcionando (paths anon mantidos)

---

## Fase 3 — Isolamento por organização no Storage path ✅

**Status: Concluída.** Todos os paths da pipeline de sync já usam `orgs/{orgId}/`.

### O que foi implementado

| Arquivo | Mudança |
|---|---|
| `TransportService.ts:23,71,77` | Construtor recebe `orgId`, paths `orgs/{orgId}/eventos/{routingId}/` |
| `InboundService.ts:22,35` | Construtor recebe `orgId`, paths `orgs/{orgId}/eventos/` com fallback legado |
| `Manifest.ts:16,20` | Construtor recebe `orgId`, paths `orgs/{orgId}/manifests/` com fallback legado |
| `lazy-sync.ts:31,51,57,114,128` | `orgId` propagado por toda a pipeline (getSyncAdapter e LazySyncAdapter) |
| `SyncContext.tsx:98,101` | `orgId` lido de `user?.org_id` e passado ao `LazySyncAdapter.configure()` |
| `StorageBootstrapService.ts:65,88` | Mantém `shared/org_config.json` (bootstrap precisa de path conhecido) |
| `OrgConfigService.ts:17` | `ORG_CONFIG_PATH = 'shared/org_config.json'` (consistente com bootstrap) |

### Estrutura de paths atual

```
sync-bucket/
  orgs/{orgId}/
    eventos/{routingId}/evt_{seq}_{id}.enc
    eventos/{routingId}/lote_{id}.tgz.enc
    manifests/manifest_{routingId}.json
  shared/
    org_config.json            ← bootstrap (path fixo)
    .bootstrap_marker
```

### Transição dual-read

Durante a transição, tanto `InboundService` quanto `Manifest` tentam o path org-scoped primeiro e, se não encontrar, fazem fallback para o path legado (`eventos/...`, `shared/manifests/...`). Isso permite convivência com dados antigos durante a migração.

---

## Fase 4 — Ativar StorageSync (mobile/web PWA) ❌

**Status: Substituída.** A arquitetura de sync migrou de snapshot-based (StorageSync) para event-based (EventSyncAdapter). O StorageSync original foi arquivado em `_deprecated/` e não é mais instanciado.

### O que existe hoje

| Componente | Localização | Descrição |
|---|---|---|
| EventSyncAdapter | `desktop/src/infrastructure/sync/EventSyncAdapter.ts` | Orquestrador de sync por eventos |
| Mobile event pipeline | `www/js/sync/` (13 arquivos) | Espelho JS do pipeline desktop: `CryptoLayer.js`, `EventBus.js`, `TransportService.js`, `InboundService.js`, `SyncAdapter.js`, etc. |
| SyncEventDB | `www/js/sync/SyncEventDB.js` | IndexedDB para fila de eventos no mobile |
| AuthManager integração | `www/js/auth-manager.js` | `login()` inicia SyncAdapter, `logout()` para e limpa |
| DataService integração | `www/js/data-service.js` | `saveFormData()` publica eventos `ecoforms.registro.criado` |

### Por que a Fase 4 original é obsoleta

- `StorageSync.ts` → `_deprecated/StorageSync.ts` (snapshot sync)
- `StorageSyncPort.ts` → `application/ports/_deprecated/StorageSyncPort.ts`
- `OfflineQueue.ts` → `_deprecated/OfflineQueue.ts`
- `indexeddb.ts` → `_deprecated/indexeddb.ts`

O pipeline de eventos (`EventSyncAdapter`) oferece:
- Criptografia ponta-a-ponta (AES-256-GCM)
- Ordenação por sequência (seq numbers)
- Resolução de conflitos determinística
- Compatibilidade cross-platform (desktop Tauri ↔ mobile PWA)
- Bit-identical envelopes entre desktop (TypeScript) e mobile (JavaScript)

---

## Fase 5 — Usuários Supabase como source of truth ✅

**Status: Concluída (2026-04-29).**

### O que foi feito

1. **`desktop/supabase/migrations/02-public-profiles.sql`**
   - `CREATE TABLE public.profiles` com RLS
   - Trigger `handle_new_user()` para auto-criar perfil ao criar usuário no Auth
   - Políticas: leitura por org, update próprio ou admin

2. **`desktop/src/infrastructure/sync/SupabaseUserSyncService.ts`**
   - `syncFromSupabase(profiles)` — recebe array de profiles do Supabase, faz upsert no SQLite local
   - `syncDeactivated(activeIds)` — desativa usuários locais que não existem mais no Supabase
   - Usa tabela `supabase_user_map` para mapeamento `local_id ↔ supabase_id`

3. **`desktop/scripts/ensure-columns.ts`** (Migration 011)
   - `CREATE TABLE supabase_user_map` para mapeamento de IDs

4. **`desktop/src-tauri/src/supabase_admin.rs`**
   - Chamadas HTTP reais via `ureq` para Supabase Management API
   - Operações: `read_users`, `create_user`, `update_user`, `delete_user`
   - Autenticação via `SUPABASE_SERVICE_ROLE_KEY` (nunca exposta ao frontend)

5. **`desktop/contexts/AuthContext.tsx:22-40`** — `syncUsersFromSupabase()` *(novo)*
   - Executado automaticamente após login bem-sucedido com Supabase Auth estabelecida
   - Busca `public.profiles` via Supabase JS client
   - Instancia `SupabaseUserSyncService` via container DI e executa sync
   - Non-fatal, fire-and-forget; também executado no retry ao reconectar offline

6. **`desktop/src/interface/hooks/queries/useSupabaseAdmin.ts`** *(novo)*
   - `syncFromSupabase()` — busca `public.profiles` e executa sync completo (com estado `syncing`)
   - `readUsers()` — lista usuários do Supabase Auth via `invoke('supabase_admin_query')`
   - `createSupabaseUser(email, password, metadata)` — provisiona usuário no Supabase Auth
   - `updateSupabaseUser(supabaseId, metadata)` — atualiza metadados
   - `deleteSupabaseUser(supabaseId)` — remove do Supabase Auth

7. **`desktop/app/admin/users/page.tsx`** *(atualizado)*
   - Botão "Sincronizar Supabase" (requer `users.edit`) com spinner animado durante sync
   - Banner de resultado (verde: processados/criados/atualizados; vermelho: erro)
   - Recarrega lista local após sync

### Fluxo de sincronização

```
Login bem-sucedido
  └─ syncSupabaseAuth()          ← Fase 1: estabelece sessão Supabase Auth
       └─ syncUsersFromSupabase() ← Fase 5: busca public.profiles → upsert SQLite local
                                            (via SupabaseUserSyncService + supabase_user_map)

Admin panel (/admin/users)
  └─ [Sincronizar Supabase]      ← Manual: mesmo fluxo via useSupabaseAdmin.syncFromSupabase()
  └─ [CRUD via supabase_admin_query] ← Rust HTTP → Supabase Management API
```

### Pré-requisito manual

Executar `desktop/supabase/migrations/02-public-profiles.sql` no SQL Editor do Supabase (cria a tabela `public.profiles` e triggers).

---

## Arquivos criados/modificados

| Arquivo | Fase | Descrição |
|---|---|---|
| `desktop/supabase/migrations/01-storage-rls-v2.sql` | 2 | Migração RLS dual-auth |
| `desktop/supabase/migrations/02-public-profiles.sql` | 5 | Tabela profiles + triggers + RLS |
| `desktop/src/infrastructure/sync/SupabaseUserSyncService.ts` | 5 | Serviço de sync de usuários Supabase → SQLite |
| `desktop/scripts/ensure-columns.ts` | 5 | +Migration 011: `supabase_user_map` |
| `desktop/src-tauri/Cargo.toml` | 5 | +`ureq` com feature `json` |
| `desktop/src-tauri/src/supabase_admin.rs` | 5 | Chamadas HTTP reais para Supabase Admin API |
| `desktop/contexts/AuthContext.tsx` | 5 | +`syncUsersFromSupabase()` — auto-sync pós-login |
| `desktop/src/interface/hooks/queries/useSupabaseAdmin.ts` | 5 | Hook: sync manual + CRUD Supabase Auth via admin API |
| `desktop/app/admin/users/page.tsx` | 5 | +Botão "Sincronizar Supabase" e banner de resultado |
| `docs/supabase-integration.md` | — | Este documento |
