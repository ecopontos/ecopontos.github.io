# Decisão de Arquitetura: Adiar Migração para `orgs/{orgId}/`

**Data:** 2026-04-29  
**Decisão:** Adiar a migração de paths para `orgs/{orgId}/` no Supabase Storage.  
**Decisor:** Usuário (após análise de prós e contras apresentada pelo assistente).  

---

## Contexto

A migração para paths prefixados com `orgs/{orgId}/` foi proposta como parte da Fase D do plano `transicao-backend-consolidado.md`. O objetivo era suportar multi-tenancy (múltiplas organizações no mesmo bucket `sync-bucket`).

Após apresentação dos prós e contras, a decisão foi **adiar** a implementação.

---

## Motivos da Decisão

1. **Cliente único atual:** O sistema atende apenas à Prefeitura de Florianópolis. Não há necessidade imediata de isolamento por organização.

2. **Risco de breaking change:** A migração afetaria tanto o desktop quanto o mobile (`www/`). O mobile está ativo em campo e qualquer mudança nos paths exigiria reinstalação/atualização dos APKs dos operadores.

3. **Momento inadequado:** A Fase C1 (Auth paralela no desktop) acabou de ser implementada. É prudente validar a estabilidade da sessão Supabase antes de adicionar mais complexidade.

4. **Rollback complexo:** A migração de arquivos existentes no bucket é irreversível sem backup completo.

---

## Alternativa Adotada

Manter os paths atuais na raiz do bucket `sync-bucket`. O `orgId` será registrado apenas como metadata em:

- `shared/org_config.json` (desktop já lê/cria este arquivo)
- Tabela SQLite local `tbl_config` ou similar (se necessário no futuro)

Quando houver um segundo cliente confirmado, a migração será reconsiderada.

---

## Impacto nos Documentos

- `plans/transicao-backend-consolidado.md`: Fase D marcada como "Adiada"
- `docs/sync-bucket-policies-backup.sql`: Políticas RLS atuais permanecem válidas (sem verificação de org)
- `CLAUDE.md`: Não requer alteração — paths atuais continuam corretos

---

## Reavaliação Futura

Reconsiderar a migração quando:
- [ ] Segundo cliente confirmado e contratado
- [ ] Mobile tiver sistema de auto-update (OTA) funcionando
- [ ] Ambiente de staging separado disponível para testar a migração
- [ ] Backup completo do bucket `sync-bucket` realizado

---

## Referências

- `plans/transicao-backend-consolidado.md` — Plano original de transição
- `docs/sync-bucket-audit.md` — Auditoria dos paths atuais no bucket
