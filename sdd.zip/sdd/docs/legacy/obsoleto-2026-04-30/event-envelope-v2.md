# Event Envelope v2 — Modelo de Dados Event-Driven

> Este documento descreve o formato de envelope de eventos usado pelo sistema de sync ativo (`EventSyncAdapter`). O código implementa uma **versão simplificada** do formato v2 em `src/infrastructure/sync/EventEnvelope.ts`. Alguns campos propostos originalmente (CloudEvents-like) ainda não foram implementados — veja seção 4 para o formato real vs. o formato alvo.
>
> **Arquivo de implementação:** `src/infrastructure/sync/EventEnvelope.ts`

---

## Relacao com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `api-contract.md` | Contrato atual de Storage Messages (Snapshot v1) |
| `data-system.md` | Tipos canonicos e servicos de sync |
| `error-handling.md` | Retry logic e offline queue |
| `adr.md` | AD-002: Pure Storage Mode, AD-003: Append-Only |
| `plans/refatorar.md` | Proposta de arquitetura event-driven completa |

---

## 1. Diagnostico do Envelope Atual (v1)

### 1.1 Formato Snapshot v1

```json
{
    "version": "1.0",
    "timestamp": "2024-01-15T10:30:00.000Z",
    "device_id": "device-uuid-123",
    "origin_device": "device-uuid-123",
    "sync_type": "incremental | full",
    "data": {
        "tbl_suite": [...],
        "tbl_tarefas": [...]
    },
    "metadata": {
        "checksum": "sha256:abc123...",
        "record_count": { "tbl_suite": 5 },
        "compressed": true,
        "file_size_bytes": 45231
    }
}
```

### 1.2 Gaps Identificados

| Gap | Impacto | Severidade |
|-----|---------|------------|
| **Sem identidade do evento** | Nao da para rastrear causacao (quem gerou, por que) | Alta |
| **Sem schema version** | Evolucao do formato e dificil; quebra silenciosa | Alta |
| **payload_json como string** | Dupla serializacao; perda de tipagem; dificil validar | Media |
| **Sem correlation/causation** | Nao da para reconstruir cadeia de decisoes | Media |
| **sync_type impreciso** | "incremental" nao diz o que mudou nem por que | Media |
| **Sem estado de sync** | Nao da para saber se ja foi enviado, falhou, etc. | Baixa |
| **timestamp ambiguo** | E hora do evento ou hora do sync? | Baixa |

---

## 2. Proposta: Event Envelope v2

### 2.1 Principios de Evolucao

1. **Backward-compatible:** v1 continua funcionando; v2 e opt-in
2. **Event-driven mindset:** Cada snapshot representa um **fato** ocorrido no dominio
3. **Rastreabilidade:** Todo artefato carrega identidade, origem e causalidade
4. **Schema evolution:** Versionamento explicito do contrato
5. **Payload nativo:** JSON como objeto, nao string escapada

### 2.2 Formato v2

```json
{
    "specversion": "2.0",
    "id": "evt_abc123_uniq",
    "type": "ecoforms.snapshot.incremental",
    "source": "desktop/device-uuid-123",
    "subject": "aggregate:tbl_suite:pkg-uuid-456",
    "time": "2024-01-15T10:30:00.000Z",
    "datacontenttype": "application/json",

    "ecoforms": {
        "schema": {
            "version": 2,
            "compat": [1, 2]
        },
        "trace": {
            "trace_id": "trace_xyz789",
            "span_id": "span_abc123",
            "correlation_id": "case_eco_00077",
            "causation_id": "evt_previous_456"
        },
        "producer": {
            "module": "task-sync",
            "device_id": "desktop-centro-01",
            "user_id": "usr_021",
            "version": "1.4.2"
        },
        "sync": {
            "state": "QUEUED_UPLOAD",
            "local_only": true,
            "retry_count": 0,
            "last_attempt": null,
            "error": null
        },
        "sequence": {
            "stream": "device-uuid-123/tbl_suite",
            "position": 47,
            "total": 120
        }
    },

    "data": {
        "tbl_suite": [
            {
                "package_id": "pkg-uuid-456",
                "version_no": 2,
                "payload": {
                    "ecoponto": "ECO-001",
                    "caixas_list": {"ocupacao": {"c1": 80}}
                }
            }
        ]
    },

    "metadata": {
        "checksum": "sha256:d7a8f9...",
        "record_count": 1,
        "file_size_bytes": 1847,
        "schema_ref": "tbl_suite/v2"
    }
}
```

### 2.3 Campos Novos vs. v1

| Campo v2 | Origem (refatorar.md) | Proposito |
|----------|----------------------|-----------|
| `specversion` | CloudEvents | Padronizacao CNCF; interoperabilidade futura |
| `id` | `header.id` | Identidade unica do evento (nao do snapshot) |
| `type` | `header.type` | Semantica do evento: `snapshot.incremental`, `task.status_changed`, etc. |
| `source` | `producer` | Origem do evento (device, modulo) |
| `subject` | `header.idcase` | Agregado afetado: `aggregate:{tipo}:{id}` |
| `ecoforms.schema.version` | `header.schemaVersion` | Versionamento do contrato de dados |
| `ecoforms.trace` | `correlationId`, `causationId` | Rastreabilidade causal |
| `ecoforms.producer` | `producer` | Quem/onde gerou |
| `ecoforms.sync` | `sync` | Estado de sincronizacao (fila, retry, erro) |
| `ecoforms.sequence` | `bundleSequence` | Ordenacao dentro do stream |
| `payload` (objeto) | `body` | Substituir `payload_json` string |

### 2.4 Tipos de Evento (type)

```
ecoforms.snapshot.incremental     — Sync parcial (default)
ecoforms.snapshot.full            — Sync completo
ecoforms.task.created             — Nova tarefa
ecoforms.task.status_changed      — Transicao de status
ecoforms.task.assigned            — Atribuicao de responsavel
ecoforms.suite.package_created    — Novo pacote tbl_suite
ecoforms.suite.status_changed     — Transicao de status de pacote
ecoforms.form.submitted           — Formulario enviado (Ad Hoc)
ecoforms.form.submitted_as_task   — Ad Hoc virou ghost task
ecoforms.media.attached           — Anexo adicionado
ecoforms.comment.added            — Comentario adicionado
ecoforms.project.created          — Novo projeto
ecoforms.project.archived         — Projeto arquivado
```

---

## 3. Tabela de Transicao: v1 -> v2

### 3.1 Mapeamento de Campos

| Campo v1 | Campo v2 | Transformacao |
|----------|----------|---------------|
| `version` | `specversion` | "1.0" -> "2.0" |
| `timestamp` | `time` | Mesmo valor; semantica: hora do evento |
| `device_id` | `ecoforms.producer.device_id` | Extraido para producer |
| `origin_device` | `source` | Formato: `desktop/{device_id}` |
| `sync_type` | `type` | "incremental" -> "ecoforms.snapshot.incremental" |
| `data` | `data` | Mesmo conteudo; payload como objeto |
| `metadata.checksum` | `metadata.checksum` | Mesmo |
| `metadata.record_count` | `metadata.record_count` | Mesmo |
| `metadata.file_size_bytes` | `metadata.file_size_bytes` | Mesmo |
| *(novo)* | `id` | UUID do evento (nao do agregado) |
| *(novo)* | `subject` | `aggregate:{tipo}:{id}` |
| *(novo)* | `ecoforms.trace` | correlationId, causationId, trace_id |
| *(novo)* | `ecoforms.sync` | estado de upload: QUEUED, SENT, ACK, ERROR |

### 3.2 Payload: string -> objeto

```json
// v1 (string escapada — problema)
{
    "payload_json": "{\"ecoponto\":\"ECO-001\",\"caixas_list\":{...}}"
}

// v2 (objeto nativo — solucao)
{
    "payload": {
        "ecoponto": "ECO-001",
        "caixas_list": {
            "ocupacao": {"c1": 80, "c2": 45}
        }
    }
}
```

**Beneficios:**
- ✅ Nao precisa `JSON.parse()` para acessar campos
- ✅ Tipagem automatica (TypeScript infere)
- ✅ Validacao com Zod funciona em profundidade
- ✅ Menor tamanho (sem escaping de quotes)

---

## 4. Rastreabilidade: correlationId + causationId

### 4.1 Conceitos

| Campo | Significado | Exemplo |
|-------|-------------|---------|
| `correlation_id` | Identidade da conversa/caso inteiro | `case_eco_00077` (sempre = idcase) |
| `causation_id` | Evento imediatamente anterior que causou este | `evt_task_dispatched_001` |
| `trace_id` | Trace distribuido (opcional, para observabilidade) | `trace_xyz789` |

### 4.2 Cadeia de Eventos

```
Evento 1 (origem):
  id: evt_record_created_001
  type: case.origin_record.created
  correlation_id: case_eco_00077
  causation_id: null

Evento 2 (consequencia):
  id: evt_task_dispatched_002
  type: case.event.task_dispatched
  correlation_id: case_eco_00077
  causation_id: evt_record_created_001

Evento 3 (alteracao):
  id: evt_due_changed_003
  type: case.event.task_due_date_changed
  correlation_id: case_eco_00077
  causation_id: evt_task_dispatched_002

Evento 4 (conclusao):
  id: evt_completed_004
  type: case.event.task_completed
  correlation_id: case_eco_00077
  causation_id: evt_due_changed_003
```

**Beneficio:** Da para reconstruir toda a cadeia de decisoes de um caso.

---

## 5. Schema Evolution

### 5.1 Versionamento

```json
{
    "ecoforms": {
        "schema": {
            "version": 2,
            "compat": [1, 2]
        }
    }
}
```

| Campo | Significado |
|-------|-------------|
| `version` | Versao deste envelope |
| `compat` | Versoes que este consumer consegue ler |

### 5.2 Regras de Compatibilidade

| Mudanca | Exemplo | Breaking? |
|---------|---------|-----------|
| Adicionar campo opcional | `+ ecoforms.sync.error` | Nao |
| Renomear campo | `sync_type` -> `type` | Sim (major) |
| Mudar tipo | `payload_json` string -> `payload` objeto | Sim (major) |
| Remover campo | `- origin_device` | Sim (major) |
| Adicionar type | `+ ecoforms.snapshot.delta` | Nao |

### 5.3 Migration Path

```
v1 (atual)                    v2 (proposto)
   |                              |
   |  1. Leitor aceita ambos      |
   |     (compat: [1, 2])         |
   |                              |
   |  2. Novos snapshots em v2    |
   |     (type: snapshot.v2)      |
   |                              |
   |  3. Leitor atualizado        |
   |     (compat: [2])            |
   |                              |
   |  4. v1 deprecated            |
   v                              v
[coexistencia]              [v2 only]
```

---

## 6. Sync State (ecoforms.sync)

### 6.1 Estados Possiveis

```json
{
    "sync": {
        "state": "QUEUED_UPLOAD | UPLOADING | SENT | ACK | ERROR | PENDING_PULL",
        "local_only": true,
        "retry_count": 0,
        "last_attempt": "2024-01-15T10:30:00Z",
        "error": null,
        "resolved_at": null
    }
}
```

| Estado | Significado |
|--------|-------------|
| `QUEUED_UPLOAD` | Na fila, aguardando rede |
| `UPLOADING` | Em progresso |
| `SENT` | Enviado, aguardando ACK |
| `ACK` | Confirmado pelo servidor |
| `ERROR` | Falhou (max retries atingido) |
| `PENDING_PULL` | Recebido da nuvem, aguardando processamento |

### 6.2 Integracao com Offline Queue

```ts
// offline-queue.ts — enriquecido com sync state

interface QueuedMutation {
    id: string;
    sql: string;
    params: any[];
    timestamp: number;
    retryCount: number;
    label?: string;
    
    // Novo: metadados de sync
    sync: {
        state: 'QUEUED_UPLOAD' | 'UPLOADING' | 'SENT' | 'ACK' | 'ERROR';
        lastAttempt?: string;
        error?: string;
        eventId?: string;        // correlation com envelope
        causationId?: string;    // encadeamento
    };
}
```

---

## 7. Integracao com Arquitetura Atual

### 7.1 O que Muda no Codigo

| Componente | Mudanca | Impacto |
|------------|---------|---------|
| `storage-sync.ts` | Gerar envelopes v2 (opt-in) | Baixo — flag `useV2` |
| `supabase-sync.ts` | Interpretar `type` para routing | Baixo — dispatch por type |
| `offline-queue.ts` | Adicionar sync state | Baixo — campo extra |
| `task-sync.ts` | Gerar causation_id ao encadear | Medio — rastrear anterior |
| `database.ts` | Adicionar colunas trace | Medio — migration |
| Validacao | Zod schema v2 | Baixo — novo schema |

### 7.2 O que NAO Muda (Backward Compatible)

| Componente | Razao |
|------------|-------|
| `tbl_tarefas` | Mantem estrutura; adiciona colunas opcionais |
| `tbl_suite` | Mantem append-only; payload vira objeto |
| `form_registry` | Inalterado |
| `data_registry` | Inalterado |
| Pure Storage Mode | Mantem JSON.gz; envelope evolui |
| Supabase Storage | Mantem paths; conteudo evolui |

### 7.3 Migration Path Sugerido

**Fase 1 (v2.0):** Envelope opcional
- Adicionar `ecoforms.sync.state` a offline queue
- Gerar envelopes v2 para novos snapshots
- Manter leitura v1

**Fase 2 (v2.1):** Rastreabilidade
- Adicionar `correlation_id`, `causation_id` a tabelas-chave
- Instrumentar use cases para gerar trace

**Fase 3 (v2.2):** Payload nativo
- Migrar `payload_json` string -> objeto em novos registros
- Converter legacy on-read

**Fase 4 (v2.3):** Event semantics
- Adicionar `type` granular (task.created, suite.status_changed)
- Substituir sync_type generico

---

## 7.1 Tipos de Evento (`EcoFormsEventType`)

O union type `EcoFormsEventType` em `src/infrastructure/sync/EventEnvelope.ts` define todos os eventos reconhecidos pelo sistema:

**Eventos de Tarefa:**
- `task.criada`

**Eventos de Demanda:**
- `demanda.criada`
- `demanda.aceita`
- `demanda.encerrada`

**Eventos de Suite:**
- `suite.aprovada`
- `suite.rejeitada`

**Eventos de Ecoponto:**
- `ecoponto.remocao.agendada`

**Eventos de Ouvidoria (legados):**
- `ouvidoria.protocolo.criado`
- `ouvidoria.protocolo.encerrado`

**Handlers Inbound:**
| Evento | Handler | Comportamento |
|---|---|---|
| `suite.aprovada` | `suite.handler.ts` | Atualiza `tbl_suite.status = 'approved'` |
| `suite.rejeitada` | `suite.handler.ts` | Atualiza `tbl_suite.status = 'refuted'` |
| `ecoponto.remocao.agendada` | `ecoponto.handler.ts` | Cria tarefa `Remoção Ecoponto {id}` no status `a_fazer` |

Consulte `action-widget-system.md` §2.6 para o mapeamento completo de ações → eventos.

---

## 8. Formato Real Implementado (Simplificado)

O código em `src/infrastructure/sync/EventEnvelope.ts` implementa uma versão simplificada do v2:

```ts
interface EventEnvelope {
    v: 2;                              // versão (number, não string "specversion")
    id: string;                        // UUID do evento
    type: EcoFormsEventType;           // semântica do evento
    time: string;                      // ISO timestamp
    source: {
        device_id: string;
        routing_id: string;
        routing_type: string;
        module: string;
        app_version: string;
    };
    aggregate: {
        type: string;
        id: string;
    };
    schema_version: number;            // versionamento do contrato
    prev_event_id: string;             // similar a causation_id
    correlation_id?: string;
    causation_id?: string;
    data: Record<string, unknown>;     // payload nativo (objeto)
}
```

**Diferenças em relação à proposta original:**

| Campo Proposto | Campo Real | Observação |
|----------------|-----------|------------|
| `specversion` | `v: 2` | Simplificado para número |
| `source` (string) | `source` (objeto) | Inclui `device_id`, `routing_id`, `routing_type`, `module`, `app_version` |
| `subject` | `aggregate` | Objeto `{ type, id }` em vez de string `aggregate:tipo:id` |
| `datacontenttype` | ❌ Ausente | Sempre JSON |
| `ecoforms.schema.compat` | `schema_version: number` | Sem array de compatibilidade |
| `ecoforms.trace` | ❌ Ausente | `correlation_id` e `causation_id` são campos de primeiro nível |
| `ecoforms.producer` | `source` | Dados do produtor estão em `source` |
| `ecoforms.sync` | ❌ Ausente | Estado de sync fica na tabela `sync_event_queue` |
| `ecoforms.sequence` | `seq` (no banco) | A sequência é controlada pelo `Manifest` e `sync_device_log` |

**Tabelas de suporte:**
- `sync_event_queue` — fila de eventos pendentes (`status: pending | sent | failed`)
- `sync_device_log` — log de sequências por dispositivo (`device_id`, `seq`, `event_id`)

---

## 9. Gaps Preenchidos

| Gap Original | Solucao v2 | Documento Relacionado |
|--------------|-----------|----------------------|
| Sem identidade do evento | `id`, `type` | api-contract.md |
| Sem schema version | `ecoforms.schema.version` | data-system.md |
| payload_json como string | `payload` objeto | database.md |
| Sem correlation | `ecoforms.trace.correlation_id` | error-handling.md |
| Sem causation | `ecoforms.trace.causation_id` | error-handling.md |
| sync_type impreciso | `type` granular | api-contract.md |
| Sem estado de sync | `ecoforms.sync.state` | error-handling.md |
| Timestamp ambiguo | `time` (evento) vs `recorded_at` | api-contract.md |

---

## 9. Decisao Arquitetural

### AD-008: Event Envelope v2

**Contexto:** O envelope Snapshot v1 funciona mas carece de rastreabilidade, schema evolution e semantica de eventos para um sistema que ja opera de forma event-driven (append-only tbl_suite, status machines, offline queue).

**Decisao:** Adotar Event Envelope v2 como formato opt-in para novos snapshots, mantendo compatibilidade com v1.

**Consequencias:**
- ✅ Melhor observabilidade e debugging
- ✅ Schema evolution controlada
- ✅ Payload nativo (menor, tipado)
- ✅ Base para event sourcing futuro
- ⚠️ Custo de migration gradual
- ⚠️ Consumer precisa suportar ambos durante transicao

---

## 10. Checklist de Implementacao

- [ ] Criar tipo TypeScript `EventEnvelopeV2`
- [ ] Criar Zod schema para validacao
- [ ] Adicionar flag `useV2Envelope` em sync-config
- [ ] Atualizar `storage-sync.ts` para gerar v2 quando flag=true
- [ ] Atualizar `validateSnapshot` para aceitar v1 e v2
- [ ] Adicionar colunas `correlation_id`, `causation_id` em `tbl_tarefas`, `tbl_suite`
- [ ] Instrumentar `CreateTaskUseCase` para gerar `causation_id`
- [ ] Atualizar `offline-queue.ts` com sync state
- [ ] Testes: v1->v2 migration, backward compat
- [ ] Documentar em `api-contract.md` (versao v2 do envelope)

---

## Resumo

A proposta `plans/refatorar.md` apresenta uma arquitetura event-driven completa com identidade, causalidade e projecoes. Este documento extrai os elementos aplicaveis **sem reescrever o sistema inteiro**:

1. **Envelope v2** com identidade, schema version e trace
2. **Payload como objeto** (fim do `payload_json` string)
3. **Sync state** integrado a offline queue
4. **Correlation/causation** para rastreabilidade
5. **Migration path** backward-compatible em 4 fases

Isso permite evoluir gradualmente para um modelo mais event-driven sem abandonar a arquitetura atual documentada.
