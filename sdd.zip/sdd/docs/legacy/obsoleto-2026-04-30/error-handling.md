# Error Handling — EcoForms Desktop

Este documento descreve a estratégia de tratamento de erros do sistema EcoForms Desktop, incluindo retry logic, offline queue, e estratégias de recovery.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `arquitetura.md` | Visão geral da arquitetura |
| `data-system.md` | Tipos canônicos, portas, serviços de sync |
| `api-contract.md` | Contrato de API, formatos de mensagem |
| `adr.md` | Decisões arquiteturais (AD-002: Pure Storage Mode) |

---

## Índice

1. [Visão Geral da Estratégia](#1-visão-geral-da-estratégia)
2. [Retry com Exponential Backoff](#2-retry-com-exponential-backoff)
3. [Offline Queue (Fila de Mutações)](#3-offline-queue-fila-de-mutações)
4. [Tratamento de Erros no Sync](#4-tratamento-de-erros-no-sync)
5. [Recovery de Snapshots Corrompidos](#5-recovery-de-snapshots-corrompidos)
6. [Dead Letter Handling](#6-dead-letter-handling)
7. [Erros de Validação](#7-erros-de-validação)
8. [Logging e Monitoramento](#8-logging-e-monitoramento)

---

## 1. Visão Geral da Estratégia

```
┌────────────────────────────────────────────────────────────────────────────────┐
│                              ERRO DETECTADO                                      │
└────────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────────────┐
│ 1. CLASSIFICAÇÃO DO ERRO                                                       │
│                                                                                │
│    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────────────┐  │
│    │  RECUPERÁVEL   │    │  TEMPORÁRIO     │    │    FATAL               │  │
│    │  (retry)       │    │  (offline queue)│    │    (dead letter)       │  │
│    └─────────────────┘    └─────────────────┘    └─────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────────┘
            │                        │                        │
            ▼                        ▼                        ▼
     Retry 1-3x              Queue IndexedDB          Log + Alert
     com backoff             Processar depois          Descartar
```

### Tipos de Erro

| Tipo | Origem | Ação |
|------|--------|------|
| **Network Error** | Timeout, DNS, conexão | Retry com backoff |
| **Storage Error** | Supabase indisponível | Retry + Offline Queue |
| **Validation Error** | Schema mismatch, dados inválidos | Log + Skip |
| **Checksum Error** | Arquivo corrompido | Recovery automático |
| **Fatal Error** | Erro de programação | Dead letter + alert |

---

## 2. Retry com Exponential Backoff

### 2.1 Implementação

**Arquivo:** `lib/sync/retry-logic.ts`

```ts
interface RetryOptions {
    maxRetries?: number;       // default: 3
    initialDelay?: number;     // default: 1000ms
    maxDelay?: number;         // default: 30000ms
    backoffFactor?: number;    // default: 2
    onRetry?: (attempt: number, error: Error) => void;
}
```

### 2.2 Algoritmo

```
Attempt 0: delay = 1000ms  (1s)
Attempt 1: delay = 2000ms  (2s)
Attempt 2: delay = 4000ms  (4s)
Attempt 3: delay = 8000ms  (8s)
... até maxDelay (30s)
```

### 2.3 Exemplo de Uso

```ts
await retryWithBackoff(
    () => supabase.storage.from('sync-bucket').upload(path, blob),
    {
        maxRetries: 3,
        initialDelay: 1000,
        onRetry: (attempt, error) => {
            console.warn(`Retry ${attempt} after error: ${error.message}`);
        }
    }
);
```

### 2.4 Erros Recuperáveis vs Não-Recuperáveis

```ts
function isRetryableError(error: any): boolean {
    // Erros de rede — recuperáveis
    if (error.message?.includes('network') || error.message?.includes('fetch')) {
        return true;
    }

    // Timeouts — recuperáveis
    if (error.message?.includes('timeout')) {
        return true;
    }

    // 5xx errors — recuperáveis
    if (error.status >= 500 && error.status < 600) {
        return true;
    }

    // 429 (rate limit) — recuperáveis
    if (error.status === 429) {
        return true;
    }

    // Outros — não recuperáveis
    return false;
}
```

### 2.5 Códigos de Erro HTTP

| Código | Significado | Ação |
|--------|-------------|------|
| `NoSuchKey` | Arquivo não encontrado | Ignorar |
| `404` | Resource não encontrado | Retry com backoff |
| `429` | Rate limit | Retry após delay |
| `500` | Erro interno Supabase | Retry com backoff |
| `502` | Bad Gateway | Retry com backoff |
| `503` | Service unavailable | Retry com backoff |
| `413` | Payload too large | Chunking ou compressão |

---

## 3. Offline Queue (Fila de Mutações)

### 3.1 Arquitetura

```
MUTATION OCCURS
      │
      ▼
offlineQueue.enqueue(sql, params, label)
      │
      ▼
IndexedDB (ecoforms-offline-queue / mutations)
      │
      ▼
  VOLTA ONLINE
      │
      ▼
offlineQueue.processAll(execFn)
      │
      ├──▶ FIFO replay: mutation.sql → db.execute()
      │
      └──▶ Max 3 retries por mutation
               │
               ├── success: delete mutation, continue
               │
               └── failure after 3 retries: DISCARD + log
```

### 3.2 Schema IndexedDB

```ts
interface QueuedMutation {
    id: string;              // `${Date.now()}-${random}`
    sql: string;             // SQL command
    params: any[];           // Parameters
    timestamp: number;       // Unix timestamp
    retryCount: number;      // Current retry count
    label?: string;          // Human-readable description
}
```

### 3.3 Limites

| Parâmetro | Valor | Descrição |
|-----------|-------|-----------|
| `maxRetries` | 3 | Tentativas antes de descartar |
| Max queue size | Unlimited | IndexedDB é virtualmente infinito |
| Retention | Until processed | Mutations são removidas após sucesso ou descarte |

### 3.4 Exemplo de Uso

```ts
// Enqueue mutation when offline
await offlineQueue.enqueue(
    `UPDATE tbl_tarefas SET status = ? WHERE id = ?`,
    ['em_progresso', taskId],
    'Move task to em_progresso'
);

// Process queue when back online
const { processed, failed } = await offlineQueue.processAll(
    async (sql, params) => {
        await db.execute(sql, params);
    }
);

console.log(`Processed: ${processed}, Failed: ${failed.length}`);
```

### 3.5 Fluxo de Recovery

```
OFFLINE QUEUE
     │
     ├── Attempt 1: SUCCESS → delete mutation, processed++
     │
     ├── Attempt 1: FAIL → retryCount=1, re-save, BREAK (FIFO stop)
     │
     ├── Attempt 2: SUCCESS → delete mutation, processed++
     │
     ├── Attempt 2: FAIL → retryCount=2, re-save, BREAK
     │
     ├── Attempt 3: FAIL → retryCount=3 (max), DISCARD, failed.push(mutation)
     │
     └── Attempt 4: NOT EXECUTED (max retries reached)
```

---

## 4. Tratamento de Erros no Sync

### 4.1 Sync Cycle Error Handling

**Arquivo:** `lib/supabase-sync.ts`

```ts
async syncAll(options: { forcePush?: boolean } = {}): Promise<SyncResult> {
    try {
        // 1. Push phase — erros não bloqueiam pull
        try {
            await this.taskSync.pushTblSuite(result, ...);
        } catch (e) {
            result.errors.push(`pushTblSuite: ${e.message}`);
            // Continue para próximo passo
        }

        try {
            await this.formSync.pushSharedData(result, ...);
        } catch (e) {
            result.errors.push(`pushSharedData: ${e.message}`);
        }

        // 2. Pull phase
        try {
            await this.taskSync.pullFromStorage(result, ...);
        } catch (e) {
            result.errors.push(`pullFromStorage: ${e.message}`);
            result.success = false; // Pull failure é mais sério
        }

    } catch (error: any) {
        if (error.message?.includes('signal is aborted')) {
            console.warn('⚠️ Sync cancelled (aborted signal).');
        } else {
            result.success = false;
            result.errors.push(error.message);
        }
    }

    return result;
}
```

### 4.2 Erro de Push

```ts
// task-sync.ts — pushTblSuite
try {
    await this.storageSync.push({ tbl_suite: rows }, 'incremental');
} catch (error: any) {
    console.error('❌ Error pushing tbl_suite:', error);
    result.errors.push(`Error pushing tbl_suite: ${error.message}`);
    // Não lança — continua para próximo tipo de push
}
```

### 4.3 Erro de Pull

```ts
// task-sync.ts — pullFromStorage
try {
    // Pull logic
} catch (error: any) {
    if (error.message?.includes('signal is aborted')) {
        console.warn('⚠️ Pull cancelled (aborted signal).');
    } else {
        console.error('❌ Error pulling from Storage:', error);
        result.success = false;  // Pull failure marca sync como failed
        result.errors.push(error.message);
    }
}
```

### 4.4 Erro de Upsert

```ts
// task-sync.ts — upsertTblSuite (per-record error isolation)
for (const record of records) {
    try {
        await this.processRecord(record);
    } catch (error: any) {
        console.warn(`⚠️ Failed to process record ${record.package_id}:`, error.message);
        result.errors.push(`Record ${record.package_id}: ${error.message}`);
        // Continua para próximo record — não falha todo o sync
    }
}
```

---

## 5. Recovery de Snapshots Corrompidos

### 5.1 Validação de Snapshot

**Arquivo:** `lib/sync/storage-sync.ts`

```ts
async validateSnapshot(blob: Blob, options?: { skipChecksum?: boolean; skipCount?: boolean }): Promise<SyncSnapshot> {
    // 1. Ler JSON
    const buffer = await blob.arrayBuffer();
    const json = new TextDecoder().decode(buffer);
    const snapshot = JSON.parse(json);

    // 2. Validar checksum
    if (!options?.skipChecksum) {
        const calculatedChecksum = this.calculateChecksum(snapshot.data);
        if (calculatedChecksum !== snapshot.metadata.checksum) {
            throw new Error('Checksum mismatch! File may be corrupted.');
        }
    }

    // 3. Validar contagem
    if (!options?.skipCount) {
        const actualCount = Array.isArray(snapshot.data) ? snapshot.data.length : 0;
        if (actualCount !== snapshot.metadata.record_count) {
            throw new Error(`Record count mismatch! Expected ${snapshot.metadata.record_count}, got ${actualCount}`);
        }
    }

    // 4. Validar estrutura
    if (!snapshot.version || !snapshot.timestamp) {
        throw new Error('Missing required fields!');
    }

    return snapshot;
}
```

### 5.2 Recovery Automático

```ts
// storage-sync.ts — pull()
try {
    snapshot = await this.validateSnapshot(blob);
} catch (validationError) {
    if (validationError.message.includes('Checksum mismatch')) {
        // Tentar sem validação de checksum
        try {
            snapshot = await this.validateSnapshot(blob, { skipChecksum: true });
            console.warn(`✅ Recovered ${filename} without checksum validation`);
        } catch {
            await this.removeCorruptedFile(filename, 'inbox');
            continue;
        }
    } else if (validationError.message.includes('Record count mismatch')) {
        // Tentar sem validação de contagem
        try {
            snapshot = await this.validateSnapshot(blob, { skipCount: true });
        } catch {
            await this.removeCorruptedFile(filename, 'inbox');
            continue;
        }
    }
}
```

### 5.3 Remoção de Arquivo Corrompido

```ts
async removeCorruptedFile(filename: string, folder: string = 'inbox'): Promise<void> {
    const filePath = `users/${this.deviceId}/${folder}/${filename}`;

    const { error } = await supabase.storage
        .from(BUCKET_NAME)
        .remove([filePath]);

    if (error) {
        console.error(`Failed to remove corrupted file ${filename}:`, error);
    } else {
        console.log(`✅ Removed corrupted file: ${filename}`);
    }
}
```

### 5.4 Níveis de Recovery

| Nível | Validação | Ação se Falhar |
|-------|-----------|-----------------|
| 1 | Estrutura JSON | Tentar parsear |
| 2 | Checksum SHA-256 | Skip checksum, tentar processar |
| 3 | Record count | Skip count, tentar processar |
| 4 | Todas | Remover arquivo corrompido |

---

## 6. Dead Letter Handling

### 6.1 Definição

Dead letters são mutações que falharam após o número máximo de retries. Elas são:
- **Descartadas** da fila
- **Logadas** para análise
- **Não bloqueiam** o sync

### 6.2 Quando Ocorre

| Situação | Contador | Ação |
|----------|----------|------|
| Offline mutation falha 3x | retryCount=3 | Descartar |
| Snapshot corrompido (todos os recovery levels) | N/A | Remover arquivo |
| Erro fatal (ex: syntax error no SQL) | N/A | Log + Skip |

### 6.3 Logging de Dead Letters

```ts
// offline-queue.ts — processAll()
if (m.retryCount >= this.maxRetries) {
    console.error(
        `❌ Mutation "${m.label}" failed after ${m.retryCount} retries, discarding:`,
        e.message
    );
    await deleteMutation(m.id);  // Remove da fila
    failed.push(m);               // Adiciona à lista de failures
}
```

### 6.4 Análise Post-Mortem

Para cada dead letter, o sistema loga:
- ID da mutação
- SQL executado
- Timestamp de criação
- Número de retries
- Mensagem do último erro

```
❌ Dead Letter Mutation
   ID: 1715432100000-abc123
   SQL: UPDATE tbl_tarefas SET status = ? WHERE id = ?
   Params: ["em_progresso", "task-uuid-456"]
   Created: 2024-01-15T10:00:00.000Z
   Retries: 3
   Last Error: "SQLITE_CONSTRAINT: UNIQUE constraint failed"
```

---

## 7. Erros de Validação

### 7.1 Erros de Domínio

```ts
// desktop/src/domain/shared/errors.ts

export class NotFoundError extends Error {
    constructor(entity: string, id: string | number) {
        super(`${entity} not found: ${id}`);
        this.name = 'NotFoundError';
    }
}

export class InvalidTransitionError extends Error {
    constructor(currentStatus: string, targetStatus: string, entity: string) {
        super(
            `Invalid transition: ${entity} cannot transition from ${currentStatus} to ${targetStatus}`
        );
        this.name = 'InvalidTransitionError';
    }
}
```

### 7.2 Validações de Use Cases

| Use Case | Validação | Erro |
|----------|-----------|------|
| `CreateTaskUseCase` | `titulo` não vazio | `Error: Título da tarefa é obrigatório.` |
| `MoveTaskUseCase` | Tarefa existe | `NotFoundError: Task {id}` |
| `MoveTaskUseCase` | Transição válida | `InvalidTransitionError` |
| `upsertTasks` | Transição de status | `Invalid status transition, skipping status update` |

### 7.3 Validação de Status

```ts
// task-sync.ts — upsertTasks
if (existing.length > 0 && localStatus && t.status && localStatus !== t.status) {
    if (!isValidTransition(localStatus as any, t.status as any)) {
        console.warn(`❌ Invalid status transition for task ${t.id}: ${localStatus} → ${t.status}. Skipping status update.`);
        t.status = localStatus;  // Mantém status local
    }
}
```

### 7.4 Validação de Status (tbl_suite)

```ts
// task-sync.ts — upsertTblSuite
const validStatuses = ['draft', 'current', 'edit', 'locked', 'dispatched', 'pending_review', 'refuted', 'superseded', 'closed'];

if (!validStatuses.includes(finalStatus)) {
    console.warn(`⚠️ Invalid status "${finalStatus}" for ${pkgId}, defaulting to 'current'`);
    finalStatus = 'current';
}
```

---

## 8. Logging e Monitoramento

### 8.1 Níveis de Log

| Nível | Uso | Exemplo |
|-------|-----|---------|
| `debug` | Detalhes de execução | `Processing ${n} queued mutations...` |
| `info` | Operações normais | `✅ Pushed ${n} packages to Storage` |
| `warn` | Problemas recuperáveis | `⚠️ Failed to parse interessados for task ${t.id}` |
| `error` | Problemas sérios | `❌ Error pushing tbl_suite: ${error}` |

### 8.2 Padrões de Log

```
✅ Success: operação completada
⚠️ Warning: problema recuperável
❌ Error: problema sério (pode bloquear)
🔄 In Progress: operação em andamento
📦 Data: mutações/arquivos processados
```

### 8.3 Exemplos de Log

```ts
// Push bem-sucedido
console.log(`✅ Pushed ${rows.length} packages to Storage`);

// Push com erro (não fatal)
console.error('❌ Error pushing tbl_suite:', error);
result.errors.push(`Error pushing tbl_suite: ${error.message}`);

// Recovery de snapshot
console.warn(`⚠️ Checksum validation failed for ${file.name}, attempting recovery...`);

// Mutation descartada
console.error(`❌ Mutation "${m.label}" failed after ${m.retryCount} retries, discarding:`);

// Sync aborted (normal durante navegação)
console.warn('⚠️ Sync cancelled (aborted signal). This is normal during navigation or reload.');
```

### 8.4 SyncResult Structure

```ts
interface SyncResult {
    success: boolean;
    synced: {
        form_registry: number;
        data_registry: number;
        tbl_suite_push: number;
        tbl_suite_pull: number;
        tbl_usuarios: number;
        projects_push: number;
        projects_pull: number;
        tasks_push: number;
        tasks_pull: number;
        task_snaps_push: number;
        ecoponto_state_push: number;
    };
    errors: string[];  // Lista de erros encontrados
}
```

### 8.5 Console Output do Sync

```
🔄 Starting Bidirectional Storage Sync (Pure Mode)...
📡 Pushing tbl_suite to Storage (v2)...
   Found 3 packages to push
   ✅ Pushed 3 packages to Storage

   📤 Preparing shared data snapshots...
   ✅ Pushed 10 form_registry records
   ✅ Pushed 25 data_registry records
   ✅ Pushed 8 users to shared/users.json
   ✅ Pushed 5 projects to shared/projects.json

⬇️ Pulling from Storage...
   ✅ Ingested 5 projects
   ✅ Ingested 12 tasks
   Found 2 inbox snapshots to process
   ✅ Processed tbl_suite record: pkg-001
   ✅ Processed tbl_suite record: pkg-002
   ⚠️ Failed to parse record: pkg-003 (invalid status)
   ✅ Pull cycle finished

🗑️ Archive cleanup: no files older than 90 days
✅ Storage sync completed successfully

   📤 Pushed details: {
     form_registry: 10,
     data_registry: 25,
     tbl_suite_push: 3,
     tbl_suite_pull: 2,
     tasks_push: 0,
     tasks_pull: 12,
     ...
   }
```

---

## Resumo: Fluxo de Erro

```
ERRO DETECTADO
      │
      ├── isRetryableError(error)?
      │       │
      │       ├── SIM → retryWithBackoff(fn, { maxRetries: 3 })
      │       │               │
      │       │               ├── Success → Continue
      │       │               │
      │       │               └── Failure after 3 retries
      │       │                     │
      │       │                     ▼
      │       │              OFFLINE QUEUE
      │       │                     │
      │       │                     ├── enqueue(sql, params)
      │       │                     │
      │       │                     └── [IndexedDB]
      │       │
      │       └── NÃO → isValidationError(error)?
      │               │
      │               ├── SIM → Log + Skip (continue)
      │               │
      │               └── NÃO → isChecksumError(error)?
      │                       │
      │                       ├── SIM → Recovery (skip checksum/count)
      │                       │
      │                       └── NÃO → isFatalError(error)?
      │                               │
      │                               ├── SIM → Dead Letter + Alert
      │                               │
      │                               └── NÃO → Log + Continue
      │
      └── Sync continua mesmo com erros
              (errors são coletados em result.errors[])
```
