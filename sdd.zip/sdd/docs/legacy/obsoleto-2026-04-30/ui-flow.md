# Fluxo de UI — EcoForms Desktop

Este documento descreve os fluxos de interface do usuário (UI) do EcoForms Desktop, detalhando navegação entre módulos, jornadas do usuário e conexões entre telas.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `modules.md` | Inventário de módulos, entidades, repositories e use cases |
| `data-flow.md` | Fluxo de dados, sincronização e processamento |
| `hooks.md` | Catálogo de 47 hooks React (layer de interface) |

---

## Índice

1. [Arquitetura de Navegação](#1-arquitetura-de-navegação)
2. [Jornadas Principais do Usuário](#2-jornadas-principais-do-usuário)
3. [Fluxo por Módulo UI](#3-fluxo-por-módulo-ui)
4. [Conexões entre Módulos](#4-conexões-entre-módulos)
5. [Fluxo de Autenticação e Inicialização](#5-fluxo-de-autenticação-e-inicialização)
6. [Estados de Interface](#6-estados-de-interface)

---

## 1. Arquitetura de Navegação

### 1.1 Estrutura de Rotas (Next.js App Router)

```
/                    → Dashboard (página inicial)
/login               → Autenticação
/kanban              → Quadro Kanban (tarefas)
/kanban/[projectId]  → Quadro Kanban por projeto
/clients             → Lista de clientes
/clients/[id]        → Detalhe do cliente
/clients/new         → Criar cliente
/crm                 → Gestão de roteiros e rotas
/crm/roteiros        → Lista de roteiros
/crm/roteiros/[id]   → Detalhe do roteiro
/ouvidoria           → Protocolos de ouvidoria
/ouvidoria/[id]      → Detalhe do protocolo
/admin/users         → Gestão de usuários
/admin/forms         → Gestão de formulários
/admin/data         → Dados de referência (data_registry)
/inbox               → Caixa de entrada (submissões pendentes)
```

### 1.2 Menu de Navegação — Sidebar Lateral Retrátil

A navegação principal foi migrada de um **header fixo no topo** para uma **sidebar lateral retrátil**, estilo WordPress Admin. Isso libera a área superior para ações de modais e maximiza o espaço de conteúdo.

**Comportamento:**
- **Expandida (`w-64`)**: mostra ícone + texto do link, grupos de menu e submenus
- **Retraída (`w-16`)**: mostra apenas ícones centralizados, com `Tooltip` no hover
- **Persistência**: estado salvo em `localStorage` (`ecoforms_sidebar_collapsed`)
- **Mobile (`< md`)**: sidebar oculta; botão hambúrguer abre `Sheet` (drawer) vindo da esquerda
- **Animação**: `transition-all duration-300` no width e padding

```
┌────────────┬──────────────────────────────────────────────────┐
│  [Logo]    │                                                  │
│  EcoSuite  │         ÁREA DE CONTEÚDO PRINCIPAL              │
│            │                                                  │
│ ▼ Operacional          (scroll independente)                │
│   ┌ Início                                                  │
│   ┌ Tarefas [3]                                             │
│   ┌ Minhas Solicitações                                     │
│ ────────────────                                            │
│ ▼ Gestão                                                    │
│   ┌ Form Builder                                            │
│   ┌ Data Registry                                           │
│   ┌ Análise                                                 │
│   ┌ Ecopontos                                               │
│   ┌ Projetos                                                │
│ ────────────────                                            │
│ ▼ Relacionamento                                            │
│   ┌ CRM                                                     │
│   ┌ Ouvidoria [2]                                           │
│   ┌ Histórico                                               │
│ ────────────────                                            │
│ ▼ Administração                                             │
│   ┌ Galeria                                                 │
│   ┌ Métricas                                                │
│   ┌ Admin ▼                                                 │
│       Visão Geral                                           │
│       Usuários                                              │
│       Setores                                               │
│       Inspetor de Dados                                     │
│       Configurações                                         │
│       Inspetor de Schema                                    │
│ ────────────────                                            │
│ [🔄] [🟢] Olá, Maria      [Sair]                           │
└────────────┴──────────────────────────────────────────────────┘
```

**Grupos de menu retráteis:**
Cada grupo pode ser expandido/colapsado clicando no cabeçalho. O grupo que contém a rota ativa inicia expandido automaticamente. Quando a sidebar está retraída, os grupos são ocultados e os itens viram uma lista plana de ícones com tooltips.

**Itens condicionais por permissão (RBAC):**
- `HideForRole roles=["operador"]`: Form Builder, Data Registry, Análise, Ecopontos, Projetos, Minhas Solicitações, Histórico
- `HideForRole roles=["operador","campo"]`: CRM, Ouvidoria
- `ShowForManager` (admin/gerente): Galeria, Métricas, Administração (com submenu)

**Badges dinâmicos:**
- Tarefas: contador de solicitações pendentes (pulsante, vermelho)
- Ouvidoria: contador de protocolos abertos (âmbar)

**Arquivos de implementação:**
- `components/layout/SidebarLayout.tsx` — wrapper flex com estado e persistência
- `components/layout/AppSidebar.tsx` — menu lateral com grupos, ícones, submenus, badges
- `components/ui/collapsible.tsx` — componente shadcn para grupos e submenu Admin
- `app/admin/layout.tsx` — removida sidebar local; navegação via submenu global

---

## 2. Jornada: Criação e Preenchimento de Formulário

### 2.1 Fluxo Completo

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. ACESSO AO FORMULÁRIO                                         │
│                                                                     │
│    Kanban ──▶ Card de Tarefa                                     │
│         │                                                          │
│         ▼                                                          │
│    Dialog de Tarefa                                                │
│         │                                                          │
│         ├──▶ [Ver Formulário] ──▶ useFormTemplate(slug)          │
│         │                        │                                │
│         │                        ▼                                │
│         │                   Modal de Formulário                   │
│         │                        │                                │
│         │                        ▼                                │
│         │                   useAssignedActiveForms()             │
│         │                        │                                │
│         │                        ▼                                │
│         │                   Lista de Forms Ativos                 │
│         │                   (form_registry + assign)             │
│         │                                                          │
│         ▼                                                          │
│    [Nova Solicitação] ──▶ useSolicitacoesList                   │
│                           │                                        │
│                           ▼                                        │
│                      Seletor de Tipo de Formulário               │
│                      (Lista de form_registry ativos)             │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. PREENCHIMENTO DO FORMULÁRIO                                   │
│                                                                     │
│    ┌─────────────────────────────────────────────────────────┐    │
│    │  Formulário Dinâmico                                    │    │
│    │  ───────────────────                                    │    │
│    │  Campo 1: [________]     ←── useFormTemplate hook       │    │
│    │  Campo 2: [________]     ←── usa schema do registry    │    │
│    │  Campo 3: [Dropdown ▼]   ←── data_registry enrichment  │    │
│    │  Campo 4: [✅ Checklist]                              │    │
│    │  ─────────────────────────────────────────────────────  │    │
│    │  [Salvar Rascunho]  [Enviar Submissão]                  │    │
│    └─────────────────────────────────────────────────────────┘    │
│                │                                                  │
│                ▼                                                  │
│    useSubmissionData()                                           │
│         │                                                          │
│         ▼                                                          │
│    SubmitSuiteUseCase.execute()                                  │
│         │                                                          │
│         ├──▶ INSERT tbl_suite (is_current=1)                      │
│         │                                                          │
│         ├──▶ Se ad_hoc: ensureRetroactiveTask()                  │
│         │                   └── INSERT tbl_tarefas (ghost task)  │
│         │                                                          │
│         └──▶ SyncContext.syncNow()                               │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. PÓS-SUBMISSÃO                                                │
│                                                                     │
│    Status: 'current'  (ou 'locked' se auto_aprovacao=1)           │
│         │                                                          │
│         ▼                                                          │
│    pushTblSuite() ──▶ Supabase Storage (outbox)                  │
│         │                                                          │
│         ▼                                                          │
│    Tela: Caixa de Entrada (Inbox)                                │
│         │                                                          │
│         ├──▶ useInboxMutations (approve/reject)                  │
│         │                                                          │
│         └──▶ ReviewSuiteUseCase (locked/refuted)                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Tela de Formulário — Componentes

```
FormularioDinamico
├── FormHeader (título, status, versão)
├── FormFields
│   ├── TextField
│   ├── SelectField (enriquecido por data_registry)
│   ├── CheckboxField
│   ├── DateField
│   └── ... (baseado no schema)
├── FormActions
│   ├── SaveDraftButton → useSQLiteMutation
│   └── SubmitButton → SubmitSuiteUseCase
└── FormFooter (timestamps, autor)
```

---

## 3. Fluxo por Módulo UI

### 3.1 Kanban (Tarefas)

```
┌─────────────────────────────────────────────────────────────────┐
│ KANBAN BOARD                                                     │
│                                                                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐        │
│  │ A Fazer  │  │Em Prog.  │  │Concluído │  │Solicit.  │        │
│  │          │  │          │  │          │  │          │        │
│  │ [Card 1]│  │ [Card 3] │  │ [Card 5] │  │ [Card 7] │        │
│  │ [Card 2]│  │ [Card 4] │  │ [Card 6] │  │          │        │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘        │
│                                                                     │
│  useKanban() ──▶ useKanbanData()                                  │
│       │                 │                                          │
│       ▼                 ▼                                          │
│  useKanbanMutations()   │                                          │
│       │                 │                                          │
│       ├──▶ createTask() │                                          │
│       ├──▶ moveTask()   │                                          │
│       ├──▶ updateTask() │                                          │
│       └──▶ patchTask()  │                                          │
│                          │                                          │
│                          ▼                                          │
│                    tbl_tarefas                                    │
└─────────────────────────────────────────────────────────────────┘
```

**Diálogo de Tarefa:**
```
TaskDialog (EditTaskModal)
├── TaskHeader (título, status badge)
├── TaskDetails
│   ├── Descrição
│   ├── Projeto (link)
│   ├── Responsável (useUsersByForm)
│   ├── Prioridade
│   └── Datas (prazo, recordatório)
├── TaskFormSection
│   └── [Ver Formulário] / [Nova Solicitação]
├── TaskComments (useTaskComments)
├── TaskHistory (useTaskHistory)
├── ActionBar (dinâmico — useWorkflowActions)
│   ├── [Aceitar Demanda]      → demanda_aceitar
│   ├── [Encerrar Demanda]     → demanda_encerrar
│   ├── [Encaminhar Remoção]   → ecoponto_encaminhar_remocao
│   ├── [Encaminhar p/ Setor]  → encaminhar_para_setor
│   └── [Aprovar Suite]        → suite_aprovar
│   (aparecem conforme contexto + perfil)
└── TaskActions (fixos)
    ├── [Mover] → useKanbanMutations.moveTask()
    ├── [Editar] → updateTask()
    └── [Arquivar] → archiveTask()
```

**Ações dinâmicas no ActionBar:**
- Renderizado por `components/ActionBar.tsx`
- Filtradas por `useWorkflowActions('task', taskFormData)`
- Regras de visibilidade (`VisibilityRule`) + permissões (`UserRole`)
- Suporta confirmação e mini-formulário de input (`requiresInput`)
- Toda ação registra em `action_log`

### 3.2 Clientes

```
┌─────────────────────────────────────────────────────────────────┐
│ LISTA DE CLIENTES                                                │
│                                                                     │
│  useClients() / useTauriClients()                                │
│         │                                                          │
│         ▼                                                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  [🔍 Busca...        ]  [ + Novo Cliente ]              │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  Cliente A    │  Tipo X  │  CEP    │  [Editar] [Ver]    │    │
│  │  Cliente B    │  Tipo Y  │  CEP    │  [Editar] [Ver]    │    │
│  │  ...                                                     │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                     │
│  useClientSearch() ──▶ FTS5 (tbl_pjuridicas_fts)                   │
└─────────────────────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ DETALHE DO CLIENTE                                               │
│                                                                     │
│  useClientById(id)                                                │
│         │                                                          │
│         ▼                                                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Dados Principais                                        │    │
│  │  ├── Nome / Razão Social                                │    │
│  │  ├── Tipo (tblPJtipo)                                   │    │
│  │  ├── CEP / Endereço                                     │    │
│  │  └── Contatos (tblContatos)                             │    │
│  │                                                         │    │
│  │  Abas:                                                │    │
│  │  ├── Roteiros vinculados  ──▶ useCRM()               │    │
│  │  ├── Formulários submetidos ──▶ useAssignedActiveForms│    │
│  │  ├── Histórico de Protocolos ──▶ useOuvidoria()      │    │
│  │  └── Auditoria ──▶ useClientAuditLog                  │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### 3.3 CRM (Roteiros e Rotas)

```
┌─────────────────────────────────────────────────────────────────┐
│ CRM DASHBOARD                                                    │
│                                                                     │
│  ┌─────────────────────┐  ┌─────────────────────┐              │
│  │  Roteiros           │  │  Resumo de Coletas  │              │
│  │  ─────────          │  │  ─────────────────   │              │
│  │  [Roteiro Alpha]    │  │  Hoje: 12            │              │
│  │  [Roteiro Beta]     │  │  Esta Semana: 48     │              │
│  │  [+ Novo Roteiro]   │  │  Pendentes: 5        │              │
│  └─────────────────────┘  └─────────────────────┘              │
│                                                                     │
│  useCRM()                                                        │
│         │                                                          │
│         ▼                                                          │
│  useCRMMutations                                                 │
│         │                                                          │
│         ├──▶ createRoteiro()                                      │
│         ├──▶ createColeta()                                       │
│         ├──▶ createDetalheSatelite()                             │
│         └──▶ deleteRota()                                        │
└─────────────────────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ DETALHE DO ROTEIRO                                              │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Roteiro: Coleta Seletiva Norte                         │    │
│  │  Periodicidade: Semanal (Segunda)                       │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  Rotas Vinculadas:                                      │    │
│  │  ┌──────────────────────────────────────────────────┐  │    │
│  │  │ 1. Cliente A    [Ordem ▲▼] [Remover]            │  │    │
│  │  │ 2. Cliente B    [Ordem ▲▼] [Remover]            │  │    │
│  │  │ 3. Cliente C    [Ordem ▲▼] [Remover]            │  │    │
│  │  └──────────────────────────────────────────────────┘  │    │
│  │  [+ Adicionar Cliente ao Roteiro]                      │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  Coletas Realizadas:                                   │    │
│  │  ├── 2024-01-15: 50kg (OK)                           │    │
│  │  └── 2024-01-22: 45kg (OK)                           │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### 3.4 Ouvidoria

```
┌─────────────────────────────────────────────────────────────────┐
│ LISTA DE PROTOCOLOS                                              │
│                                                                     │
│  useOuvidoria()                                                  │
│         │                                                          │
│         ▼                                                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Filtros: [Status ▼] [Data Range] [Tipo ▼]              │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  #2024-0001 │ Cliente A │ Aberto  │ 22/01/2024         │    │
│  │  #2024-0002 │ Cliente B │ Andamento│ 21/01/2024        │    │
│  │  ...                                                    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                     │
│  useOuvidoriaMutations                                           │
│         │                                                          │
│         ├──▶ createProtocolo()  ──▶ gerarIdProtocolo()           │
│         ├──▶ addEvento()                                        │
│         ├──▶ upsertAtendimento()                                │
│         └──▶ encerrarProtocolo()                                │
└─────────────────────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ DETALHE DO PROTOCOLO                                             │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Protocolo #2024-0001                                   │    │
│  │  Status: [Aberto]                                      │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  Dados do Cliente                                       │    │
│  │  Tema: Coleta Irregular                                 │    │
│  │  Subtema: Container não coletado                        │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  Andamentos:                                            │    │
│  │  ├── 22/01 10:30 - Abertura (Operador)                 │    │
│  │  ├── 22/01 14:00 - Encaminhado ao Setor X (Coordenador)│    │
│  │  └── 23/01 09:00 - Visita agendada (Encarregado)       │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  [ + Adicionar Evento ]                                │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### 3.5 Caixa de Entrada (Inbox)

```
┌─────────────────────────────────────────────────────────────────┐
│ CAIXA DE ENTRADA                                                 │
│                                                                     │
│  useInboxSync() / useSolicitacoesList()                         │
│         │                                                          │
│         ▼                                                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Tab: [Pendentes] [Em Revisão] [Aprovados] [Rejeitados] │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  #2024-0001 │ Form X │ Maria │ 22/01/2024 │ [Ver] [✓] [✗]│   │
│  │  #2024-0002 │ Form Y │ João  │ 21/01/2024 │ [Ver] [✓] [✗]│   │
│  │  ...                                                    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                     │
│  useInboxMutations                                               │
│         │                                                          │
│         ├──▶ approveSubmission() ──▶ ReviewSuiteUseCase        │
│         │                               └── status: 'locked'     │
│         │                                                        │
│         └──▶ rejectSubmission() ──▶ ReviewSuiteUseCase         │
│                                     └── status: 'refuted'        │
└─────────────────────────────────────────────────────────────────┘
```

### 3.6 Admin

```
┌─────────────────────────────────────────────────────────────────┐
│ ADMIN: FORMULÁRIOS                                               │
│                                                                     │
│  useFormTemplate()                                               │
│         │                                                          │
│         ▼                                                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  [ + Novo Formulário ]                                  │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  ecopontoCaixasForm  │ v3 │ Ativo │ [Editar] [Preview] │    │
│  │  coletaMensalForm     │ v1 │ Ativo │ [Editar] [Preview] │    │
│  │  ...                                                        │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                     │
│  useFormPermissions() ──▶ Verifica quem pode editar            │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ ADMIN: DADOS DE REFERÊNCIA                                       │
│                                                                     │
│  useDataRegistry()                                              │
│         │                                                          │
│         ▼                                                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Tipos: [Bairros] [Ruas] [Categorias] [Clientes]       │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  [+ Adicionar Item]                                     │    │
│  │  ─────────────────────────────────────────────────────   │    │
│  │  norte     │ Bairro Norte │ { "regiao": "norte" }       │    │
│  │  sul       │ Bairro Sul   │ { "regiao": "sul" }         │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                     │
│  useDataRegistryMutations                                       │
│         │                                                          │
│         ├──▶ createDataRegistry()                               │
│         └──▶ deleteDataRegistry()                                │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ ADMIN: USUÁRIOS                                                  │
│                                                                     │
│  useAllUsers() / useAdminUsers()                                │
│         │                                                          │
│         ▼                                                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  [ + Novo Usuário ]                                     │    │
│  ├─────────────────────────────────────────────────────────┤    │
│  │  Maria   │ admin     │ Ativo │ [Editar] [Desativar]     │    │
│  │  João    │ operador  │ Ativo │ [Editar] [Desativar]     │    │
│  │  Carlos  │ campo     │ Inativo│ [Editar] [Ativar]       │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                     │
│  usePermissions() ──▶ RBAC (6 perfis, 36 permissões)           │
└─────────────────────────────────────────────────────────────────┘
```

### 3.9 Dashboard (Página Inicial)

```
Dashboard (page.tsx)
├── DynamicDashboard (widgets filtrados por perfil)
│   ├── KPI Card: Tarefas Abertas
│   ├── KPI Card: Protocolos Abertos
│   ├── Bar Chart: Tarefas por Status
│   ├── Recent Activity: Atividade Recente
│   └── Table: Últimas Demandas
│   (renderizados via useDashboardWidgets → getAvailableWidgets)
│
├── Atalhos de Formulários
│   └── Lista de formulários acessíveis (formPermissions)
│
├── Notificações de Tarefas
│   └── Cards de tarefas atribuídas ao usuário
│
└── Inbox Operacional
    └── Tabela de submissões com filtros e seleção
```

**Comportamento:**
- Widgets são filtrados por `requiredRoles` do perfil logado
- Dados carregados via `container[useCaseGroup][method]` em runtime
- `refreshInterval` atualiza widgets automaticamente
- Layout responsivo: grid de 1 coluna (mobile) a 3 colunas (desktop)

---

## 4. Conexões entre Módulos

### 4.1 Mapa de Navegação Cruzada

```
┌─────────────┐
│  Dashboard  │
└──────┬──────┘
       │
       ├──────────────────┬──────────────────┬──────────────────┐
       ▼                  ▼                  ▼                  ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│   Kanban    │  │  Clientes   │  │    CRM      │  │  Ouvidoria  │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │                │
       │                │                │                │
       ▼                ▼                ▼                ▼
  Card de          Detalhe do      Roteiro com       Protocolo com
  Tarefa ─────────▶ Cliente ──────▶ Cliente ────────▶ Cliente
       │                │                │                │
       │                │                │                │
       ▼                ▼                ▼                ▼
  [Ver Form]     [Ver Roteiros]  [Ver Cliente]   [Ver Cliente]
       │                │                │                │
       ▼                ▼                ▼                ▼
  Submit ──────▶  tbl_suite ──▶  useCRM ────────▶  useOuvidoria
       │                │                │                │
       ▼                ▼                ▼                ▼
  pushTblSuite()  useInboxSync()  local only       local only
```

### 4.2 Links Cruzados Comuns

| De | Para | Ação |
|----|------|------|
| Task (Kanban) | Client | Ver dados do cliente vinculado à tarefa |
| Task (Kanban) | Form | Preencher/submeter formulário |
| Task (Kanban) | Suite (Inbox) | Ver submissão vinculada |
| Client | CRM | Ver roteiros do cliente |
| Client | Ouvidoria | Ver protocolos do cliente |
| Client | Suite (Inbox) | Ver formulários submetidos |
| Roteiro | Client | Ver detalhes do cliente na rota |
| Protocolo | Client | Ver dados do cliente do protocolo |

### 4.3 Fluxo de Dados entre Módulos

```
┌─────────────────────────────────────────────────────────────────┐
│ TASK ──▶ SUITE                                                   │
│                                                                     │
│  TaskDialog                                                       │
│     │                                                             │
│     ├──▶ [Nova Solicitação]                                      │
│     │         │                                                  │
│     │         ▼                                                  │
│     │    Seletor de Formulário                                   │
│     │         │                                                  │
│     │         ▼                                                  │
│     │    SubmitSuiteUseCase.execute()                            │
│     │         │                                                  │
│     │         ▼                                                  │
│     │    tbl_suite.package_id                                   │
│     │         │                                                  │
│     │         ▼                                                  │
│     └── UPDATE tbl_tarefas.tbl_suite_id                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CLIENT ──▶ CRM                                                   │
│                                                                     │
│  ClienteDetailPage                                               │
│     │                                                             │
│     └──▶ Aba "Roteiros"                                          │
│               │                                                  │
│               ▼                                                  │
│          useCRM()                                                │
│               │                                                  │
│               ▼                                                  │
│          findRotasByClient(idPJ)                                 │
│               │                                                  │
│               ▼                                                  │
│          Lista de Rotas (tblRotas)                              │
│               │                                                  │
│               ▼                                                  │
│          useCRMMutations.createRota()                           │
│               │                                                  │
│               ▼                                                  │
│          INSERT tblRotas                                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ SUITE ──▶ TASK (Ghost Task - Ad Hoc)                            │
│                                                                     │
│  SubmitSuiteUseCase.execute()                                    │
│     │                                                             │
│     ├── Verifica se form é ad_hoc                                │
│     │         │                                                  │
│     │         ▼                                                  │
│     │    useFormTemplate(slug).ad_hoc === 1                      │
│     │         │                                                  │
│     │         ▼                                                  │
│     │    ensureRetroactiveTask(package_id)                       │
│     │         │                                                  │
│     │         ▼                                                  │
│     │    INSERT tbl_tarefas (ghost task)                        │
│     │    UNIQUE INDEX idx_tbl_tarefas_suite_id_unique           │
│     │         │                                                  │
│     │         ▼                                                  │
│     └── Kanban exibe nova tarefa                                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## 5. Fluxo de Autenticação e Inicialização

### 5.1 Startup Sequence

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. LOADING                                                       │
│                                                                     │
│    ┌─────────────────────────────────────────────────────────┐    │
│    │  [Logo]                                                │    │
│    │  Carregando...                                        │    │
│    └─────────────────────────────────────────────────────────┘    │
│                                                                     │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. AUTH CHECK                                                    │
│                                                                     │
│    AuthContext                                                   │
│         │                                                         │
│         ▼                                                         │
│    ┌─────────────────────────────────────────────────────────┐    │
│    │  Token existe? ──▶ NÃO ──▶ /login                      │    │
│    │         │                                              │    │
│    │        SIM                                              │    │
│    │         │                                              │    │
│    │         ▼                                              │    │
│    │  verifyPassword() via Tauri ──▶ FALHA ──▶ /login      │    │
│    │         │                                              │    │
│    │        OK                                              │    │
│    │         │                                              │    │
│    │         ▼                                              │    │
│    │  usePermissions() ──▶ Carrega RBAC                     │    │
│    └─────────────────────────────────────────────────────────┘    │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. SYNC INIT                                                     │
│                                                                     │
│    SyncContext                                                   │
│         │                                                         │
│         ▼                                                         │
│    ColumnSchemaManager.runMigrations()                           │
│         │                                                         │
│         ▼                                                         │
│    SyncService.syncAll()                                         │
│         │                                                         │
│         ├──▶ pullSharedData() (shared/*.json)                  │
│         │                                                          │
│         ├──▶ pullTaskPatches() (inbox/*.json)                   │
│         │                                                          │
│         └──▶ pullTaskStatusUpdates()                            │
│                                                                     │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. DASHBOARD                                                     │
│                                                                     │
│    / ──▶ Dashboard                                               │
│         │                                                         │
│         ├──▶ useKanban() (tarefas recentes)                     │
│         ├──▶ useTaskMetrics() (stats)                           │
│         ├──▶ useSyncSettings() (sync status)                    │
│         └──▶ useOnlineStatus()                                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────┘
```

### 5.2 Sync Status UI

O indicador de sync foi movido do header (removido) para o **rodapé da sidebar lateral**, junto ao `DatabaseStatus`, nome do usuário e botão de logout.

```
┌─────────────────────────────────────────────────────────────────┐
│ SYNC INDICATOR (Rodapé da Sidebar)                               │
│                                                                     │
│  useSyncContext()                                                │
│         │                                                         │
│         ▼                                                         │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  [🟢 Sincronizado]    Last: 14:30                      │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  [🔄 Sincronizando...  45%]                            │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  [⚠️ Offline]  (fila: 3 operações)                      │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  [🔴 Erro Sync]  [Tentar Novamente]                    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                     │
│  useSyncSettings() ──▶ Intervalo, triggers, etc.               │
└─────────────────────────────────────────────────────────────────┘
```

---

## 6. Estados de Interface

### 6.1 Estados Comuns por Componente

| Componente | Estados |
|------------|---------|
| **Formulário** | `draft`, `submitting`, `submitted`, `error` |
| **Tarefa (Kanban)** | `a_fazer`, `em_progresso`, `concluido`, `solicitacao`, `cancelado` |
| **Suite (Inbox)** | `current`, `locked`, `refuted`, `dispatched`, `closed` |
| **Protocolo** | `aberto`, `andamento`, `encerrado`, `cancelado` |
| **Cliente** | `ativo`, `inativo` |
| **Sync** | `synced`, `syncing`, `offline`, `error` |

### 6.2 Loading States

```
useTauriQuery / useSQLiteQuery
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│  if (isLoading)                                                 │
│      ┌─────────────────────────────────────────────────────────┐ │
│      │  [Spinner] Carregando...                                │ │
│      └─────────────────────────────────────────────────────────┘ │
│  else if (error)                                                │
│      ┌─────────────────────────────────────────────────────────┐ │
│      │  [❌ Erro] Mensagem de erro  [Tentar Novamente]         │ │
│      └─────────────────────────────────────────────────────────┘ │
│  else                                                            │
│      ┌─────────────────────────────────────────────────────────┐ │
│      │  [Conteúdo renderizado]                                 │ │
│      └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### 6.3 Empty States

```
if (data.length === 0)
    ┌─────────────────────────────────────────────────────────┐
    │  [📭 Nenhum item encontrado]                            │
    │  ─────────────────────────────────────────────────────  │
    │  Descrição do estado vazio                              │
    │  [Ação Primária]  [Ação Secundária]                     │
    └─────────────────────────────────────────────────────────┘
```

### 6.4 Error States

```
useTauriMutation
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│  onError: (error)                                               │
│      │                                                         │
│      ▼                                                         │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  [❌ Erro]                                               │  │
│  │  ─────────────────────────────────────────────────────  │  │
│  │  {error.message}                                        │  │
│  │  ─────────────────────────────────────────────────────  │  │
│  │  [Copiar Erro]  [Tentar Novamente]                      │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│  LogContext.logError()                                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## Resumo: Navegação por Perfil

| Perfil | Módulos Acessíveis |
|--------|-------------------|
| **Admin** | Todos os módulos + Admin |
| **Gerente** | Dashboard, Kanban, Clientes, CRM, Ouvidoria, Inbox |
| **Coordenador** | Dashboard, Kanban, Clientes, CRM, Ouvidoria (próprios), Inbox |
| **Operador** | Dashboard, Kanban, Clientes (leitura), Inbox |
| **Campo** | Dashboard, Kanban, Clientes, CRM, Inbox |
| **Encarregado** | Dashboard, Kanban, Clientes, CRM, Ouvidoria, Inbox |
