# Módulos do Sistema — EcoForms Desktop

Este documento apresenta o inventário completo de módulos do EcoForms Desktop, suas responsabilidades, tabelas gerenciadas, portas implementadas/consumidas, e relações com os documentos existentes.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `data-system.md` | Tipos canônicos, portas de aplicação, wrappers SQLite, serviço de sincronização Supabase (Pure Storage Mode), sistema offline |
| `hooks.md` | Catálogo completo dos ~44 hooks personalizados em `src/interface/hooks/` |
| `action-widget-system.md` | ActionRegistry + WidgetRegistry — tipos, registros, ações e widgets built-in, fluxos de UI |

---

## Índice

1. [Arquitetura Geral](#1-arquitetura-geral)
2. [Diagrama de Dependências](#2-diagrama-de-dependências)
3. [Domínio (src/domain/)](#3-domínio-srcdomain)
4. [Aplicação (src/application/)](#4-aplicação-srcapplication)
5. [Infraestrutura (src/infrastructure/)](#5-infraestrutura-srcinfrastructure)
6. [Interface (src/interface/)](#6-interface-srcinterface)
7. [Camadas Legadas (lib/, contexts/)](#7-camadas-legadas-lib-contexts)
8. [Camada Web Capacitor (www/)](#8-camada-web-capacitor-www)
9. [Backend Tauri (src-tauri/)](#9-backend-tauri-src-tauri)
10. [Tabela Inventário de Módulos](#10-tabela-inventário-de-módulos)

---

## 1. Arquitetura Geral

O projeto segue **Clean Architecture** com separação clara de responsabilidades:

```
┌─────────────────────────────────────────────────────────────┐
│                    Interface Layer                           │
│              (React Components + Hooks)                       │
├─────────────────────────────────────────────────────────────┤
│                    Application Layer                          │
│              (Use Cases + Port Interfaces)                    │
├─────────────────────────────────────────────────────────────┤
│                     Domain Layer                             │
│              (Entities + Repository Interfaces)              │
├─────────────────────────────────────────────────────────────┤
│                   Infrastructure Layer                       │
│         (Repository Implementations + Adapters)              │
└─────────────────────────────────────────────────────────────┘
```

**Camadas legadas:**
- `lib/` — migrado para `src/` (ver seção 7 abaixo)
- `contexts/` — React contexts (AuthContext, SyncContext)

> **Nota:** Os hooks foram migrados de `hooks/` para `src/interface/hooks/` em 2026-04-27. A pasta `hooks/` está vazia.
> **Nota:** A pasta `lib/` foi migrada para `src/` em 2026-04-27. Utilitários puros foram para `src/lib/`, serviços de sync para `src/infrastructure/sync/`, e wrappers de DB para `src/infrastructure/persistence/`.

**Stack:**
- **Frontend:** Next.js 14 (App Router) + React + TypeScript
- **Desktop Runtime:** Tauri (Rust backend + WebView)
- **Mobile Runtime:** Capacitor (web app hibrido)
- **Sync:** Supabase Storage (JSON + SHA-256) — sem tabelas PostgreSQL
- **DB Local:** SQLite (desktop via Tauri; mobile via IndexedDB)

> **IMPORTANTE**: O sistema NÃO utiliza tabelas PostgreSQL no Supabase. Todo o trânsito de dados ocorre exclusivamente via **Supabase Storage** (arquivos JSON no bucket `sync-bucket`).

---

## 2. Diagrama de Dependências

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          SyncContext                               │
│              (contexts/SyncContext.tsx)                            │
│         auto-sync: online/focus | forcePush | interval             │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
          ┌────────────────┴────────────────┐
          ▼                                 ▼
┌─────────────────────┐          ┌─────────────────────────────┐
│    SyncService      │          │  RuntimeStorageSync           │
│  (src/infrastructure│          │  (src/infrastructure/sync/    │
│  /sync/SyncService) │          │   RuntimeStorageSync.ts)      │
│  ← StorageSync      │          │  ← IndexedDB                 │
│  ← PushTasksUseCase │          └──────────────┬──────────────┘
│  ← PullTasksUseCase │                             │
│  ← ColumnSchema     │                             ▼
└─────────┬───────────┘              ┌─────────────────────────────┐
          │                          │   OfflineQueue               │
          ▼                          │   (src/infrastructure/sync/  │
┌─────────────────────────────────────┐   OfflineQueueLegacy.ts)  │
│            Supabase Storage          │     (IndexedDB)
│              (sync-bucket)          │
│  users/{deviceId}/outbox   ──── push        │
│  users/{deviceId}/inbox    ──── pull        │
│  shared/form_registry      ──── shared      │
│  shared/tasks              ──── shared       │
│  shared/adhoc              ──── ad hoc       │
│  shared/dimensions         ──── dim_*       │
│  archive/YYYY-MM/         ──── 90-day       │
└─────────────────────────────────────────────┘
```

---

## 3. Domínio (`src/domain/`)

### 3.1 Task Module

**Arquivos:**
- `src/domain/task/Task.ts` — entidade de domínio
- `src/domain/task/TaskStatus.ts` — valores e transições de status
- `src/domain/task/TaskRepository.ts` — interface do repositório

**Entidade `Task`:**
- Hierarquia: `parent_task_id`, `container_task_id`, `cycle_id`, `depends_on_task_id`
- Snapshot freeze: `snap_version`, `snap_hash`, `snap_frozen_at`
- Status: `a_fazer | em_progresso | concluido | solicitacao | cancelado`
- Prioridade: `baixa | media | alta`
- Recorrência: suporte a `tipo_prazo: 'unico' | 'periodo' | 'recorrente'`

**Repository:**
```ts
interface TaskRepository {
    findById(id: string): Promise<Task | null>
    findByProject(projectId: string | null, includeArchived?: boolean): Promise<Task[]>
    query(filter: TaskQuery): Promise<Task[]>
    save(task: Task): Promise<void>
    delete(id: string): Promise<void>
    nextOrder(projectId: string | null, status: TaskStatus): Promise<number>
}
```

**Tabelas:** `tbl_tarefas`, `tbl_tarefas_eventos`, `tbl_tarefas_interessados`, `tbl_projetos_interessados`

**Sync:** Sim (push/pull via Use Cases)

---

### 3.2 Suite Module

**Arquivos:**
- `src/domain/suite/SuitePackage.ts` — entidade
- `src/domain/suite/SuiteStatus.ts` — state machine de status
- `src/domain/suite/SuiteRepository.ts` — interface

**Entidade `SuitePackage`:**
- `package_id` (UUID), `version_no`, `module_type`, `resource_type`
- Status flow: `draft → current → edit → locked → dispatched → ... → closed`
- `is_current: 1` = vigente, `0` = histórico
- `payload_json` — JSON serializado do formulário

**Repository:**
```ts
interface SuiteRepository {
    findById(packageId: string): Promise<SuitePackage | null>
    findCurrent(resourceType: string, ownerId?: string): Promise<SuitePackage[]>
    query(filter: SuiteQuery): Promise<SuitePackage[]>
    save(pkg: SuitePackage): Promise<void>
    appendHistory(entry: SuiteHistoryEntry): Promise<void>
}
```

**Tabelas:** `tbl_suite`, `tbl_suite_historico`

**Sync:** Sim (push/pull via Use Cases)

---

### 3.3 Client Module

**Arquivos:**
- `src/domain/client/Client.ts`
- `src/domain/client/ClientRepository.ts`

**Entidade `Client`:** Pessoa jurídica com tipo, CEP, contactos.

**Repository:**
```ts
interface ClientRepository {
    findAll(ativoOnly?: boolean): Promise<Client[]>
    findById(idPJ: number): Promise<Client | null>
    findContacts(idPJ: number): Promise<ClientContact[]>
    findTypes(): Promise<ClientType[]>
    save(client: Client): Promise<void>
    delete(idPJ: number): Promise<void>
    nameExists(nome: string, excludeId?: number): Promise<boolean>
}
```

**Tabelas:** `tblPJuridicas`, `tblPJtipo`, `tblContatos`, `tblPFisicas`

**Sync:** Parcial (não há sync dedicated, mas usa hooks de clientes que consultam SQLite local)

---

### 3.4 User Module

**Arquivos:**
- `src/domain/user/User.ts`
- `src/domain/user/UserRepository.ts`

**Repository:**
```ts
interface UserRepository {
    findAll(): Promise<User[]>
    findById(id: string): Promise<User | null>
    save(user: User): Promise<void>
    delete(id: string): Promise<void>
    assignSectors(userId: string, setores: string[]): Promise<void>
}
```

**Tabelas:** `tbl_usuarios`, `tbl_usuarios_setores`

**Sync:** Sim (via `FormSyncManager.pushSharedData()` → `shared/users.json`)

---

### 3.5 Data Registry Module

**Arquivos:**
- `src/domain/data-registry/DataRegistryItem.ts`
- `src/domain/data-registry/DataRegistryRepository.ts`

**Entidade `DataRegistryItem`:** itens de dados de referência (`tipo`, `chave`, `conteudo`, `versao`)

**Repository:**
```ts
interface DataRegistryRepository {
    findByTipo(tipo: string): Promise<DataRegistryItem[]>
    findAllTypes(): Promise<string[]>
    findAll(): Promise<DataRegistryItem[]>
    findById(id: string): Promise<DataRegistryItem | null>
    save(item: DataRegistryItem): Promise<void>
    delete(id: string): Promise<void>
}
```

**Tabela:** `data_registry`

**Sync:** Sim (via `FormSyncManager.pushSharedData()` → `shared/data_registry.json`)

---

### 3.6 CRM Module (Roteiros/Rotas/Coletas)

**Arquivos:**
- `src/domain/crm/Roteiro.ts`, `Rota.ts`
- `src/domain/crm/CRMRepository.ts`

**Entidades:**
- `Roteiro` — roteiro de coleta (tblRoteiros)
- `Rota` — vínculo roteiro ↔ cliente (tblRotas)
- `Coleta` — registro de coleta (**tbl_suite** `module_type='coleta'` + `entity_id=idPJ`; legado: tblColetas)

**Repository:**
```ts
interface CRMRepository {
    findRoteiros(): Promise<Roteiro[]>
    findRotasByClient(idPJ: number): Promise<Rota[]>
    findColetasByRoteiro(idRoteiro: number): Promise<Coleta[]>
    createRota(rota: Rota): Promise<void>
    updateRotaOrdem(idRota: number, ordem: number): Promise<void>
    deleteRota(idRota: number): Promise<void>
}
```

**Tabelas:** `tblRoteiros`, `tblRotas`, `tblColetas` (legado), `tblDetalhesSatelite` (legado), `tblTipoProblema`, **tbl_suite** (`module_type='coleta'`)

**Hooks adicionais:** `useColetaMutations().registerColeta()` escreve em `tbl_suite`. `useCRMQueries.useColetasByRoteiro()` lê de ambas as fontes (legado + tbl_suite).

**Entity Registry:** `tblPJuridicas`, `tblPFisicas`, `tblContatos` permanecem como infraestrutura de plataforma referenciada por todos os módulos via `entity_picker`.

**DataSources (AD-020):** `crm-datasources.ts` expõe 7 resolvers para campos de formulário (`clientes_crm`, `catadores_crm`, `galpoes_crm`, `cooperativas_crm`, `pessoas_fisicas_crm`, `ecopontos_crm`, `setores_ativos`).

**Sync:** Coletas ✅ via `crm.coleta.registrada` → tbl_suite (EventSyncAdapter). Entidades do Entity Registry ❌ local (cadastro de clientes).

> **AD-015:** tblColetas e tblDetalhesSatelite são legado. Novos registros usam `tbl_suite` com `module_type='coleta'`. A migração é progressiva — queries leem ambas as fontes.

---

### 3.7 Ouvidoria Module (AD-014 — migrado para plataforma genérica)

**Status:** Refatorado. O módulo dedicado foi eliminado. Toda a funcionalidade agora usa infraestrutura genérica.

**Antes (legado — código arquivado em `_deprecated/`):**
- 6 tabelas dedicadas: `tblProtocolo`, `tblProtocoloEventos`, `tblProtocoloAssunto`, `tblProtocoloSubtema`, `Atendimento`, `tblMensagens`
- 13 use cases, 1 repository (`SqliteOuvidoriaRepository`), hooks dedicados
- **Sync:** ❌ local-only

**Depois (plataforma genérica):**
- Protocolos → `tbl_suite` com `module_type='ouvidoria'` e `resource_type='abertura'`
- Eventos → `tbl_suite` com `resource_type='evento'`, vinculados via `ref_package_id`
- Atendimento → `tbl_suite` com `resource_type='atendimento'`
- Assuntos/Subtemas → `data_registry` com `tipo='ouvidoria_assuntos'` / `'ouvidoria_subtemas'`
- Mensagens → `data_registry` com `tipo='mensagens_template'`
- **Sync:** ✅ completo via EventSyncAdapter (herdado de `tbl_suite`)

**Hooks:** `useOuvidoriaQueries.ts` — lê diretamente de `tbl_suite` + `data_registry`. `useOuvidoriaMutations()` escreve em `tbl_suite` via SQL direto.

**UI:** Páginas `app/ouvidoria/` mantidas, consumindo os mesmos tipos legados (`Protocolo`, `ProtocoloEvento`) populados a partir das queries genéricas.

> **AD-014:** As 6 tabelas legadas serão dropadas quando a migração de dados antigos estiver concluída.

---

### 3.8 Demanda Module

**Arquivos:**
- `src/domain/demanda/Demanda.ts` — entidade de domínio (classe com `fromProps/toProps`)
- `src/domain/demanda/DemandaEvento.ts` — eventos do ciclo de vida
- `src/domain/demanda/TarefaFormulario.ts` — formulários vinculados a tarefas da demanda
- `src/domain/demanda/DemandaRepository.ts` — interface do repositório

**Entidade `Demanda`:**
- Origem: `ouvidoria | interno | proprio`
- Status: `aberta | aceita | em_campo | concluida`
- Política de conclusão: `todas | declarado`
- Auto-aceite quando `origemTipo === 'proprio'`

**Repository:**
```ts
interface DemandaRepository {
    findById(id: string): Promise<Demanda | null>
    findByStatus(status: DemandaStatus): Promise<Demanda[]>
    findByDestinatario(setorId: string): Promise<Demanda[]>
    findBySolicitante(setorId: string): Promise<Demanda[]>
    save(demanda: Demanda): Promise<void>
    updateStatus(id: string, status: DemandaStatus, extra?: Partial<DemandaProps>): Promise<void>
    findEventos(demandaId: string): Promise<DemandaEvento[]>
    saveEvento(evento: DemandaEvento): Promise<void>
    findTarefaFormularios(tarefaId: string): Promise<TarefaFormulario[]>
    saveTarefaFormulario(tf: TarefaFormulario): Promise<void>
    markFormularioConcluido(id: string): Promise<void>
    allFormulariosObrigatoriosConcluidos(tarefaId: string): Promise<boolean>
    allTarefasObrigatoriasConcluidasParaDemanda(demandaId: string): Promise<boolean>
    transaction<T>(fn: () => Promise<T>): Promise<T>
}
```

**Tabelas:** `tbl_demandas`, `tbl_demanda_eventos`, `tbl_tarefa_formularios`

**Sync:** Não (dados locais desktop-only)

---

### 3.9 Access Control Module

**Arquivos:**
- `src/domain/access/AccessPolicy.ts`
- `src-tauri/src/session.rs`
- `src-tauri/src/commands/rbac.rs`
- `src-tauri/src/commands/audit.rs`
- `src-tauri/src/commands/actions.rs`

**Entidade `AccessPolicy`:** regras RBAC com 6 perfis. O mapa completo de permissões (~35 entradas) está em:
- `src/interface/hooks/utils/usePermissions.ts` (`PERMISSIONS_MAP` — fallback offline)
- `tbl_permissions` (banco SQLite — fonte de verdade para commands Rust)

**Perfis:** `admin | gerente | coordenador | campo | operador | encarregado`

**Tabelas dinâmicas:**
- `tbl_perfis` — perfis master
- `tbl_role_hierarchy` — níveis numéricos (admin=0, gerente=1, ...)
- `tbl_permissions` — matriz de permissões seedeada no boot
- `tbl_audit_log` — log de segurança (actor_id, action, target_table, target_id, old/new values)

**Commands Rust protegidos:**
- `suite_approve` / `suite_reject` — requer `data.edit_all`
- `demanda_aceitar` / `demanda_encerrar` — requer `activities.manage`
- `ecoponto_agendar_remocao` — requer `activities.manage`

**Sanitização:** `db_query`/`db_execute`/`db_execute_batch` bloqueiam acesso a `password_hash` e mutations em tabelas sensíveis para não-admin.

**Componentes de guarda (frontend):** `components/auth/PermissionGuards.tsx`
- `RequirePermission`, `RequireAnyPermission`, `RequireAllPermissions`
- `ShowForPermission`, `HideForPermission`
- `ShowForAdmin`, `ShowForManager`, `ShowForRole`, `HideForRole`
- `ProtectedPage` (redireciona se sem permissão)

**Regra:** nunca usar `user.perfil === 'admin'` inline — sempre usar `usePermissions()` ou os guards acima.

**Regras de edição por tempo:**
- Admin: sempre
- Gerente: até 72h
- Coordenador: até 48h (próprios)
- Operador/Campo: até 24h (próprios)

**Consulte também:** `docs/hooks.md` — Seção 9 (RBAC & Permissões), `docs/security.md` — Seção 2 (Autorização)

---

## 4. Aplicação (`src/application/`)

### 4.1 Ports (Interfaces de Contrato)

| Port | Responsabilidade |
|------|-----------------|
| `SqlitePort` | Leitura/escrita de SQLite com transação |
| `SyncPort` | Orquestrador de sincronização |
| `StorageSyncPort` | I/O de snapshots no Supabase Storage |
| `FileStoragePort` | Upload/download de arquivos bucket |
| `ClockPort` | Interface de tempo (para testabilidade) |
| `LoggerPort` | Interface de logging (para testabilidade) |

**Consulte:** `docs/data-system.md` — Seção 2 (Portas de Aplicação)

---

### 4.2 Use Cases

| Módulo | Use Cases |
|--------|-----------|
| **Task** | `CreateTaskUseCase`, `MoveTaskUseCase`, `AssignTaskUseCase`, `ArchiveTaskUseCase`, `DeleteTaskUseCase`, `ListTasksByProjectUseCase` |
| **Suite** | `SubmitSuiteUseCase`, `EditSuiteUseCase`, `ReviewSuiteUseCase`, `ListInboxUseCase` |
| **Client** | `ListClientsUseCase`, `GetClientByIdUseCase`, `ListClientContactsUseCase`, `ListClientTypesUseCase`, `CreateClientUseCase`, `UpdateClientUseCase`, `DeleteClientUseCase`, `CheckClientNameExistsUseCase`, `GetClientAuditLogUseCase` |
| **User** | `ListUsersUseCase`, `CreateUserUseCase`, `UpdateUserUseCase`, `ToggleUserStatusUseCase` |
| **DataRegistry** | `ListItemsUseCase`, `ListByTypeUseCase`, `ListTypesUseCase`, `CreateDataRegistryUseCase`, `SaveDataRegistryUseCase`, `DeleteDataRegistryUseCase`, `AggregateByTypeUseCase`, `CountByTypeUseCase`, `BulkInsertDataRegistryUseCase` |
| **CRM** | `ListRoteirosUseCase`, `ListRotasByClientUseCase`, `ListColetasByRoteiroUseCase`, `CreateRotaUseCase`, `UpdateRotaOrdemUseCase`, `DeleteRotaUseCase` |
| **Ouvidoria** | `ListProtocolosUseCase`, `GetProtocoloUseCase`, `ListEventosUseCase`, `GetAtendimentoUseCase`, `CreateProtocoloUseCase`, `UpdateProtocoloStatusUseCase`, `AddProtocoloEventoUseCase`, `UpsertAtendimentoUseCase`, `EncerrarProtocoloUseCase`, `CountProtocolosAbertosUseCase`, `ListAssuntosUseCase`, `ListSubtemasUseCase`, `ListMensagensUseCase` |
| **Ouvidoria** (AD-014) | ~~13 use cases~~ → 0. Substituídos por queries diretas em `tbl_suite` (`module_type='ouvidoria'`) + `data_registry`. Hooks: `useOuvidoriaQueries.ts`, `useOuvidoriaMutations()`. |
| **Demanda** | `CreateDemandaUseCase`, `AcceptDemandaUseCase`, `CloseDemandaUseCase`, `GetDemandaStatusUseCase` |
| **Sync** | `PushTasksUseCase`, `PullTasksUseCase` |
| **ActionRegistry** | `registerAction()`, `getAvailableActions()`, `aplicarMapeamento()`, `evaluateVisibilityRules()` |
| **WidgetRegistry** | `registerWidget()`, `getAvailableWidgets()`, `getAllWidgets()` |

**Ações Built-in:**
| Arquivo | Ações registradas |
|---------|-------------------|
| `src/application/actions/builtin/demanda.actions.ts` | `demanda_aceitar`, `demanda_encerrar` |
| `src/application/actions/builtin/suite.actions.ts` | `suite_aprovar`, `suite_rejeitar` |
| `src/application/actions/builtin/ecoponto.actions.ts` | `ecoponto_encaminhar_remocao` |
| `src/application/actions/builtin/encaminhamento.actions.ts` | `encaminhar_para_setor` |

**Widgets Built-in:**
| Arquivo | Widgets registrados |
|---------|---------------------|
| `src/application/widgets/builtin/initializeWidgets.ts` | `tarefas_abertas`, `protocolos_abertos`, `tarefas_por_status`, `atividade_recente`, `ultimas_demandas` |

---

## 5. Infraestrutura (`src/infrastructure/`)

### 5.1 Container de DI

**Arquivo:** `src/infrastructure/container.ts`

Provides centralizado:
- `sqlite: SqlitePort` — adapter Tauri SQLite
- `fileStorage: FileStoragePort` — Supabase file storage
- `clock: ClockPort` — system clock
- `logger: LoggerPort` — console logger
- `sync: SyncPort` — implementado atualmente por `NullSyncAdapter` (stub seguro; sync real ocorre via `SyncService`/`StorageSyncService` fora do container Clean Architecture)
- Todas as instâncias de repositórios e use cases

> **Nota (2026-04-28):** O `EventSyncAdapter` foi substituído por `NullSyncAdapter` no container para eliminar dependências `null as any`. A sincronização de dados segue ocorrendo via `SyncContext` → `SyncService` (camada legada compatível), que será integrada ao container em fase futura.

---

### 5.2 Repositórios SQLite

| Repositório | Implementação |
|------------|--------------|
| `TaskRepository` | `SqliteTaskRepository` |
| `SuiteRepository` | `SqliteSuiteRepository` |
| `ClientRepository` | `SqliteClientRepository` |
| `UserRepository` | `SqliteUserRepository` |
| `DataRegistryRepository` | `SqliteDataRegistryRepository` |
| `CRMRepository` | `SqliteCRMRepository` |
| ~~`OuvidoriaRepository`~~ | ~~`SqliteOuvidoriaRepository`~~ → código arquivado em `_deprecated/`. Substituído por queries diretas em `tbl_suite` + `data_registry`. |

---

### 5.3 Adapters

| Adapter | Arquivo |
|---------|---------|
| `TauriSqliteAdapter` | `src/infrastructure/persistence/sqlite/tauriSqliteAdapter.ts` |
| `SupabaseFileStorage` | `src/infrastructure/storage/SupabaseFileStorage.ts` |
| `ConsoleLogger` | `src/infrastructure/adapters/ConsoleLogger.ts` |
| `SystemClock` | `src/infrastructure/adapters/SystemClock.ts` |

---

### 5.4 Sync Infrastructure

| Serviço | Arquivo |
|---------|---------|
| `SyncService` | `src/infrastructure/sync/SyncService.ts` |
| `StorageSyncService` | `src/infrastructure/sync/StorageSyncService.ts` |
| `OfflineQueue` | `src/infrastructure/sync/OfflineQueue.ts` |

**Consulte:** `docs/data-system.md` — Seções 4 e 5 (Serviço de Sincronização e Storages)

---

## 6. Interface (`src/interface/`)

### 6.1 Hooks de Interface

Todos os hooks do projeto residem em `src/interface/hooks/`. Eles se dividem em dois grupos:

**A. Thin wrappers sobre use cases (Clean Architecture):**

| Hook | Responsabilidade |
|------|-----------------|
| `useTaskUseCases()` | Use cases de tarefa |
| `useSuiteUseCases()` | Use cases de suite |
| `useClientUseCases()` | Use cases de cliente |
| `useUserUseCases()` | Use cases de usuário |
| `useDataRegistryUseCases()` | Use cases de data registry |
| `useCRMUseCases()` | Use cases de CRM |
| `useOuvidoriaUseCases()` | Use cases de ouvidoria |

**B. Hooks de infraestrutura e domínio de interface:**

| Hook | Responsabilidade |
|------|-----------------|
| `useSqlite()` | Acesso direto ao SQLite |
| `useSync()` | Serviço de sincronização stateful |
| `useTauriQuery()` | Queries via Tauri invoke |
| `useTauriMutation()` | Mutations via Tauri invoke |
| `useSQLiteQuery()` | Queries reativas via useSqlite |
| `useSQLiteMutation()` | Mutations via useSqlite |
| `useKanban()` | Orquestração do módulo Kanban |
| `useKanbanData()` | Dados do Kanban |
| `useKanbanMutations()` | Mutações do Kanban |
| `useTaskMetrics()` | Métricas de produtividade |
| `useTaskHistory()` | Linha do tempo de eventos |
| `useTaskComments()` | Comentários em tarefas |
| `useProjects()` | Listagem de projetos |
| `useClients()` | Queries de clientes (wrapper) |
| `useClientMutations()` | Mutações de clientes (wrapper) |
| `useAdminUsers()` | Gestão de usuários admin |
| `usePermissions()` | Sistema RBAC |
| `useFormPermissions()` | Permissões de formulário |
| `useInboxMutations()` | Mutações de inbox |
| `useWorkflowActions()` | Filtra ações disponíveis por contexto e perfil (ActionRegistry) |
| `useDashboardWidgets()` | Filtra widgets disponíveis por perfil (WidgetRegistry) |
| `useFormTemplate()` | Templates de formulário |
| `useVisibilityEvaluator()` | Regras de visibilidade |
| `useDeviceConfig()` | Configuração do dispositivo |
| `useOnlineStatus()` | Status de conectividade |
| `useKeyboardShortcuts()` | Atalhos de teclado |

**Consulte:** `docs/hooks.md` — Catálogo completo organizado por 12 categorias funcionais

---

## 7. Camadas Legadas (`lib/`, `contexts/`)

### 7.1 Visão Geral

A arquitetura Clean Architecture está completamente implementada:

```
src/domain/ → src/application/ → src/infrastructure/ → src/interface/
```

> **Nota (2026-04-27):** A pasta `lib/` foi **parcialmente migrada** para `src/`:
> - Utilitários puros (cn, logger, window-utils, brasilia-time, field-type-map, registry-schema) → `src/lib/`
> - Serviços de sync → `src/infrastructure/sync/`
> - Wrappers de DB → `src/infrastructure/persistence/`
> - Filtros de acesso SQL → `src/infrastructure/persistence/AccessFilterBuilder.ts`
> - Utilitários de tarefa → `src/domain/task/TaskRecurrence.ts`
> - Utilitários de exportação → `src/infrastructure/export/`
>
> **A pasta `lib/` ainda existe** com arquivos ativos (`utils.ts`, `logger.ts`, `window-utils.ts`, `offline-storage.ts`, `export/excel-exporter.ts`, `import/excel-parser.ts`, `queries/task-metrics-queries.ts`, `form/brasilia-time.ts`, `form/field-type-map.ts`).

A única camada legada restante é:
- `contexts/` — React contexts (AuthContext, SyncContext)

> **Nota:** A pasta `hooks/` foi esvaziada em 2026-04-27. Todos os hooks foram migrados para `src/interface/hooks/`.

---

### 7.2 Camada de Sync (`src/infrastructure/sync/`)

| Arquivo | Função |
|---------|--------|
| `EventSyncAdapter.ts` | **Adaptador ativo** — orquestra push/pull de eventos criptografados |
| `TransportService.ts` | Push de envelopes `.enc` para `eventos/{routingId}/` no Storage |
| `InboundService.ts` | Pull de envelopes de outros setores, validação de sequência |
| `EventBus.ts` | Publicação/despacho de eventos de domínio |
| `HandlerRegistry.ts` | Registro dos 8 handlers de domínio (demanda — incluindo `encaminhada`/`reencaminhada` + suite + ecoponto + CRM + form_registry + data_registry + usuario + org_config). Ouvidoria removido (AD-014). |
| `CryptoLayer.ts` | Criptografia AES-256-GCM via Tauri Rust |
| `Manifest.ts` | Controle de sequência por `routing_id` |
| `StorageBootstrapService.ts` | Bootstrap automático de `org_config.json` no primeiro boot |
| `OrgConfigService.ts` | Carrega/salva configuração organizacional no Storage |
| `OfflineQueue.ts` | Fila offline baseada em `localStorage` |
| `ColumnSchemaManager.ts` | Helpers para migração de schema SQLite |
| `lazy-sync.ts` | Inicialização lazy do `EventSyncAdapter` (singleton) |
| `StorageSync.ts` | Serviço legado de sync por snapshots JSON (não instanciado) |
| `NullSyncAdapter.ts` | Adaptador no-op usado no container DI por padrão |

**Consulte:** `docs/data-system.md` — Seções 4 e 5

### 7.3 Hooks de Domínio (por Categoria)

| Categoria | Hooks |
|-----------|-------|
| Infra/Base | `useTauriQuery`, `useTauriMutation`, `useSQLiteQuery`, `useSQLiteMutation`, `useSQLiteSchema` |
| Clean Architecture | `useTaskUseCases`, `useSuiteUseCases`, `useClientUseCases`, `useUserUseCases`, `useDataRegistryUseCases`, `useCRMUseCases` |
| Kanban/Tarefas | `useKanban`, `useKanbanData`, `useKanbanMutations`, `useKanbanViewState`, `useTaskMetrics`, `useTaskComments`, `useTaskHistory` |
| Projetos | `useProjects`, `useProjectMutations`, `useProjectDetail` |
| Clientes | `useClients`, `useClientMutations`, `useClientSearch`, `useClientExport`, `useCEP` |
| CRM | `useCRMQueries` |
| Formulários | `useFormTemplate`, `useFormPermissions` |
| Solicitações/Suite | `useSolicitacoesList`, `useSolicitacaoEditor`, `useInboxMutations`, `useSubmissionData`, `useSync` |
| Ouvidoria | `useOuvidoriaQueries` (queries diretas em `tbl_suite` + `data_registry`) |
| Sistema/Config | `useSyncSettings`, `useDeviceConfig`, `useOnlineStatus` |
| RBAC/Permissões | `usePermissions`, `useFormPermissions` |
| Dados/Sincronização | `useDataRegistryUseCases`, `useNetworkParquet` |
| UI/Experiência | `useVisibilityEvaluator`, `useKeyboardShortcuts` |
| Administração | `useAdminUsers`, `useAllUsers`, `useUsersByForm` |

**Total:** ~61 hooks exportados. Consulte `docs/hooks.md` para catálogo completo.

---

### 7.4 Contexts

| Context | Responsabilidade |
|---------|-----------------|
| `AuthContext` | Estado de autenticação, usuário logado |
| `SyncContext` | Estado global de sincronização, auto-sync em online/focus/interval |
| `LogContext` | Contexto de logging |

**`SyncContext`:**
- `syncNow(forcePush?)` — força sync via `EventSyncAdapter` (lazy-init)
- `syncOnFocus` — sincroniza ao focar janela
- `syncInterval` — intervalo configurável
- `notifyOnSuccess/Error` — notificações
- Escuta eventos `online`/`offline`/`visibilitychange`

---

## 8. Camada Web Capacitor (`www/`)

Aplicação web hibrida (Capacitor) para runtime mobile.

| Arquivo | Função |
|---------|--------|
| `login.html` | Página de login |
| `index.html` | Página principal |
| `js/services/DatabaseSyncService.js` | Placeholder (sem implementação) |
| `js/supabase-client.js` | Placeholder Supabase client |
| `js/auth-manager.js` | Gerenciamento de autenticação |
| `js/data-service.js` | Serviço de dados |
| `js/smart-cache.js` | Cache inteligente |
| `forms/sample-form.json` | Formulário de exemplo |

**Nota:** Esta camada está em estado de **placeholder** — não há implementação real de sync ou serviços. O sync runtime é implementado em `src/infrastructure/sync/RuntimeStorageSync.ts`.

---

## 9. Backend Tauri (`src-tauri/`)

### 9.1 Comandos Disponíveis

**Database:**
```rust
db_connect, db_disconnect, db_get_path
db_query       // SELECT → { columns, rows }
db_execute     // INSERT/UPDATE/DELETE → rows_affected
db_execute_batch // múltiplos SQLs em transação
db_last_insert_id
```

**Auth:**
```rust
verify_password, hash_password
```

**Network:**
```rust
network_probe_path    // testa acessibilidade de caminho
network_list_parquet  // lista arquivos .parquet
network_write_parquet // escreve parquet
```

**Admin:**
```rust
supabase_admin_query   // operações admin via Supabase
supabase_admin_status  // verifica status admin
```

**Dev:**
```rust
toggle_devtools
```

**Config:** `tauri.conf.json`

---

## 10. Tabela Inventário de Módulos

| Módulo | Entidade Dominio | Repository | Use Cases | Tabelas | Hooks Associados | Sync | Docs |
|--------|-----------------|------------|-----------|---------|-----------------|------|------|
| **Task** | Task, TaskStatus | TaskRepository | CreateTask, MoveTask, AssignTask, ArchiveTask, DeleteTask, ListTasksByProject | tbl_tarefas, tbl_tarefas_eventos | useKanban, useKanbanMutations, useTaskMetrics, useTaskComments, useTaskHistory | ✅ Full | data-system.md |
| **Suite** | SuitePackage, SuiteStatus | SuiteRepository | SubmitSuite, EditSuite, ReviewSuite, ListInbox | tbl_suite, tbl_suite_historico | useSolicitacoesList, useSolicitacaoEditor, useInboxMutations, useSync | ✅ Full | data-system.md |
| **Client** | Client, ClientContact, ClientType | ClientRepository | ListClients, GetClientById, ListContacts, ListTypes, CreateClient, UpdateClient, DeleteClient, CheckNameExists, GetAuditLog | tblPJuridicas, tblPJtipo, tblContatos, tblPFisicas | useClients, useClientMutations, useClientSearch, useClientExport | ⚠️ Parcial | hooks.md §5 |
| **User** | User | UserRepository | ListUsers, CreateUser, UpdateUser, ToggleStatus | tbl_usuarios, tbl_usuarios_setores | useAdminUsers, useAllUsers, useUsersByForm | ✅ Shared | hooks.md §10 |
| **DataRegistry** | DataRegistryItem | DataRegistryRepository | ListItems, ListByType, ListTypes, Create, Save, Delete, Aggregate, CountByType, BulkInsert | data_registry | useDataRegistryUseCases | ✅ Shared | hooks.md §11 |
| **CRM** | Roteiro, Rota, Coleta | CRMRepository | ListRoteiros, ListRotas, ListColetas, CreateRota, UpdateOrdem, DeleteRota | tblRoteiros, tblRotas, tblColetas (legado), tblDetalhesSatelite (legado), **tbl_suite** (`module_type='coleta'`) | useCRMQueries, `useColetaMutations` | ✅ Coletas via EventSyncAdapter | hooks.md §5 |
| **Ouvidoria** (AD-014) | ~~Protocolo, ProtocoloEvento, Atendimento~~ → `tbl_suite` registros | ~~OuvidoriaRepository~~ → 0 | ~~13 use cases~~ → 0. Substituídos por queries diretas. | ~~tblProtocolo, tblProtocoloEventos, etc.~~ → `tbl_suite` (`module_type='ouvidoria'`) + `data_registry` (`ouvidoria_assuntos`, `ouvidoria_subtemas`, `mensagens_template`) | useOuvidoriaQueries | ✅ via EventSyncAdapter (herdado de tbl_suite) | ADR-014 |
| **Projects** | KanbanProject | — (via hooks) | — | tbl_projetos, tbl_projetos_interessados | useProjects, useProjectDetail | ✅ Shared | hooks.md §4 |
| **Sync** | SyncSnapshot | SyncRepository | PushTasks, PullTasks | — | useSync, useSyncSettings | **Core** | data-system.md §4 |
| **Access** | AccessPolicy | — | — | tbl_usuarios | usePermissions, useFormPermissions | — | hooks.md §10 |
| **Form Templates** | FormContent, FormField | — (via SQLite) | — | form_registry | useFormTemplate, useFormPermissions | ✅ Shared | data-system.md §1 |

---

## 11. Relações entre Módulos e Documentação

```
data-system.md
├── Tipos canônicos (types/index.ts, clients.ts, crm.ts, ouvidoria.ts)
├── Portas de aplicação (SqlitePort, SyncPort, StorageSyncPort, ...)
├── SQLiteDBWrapper (src/infrastructure/persistence/)
├── SyncService (src/infrastructure/sync/SyncService.ts)
│   ├── PushTasksUseCase (src/application/sync/PushTasksUseCase.ts)
│   │   ├── pushTblSuite()
│   │   ├── pushTaskSnaps()
│   │   └── pushEcopontoState()
│   └── PullTasksUseCase (src/application/sync/PullTasksUseCase.ts)
│       ├── pullFromStorage()
│       ├── pullTaskPatches()
│       └── pullTaskStatusUpdates()
├── StorageSync (src/infrastructure/sync/StorageSyncService.ts)
├── ColumnSchemaManager (src/infrastructure/sync/ColumnSchemaManager.ts)
├── DimensionSyncService (src/infrastructure/sync/DimensionSyncService.ts)
├── OfflineQueue (src/infrastructure/sync/OfflineQueue.ts)
└── Access Control helpers (src/infrastructure/persistence/AccessFilterBuilder.ts)

hooks.md
├── Infraestrutura/Base
│   ├── useTauriQuery ──────────────────────────────▶ Tauri db_query
│   ├── useTauriMutation ────────────────────────────▶ Tauri db_execute
│   ├── useSQLiteQuery ──────────────────────────────▶ useSqlite (context)
│   └── useSQLiteMutation ───────────────────────────▶ useSqlite execute
├── Kanban/Tarefas
│   ├── useKanban ───────────────────────────────────▶ orchestration
│   ├── useKanbanData ───────────────────────────────▶ useTauriQuery (tasks, projects, solicitations)
│   ├── useKanbanMutations ──────────────────────────▶ createTask, moveTask, updateTask, patchTask...
│   ├── useTaskMetrics ───────────────────────────────▶ TASK_METRICS_*_SQL
│   └── useTaskHistory ──────────────────────────────▶ tbl_tarefas_eventos UNION
├── Clientes/CRM
│   ├── useClients ─────────────────────────────────▶ useSQLiteQuery
│   ├── useClientMutations ───────────────────────────▶ useSQLiteMutation
│   ├── useCRM ─────────────────────────────────────▶ useSQLiteQuery (roteiros, coletas)
│   └── useClientSearch ─────────────────────────────▶ FTS5 (tbl_pjuridicas_fts)
├── Data/Sync
│   ├── useDataRegistry ─────────────────────────────▶ tbl_suite push/pull
│   ├── useSync ─────────────────────────────────────▶ SyncService
│   └── useDimensions ─────────────────────────────▶ DimensionSyncService
└── Permissions
    └── usePermissions ──────────────────────────────▶ PERMISSIONS_MAP (RBAC)
```

---

## 12. Notas de Arquitetura

### Dual Query Layer
O projeto opera com **duas formas de consultar SQLite** em paralelo:
1. **`useTauriQuery`** — bypass direto via `invoke('db_query')` para o Rust, sem passar pelo contexto React
2. **`useSQLiteQuery`** — usa `useSqlite` do context (via provider), wrapper reativo com cache

### Versionamento Append-Only
`tbl_suite` segue **regra estrita**: nunca UPDATE — sempre INSERT nova versão com `is_current=0` para a versão anterior.

### Schema Legacy Detection
Hooks que acessam `tblPJtipo`, `tblProtocolo` verificam existência de colunas canônicas (`idPJtipo`, `idProtocolo`) vs `id_legacy` para adaptar SQLs dinamicamente.

### Snapshot Freeze
Tarefas atribuídas a operadores mobile podem ser **congeladas** (`snap_frozen_at`). Campo `snap_hash` (FNV-1a) identifica conflitos; patches são consolidados via `unfreezeTask()`.

### Sync Pure Storage
O sync não usa tabelas Supabase — apenas **Supabase Storage** como intermediário (JSON + SHA-256).

> **REGRA FUNDAMENTAL**: Todo o trânsito de dados entre dispositivos ocorre exclusivamente via Supabase Storage. Nunca acessar tabelas PostgreSQL diretamente via `supabase.from()`.
