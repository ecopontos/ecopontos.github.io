# Decisões Arquiteturais — EcoForms Desktop

Este documento registra as principais decisões arquiteturais (ADs) do sistema EcoForms Desktop, explicando o **porquê** de cada escolha técnica.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `arquitetura.md` | Visão geral da arquitetura, stack, módulos |
| `database.md` | Esquema de banco de dados, tabelas, relacionamentos |
| `data-system.md` | Tipos canônicos, portas, serviços de sincronização |
| `modules.md` | Inventário de módulos, repositories, use cases |

---

## Índice

1. [AD-001: Arquitetura Dual SQLite + Supabase](#ad-001-arquitetura-dual-sqlite--supabase)
2. [AD-002: Pure Storage Mode (Sem Tabelas Supabase)](#ad-002-pure-storage-mode-sem-tabelas-supabase)
3. [AD-003: Padrão Append-Only para tbl_suite](#ad-003-padrão-append-only-para-tbl_suite)
4. [AD-004: Hash SHA-256 para Detecção de Mudanças](#ad-004-hash-sha-256-para-detecção-de-mudanças)
5. [AD-005: Tauri como Runtime Desktop](#ad-005-tauri-como-runtime-desktop)
6. [AD-006: Coexistência de Arquiteturas (Clean + Legacy Hooks)](#ad-006-coexistência-de-arquiteturas-clean--legacy-hooks)
7. [AD-007: Compressão para Sync Payloads](#ad-007-compressão-para-sync-payloads)
8. [AD-008: Event Envelope v2 (Evolução do Snapshot)](#ad-008-event-envelope-v2-evolução-do-snapshot)

---

## AD-001: Arquitetura Dual SQLite + Supabase

**Decisão:** O sistema utiliza SQLite como banco de dados local primário no desktop, com Supabase (Storage + PostgreSQL opcional) como camada de sincronização e compartilhamento.

### Contexto

O EcoForms é um sistema de gestão de operações de campo que precisa funcionar:
- **Offline** em áreas sem conectividade (roteiros de coleta em zonas rurais)
- **Multi-dispositivo** (desktop do escritório + mobile/tablet do operador de campo)
- **Com dados compartilhados** entre dispositivos de uma mesma equipe

### Opções Consideradas

| Opção | Prós | Contras |
|-------|------|---------|
| **SQLite + Supabase (escolhida)** | Offline-first, sync flexible, baixo custo | Complexidade de reconciliação |
| PostgreSQL único (cloud-only) | Consistência nativa, sem reconciliation | Inútil offline, latência alta |
| Firebase Realtime DB | Sync automático, offline suporte | Vendor lock-in, custo escalável |
| CouchDB/PouchDB | Sync nativo built-in | Curva de aprendizado, ecosystem menor |

### Análise

**1. Requisito Offline-First:**
O SQLite é embedded no dispositivo desktop. Todas as operações são locais por padrão, eliminando dependência de rede. O operador de campo pode coletar dados sem conexão e sincronizar depois.

**2. Multi-tenant com dados compartilhados:**
O Supabase Storage serve como "hub" de sincronização. Cada desktop push para seu `outbox/` e o mobile faz pull do `inbox/`. Dados compartilhados (formulários, usuários, projetos) ficam em `shared/`.

**3. Custo e controle:**
- SQLite: gratuito, sem servidor
- Supabase Storage: ~$0.02/GB, pay-as-you-go
- Supabase PostgreSQL: opcional para admin (não usado no sync core)

**4. Latência:**
Operações locais no SQLite são sub-milissegundo. Sync é assíncrono e não bloqueia a UI.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Performance offline excelente | Reconciliation de conflitos pode ser complexo |
| Resiliência a falhas de rede | Necessidade de hash/checksum para detecção de mudanças |
| Custos de infraestrutura previsíveis | Latência de sync pode causar inconsistências temporárias |
| Dados nunca perdem por falha de rede | Debug de sync issues é mais difícil |

### Referências

- `database.md` — Arquitetura de banco (Seção "Visão Geral da Arquitetura")
- `data-flow.md` §4 — Ciclo completo de sincronização
- `data-system.md` §4 — SyncService

---

## AD-002: Pure Storage Mode (Sem Tabelas Supabase)

**Decisão:** O sistema de sincronização **não utiliza tabelas Supabase (PostgreSQL)**. Toda comunicação entre dispositivos ocorre via Supabase Storage (file storage genérico), usando JSON.

### Contexto

A primeira versão do sistema utilizava Supabase Tables (PostgreSQL) para sincronização. Isso criou problemas de:
- Custo escalável com muitas tabelas
- Latência de rede para operações pequenas
- Complexidade de schema migrations
- Vendor lock-in com o ecosystem Supabase

### Opções Consideradas

| Opção | Prós | Contras |
|-------|------|---------|
| **Pure Storage (escolhida)** | Baixo custo, simple, portable | Sem queries no servidor, processamento local |
| Supabase Tables + RLS | Queries powerful, RLS nativo | Custo, vendor lock-in, latência |
| GraphQL custom (Apollo) | Flexibilidade | Overhead, necessidade de servidor |
| REST API custom | Simplicidade conceitual | Manutenção de servidor, scaling |

### Análise

**1. Arquitetura "dumb storage, smart client":**
O Supabase Storage é usado apenas como um "bucket de arquivos" genérico. Toda a lógica de negócio, queries e sincronização roda no cliente. Isso significa:

```
Desktop: SQLite → JSON → Supabase Storage
Mobile: Supabase Storage → JSON → IndexedDB
```

**2. Formato de sync:**
```json
// shared/tbl_suite.json
{
  "version": "1.0",
  "timestamp": "2024-01-15T10:30:00Z",
  "device_id": "desktop-001",
  "data": [...],
  "metadata": {
    "checksum": "sha256:abc123...",
    "record_count": 150
  }
}
```

**3. Vantagens concretas:**
- **Custo**: Storage é 100x mais barato que Database para nosso padrão de uso
- **Portabilidade**: Podemos migrar para S3/CloudFlare R2/GCS facilmente — o formato é vendor-agnostic
- **Simplicidade**: Sem schema migrations no servidor, sem RLS policies para manter
- **Debugging**: Arquivos JSON são facilmente inspecionáveis

**4. Desvantagens aceitas:**
- Não podemos fazer "SELECT WHERE" no servidor — todos os dados vem para o cliente
- Para datasets pequenos (~MBs), isso é aceitável
- Para datasets grandes, deve-se implementar paginação ou filtering client-side

**5. Regras importantes:**
- **NUNCA** acessar tabelas PostgreSQL diretamente via `supabase.from()`
- **SEMPRE** usar Storage para trânsito de dados entre dispositivos
- **SEMPRE** usar cache local (IndexedDB/localStorage) como fonte primária de leitura

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Custo drasticamente menor | Todo processamento no cliente |
| Zero vendor lock-in | Sync de grandes volumes pode ser lento |
| Schema evolution simples | Sem validação server-side |
| Formato universal (JSON) | Necessidade de hash para integridade |
| Fácil debugging (arquivos legíveis) | — |

### Referências

- `data-system.md` §4 — SyncService (Pure Storage Mode)
- `data-flow.md` §4.2 — Ciclo de Sync (Desktop → Cloud → Desktop)
- `data-flow.md` §6.1 — Detecção de Mudanças (Hash Cache)

---

## AD-003: Padrão Append-Only para tbl_suite

**Decisão:** A tabela `tbl_suite` (pacotes de formulários) utiliza um padrão **append-only**: nunca se faz UPDATE em registros existentes. Cada modificação cria um novo registro com `version_no` incrementado e `is_current=0` no anterior.

### Contexto

Formulários no EcoForms passam por um fluxo de revisão:
1. `draft` → `current` (enviado)
2. `current` → `edit` (precisa correção)
3. `edit` → `current` (reenviado)
4. `current` → `locked` (aprovado)

O sistema precisa manter **histórico completo** de todas as versões de um formulário, incluindo quem alterou, quando, e por quê.

### Opções Consideradas

| Opção | Prós | Contras |
|-------|------|---------|
| **Append-only (escolhida)** | Histórico completo, audit trail nativo, paralelismo | Uso de disco maior, queries mais complexas |
| UPDATE com audit_log separado | Simples de implementar, menor storage | Duas fontes de verdade, possibilidade de divergência |
| Temporal database (Postgres temporal) | Queries temporais nativas | Complexidade, vendor-specific |
| Event sourcing | Audit completo, replay possível | Overhead significativo, Curva de aprendizado |

### Análise

**1. Histórico automático:**
```sql
-- Regra: NUNCA faz UPDATE em tbl_suite
-- Sempre: INSERT nova versão + UPDATE is_current=0 na anterior

-- Ao editar um pacote:
UPDATE tbl_suite SET is_current = 0 WHERE package_id = ? AND is_current = 1;

INSERT INTO tbl_suite (
  package_id, version_no, module_type, status,
  is_current, payload_json, created_at
) VALUES (
  ?, ?, ?, 'current', 1, ?, datetime('now')
);

-- Registrar a transição:
INSERT INTO tbl_suite_historico (
  package_id, version_from, version_to,
  status_anterior, status_novo, alterado_por, alterado_em, motivo
) VALUES (
  ?, 3, 4, 'current', 'edit', ?, datetime('now'), ?
);
```

**2. Queries de leitura filtram `is_current=1`:**
```sql
-- Pegar versão vigente:
SELECT * FROM tbl_suite WHERE package_id = ? AND is_current = 1;

-- Ver histórico completo:
SELECT * FROM tbl_suite WHERE package_id = ? ORDER BY version_no DESC;
```

**3. Benefícios específicos:**
- **Paralelismo**: Operador A pode editar versão 3 enquanto Operador B está visualizando versão 2 — sem locks
- **Audit trail**: `tbl_suite_historico` registra transições com motivo
- **Rollback**: Trivial — basta fazer `is_current=0` na versão nova e `is_current=1` na antiga
- **Reproducibilidade**: Qualquer versão pode ser reconstruída a qualquer momento

**4. Custo aceito:**
- Storage: Cada versão completa é mantida. Para formulários grandes, isso pode consumir espaço
- Queries: Clientes devem sempre filtrar `is_current=1` ou fazer JOIN com histórico

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Histórico completo e à prova de falhas | Maior uso de storage |
| Rollback trivial | Queries mais verbosas (WHERE is_current=1) |
| Paralelismo de edição | Necessidade de índice composto |
| Audit trail nativo | — |
| Consistência eventual automática | — |

### Referências

- `database.md` §Padrão-Append-Only — Implementação details
- `data-system.md` §1 — TblSuitePackage type
- `modules.md` §3.2 — Suite Module
- `data-flow.md` §3.2 — Fluxo Suite Module

---

## AD-004: Hash SHA-256 para Detecção de Mudanças

**Decisão:** O sistema utiliza SHA-256 para detectar se dados foram modificados entre sincronizações, evitando push desnecessário.

### Contexto

Com sync baseado em arquivos (Pure Storage Mode), não temos "last modified timestamp" nativo do PostgreSQL. Precisamos de uma forma determinística de saber se um registro mudou.

### Análise

**1. JSON determinístico com stable-stringify:**
```ts
// Problema: JSON.stringify não é determinístico
JSON.stringify({ a: 1, b: 2 }) !== JSON.stringify({ b: 2, a: 1 })

// Solução: stable-stringify (ordena chaves)
stableStringify({ a: 1, b: 2 }) === stableStringify({ b: 2, a: 1 })
```

**2. Hash cache em memória:**
```ts
class SyncService {
  private sharedHashCache = new Map<string, string>();

  hasChanged(table: string, data: any): boolean {
    const json = stableStringify(data);
    const hash = sha256(json);
    const previous = this.sharedHashCache.get(`shared_hash_${table}`);

    if (previous === hash) return false;  // Sem mudanças

    this.sharedHashCache.set(`shared_hash_${table}`, hash);
    return true;
  }
}
```

**3. Por que SHA-256 e não outros:**
| Algoritmo | Prós | Contras |
|-----------|------|---------|
| **SHA-256 (escolhida)** | Padrão crypto, irreversível, 256 bits | Ligeiramente mais lento que MD5/SHA-1 |
| MD5 | Rápido | Quebrado, colisões possíveis |
| SHA-1 | Padrão histórico | Depreciado, colisões conhecidas |
| CRC32 | Muito rápido | Não é hash criptográfico, colisões prováveis |

SHA-256 é overkill para integridade (não precisamos de resistência a ataques), mas é o padrão da indústria e disponível em todas as plataformas (Rust: `sha2`, JS: `crypto`).

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Push só quando necessário | Memória para cache de hashes |
| Detecção de corrupção de dados | Hash recalculado a cada sync |
| Formato determinístico (stable-stringify) | — |

### Referências

- `data-flow.md` §6.1 — Detecção de Mudanças
- `lib/sync/stable-stringify.ts`

---

## AD-005: Tauri como Runtime Desktop

**Decisão:** O desktop application é construído com Tauri (Rust backend + WebView), ao invés de Electron ou NW.js.

### Contexto

A primeira versão do sistema utilizava Electron. Problemas identificados:
- Bundle size grande (~150MB+)
- Memory footprint alto
- Cross-origin errors frequentes com SQLite

### Opções Consideradas

| Opção | Prós | Contras |
|-------|------|---------|
| **Tauri (escolhida)** | Binário pequeno (~10MB), Rust performance, native bindings | Ecosystem menor, plugins less maduros |
| Electron | Ecosystem huge, debugging tools | Bundle size, memory, security concerns |
| NW.js | Simples, Node integration | Abandonado? |
| Neutralino.js | Leve | Funcionalidades limitadas |

### Análise

**1. Comandos Tauri disponíveis:**
```rust
// Database
db_connect, db_disconnect, db_get_path
db_query       // SELECT → { columns, rows }
db_execute     // INSERT/UPDATE/DELETE → rows_affected
db_execute_batch // transação

// Auth
verify_password, hash_password

// Network
network_probe_path    // testa acessibilidade
network_list_parquet  // lista .parquet files
network_write_parquet // escreve .parquet

// Admin
supabase_admin_query
supabase_admin_status
```

**2. Vantagens práticas:**
- Binário final ~8MB vs ~150MB do Electron
- Startup time < 1s
- Rust para operações crypto (SHA-256, password hashing)
- Bindings nativos para SQLite (rusqlite)

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Binário pequeno | Plugins less maduros que Electron |
| Performance Rust | Ecosystem menor |
| Native SQLite bindings | Curva de aprendizado Rust |
| Security (Chromium sandbox) | Debugging mais complexo |

### Referências

- `modules.md` §9 — Backend Tauri
- `src-tauri/`

---

## AD-006: Coexistência de Arquiteturas (Clean + Legacy Hooks)

**Decisão:** O projeto opera com duas arquiteturas coexistindo: Clean Architecture (`src/domain/`, `src/application/`, `src/infrastructure/`) e o sistema legacy de hooks (`hooks/`, `lib/`, `contexts/`).

### Contexto

O sistema evoluiu ao longo de 2+ anos. A arquitetura original era baseada em hooks React ("hooks-centric"). Durante a refatoração, uma Clean Architecture foi introduzida, mas migrar completamente seria:
- Risco operacional alto
- Tempo de desenvolvimento longo demais
- Interrupção de features em progresso

### Análise

**Arquitetura nova (Clean):**
```
src/domain/       → Entities + Repository Interfaces
src/application/  → Use Cases + Ports
src/infrastructure/ → Repository Implementations
src/interface/    → Hooks de domínio
```

**Arquitetura legacy:**
```
hooks/      → 47 hooks React (Presentation + Application misturados)
lib/       → sync/, normalization/, utils/
contexts/  → SyncContext, AuthContext
```

**Decisão: Coexistência gradual**

Ambas as arquiteturas convergem para o mesmo SQLite e Supabase Storage. A estratégia é:
1. Novos módulos vão para Clean Architecture
2. Módulos legados são migrados incrementalmente quando tocados
3. Hooks existentes não são refeitos sem necessidade

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Zero risco operacional | Duplicação de conceitos |
| Evolução incremental | Curva de aprendizado para novos devs |
| Features não travam | Manutenção de duas arquiteturas |
| — | Nomenclatura inconsistente |

### Referências

- `modules.md` §1 — Arquitetura Geral (duas arquiteturas)
- `modules.md` §7 — Legacy (lib/, hooks/, contexts/)
- `hooks.md` — Catálogo completo dos 47 hooks

---

## AD-007: Compressão para Sync Payloads

**Decisão:** Os arquivos de sync podem ser comprimidos quando necessário, mas o formato padrão é JSON puro para compatibilidade com mobile.

### Contexto

O sistema sincroniza:
- Formulários completos com payloads JSON (podendo chegar a KBs)
- Múltiplos registros por sync
- snapshots de tarefas

Sem compressão, o bandwidth seria o gargalo, especialmente para operadores mobile em áreas rurais.

### Análise

**1. Formato do arquivo:**
```
shared/tbl_suite.json           (JSON puro - padrão mobile)
users/{deviceId}/outbox/*.json  (JSON puro - compatível)
```

**2. Compressão no fluxo:**
```ts
// StorageSync.createSnapshot()
const json = stableStringify(data);
const hash = sha256(json);  // Hash do JSON
await storage.upload(json);  // Upload do JSON puro
```

**3. Por que JSON puro como padrão:**
| Formato | Vantagem | Desvantagem |
|---------|----------|-------------|
| **JSON puro (escolhido)** | Compatibilidade universal, debug fácil | Maior tamanho |
| JSON puro | Compatibilidade universal | Maior tamanho |

Para o mobile (Capacitor), JSON puro é mais compatível. O Desktop pode usar compressão para snapshots maiores.

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Compatibilidade universal | Maior uso de bandwidth |
| Debug fácil (arquivos legíveis) | — |
| Sem dependência de libraries de compressão | — |

### Referências

- `src/infrastructure/sync/StorageSyncService.ts` — createSnapshot(), push(), pull()
- `data-flow.md` §4.3 — Storage Paths

---

## AD-008: Event Envelope v2 (Evolução do Snapshot)

**Decisão:** Evoluir o envelope de sincronização de Snapshot v1 (flat) para Event Envelope v2, adicionando identidade de evento, rastreabilidade causal (correlationId/causationId), schema version e payload nativo, mantendo backward compatibility com v1.

### Contexto

O envelope Snapshot v1 funciona para sync state-based mas carece de semântica de eventos para um sistema que já opera de forma event-driven:
- `tbl_suite` é append-only (não atualiza, cria nova versão)
- Máquinas de estado tratam transições como fatos
- Offline queue acumula mutações como eventos pendentes
- Ghost tasks (Ad Hoc -> tarefa) são reações a eventos

Além disso, `payload_json` como string escapada impede validação estruturada e tipagem.

### Opções Consideradas

| Opção | Prós | Contras |
|-------|------|---------|
| **Event Envelope v2 (escolhida)** | Rastreabilidade, schema evolution, payload tipado | Custo de migração gradual |
| Manter v1 indefinidamente | Zero custo | Sem evolução, debugging difícil |
| Event Sourcing completo (refatorar.md) | Audit total, replay possível | Reescrever todo o sistema |
| CloudEvents nativo | Padrão CNCF | Verboso, overkill para nosso caso |

### Análise

**1. Gap no v1:**
```json
{
    "version": "1.0",
    "timestamp": "2024-01-15T10:30:00.000Z",
    "device_id": "...",
    "sync_type": "incremental",
    "data": { "tbl_suite": [...] },
    "metadata": { "checksum": "..." }
}
```
Problemas:
- Não identifica **qual evento** gerou o snapshot
- Sem `correlation_id` — não dá para rastrear o caso inteiro
- Sem `causation_id` — não dá para reconstruir cadeia de decisões
- `payload_json` como string — dupla serialização
- Sem schema version — evolução do formato é difícil

**2. Solução v2:**
```json
{
    "specversion": "2.0",
    "id": "evt_abc123",
    "type": "ecoforms.snapshot.incremental",
    "source": "desktop/device-uuid-123",
    "subject": "aggregate:tbl_suite:pkg-uuid-456",
    "time": "2024-01-15T10:30:00.000Z",
    "ecoforms": {
        "schema": { "version": 2, "compat": [1, 2] },
        "trace": {
            "trace_id": "trace_xyz789",
            "correlation_id": "case_eco_00077",
            "causation_id": "evt_previous_456"
        },
        "producer": { "module": "task-sync", "device_id": "...", "user_id": "..." },
        "sync": { "state": "QUEUED_UPLOAD", "retry_count": 0 },
        "sequence": { "stream": "device-uuid-123/tbl_suite", "position": 47 }
    },
    "data": { "tbl_suite": [{ "package_id": "...", "payload": { ... } }] },
    "metadata": { "checksum": "sha256:...", "schema_ref": "tbl_suite/v2" }
}
```

**3. Backward Compatibility:**
- v1 continua funcionando (leitor aceita ambos)
- v2 é opt-in via flag `useV2Envelope`
- Migration path em 4 fases (envelope -> trace -> payload -> semantics)

### Consequências

| Positivas | Negativas |
|-----------|-----------|
| Rastreabilidade completa (correlation, causation) | Consumer precisa suportar v1 e v2 durante transição |
| Schema evolution controlada | Custo de adicionar colunas trace em tabelas |
| Payload nativo (tipado, menor) | Mudança de mentalidade (state -> event) |
| Base para event sourcing futuro | — |
| Melhor observabilidade e debugging | — |

### Referências

- `docs/event-envelope-v2.md` — Documentação completa da proposta
- `plans/refatorar.md` — Proposta original de arquitetura event-driven
- `lib/sync/storage-sync.ts` — Implementação do sync
- `api-contract.md` §2 — Formato atual de Storage Messages

---

## Resumo das Decisões

| AD | Decisão | Motivação Principal |
|----|---------|---------------------|
| AD-001 | SQLite + Supabase dual | Offline-first + multi-device |
| AD-002 | Pure Storage Mode | Custo + portabilidade |
| AD-003 | Append-only tbl_suite | Histórico completo + audit |
| AD-004 | SHA-256 hash cache | Detecção eficiente de mudanças |
| AD-005 | Tauri runtime | Performance + binário pequeno |
| AD-006 | Coexistência arquiteturas | Evolução incremental sem risco |
| AD-007 | JSON puro para sync | Compatibilidade universal |
| AD-008 | Event Envelope v2 | Rastreabilidade + schema evolution |
