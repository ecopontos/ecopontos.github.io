# Segurança — EcoForms Desktop

Este documento descreve as medidas de segurança do sistema EcoForms Desktop, incluindo autenticação, autorização, criptografia, validação e proteção contra vulnerabilidades.

> **Fonte de verdade:** este documento reflete a implementação real em `src-tauri/src/`, `contexts/AuthContext.tsx`, `src/domain/access/`, `src/interface/hooks/utils/usePermissions.ts` e `src/infrastructure/sync/`.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `arquitetura.md` | Visão geral da arquitetura e stack |
| `api-contract.md` | Contrato de API e ports |
| `database.md` | Schema do SQLite — tabelas, índices, relacionamentos |

---

## Índice

1. [Autenticação](#1-autenticação)
2. [Autorização (RBAC)](#2-autorização-rbac)
3. [Criptografia](#3-criptografia)
4. [Validação de Inputs](#4-validação-de-inputs)
5. [Proteção contra Vulnerabilidades](#5-proteção-contra-vulnerabilidades)
6. [Gerenciamento de Secrets](#6-gerenciamento-de-secrets)
7. [Segurança do Sync](#7-segurança-do-sync)
8. [Políticas de Acesso](#8-políticas-de-acesso)

---

## 1. Autenticação

> **Modelo real**: autenticação **local primária** com Supabase Auth **paralela** (Fase 1/C1 implementada). Após login local bem-sucedido, `syncSupabaseAuth()` autentica em background no Supabase via `signInWithPassword`/`signUp`. Falha no Supabase Auth é **non-fatal** — login local continua funcional mesmo offline.

### 1.1 Fluxo de Autenticação

```
┌─────────────┐     ┌─────────────────────┐     ┌────────────────────────┐
│   Usuário   │────▶│  app/login/page.tsx │────▶│ invoke('db_query')     │
│             │     │  username + password│     │ SELECT FROM tbl_usuarios│
└─────────────┘     └─────────────────────┘     └──────────┬─────────────┘
                                                            │
                                                            ▼
                                                 ┌────────────────────────┐
                                                 │ invoke('verify_password')│
                                                 │ bcrypt (Rust backend)  │
                                                 └──────────┬─────────────┘
                                                            │ válido
                                                            ▼
                                                  ┌────────────────────────┐
                                                  │ AuthContext.login()    │
                                                  │ localStorage (user JSON)│
                                                  │ + syncSupabaseAuth()   │
                                                  │   [background,         │
                                                  │    signIn/signUp,      │
                                                  │    non-fatal]          │
                                                  └────────────────────────┘
```

**O que acontece em paralelo**: após login local, `supabase.auth.signInWithPassword({ email, password })` é chamado. Se o usuário não existir no Supabase Auth, auto-provisiona via `signUp()`. Email sintético: `{username}@ecoforms.local`. A falha do Supabase Auth **não bloqueia** o login — o sistema continua funcional com auth local.

### 1.2 Primeiro Acesso (First-Run Setup)

Em uma **instalação limpa** (banco SQLite vazio), o app detecta automaticamente que `tbl_usuarios` está vazia e exibe o modal `FirstRunSetupModal` na tela de login:

```
App inicia
  → initDatabase() → db_connect() → ensureColumns()
  → LoginPage monta
    → useEffect: SELECT COUNT(*) FROM tbl_usuarios
      → count = 0?
        → renderiza FirstRunSetupModal (sobreposta ao login)
          → usuário preenche: nome, username, senha (apenas números, min 4)
          → invoke('create_first_admin', { nome, username, password })
            → Rust valida inputs
            → verifica proteção: tbl_usuarios deve estar vazia
            → bcrypt hash (cost 10)
            → INSERT admin / perfil='admin' / ativo=1
            → seed tbl_perfis + tbl_role_hierarchy + tbl_permissions
            → log audit: system.bootstrap
          → modal fecha → toast "Administrador criado. Faça login."
```

**Proteções:**
- `create_first_admin` falha se `tbl_usuarios` não estiver vazia (proteção contra re-execução)
- Senha validada no frontend e backend: apenas dígitos, mínimo 4 caracteres
- Sem backdoor hardcoded — o admin é criado pelo usuário real na primeira execução

> Legado: scripts manuais (`seed-local-admin.js`, `create-admin.js`, `migrations/008_seed_admin.sql`) ainda existem para casos de recuperação de emergência, mas não são necessários para instalações normais.

### 1.3 Persistência de Sessão

| Local | Dado | Duração |
|-------|------|---------|
| `localStorage` | Objeto `User` serializado (JSON), chave `ecoforms_user` | Até logout ou expiração |
| Memória (`AuthContext`) | `user` state React | Runtime only |
| Memória Rust (`SessionState`) | `user_id` + `perfil` | Runtime only (validado no banco) |

Timeout de inatividade: **30 minutos** (`SESSION_TIMEOUT_MS = 30 * 60 * 1000`). Rastreado via `mousedown` e `keydown` no `window`.

**Sessão no Rust:** `AuthContext` chama `invoke('set_session', { userId, perfil })` no login e `invoke('clear_session')` no logout. O `SessionState` armazena `user_id` + `perfil` em memória e re-valida contra `tbl_usuarios` (`ativo = 1`) a cada comando protegido.

### 1.4 Re-validação Periódica

A cada mount do `AuthContext` e quando `user` muda, o sistema consulta `SELECT ativo FROM tbl_usuarios WHERE id = ? LIMIT 1`. Se `ativo != 1`, o logout é forçado automaticamente.

### 1.5 Logout e Cleanup

```
LOGOUT TRIGGERED
      │
      ├── 1. localStorage.removeItem('ecoforms_user')
      ├── 2. setUser(null) — limpa AuthContext
      └── 3. router.push('/login')

NOTA: SQLite NÃO é deletado no logout.
      Dados permanecem para próximo login.
```

### 1.6 Commands de Sessão (Rust)

| Command | Entrada | Saída | Descrição |
|---------|---------|-------|-----------|
| `set_session` | `user_id`, `perfil` | `Result<(), String>` | Valida no banco e armazena sessão |
| `clear_session` | — | `Result<(), String>` | Limpa sessão |
| `get_session` | — | `Option<SessionInfo>` | Retorna sessão atual |

### 1.7 Roadmap de Autenticação

| Recurso | Status |
|---------|--------|
| Auth local (SQLite + bcrypt Rust) | ✅ Implementado |
| Sessão no Rust (`SessionState`) | ✅ Implementado |
| Supabase Auth session no login | ✅ Implementado (Fase 1/C1) |
| OAuth (Google/Gov.br) | 🔄 Planejado |
| MFA (TOTP) | 🔄 Planejado |

---

## 2. Autorização (RBAC)

### 2.1 Modelo RBAC

O sistema usa **Role-Based Access Control** com 6 perfis hierárquicos:

```
┌─────────────────────────────────────────────────────────────┐
│                        PERFIS                               │
├─────────────────────────────────────────────────────────────┤
│  admin       │ Nível 0 │ Acesso total                       │
│  gerente     │ Nível 1 │ Gestão de usuários, relatórios     │
│  coordenador │ Nível 2 │ Coordenação de equipe              │
│  encarregado │ Nível 3 │ Supervisão de campo                │
│  operador    │ Nível 4 │ Execução de tarefas, formulários   │
│  campo       │ Nível 4 │ Execução de tarefas, formulários   │
└─────────────────────────────────────────────────────────────┘
```

**Hierarquia** (fonte: `src/domain/access/AccessPolicy.ts`):
- `roleLevel('admin') = 0` → pode acessar dados de todos os níveis
- `roleLevel('gerente') = 1` → pode acessar dados de gerente, coordenador, encarregado, operador, campo
- `roleLevel('operador') = roleLevel('campo') = 4` → apenas dados do próprio nível

Funções utilitárias:
- `isAdmin(perfil)` — verifica se é admin
- `isManagerOrAbove(perfil)` — verifica se é admin ou gerente
- `getAccessiblePerfis(userPerfil)` — lista perfis que o usuário pode visualizar
- `getSubordinatePerfis(userPerfil)` — lista perfis subordinados
- `canAccessUserData(currentPerfil, targetPerfil)` — verifica se pode acessar dados de outro perfil

### 2.2 Tabelas de RBAC (Dinâmicas)

As tabelas de controle de acesso são criadas no boot (Rust + `ensure-columns.ts`) e seedeadas automaticamente se vazias:

| Tabela | Descrição |
|--------|-----------|
| `tbl_perfis` | Perfis master (admin, gerente, coordenador, encarregado, operador, campo) |
| `tbl_role_hierarchy` | Níveis numéricos (admin=0, gerente=1, ..., operador/campo=4) |
| `tbl_permissions` | Matriz de permissões (~35 entradas) seedeada no boot |

**Fontes de verdade:**
- Rust: `src-tauri/src/database.rs` (CREATE TABLE + seeding)
- Web/PWA: `scripts/ensure-columns.ts` (CREATE TABLE IF NOT EXISTS + seeding)

### 2.3 Mapa de Permissões

O mapa real de permissões está em `src/interface/hooks/utils/usePermissions.ts` (`PERMISSIONS_MAP`) e é espelhado em `tbl_permissions`:

| Permissão | Perfis Permitidos |
|-----------|-------------------|
| `users.create` | admin, gerente |
| `users.edit` | admin, gerente |
| `users.delete` | admin |
| `users.view_all` | admin, gerente |
| `users.change_password` | todos |
| `forms.create` | admin, gerente |
| `forms.edit` | admin, gerente |
| `forms.delete` | admin |
| `forms.assign` | admin, gerente |
| `forms.fill` | todos |
| `data.view_all` | admin, gerente |
| `data.view_own` | todos |
| `data.edit_all` | admin |
| `data.edit_own` | todos |
| `data.delete` | admin |
| `data.export` | admin, gerente |
| `data.archive` | admin, gerente |
| `system.config` | admin |
| `system.logs` | admin, gerente |
| `system.sync` | todos |
| `system.device_setup` | admin, gerente |
| `reports.view` | admin, gerente |
| `reports.export` | admin, gerente |
| `activities.manage` | admin, gerente |
| `clients.view` | admin, gerente, coordenador |
| `clients.create` | admin, gerente |
| `clients.edit` | admin, gerente |
| `clients.delete` | admin |
| `clients.export` | admin, gerente |
| `tasks.reassign` | admin, gerente, encarregado |
| `crm.view` | admin, gerente, coordenador, encarregado |
| `crm.edit` | admin, gerente, coordenador |
| `ouvidoria.view` | admin, gerente, coordenador, encarregado |
| `ouvidoria.create` | admin, gerente, coordenador, encarregado |
| `ouvidoria.respond` | admin, gerente, coordenador |
| `ouvidoria.close` | admin, gerente |

### 2.4 Commands Dedicados (Protegidos)

Mutações sensíveis não usam mais `db_execute` genérico. Cada operação crítica tem um command Rust dedicado que valida sessão + permissão:

| Command | Permissão Requerida | Audit |
|---------|---------------------|-------|
| `suite_approve` | `data.edit_all` | `tbl_audit_log` + `audit.registro` |
| `suite_reject` | `data.edit_all` | `tbl_audit_log` + `audit.registro` |
| `demanda_aceitar` | `activities.manage` | `tbl_audit_log` + `audit.registro` |
| `demanda_encerrar` | `activities.manage` | `tbl_audit_log` + `audit.registro` |
| `ecoponto_agendar_remocao` | `activities.manage` | `tbl_audit_log` + `audit.registro` |

### 2.5 Sanitização de Commands Genéricos

Para impedir bypass dos commands dedicados, `db_query`/`db_execute`/`db_execute_batch` receberam sanitização adicional:

- **`db_query`**: bloqueia `SELECT` com `password_hash`
- **`db_execute`**: bloqueia `INSERT/UPDATE/DELETE` em `tbl_usuarios`, `tbl_perfis`, `tbl_role_hierarchy`, `tbl_permissions` para não-admin
- **`db_execute`**: bloqueia `UPDATE tbl_usuarios SET perfil = ...` (elevação de privilégio)

### 2.6 Componentes de Guarda de Permissão

Os componentes React em `components/auth/PermissionGuards.tsx` implementam o controle de acesso na UI. Todos consomem `usePermissions` via `AuthContext` — nunca fazem checks inline de `user.perfil`:

| Componente | Propósito |
|------------|-----------|
| `RequirePermission` | Renderiza children apenas se o usuário tiver a permissão |
| `ProtectedPage` | HOC que protege páginas inteiras (redireciona se sem permissão) |
| `ShowForRole` | Mostra conteúdo apenas para perfis específicos |
| `ShowForAdmin` | Atalho para `roles=["admin"]` |
| `ShowForManager` / `ShowForAdminOrManager` | Atalho para `roles=["admin","gerente"]` |
| `HideForRole` | Oculta conteúdo para perfis específicos |
| `ShowForPermission` | Mostra conteúdo se tiver permissão específica |
| `HideForPermission` | Oculta conteúdo se tiver permissão específica |
| `RequireAnyPermission` | Renderiza se tiver **pelo menos uma** das permissões (OR) |
| `RequireAllPermissions` | Renderiza apenas se tiver **todas** as permissões (AND) |

**Regra:** checks inline como `user.perfil === 'admin'` estão proibidos em novos componentes. Sempre usar `usePermissions()` ou os guards acima.

### 2.7 Propriedade de Dados e Edição por Tempo

Regras de edição de registros (`usePermissions.ts:canEditData`):

| Perfil | Prazo de Edição | Escopo |
|--------|----------------|--------|
| admin | Sem limite | Todos os registros |
| gerente | 72h após criação | Todos os registros |
| coordenador | 48h após criação | Apenas próprios registros |
| operador / campo | 24h após criação | Apenas próprios registros |

Regras de edição de usuários (`usePermissions.ts:canEditUser`):
- Admin pode editar todos
- Gerente pode editar coordenador, campo, operador e encarregado
- Usuário pode editar apenas a si mesmo

---

## 3. Auditoria

### 3.1 `tbl_audit_log` (Segurança)

Tabela de auditoria de segurança, populada pelos **commands dedicados** no Rust:

| Coluna | Descrição |
|--------|-----------|
| `id` | UUID do registro de audit |
| `actor_id` | ID do usuário que executou a ação |
| `actor_perfil` | Perfil do usuário no momento da ação |
| `action` | Nome da ação (ex: `suite.approve`, `demanda.aceitar`) |
| `target_table` | Tabela afetada |
| `target_id` | ID do registro afetado |
| `old_value` | Valor anterior (JSON) |
| `new_value` | Valor novo (JSON) |
| `metadata` | Dados adicionais |
| `created_at` | Timestamp ISO-8601 |
| `synced` | 0 = pendente, 1 = enviado para nuvem |

### 3.2 Evento `audit.registro`

Cada inserção em `tbl_audit_log` gera um evento `audit.registro` na `sync_event_queue`. O `TransportService.pushPending()` envia automaticamente para:

```
eventos/{routingId}/evt_{seq}_{id}.enc
```

Criptografado com AES-256-GCM. O consumo no servidor é responsabilidade de um processo futuro.

### 3.3 `action_log` (Workflow)

A tabela `action_log` continua existindo como **log operacional** do ActionRegistry (quem clicou em qual botão, sucesso/erro). É separada de `tbl_audit_log` (imutável, segurança/compliance).

---

## 4. Criptografia

### 3.1 Dados em Trânsito

| Canal | Mecanismo |
|-------|-----------|
| App ↔ Supabase Storage | TLS 1.3 (HTTPS) |
| Tauri ↔ Frontend | IPC seguro (mesmo processo) |

### 3.2 Dados em Repouso

| Local | Mecanismo | Observação |
|-------|-----------|------------|
| SQLite local | **Sem criptografia de arquivo** | `rusqlite` padrão. Proteção depende do OS/filesystem (ACL do usuário) |
| `localStorage` | Same-origin | Dados de sessão (user JSON) |
| Supabase Storage | AES-256 (server-side, AWS S3) | Encriptação at-rest gerenciada pela AWS |

> **IMPORTANTE**: Não há SQLCipher nem criptografia do arquivo SQLite. A proteção do banco local depende das permissões do sistema operacional (`chmod 600` equivalente no diretório do app).

### 3.3 Criptografia de Sync (Eventos)

Os envelopes de sync são criptografados via AES-256-GCM. A chave é derivada do password do usuário via PBKDF2 a cada login:

**Derivação de chave (PBKDF2):**
```
Password → crypto.subtle.deriveBits(PBKKDF2, 100k iters, SHA-256, salt='ecoforms-sync-salt-v1')
  → 32 bytes → Rust load_crypto_key()
```

**Fluxo de encriptação:**
```
EventEnvelope (JSON)
  → PBKDF2deriveKey(password) → CryptoLayer (JS ou TS)
  → crypto.subtle.encrypt(AES-GCM) → nonce + ciphertext → Uint8Array (.enc)
  → SupabaseFileStorage.upload('eventos/{routingId}/evt_{seq}_{id}.enc')
```

A chave **nunca é persistida** — é re-derivada a cada login e limpa no logout.

Comandos Rust disponíveis:
- `load_crypto_key(key_bytes: Vec<u8>)` — carrega chave derivada no state Rust
- `encrypt_payload(data: String) -> Vec<u8>` — encripta com AES-256-GCM
- `decrypt_payload(blob: Vec<u8>) -> String` — decripta com AES-256-GCM

**Mobile (www/):** Usa `www/js/sync/CryptoLayer.js` com implementação idêntica via Web Crypto API.

**Desktop (desktop/):** Usa `desktop/src/infrastructure/sync/CryptoLayer.ts` com `deriveAndStoreKey(password)` chamado em `AuthContext.tsx` após login.

```
ENVELOPE SECURITY
─────────────────
1. AES-256-GCM (encriptação + autenticidade)
   └─ Chave no processo Rust, não exposta ao JS

2. SEQUÊNCIA (seq)
   └─ Detecta gaps e replay no InboundService

3. TLS 1.3 EM TRÂNSITO
   └─ Protege o canal HTTP

4. AES-256 AT-REST
   └─ Supabase Storage (AWS S3 server-side encryption)
```

---

## 5. Validação de Inputs

### 4.1 Validação em Camadas

```
┌─────────────────────────────────────────────────────────────┐
│                    INPUT VALIDATION LAYERS                    │
├─────────────────────────────────────────────────────────────┤
│  Layer 1: UI (React + HTML5 validation)                     │
│  ├── Immediate feedback                                     │
│  ├── Client-side only                                       │
│  └── Prevents obvious errors                                │
│                                                              │
│  Layer 2: Use Case / Repository                             │
│  ├── Validação manual nos use cases                         │
│  └── Regras de negócio (ex: canEditData, canEditUser)       │
│                                                              │
│  Layer 3: Database (Constraints)                            │
│  ├── NOT NULL, CHECK, FOREIGN KEY                           │
│  ├── Final line of defense                                  │
│  └── SQLite enforces constraints                            │
└─────────────────────────────────────────────────────────────┘
```

> **Nota**: Não há Zod schemas no domínio. A validação é feita nos formulários React (HTML5 + lógica de componentes) e nas regras de negócio dos use cases.

### 4.2 Sanitização de SQL

Todas as queries usam **parameterized queries**:

```ts
// ✅ SEMPRE use parameterized queries
await db.execute(
    'SELECT * FROM tbl_usuarios WHERE username = ?',
    [username]
);
```

No backend Rust (`database.rs`), há uma camada adicional de defesa (`validate_sql`):
- Rejeita comentários SQL (`--`, `/*`, `*/`)
- Rejeita múltiplas statements (semicolon seguido de conteúdo)
- Rejeita comandos perigosos: `ATTACH`, `DETACH`, `PRAGMA`, `VACUUM`, `REINDEX`

### 4.3 Validação de File Uploads

Uploads de arquivo são validados em `components/FileUpload.tsx` (quando presente):
- MIME type whitelist
- Tamanho máximo configurável
- Extensão deve corresponder ao MIME type

---

## 6. Proteção contra Vulnerabilidades

### 5.1 XSS (Cross-Site Scripting)

| Vetor | Mitigação |
|-------|-----------|
| User input em DOM | React escapa JSX automaticamente |
| `dangerouslySetInnerHTML` | Evitado; quando necessário, sanitizado com DOMPurify |
| URL parameters | Validados via Next.js routing |

### 5.2 CSRF (Cross-Site Request Forgery)

Como é um app desktop (Tauri), CSRF é mitigado naturalmente:
- Não há navegador web tradicional
- Requests são feitos via Tauri IPC, não via browser
- Origem é controlada (`tauri://localhost`)

### 5.3 SQL Injection

| Tipo | Mitigação |
|------|-----------|
| SQL Injection | Parameterized queries ONLY + validação Rust |
| NoSQL Injection | N/A (não usa MongoDB) |
| Command Injection | Não executa shell commands com user input |
| Path Traversal | Paths fixos no TransportService (`eventos/{routingId}/...`) |

### 5.4 Insecure Deserialization

| Vetor | Mitigação |
|-------|-----------|
| JSON.parse() de storage | `JSON.parse()` seguido de validação de tipo manual |
| Snapshot ingestion | Checksum SHA-256 + verificação de schema version |
| URL parameters | Parse + validate, nunca `eval()` |

---

## 7. Gerenciamento de Secrets

### 6.1 Tipos de Secrets

| Secret | Uso | Armazenamento |
|--------|-----|---------------|
| Supabase URL | API endpoint | Environment variable (build time) — `.env.local` |
| Supabase Anon Key | Acesso ao Storage | Environment variable (build time) — `.env.local` |
| AES Sync Key | Criptografia de eventos | Gerada no State Rust (`CryptoState`), nunca exposta ao JS |
| bcrypt hashes | Senhas de usuários | Coluna `password_hash` em `tbl_usuarios` (SQLite) |

### 6.2 Environment Variables

```env
# .env.local (nunca commitado!)
NEXT_PUBLIC_SUPABASE_URL=https://xyz.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbG...
```

> `.env.local` está no `.gitignore`. Não há `SUPABASE_SERVICE_KEY` nem secrets de OAuth no código frontend.

### 6.3 Rotação de Secrets

| Secret | Frequência | Processo |
|--------|-----------|----------|
| bcrypt hashes | On password change | Re-hash via `hash_password` (Rust) |
| AES sync key | On reinstalação | Gerada automaticamente no primeiro boot |
| API keys | Manual (quando vazado) | Regenerate no Supabase dashboard |

---

## 8. Segurança do Sync

### 7.1 Criptografia de Eventos

Ver seção [3.3 Criptografia de Sync](#33-criptografia-de-sync-eventos).

### 7.2 org_config.json — Sem Criptografia (Intencional)

O `shared/org_config.json` é legível por qualquer dispositivo com a `anon key`. Contém apenas IDs e nomes dos setores — sem dados sensíveis. É a base para o roteamento de eventos entre setores.

### 7.3 Prevenção de Replay e Tampering

| Ataque | Mitigação |
|--------|-----------|
| Replay de evento | Campo `seq` sequencial — gap detectado no `InboundService` |
| Tampering de envelope | AES-256-GCM autentica o ciphertext (GCM tag) |
| Upload não autorizado | Apenas dispositivos com a `anon key` correta |
| Path traversal | Paths fixos no `TransportService` (`eventos/{routingId}/...`) |

### 7.4 Manifesto de Eventos

O `Manifest` (`src/infrastructure/sync/Manifest.ts`) rastreia a última sequência por `routing_id`, garantindo que:
- Nenhum evento é processado duas vezes
- Gaps na sequência são detectados
- Apenas eventos novos são baixados

---

## 9. Políticas de Acesso

### 8.1 Supabase Storage Policies (RLS)

> **Modelo atual (v2)**: o desktop cria sessão Supabase Auth (Fase 1), portanto `auth.uid()` é válido após login. Políticas usam **dual-auth**: role `authenticated` para paths org-scoped do desktop + role `anon` para paths restritos do mobile. Migração completa definida em `desktop/supabase/migrations/01-storage-rls-v2.sql` (8 policies — 4 authenticated + 4 anon path-restricted).

**Resumo das políticas v2:**

| Policy | Role | Paths |
|--------|------|-------|
| `auth_read_desktop` | authenticated | `orgs/%/eventos/%`, `orgs/%/manifests/%`, `shared/org_config.json`, `eventos/%`, `shared/manifests/%` |
| `auth_insert_desktop` | authenticated | Idem |
| `auth_update_desktop` | authenticated | Idem |
| `auth_delete_desktop` | authenticated | Idem |
| `anon_read_mobile` | anon | `shared/users.json`, `shared/form_%`, `shared/data_%`, `shared/tasks.json`, `shared/ecoponto_%`, `shared/inbox/%`, `shared/adhoc/%`, `users/%`, `archive/%`, `forms/%`, `data/%` |
| `anon_insert_mobile` | anon | `shared/inbox/%`, `users/%/images/%`, `archive/%` |
| `anon_update_mobile` | anon | `shared/inbox/%`, `users/%/images/%`, `archive/%` |
| `anon_delete_mobile` | anon | `shared/inbox/%`, `users/%/images/%`, `archive/%` |

**Nível de isolamento**: paths org-scoped (`orgs/{orgId}/...`) garantem que dispositivos de organizações diferentes não acessem dados alheios. Mobile mantém acesso anon para compatibilidade com PWA (sem Supabase Auth).

### 8.2 SQLite Access Control

| Nível | Acesso | Mecanismo |
|-------|--------|-----------|
| Processo | Total | App tem acesso total ao arquivo |
| User | Restrito | Proteção do OS (file permissions no diretório do app) |
| OS | Restrito | ACL do usuário logado |

### 8.3 Account Deletion

Não há fluxo automatizado de deleção de conta. Usuários são desativados (`ativo = 0`) em `tbl_usuarios`. Dados permanecem no SQLite local e no Storage para fins de auditoria.

---

## Resumo de Medidas de Segurança

| Camada | Medida | Status |
|--------|--------|--------|
| **Autenticação** | Local (SQLite + bcrypt Rust) + Supabase Auth paralela (Fase 1/C1) | ✅ |
| **Autorização** | RBAC com 6 perfis e ~25 permissões | ✅ |
| **Dados em trânsito** | TLS 1.3 (Supabase) + AES-256-GCM (sync events) | ✅ |
| **Dados em repouso (SQLite)** | Proteção do OS/filesystem (sem SQLCipher) | ⚠️ |
| **Input validation** | Parameterized queries + validação Rust + regras de negócio | ✅ |
| **SQL injection** | Parameterized queries + `validate_sql` (Rust) | ✅ |
| **XSS** | React escape + sanitização quando necessário | ✅ |
| **CSRF** | N/A (desktop app via Tauri IPC) | ✅ |
| **Path traversal** | Paths fixos no TransportService com `orgs/{orgId}/` | ✅ |
| **Storage RLS** | Políticas v2: authenticated (desktop) + anon path-restricted (mobile) — 8 policies | ✅ |
| **Sync encryption** | AES-256-GCM via Rust (chave nunca exposta ao JS) | ✅ |

---

## Checklist de Segurança (Pre-Release)

- [ ] Nenhuma senha em código-fonte
- [ ] `.env.local` no `.gitignore`
- [ ] HTTPS obrigatório para Supabase
- [ ] Logs de acesso não vazam dados sensíveis
- [ ] Dependency audit (`npm audit`)
- [ ] bcrypt cost adequado (atualmente 10)
- [ ] Chave AES nunca exposta ao frontend JS
