# Hooks - EcoForms Desktop

Este documento cataloga todos os hooks personalizados do projeto EcoForms Desktop, organizados por categoria funcional.

> **Nota de Migração (2026-04-27):** Todos os hooks foram migrados de `hooks/` para `src/interface/hooks/` como parte da Fase 6.2 da migração Clean Architecture. A pasta `hooks/` está vazia — não há mais hooks legados. A pasta `lib/` também foi migrada para `src/` (utilitários em `src/lib/`, sync em `src/infrastructure/sync/`, persistência em `src/infrastructure/persistence/`).

---

## Índice

1. [Infraestrutura / Base](#1-infraestrutura--base)
2. [Clean Architecture Interface](#2-clean-architecture-interface)
3. [Kanban & Tarefas](#3-kanban--tarefas)
4. [Projetos](#4-projetos)
5. [Clientes & CRM](#5-clientes--crm)
6. [Formulários](#6-formulários)
7. [Solicitações & Suite](#7-solicitações--suite)
8. [Ouvidoria](#8-ouvidoria)
9. [Sistema & Configurações](#9-sistema--configurações)
10. [RBAC & Permissões](#10-rbac--permissões)
11. [Dados & Sincronização](#11-dados--sincronização)
12. [UI & Experiência](#12-ui--experiência)

---

## 1. Infraestrutura / Base

### `useTauriQuery`
**Arquivo:** `src/interface/hooks/useTauriQuery.ts`

Executa queries SELECT via Tauri (`invoke('db_query')`). Usa React Query internamente.

```ts
const { data, isPending, refetch } = useTauriQuery<T>(
  sql: string,
  params: any[] = [],
  options?: UseQueryOptions
)
```

**Peculiaridade:** O backend Tauri retorna `{ columns: string[], rows: any[][] }` — o hook faz o mapping para objetos antes de retornar.

---

### `useTauriMutation`
**Arquivo:** `src/interface/hooks/useTauriMutation.ts`

Executa comandos SQL (INSERT, UPDATE, DELETE) via Tauri (`invoke('db_execute')`). Invalida o cache do React Query no `onSuccess`.

```ts
const mutation = useTauriMutation()
await mutation.mutateAsync({ sql: 'UPDATE ...', params: [...] })
// Retorna número de rows affected
```

**Também expõe:**
- `useLastInsertId()` — retorna o último ID inserido
- `useTauriBatch(sqls: string[])` — executa múltiplos SQLs em transação

---

### `useSQLiteQuery`
**Arquivo:** `src/interface/hooks/useSQLiteQuery.ts`

Wrapper reativo em torno do `useSqlite` (interface SQLite do frontend). Suporta:
- `enabled` flag
- `dependencies` array para re-execução controlada
- Refetch trigger manual

```ts
const { data, loading, error, refetch } = useSQLiteQuery<T>(
  sql: string,
  params: SQLiteParam[] = [],
  options?: { enabled?: boolean; dependencies?: unknown[] }
)
```

---

### `useSQLiteMutation`
**Arquivo:** `src/interface/hooks/useSQLiteMutation.ts`

Executa comandos de escrita via `useSqlite.execute()`, sem invalidação automática (diferente de `useTauriMutation`).

```ts
const { mutateAsync, loading, error } = useSQLiteMutation()
await mutateAsync(sql: string, params: any[])
```

---

### `useSQLiteSchema`
**Arquivo:** `src/interface/hooks/useSQLiteSchema.ts`

Auxiliar de introspecção de schema. Expõe `useSQLiteColumnExists(table, column)` que retorna `hasColumn: boolean`.

```ts
const { hasColumn, loading } = useSQLiteColumnExists('tblPJtipo', 'idPJtipo')
```

**Uso principal:** detectar schemas legados (sem colunas canônicas) para adaptar SQLs dinamicamente.

---

## 2. Clean Architecture Interface

### `useTaskUseCases`
**Arquivo:** `src/interface/hooks/useTaskUseCases.ts`

Ponto de entrada para o módulo Task na Clean Architecture. Expõe: `create`, `move`, `assign`, `archive`, `delete`, `listByProject`.

```ts
const taskUC = useTaskUseCases()
await taskUC.create.execute({ titulo: '...', projetoId: '...' })
```

---

### `useSuiteUseCases`
**Arquivo:** `src/interface/hooks/useSuiteUseCases.ts`

Ponto de entrada para o módulo Suite. Expõe: `submit`, `edit`, `review`, `listInbox`.

---

### `useClientUseCases`
**Arquivo:** `src/interface/hooks/useClientUseCases.ts`

Ponto de entrada para o módulo Client. Expõe: `list`, `getById`, `listContacts`, `listTypes`, `create`, `update`, `delete`, `nameExists`, `auditLog`.

---

### `useUserUseCases`
**Arquivo:** `src/interface/hooks/useUserUseCases.ts`

Ponto de entrada para o módulo User. Expõe: `list`, `create`, `update`, `toggleStatus`.

---

### `useDataRegistryUseCases`
**Arquivo:** `src/interface/hooks/useDataRegistryUseCases.ts`

Ponto de entrada para o módulo DataRegistry. Expõe: `listItems`, `listByType`, `listTypes`, `create`, `save`, `delete`, `aggregate`, `countByType`, `bulkInsert`.

---

### `useCRMUseCases`
**Arquivo:** `src/interface/hooks/useCRMUseCases.ts`

Ponto de entrada para o módulo CRM. Expõe: `listRoteiros`, `listRotasByClient`, `listColetasByRoteiro`, `createRota`, `updateRotaOrdem`, `deleteRota`.

---

### `useOuvidoriaUseCases`
**Arquivo:** `src/interface/hooks/useOuvidoriaUseCases.ts`

Ponto de entrada para o módulo Ouvidoria. Expõe: `listProtocolos`, `getProtocolo`, `listEventos`, `getAtendimento`, `createProtocolo`, `updateStatus`, `addEvento`, `upsertAtendimento`, `encerrarProtocolo`, `countAbertos`, `listAssuntos`, `listSubtemas`, `listMensagens`.

---

## 3. Kanban & Tarefas

### `useKanban`
**Arquivo:** `src/interface/hooks/useKanban.ts`

Hook orquestrador que combina `useKanbanViewState` + `useKanbanData` + `useKanbanMutations`. É o ponto de entrada principal para o módulo Kanban.

```ts
const {
  projects, tasks, loading,
  currentProjectId, setCurrentProjectId,
  showAllProjects, setShowAllProjects,
  viewMode, setViewMode,
  moveTask, createTask, updateTask, deleteTask, archiveTask, cancelTask,
  approveSolicitacao, rejectSolicitacao,
  createProject, updateProject,
  refetchTasks, refetchProjects
} = useKanban()
```

**Também exporta:** `useTaskOptions()` — busca listas de users, forms e projects para selects.

---

### `useKanbanData`
**Arquivo:** `src/interface/hooks/useKanbanData.ts`

Busca dados do Kanban via `useTauriQuery`. Executa 3 queries em paralelo:
- `projectsQuery` — projetos acessíveis ao usuário
- `taskQuery` — tarefas com filtros de acesso, projeto e status
- `solicitacoesQuery` — pacotes de solicitação pendentes (só para gerentes+)

**Tratamento de acesso:** Usa `accessFilter` que gera WHERE clauses baseadas em `perfil` e `interessados`.

**Peculiaridades:**
- Normaliza `arquivado`, `atrasado`, `tags`, `payload` ao consumir os dados
- `solicitacoes` são transformadas em `UnifiedTaskView` com prefixo `solik_`

---

### `useKanbanViewState`
**Arquivo:** `src/interface/hooks/useKanbanViewState.ts`

Estado local leve para controle de visualização do Kanban.

```ts
const { currentProjectId, setCurrentProjectId, showAllProjects, setShowAllProjects, viewMode, setViewMode } = useKanbanViewState()
// viewMode: 'kanban' | 'table'
```

---

### `useKanbanMutations`
**Arquivo:** `src/interface/hooks/useKanbanMutations.ts`

Hook de mutações completo para o Kanban. Recebe `tasks`, `solicitacoes`, `setTasks`, `currentProjectId` e referências de refetch.

**Funções expostas:**

| Função | Descrição |
|--------|-----------|
| `moveTask(id, newStatus, newOrder)` | Move tarefa entre colunas; valida runtime task; dispara eventlog + sync |
| `createTask(task)` | Cria tarefa com validações, snap_hash, interessados, eventos |
| `updateTask(id, updates)` | Atualiza campos, interessados, eventos; valida frozen state |
| `unfreezeTask(id)` | Consolida patches do Supabase storage antes de liberar edição |
| `patchTask(id, updates)` | Grava patch no Supabase storage (para operadores mobile) |
| `getTaskPatches(id)` | Lista patches pendentes de uma tarefa |
| `deleteTask(id)` | Soft-delete via taskUseCases |
| `archiveTask(id, archived)` | Arquiva ou restaura tarefa |
| `cancelTask(id, motivo)` | Move para status `cancelado` com registro de motivo |
| `approveSolicitacao(id, overrides?, updatedFormDados?)` | Converte pacote suite em tarefa |
| `rejectSolicitacao(id, motivo)` | Rejeita pacote suite |
| `createProject(name, desc?, color?, interessados?)` | Cria projeto |
| `updateProject(id, patch)` | Atualiza projeto |

**Características notables:**
- `validateRuntimeTask()` — impede tarefas atribuídas sem formulário vinculadas
- `buildSnapHash()` — FNV-1a hash para detecção de conflitos offline
- `scheduleTaskSync(delayMs)` — agenda sync com retry (3 tentativas)
- `insertTaskEvent()` — instrumenta todos os eventos em `tbl_tarefas_eventos`

---

### `useTaskMetrics`
**Arquivo:** `src/interface/hooks/useTaskMetrics.ts`

Métricas agregadas de tarefas: resumo geral, por usuário, por prioridade e tendências diárias.

```ts
const { summary, byUser, byPriority, dailyTrends, loading, error, refresh } = useTaskMetrics(daysBack = 30)
// summary: { total, completed, inProgress, pending, overdue, completedToday, completedThisWeek, completedThisMonth }
```

**SQLs usados:** `TASK_METRICS_SUMMARY_SQL`, `TASK_METRICS_BY_USER_SQL`, `TASK_METRICS_BY_PRIORITY_SQL`, `taskMetricsDailyTrendsSQL()`

---

### `useTaskComments`
**Arquivo:** `src/interface/hooks/useTaskComments.ts`

Adiciona comentários a uma tarefa em `tbl_tarefas_comentarios`.

```ts
const { addComment, loading } = useTaskComments()
await addComment(tarefaId: string, comentario: string)
```

---

### `useTaskHistory`
**Arquivo:** `src/interface/hooks/useTaskHistory.ts`

Linha do tempo unificada de eventos de uma tarefa via UNION de 4 fontes:
1. `tbl_tarefas_eventos` — eventos instrumentados
2. `tbl_tarefas_comentarios` — comentários retroativos
3. `tbl_tarefas_anexos` — anexos retroativos
4. `tbl_suite` — submissions de formulário

```ts
const { events, loading, error, refetch } = useTaskHistory(taskId: string, enabled = true)
// events: TaskHistoryEvent[]
```

---

## 4. Projetos

### `useProjects`
**Arquivo:** `src/interface/hooks/useProjects.ts`

Lista projetos acessíveis ao usuário com métricas de contagem.

```ts
const { projects, loading, refetch } = useProjects()
// projects: ProjectWithMetrics[] (com cnt_a_fazer, cnt_em_progresso, cnt_concluido, total_tarefas, cnt_baixa, cnt_media, cnt_alta)
```

**Também exporta:** `useProjectMutations()` com `createProject`, `updateProject`, `archiveProject`.

---

### `useProjectDetail`
**Arquivo:** `src/interface/hooks/useProjectDetail.ts`

Detalhe de um projeto específico com tarefas recentes e eventos.

```ts
const { project, loading, refetch } = useProjectDetail(projectId: string | null)
// project: ProjectDetailData (com tarefas[] e eventos[])
```

Executa 3 queries em paralelo: projeto, tarefas, eventos.

---

## 5. Clientes & CRM

### `useClients` (interface wrapper)
**Arquivo:** `src/interface/hooks/useClients.ts`

Wrapper reativo sobre `useClientUseCases`. Adapta os DTOs da Clean Architecture para o formato legado usado pelos componentes.

```ts
useClients(ativoOnly = true)         // → { data, loading, error, refetch }
useClientById(idPJ)                 // → { client, loading, error, refetch }
useClientContacts(idPJ)             // → { data, loading }
useClientTypes()                    // → { data, loading }
useCEP(cep)                         // → { cepData, loading, error }
useClientAuditLog(idPJ)             // → { data, loading }
useClientNameExists(name, excludeId?) // → { exists: boolean }
```

---

### `useClientMutations` (interface wrapper)
**Arquivo:** `src/interface/hooks/useClientMutations.ts`

Wrapper sobre `useClientUseCases` com validação de duplicidade e estado local.

```ts
const { createPJ, updatePJ, deletePJ, loading, error, validationError } = useClientMutations()
```

---

### `useClientSearch`
**Arquivo:** `src/interface/hooks/useClientSearch.ts`

Busca FTS5 (Full-Text Search) para clientes.

```ts
useClientSearch(searchTerm)  // → useSQLiteQuery<PessoaJuridica> (FTS5 PJ)
usePFSearch(searchTerm)       // → useSQLiteQuery<PessoaFisica> (FTS5 PF)
```

**Nota:** Termo é tokenizado (`term*`) e combinado com OR.

---

### `useClientExport`
**Arquivo:** `src/interface/hooks/useClientExport.ts`

Exportação de clientes para Excel e PDF.

```ts
const { exportExcel, exportPDF, loading, error } = useClientExport()
await exportExcel(data, filename?)
await exportPDF(data, { filename?, title?, filters? })
```

**Usa:** `src/infrastructure/export/`

---

### `useCRMQueries`
**Arquivo:** `src/interface/hooks/useCRMQueries.ts`

Queries para o módulo CRM (Roteiros, Rotas, Coletas, Detalhes Satelite).

**Queries:**

| Hook | Descrição |
|------|-----------|
| `useClientesComRoteiros()` | Clientes PJ agrupados com roteiros via view |
| `useClienteById(idPJ)` | Cliente específico com roteiros |
| `useRoteiros()` | Lista todos roteiros |
| `useColetasByRoteiro(idRoteiro)` | Histórico de coletas com detalhes satélite |
| `useTiposProblema()` | Tipos de problema para selects |

---

## 6. Formulários

### `useFormTemplate`
**Arquivo:** `src/interface/hooks/useFormTemplate.ts`

Busca template de formulário por slug.

```ts
const { template, loading } = useFormTemplate(slug: string | undefined)
// template: FormContent | null
```

**Tratamento:** lida com double stringification no banco.

---

### `useFormPermissions`
**Arquivo:** `src/interface/hooks/useFormPermissions.ts`

Wrapper de `usePermissions` que injeta contexto de tarefas ativas automaticamente.

```ts
const { hasPermission, canAccessForm, isAdmin, ... } = useFormPermissions()
```

**Nota:** A versão anterior usava `useAssignedActiveForms`; após a migração, o hook delega para `usePermissions` diretamente.

---

## 7. Solicitações & Suite

### `useSolicitacoesList`
**Arquivo:** `src/interface/hooks/useSolicitacoesList.ts`

Lista pacotes de solicitação do usuário logado.

```ts
const { solicitacoes, availableForms, loading, fetchSolicitacoes, fetchAvailableForms } = useSolicitacoesList(userId)
```

**Nota:** Usa `invoke('db_query')` direto, não `useTauriQuery`.

---

### `useSolicitacaoEditor`
**Arquivo:** `src/interface/hooks/useSolicitacaoEditor.ts`

Gerencia edição e re-submissão de pacotes (contrato v2). Regra: **nunca usa UPDATE em tbl_suite — sempre INSERT de nova versão**.

```ts
const {
  selectedPackage, setSelectedPackage,
  editingPayload, setEditingPayload,
  editingFormDefinition, isSaving,
  openEditor(pkg),       // → boolean
  saveResubmission(),   // → boolean
} = useSolicitacaoEditor(userId)
```

---

### `useInboxMutations`
**Arquivo:** `src/interface/hooks/useInboxMutations.ts`

Atualiza status de pacotes suite com versionamento (INSERT nova versão + histórico).

```ts
const { updateStatus, processing } = useInboxMutations()
await updateStatus(packageId, newStatus, { revisorId?, motivo?, notes?, payloadPatch? })
// Usa INSERT + is_current=0 para versioning
```

---

### `useSync`
**Arquivo:** `src/interface/hooks/useSync.ts`

Sincroniza dados locais SQLite → Supabase via `SyncService` e gerencia o estado da interface.

```ts
const { sync, syncing, error } = useSync()
```

---

### `useSubmissionData`
**Arquivo:** `src/interface/hooks/useSubmissionData.ts`

Normaliza dados de submissão de formulário (lida com múltiplos formatos e alias de campos).

```ts
const normalizedData = useSubmissionData(submissionDados, formFields)
// Lida com: { contexto:{...}, campos:{...}, arquivos:{...} }
// e aliases como 'rejeito' → 'vidros_2'
```

---

## 8. Ouvidoria

### `useOuvidoriaQueries`
**Arquivo:** `src/interface/hooks/useOuvidoriaQueries.ts`

Queries para o módulo Ouvidoria. Usa `useOuvidoriaUseCases` internamente.

**Queries:**

| Hook | Descrição |
|------|-----------|
| `useProtocolos(filtros?)` | Lista protocolos com filtros |
| `useProtocoloById(id)` | Detalhe de protocolo |
| `useProtocoloEventos(id)` | Eventos em ordem cronológica |
| `useAtendimentoByProtocolo(id)` | Atendimento do protocolo |
| `useAssuntos()` | Lista temas |
| `useSubtemas(idTema)` | Subtemas de um tema |
| `useMensagens()` | Templates de mensagem |
| `useProtocolosAbertosCount()` | Contagem para badge |

**Mutations (`useOuvidoriaMutations`):**

| Função | Descrição |
|--------|-----------|
| `createProtocolo(data)` | Abre novo protocolo |
| `updateProtocoloStatus(id, status)` | Atualiza status |
| `addEvento(id, evento)` | Adiciona evento/andamento |
| `upsertAtendimento(id, data)` | Cria ou atualiza atendimento |
| `encerrarProtocolo(id, motivo?)` | Encerra protocolo |

---

## 9. Sistema & Configurações

### `useSyncSettings`
**Arquivo:** `src/interface/hooks/useSyncSettings.ts`

Persiste preferências de sincronização em localStorage.

```ts
const { syncInterval, setSyncInterval, syncOnFocus, setSyncOnFocus, notifyOnSuccess, setNotifyOnSuccess, notifyOnError, setNotifyOnError, save } = useSyncSettings()
```

---

### `useDeviceConfig`
**Arquivo:** `src/interface/hooks/useDeviceConfig.ts`

Lê e persiste configuração do dispositivo (deviceId + deviceName) via `src/infrastructure/config/device-config`.

```ts
const { deviceConfig, deviceName, setDeviceName, isLoading, isSaving, save, regenerateId } = useDeviceConfig()
```

---

### `useOnlineStatus`
**Arquivo:** `src/interface/hooks/useOnlineStatus.ts`

Detecta status online/offline via `navigator.onLine`.

```ts
const isOnline: boolean = useOnlineStatus()
```

---

## 10. RBAC & Permissões

### `usePermissions`
**Arquivo:** `src/interface/hooks/utils/usePermissions.ts`

Sistema completo de permissões RBAC. É a **única fonte de verdade** para checks de permissão no frontend. Nunca use `user.perfil === 'admin'` diretamente.

```ts
const { hasPermission, canEditUser, canEditData, canCreateUserWithRole, canAccessForm, isAdmin, isManager, isOperator, userRole } = usePermissions(user, assignedActiveForms?)
```

**Perfis suportados:** `admin`, `gerente`, `coordenador`, `campo`, `operador`, `encarregado`

**Permissões catalogadas:** 36 permissões divididas em: users, forms, data, system, reports, activities, tasks, clients, crm, ouvidoria

**Lógica de edição de dados por tempo:**
- Admin: sempre
- Gerente: até 72h
- Coordenador: até 48h (próprios)
- Operador/Campo: até 24h (próprios)

**Refatoração v4.1:** todos os hooks de dados (`useKanbanData`, `useProjects`, `useKanbanMutations`) foram migrados de checks inline (`user.perfil === 'admin'`) para `permissions.isAdmin()` / `permissions.isManager()` / `permissions.hasPermission()` via `AuthContext`.

---

### PermissionGuards
**Arquivo:** `components/auth/PermissionGuards.tsx`

Componentes declarativos para controle de acesso na UI. Consomem `usePermissions` via `AuthContext`.

```tsx
<RequirePermission permission="users.create">
  <Button>Criar Usuário</Button>
</RequirePermission>

<RequireAnyPermission permissions={["data.edit_all", "data.edit_own"]}>
  <EditButton />
</RequireAnyPermission>

<ShowForPermission permission="activities.manage">
  <AdminPanel />
</ShowForPermission>

<ShowForManager>
  <GerencialWidget />
</ShowForManager>
```

| Guard | Lógica |
|-------|--------|
| `RequirePermission` | AND — uma permissão |
| `RequireAnyPermission` | OR — pelo menos uma |
| `RequireAllPermissions` | AND — todas |
| `ShowForPermission` | Renderiza se tiver permissão |
| `HideForPermission` | Oculta se tiver permissão |
| `ShowForRole` / `ShowForAdmin` / `ShowForManager` | Por perfil (legado — preferir por permissão) |
| `ProtectedPage` | Redireciona se sem permissão |

---

## 11. Dados & Sincronização

### `useDataRegistryUseCases`
**Arquivo:** `src/interface/hooks/useDataRegistryUseCases.ts`

Ponto de entrada Clean Architecture para DataRegistry. Expõe: `listItems`, `listByType`, `listTypes`, `create`, `save`, `delete`, `aggregate`, `countByType`, `bulkInsert`.

---

### `useNetworkParquet`
**Arquivo:** `src/interface/hooks/useNetworkParquet.ts`

Gerencia configuração de pasta de rede para arquivos Parquet.

```ts
const { path, setPath, probeResult, parquetFiles, isProbing, isSaving, isListing, probe, save, listFiles } = useNetworkParquet()
```

---

## 12. UI & Experiência

### `useVisibilityEvaluator`
**Arquivo:** `src/interface/hooks/useVisibilityEvaluator.ts`

Avalia regras de visibilidade de campos de formulário.

```ts
const { isFieldVisible, isFieldEnabled, resolveFieldType, visibleFields, evaluateRules } = useVisibilityEvaluator(formData)
```

**Operadores suportados:** `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `contains`, `startsWith`, `endsWith`, `in`, `notIn`, `empty`, `notEmpty`

**Suporta:** negação, lógica AND/OR entre regras, type variants condicionais.

---

### `useKeyboardShortcuts`
**Arquivo:** `src/interface/hooks/useKeyboardShortcuts.ts`

Gerencia atalhos de teclado globais.

```ts
useKeyboardShortcuts([
  { key: 's', ctrl: true, callback: () => save(), description: 'Salvar' },
  { key: 'Escape', callback: () => close(), description: 'Fechar' }
])
```

---

## Hooks de Administração

### `useAdminUsers`
**Arquivo:** `src/interface/hooks/queries/useAdminUsers.ts`

Gerencia usuários administrativos (CRUD completo com setores). Usa `useUserUseCases` internamente.

```ts
const { users, loading, loadUsers, toggleUserStatus, updateUser, createUser } = useAdminUsers()
```

---

### `useSupabaseAdmin`
**Arquivo:** `src/interface/hooks/queries/useSupabaseAdmin.ts`

Interface para sincronização e administração de usuários no Supabase. Combina acesso direto à tabela `public.profiles` via Supabase JS client com operações admin via `invoke('supabase_admin_query')` (Rust HTTP com `service_role` key).

```ts
const { syncing, syncFromSupabase, readUsers, createSupabaseUser, updateSupabaseUser, deleteSupabaseUser } = useSupabaseAdmin()

// Sincronizar public.profiles → SQLite local (ProfileSyncResult)
const result = await syncFromSupabase()
// result: { synced, created, updated, skipped, errors }

// Listar usuários do Supabase Auth (requer perfil admin)
const response = await readUsers()

// Provisionar novo usuário no Supabase Auth
await createSupabaseUser(email, password, { nome, perfil, org_id })

// Atualizar metadados de usuário Supabase
await updateSupabaseUser(supabaseId, { nome, perfil })

// Remover usuário do Supabase Auth
await deleteSupabaseUser(supabaseId)
```

**Fluxo `syncFromSupabase`:** busca `public.profiles` → instancia `SqliteUserRepository` + `SupabaseUserSyncService` via container DI → faz upsert local registrando mapeamentos em `supabase_user_map`.

**Segurança:** operações `create/update/delete` só têm efeito se o usuário autenticado tem `perfil = 'admin'` (validado no Rust, não apenas no frontend).

**Usado em:** `app/admin/users/page.tsx` — botão "Sincronizar Supabase".

---

### `useAllUsers`
**Arquivo:** `src/interface/hooks/queries/useAdminUsers.ts`

Busca todos os usuários do banco local. Exportado junto com `useAdminUsers`.

```ts
const { users, loading } = useAllUsers()
```

---

### `useUsersByForm`
**Arquivo:** `src/interface/hooks/useUsersByForm.ts`

Lista usuários com acesso a um formulário (via tarefa ativa ou perfil admin/gerente).

```ts
const { users, loading, refetch } = useUsersByForm(formId?)
// users: UserAccessInfo[] (com explicit_grant)
```

---

### `useWorkflowActions`
**Arquivo:** `src/interface/hooks/useWorkflowActions.ts`

Filtra ações disponíveis do ActionRegistry para um contexto específico, respeitando perfil do usuário e regras de visibilidade (`VisibilityRule`).

```ts
const actions = useWorkflowActions(
  targetType: 'task' | 'suite_package' | 'demand' | 'ecoponto',
  formData: Record<string, unknown>
)
// actions: ActionButtonConfig[]
```

**Usado em:** `EditTaskModal` para renderizar o `<ActionBar>` dinâmico.

---

### `useDashboardWidgets`
**Arquivo:** `src/interface/hooks/useDashboardWidgets.ts`

Filtra widgets disponíveis do WidgetRegistry para o perfil do usuário logado.

```ts
const widgets = useDashboardWidgets()
// widgets: WidgetConfig[]
```

**Usado em:** Página inicial (`page.tsx`) para montar o `<DynamicDashboard>`.

---

## Resumo Quantitativo

| Categoria | Quantidade |
|----------|------------|
| Infraestrutura / Base | 5 |
| Clean Architecture Interface | 7 |
| Kanban & Tarefas | 6 |
| Projetos | 2 |
| Clientes & CRM | 4 |
| Formulários | 2 |
| Solicitações & Suite | 4 |
| Ouvidoria | 1 (wrapper) |
| Sistema & Configurações | 3 |
| RBAC & Permissões | 1 |
| Dados & Sincronização | 2 |
| UI & Experiência | 2 |
| Administração | 4 |
| Action & Widget System | 2 |
| **Total** | **~45 hooks exportados** |

---

## Padrões Observados

1. **Dual query layer:** Muitos hooks existem em duas versões — `useSQLiteQuery` (via `useSqlite`) e `useTauriQuery` (via Tauri invoke direto). A versão Tauri é usada para queries mais complexas ou quando o frontend não tem acesso direto ao SQLite.

2. **Schema legacy detection:** Hooks que acessam `tblPJtipo`, `tblProtocolo` verificam a existência de colunas canônicas (`idPJtipo`, `idProtocolo`) vs `id_legacy` para adaptar SQLs dinamicamente.

3. **Versionamento de pacotes:** `tbl_suite` usa padrão append-only — nunca UPDATE, sempre INSERT nova versão com `is_current=0` para anterior.

4. **Instrumentação de eventos:** Mutações de Kanban instrumentam todas as operações em `tbl_tarefas_eventos` para auditoria.

5. **Snapshots:** Tarefas têm mecanismo de `snap_hash` (FNV-1a) e `snap_frozen_at` para detecção de conflitos offline e bloqueio de edição.

6. **Sync agenciado:** `scheduleTaskSync()` agenda sincronização com retry automático em caso de falha.

7. **Patch offline:** Sistema de patches via Supabase Storage para operadores mobile editarem dados desconectados.

8. **Clean Architecture Interface:** Hooks `*UseCases` são thin wrappers sobre o container DI (`getContainer()`), expondo use cases da camada de aplicação ao React.

---

## Migração Completada (2026-04-27)

| Fase | Módulo | Status |
|------|--------|--------|
| 0 | Deletar órfãos | ✅ Completo |
| 1 | DataRegistry | ✅ Completo |
| 2 | Ouvidoria | ✅ Completo |
| 3 | CRM | ✅ Completo |
| 4 | Clients | ✅ Completo |
| 5 | Users/Admin | ✅ Completo |
| 6 | Task/Kanban | ✅ Completo |
| 7 | Utilitários | ✅ Completo |

**Resultado:** Pasta `desktop/hooks/` vazia. Todos os hooks residem em `desktop/src/interface/hooks/`.
