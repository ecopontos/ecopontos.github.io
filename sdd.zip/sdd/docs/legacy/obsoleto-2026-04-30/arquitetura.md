# Arquitetura do Sistema — EcoForms Desktop

Este documento descreve a arquitetura geral do EcoForms Desktop em alto nível, serving as the entry point for understanding the system's design.

---

## Relação com Outros Documentos

| Documento | Descrição |
|-----------|-----------|
| `database.md` | Esquema completo do banco de dados (~22 tabelas, relacionamentos, índices) |
| `data-flow.md` | Fluxos de dados detalhados, do frontend ao storage |
| `data-system.md` | Tipos canônicos, portas de aplicação, serviços de sincronização |
| `modules.md` | Inventário de módulos Clean Architecture, repositories, use cases |
| `ui-flow.md` | Navegação, jornadas do usuário e fluxos de interface |
| `hooks.md` | Catálogo completo dos ~44 hooks React em `src/interface/hooks/` |
| `action-widget-system.md` | ActionRegistry + WidgetRegistry — ações configuráveis e widgets de dashboard |

---

## Índice

1. [Visão Geral da Arquitetura](#1-visão-geral-da-arquitetura)
2. [Stack Tecnológico](#2-stack-tecnológico)
3. [Arquitetura de Camadas](#3-arquitetura-de-camadas)
4. [Arquitetura Dual (Desktop + Mobile)](#4-arquitetura-dual-desktop--mobile)
5. [Módulos Principais](#5-módulos-principais)
6. [Sincronização de Dados](#6-sincronização-de-dados)
7. [Segurança e Controle de Acesso](#7-segurança-e-controle-de-acesso)
8. [Fluxo de Inicialização](#8-fluxo-de-inicialização)

---

## 1. Visão Geral da Arquitetura

O EcoForms é um sistema de gestão de formulários e tarefas com foco em operações de campo (coleta seletiva, roteirização, ouvidoria). A arquitetura combina:

- **Desktop**: Aplicação principal via Tauri (Rust + WebView)
- **Mobile**: Runtime web hibrido via Capacitor
- **Backend**: Supabase Storage para sincronização (sem backend fixo)

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                        │
│              Next.js 14 (App Router) + React               │
│              + 42 Hooks em src/interface/hooks/             │
├─────────────────────────────────────────────────────────────┤
│                    APPLICATION LAYER                        │
│          Use Cases (Clean Architecture) + Ports             │
├─────────────────────────────────────────────────────────────┤
│                      DOMAIN LAYER                           │
│            Entities + Repository Interfaces                 │
├─────────────────────────────────────────────────────────────┤
│                   INFRASTRUCTURE LAYER                      │
│      SQLite (Tauri) │ Supabase Storage │ File Storage      │
└─────────────────────────────────────────────────────────────┘
```

**Nota**: A migração Clean Architecture foi completada em 2026-04-27. Todos os hooks legados de `hooks/` foram migrados para `src/interface/hooks/`.

Consulte `modules.md` §1 e `data-system.md` §1 para detalhes completos.

---

## 2. Stack Tecnológico

| Camada | Tecnologia |
|--------|------------|
| **Frontend Web** | Next.js 14 (App Router), React 18, TypeScript |
| **Desktop Runtime** | Tauri 2.x (Rust backend + WebView) |
| **Mobile Runtime** | Capacitor (web app hibrido) |
| **DB Local (Desktop)** | SQLite via Tauri/Rust |
| **DB Local (Mobile)** | IndexedDB |
| **Sync Storage** | Supabase Storage (eventos criptografados AES-256-GCM) |
| **State Management** | React Context + React Query |
| **Styling** | CSS Modules / Styled Components |

**Consulte**: `modules.md` §1 (Stack) e `data-flow.md` §1 (Arquitetura de Camadas)

---

## 3. Arquitetura de Camadas

### 3.1 Domínio (`src/domain/`)

Entidades e interfaces de repositório. Consulte `modules.md` §3:

| Módulo | Entidade Principal | Tabelas |
|--------|-------------------|---------|
| **Task** | `Task`, `TaskStatus` | `tbl_tarefas`, `tbl_tarefas_eventos` |
| **Suite** | `SuitePackage`, `SuiteStatus` | `tbl_suite`, `tbl_suite_historico` |
| **Client** | `Client`, `ClientContact` | `tblPJuridicas`, `tblPFisicas`, `tblContatos` |
| **User** | `User` | `tbl_usuarios`, `tbl_usuarios_setores` |
| **DataRegistry** | `DataRegistryItem` | `data_registry` |
| **CRM** | `Roteiro`, `Rota`, `Coleta` | `tblRoteiros`, `tblRotas`, `tblColetas` |
| **Ouvidoria** | `Protocolo`, `ProtocoloEvento` | `tblProtocolo`, `tblProtocoloEventos` |
| **Access** | `AccessPolicy` | RBAC (6 perfis, 36 permissões) |

### 3.2 Aplicação (`src/application/`)

Use Cases e Port Interfaces. Consulte `modules.md` §4:

**Ports (contratos)**:
- `SqlitePort` — Leitura/escrita SQLite
- `SyncPort` — Orquestrador de sincronização
- `StorageSyncPort` — I/O de snapshots no Supabase Storage
- `FileStoragePort` — Upload/download de arquivos

**Use Cases por módulo**: `CreateTaskUseCase`, `MoveTaskUseCase`, `SubmitSuiteUseCase`, `ReviewSuiteUseCase`, etc. (ver `modules.md` §4.2)

**Subsistemas Configuráveis:**
- **ActionRegistry** (`src/application/actions/`) — decisões de negócio configuráveis por contexto (ex: "Aceitar Demanda", "Encaminhar para Setor"). Cada ação define visibilidade (`VisibilityRule`), permissão (`UserRole`), mini-formulário de entrada e handler que orquestra use cases.
- **WidgetRegistry** (`src/application/widgets/`) — indicadores de dashboard configuráveis por perfil (KPIs, gráficos, tabelas). Cada widget define fonte de dados (`useCaseGroup` + `method`), refresh interval e renderizador por tipo.

Consulte `action-widget-system.md` para design completo.

### 3.3 Infraestrutura (`src/infrastructure/`)

Implementações de repositories e adapters. Consulte `modules.md` §5:

- **DI Container**: `src/infrastructure/container.ts`
- **SQLite Repositories**: `SqliteTaskRepository`, `SqliteSuiteRepository`, etc.
- **Adapters**: `TauriSqliteAdapter`, `SupabaseFileStorage`
- **Sync Services**: `SyncService`, `StorageSyncService`, `OfflineQueue`

### 3.4 Interface (`src/interface/`)

Hooks de domínio que expõem use cases ao React. Ver `modules.md` §6.

---

## 4. Arquitetura Dual (Desktop + Mobile)

### 4.1 Desktop (Tauri)

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (Next.js)                        │
│         useTauriQuery / useTauriMutation ──▶ invoke()       │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                    Backend Tauri (Rust)                      │
│                                                             │
│   db_query, db_execute, db_execute_batch ──▶ SQLite        │
│   verify_password, hash_password                             │
│   network_probe_path, network_list_parquet                  │
│   supabase_admin_query                                      │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                    SQLite Local                              │
│               (ecoforms_local_desktop.db)                   │
│                                                             │
│   tbl_tarefas, tbl_suite, tbl_projetos, tbl_usuarios,      │
│   form_registry, data_registry, tblPJuridicas, tblRoteiros,│
│   tblColetas, tblProtocolo, etc.                            │
└─────────────────────────────────────────────────────────────┘
```

Comandos Tauri disponíveis: `db_connect`, `db_query`, `db_execute`, `db_execute_batch`, `db_last_insert_id`, `network_probe_path`, `network_list_parquet`, `supabase_admin_query`, etc.

### 4.2 Mobile (Capacitor)

```
┌─────────────────────────────────────────────────────────────┐
│                    Web App (Capacitor)                       │
│                                                             │
│   IndexedDB (offline-first)                                 │
│   RuntimeStorageSync ──▶ Supabase Storage                 │
└─────────────────────────────────────────────────────────────┘
```

**Sync unificado Desktop ↔ Mobile (2026-04-29):**
- Desktop: `desktop/src/infrastructure/sync/` (TypeScript)
- Mobile: `www/js/sync/` (JavaScript) — 13 módulos incluindo CryptoLayer, EventBus, TransportService, InboundService, HandlerRegistry
- Ambos usam PBKDF2 (100k iterações) + AES-256-GCM
- Canal: Supabase Storage (`eventos/{routingId}/`, `shared/manifests/`)

### 4.3 Sincronização (Desktop ↔ Mobile)

```
Desktop (SQLite) ◄────► Supabase Storage ◄────► Mobile (IndexedDB)
                     sync-bucket              www/js/sync/
                   eventos/*.enc            SyncAdapter
```

> **IMPORTANTE**: O trânsito de dados operacionais entre dispositivos ocorre exclusivamente via **Supabase Storage** (arquivos JSON no bucket `sync-bucket`). Apenas `public.profiles` (tabela PostgreSQL) é usada como espelho de `auth.users` para sync de usuários (Fase 5).

**Paths no Supabase Storage (sistema ativo)**:
| Path | Conteúdo | Direção |
|------|----------|---------|
| `shared/org_config.json` | Setores da organização (sem criptografia) | Bootstrap |
| `orgs/{orgId}/manifests/manifest_{routingId}.json` | Controle de sequência por setor | Push/Pull |
| `orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc` | Envelope criptografado (AES-256-GCM) | Push |
| `orgs/{orgId}/eventos/{routingId}/lote_{id}.tgz.enc` | Lote compactado criptografado | Push |

> **Sistema legado (StorageSync)** — As pastas `users/{deviceId}/`, `shared/users.json`, `shared/tasks.json`, `archive/` e afins existem no código (`StorageSync.ts`) mas **não são instanciadas em lugar nenhum**. Serão conectadas em versão futura para sync mobile.

**Regras de Acesso ao Storage**:
1. **NUNCA** acessar tabelas PostgreSQL para trânsito de dados operacionais (exceção: `public.profiles` para sync de usuários)
2. **SEMPRE** usar Storage para trânsito de dados entre dispositivos
3. O bucket `sync-bucket` usa **dual-auth**: role `authenticated` (desktop) + role `anon` (mobile)
4. O bootstrap automático (`StorageBootstrapService`) cria o `org_config.json` na primeira execução online
5. Políticas RLS definidas em `desktop/supabase/migrations/01-storage-rls-v2.sql` (8 policies)

Consulte `database.md` §Sincronização e `data-flow.md` §4 para fluxo completo.

---

## 5. Módulos Principais

### 5.1 Task Module

Gestão de tarefas Kanban com hierarquia (subtarefas, tarefas agrupadoras, recorrência).

**Características**:
- Status machine: `a_fazer → em_progresso → concluido` / `cancelado`
- Hierarquia: `parent_task_id`, `container_task_id`, `cycle_id`, `depends_on_task_id`
- Snapshot freeze para operadores mobile (`snap_version`, `snap_hash`, `snap_frozen_at`)
- Suporte a anexos, comentários, eventos de auditoria

**Tabelas**: `tbl_tarefas`, `tbl_tarefas_eventos`, `tbl_tarefas_interessados`, `tbl_projetos_interessados`

**Sync**: Completo (push/pull via Use Cases)

Consulte `database.md` §tbl_tarefas, `data-flow.md` §3.1, `modules.md` §3.1.

### 5.2 Suite Module (Form Packages)

Pacotes de formulários com versionamento append-only.

**Características**:
- Padrão **append-only**: nunca UPDATE — sempre INSERT nova versão
- `is_current=1` marca versão vigente; `is_current=0` marca histórico
- Status machine: `draft → current → edit → locked → dispatched → ... → closed`
- Ghost tasks: Ad Hoc submissions criam tarefas automaticamente

**Tabelas**: `tbl_suite`, `tbl_suite_historico`, `tbl_suite_history`

**Sync**: Completo

Consulte `database.md` §tbl_suite, `data-flow.md` §3.2, `modules.md` §3.2, `data-system.md` §1.

### 5.3 Client Module

Gestão de clientes (Pessoas Jurídicas) e seus contatos.

**Tabelas**: `tblPJuridicas`, `tblPJtipo`, `tblPFisicas`, `tblContatos`, `tblCEP`

**Features**:
- Busca FTS5 (full-text search)
- Importação CSV/Excel
- Histórico de auditoria (`tblPJuridicas_history`)

**Sync**: Parcial (não há sync dedicated — local via hooks)

Consulte `database.md` §CRM-Clientes-e-Rotas, `data-flow.md` §3.5, `modules.md` §3.3.

### 5.4 CRM Module (Roteirização)

Gestão de roteiros de coleta e vinculação a clientes.

**Tabelas**: `tblRoteiros`, `tblRotas`, `tblColetas`, `tblDetalhesSatelite`, `tblTipoProblema`

**Sync**: Local-only (desktop)

Consulte `database.md` §Roteirização, `data-flow.md` §3.6, `modules.md` §3.6.

### 5.5 Ouvidoria Module

Gestão de protocolos e atendimentos.

**Tabelas**: `tblProtocolo`, `tblProtocoloEventos`, `tblProtocoloAssunto`, `tblProtocoloSubtema`, `Atendimento`, `tblMensagens`

**Features**:
- Geração automática de ID (formato `YYYY-NNNN`)
- Eventos/andamentos encadeados
- Encaminhamento por setor

**Sync**: Local-only

Consulte `database.md` §Ouvidoria, `data-flow.md` §3.7, `modules.md` §3.7.

### 5.6 Form Registry

Templates de formulários dinâmicos.

**Tabela**: `form_registry`

**Features**:
- Campos com visibilidade/habilitação condicional
- Suporte a campos aninhados (grupos repetíveis)
- Enriqueecimento por `data_registry`
- Auto-aprovação configurável

Consulte `database.md` §Form-Registry, `data-flow.md` §3.3, `data-system.md` §1.

---

## 6. Sincronização de Dados

### 6.1 Arquitetura de Sync (Event-Driven v2)

**Pure Storage Mode**: O sync NÃO usa tabelas Supabase — apenas **Supabase Storage** como intermediário (arquivos criptografados no bucket `sync-bucket`).

> **REGRA FUNDAMENTAL**: Todo o trânsito de dados entre dispositivos ocorre exclusivamente via Supabase Storage. Nunca acessar tabelas PostgreSQL diretamente.

**Arquitetura event-driven** (substituiu o modelo snapshot-legacy):

```
Domínio
  → EventBus.publish(type, data)
  → persiste em sync_event_queue (SQLite)
  → TransportService.pushPending()
      → CryptoLayer.encrypt()       [Tauri Rust — AES-256-GCM]
      → SupabaseFileStorage.upload()
      → Manifest.update()

Supabase Storage
  → InboundService.pull()
      → Manifest.hasNewEvents()
      → SupabaseFileStorage.download()
      → CryptoLayer.decrypt()       [Tauri Rust]
      → handler por tipo de evento
      → aplica no SQLite local
```

```
EventSyncAdapter (SyncPort)
├── EventBus — publica eventos, gerencia handlers inbound
│   ├── publish() → INSERT sync_event_queue
│   ├── onInbound() → registra handler por tipo
│   └── dispatch() → executa handlers locais
├── TransportService — push de envelopes para Storage
│   ├── pushPending() — envia todos os pending em ordem de seq
│   ├── pushSingle()  — upload orgs/{orgId}/eventos/{routingId}/...enc
│   └── pushBatch()   — upload de lote compactado
├── InboundService — pull de envelopes de outros setores
│   └── pull(knownRoutingIds) — download + dispatch
├── Manifest — manifesto por routing_id
│   └── orgs/{orgId}/manifests/manifest_{routingId}.json
├── CryptoLayer — AES-256-GCM via Tauri Rust
│   ├── encryptJson() / decryptJson()
│   └── Chave armazenada no State Rust (não trafega via IPC)
├── OrgConfigService — configuração da organização
│   └── shared/org_config.json (sem criptografia)
└── HandlerRegistry — registra todos os handlers inbound
    ├── demanda.handler.ts    (demanda.criada/aceita/encerrada/tarefa.criada)
    ├── crm.handler.ts        (crm.cliente.criado/atualizado/coleta.registrada)
    ├── ouvidoria.handler.ts  (ouvidoria.protocolo.aberto/encaminhado/encerrado/evento)
    ├── form_registry.handler.ts
    ├── data_registry.handler.ts
    ├── usuario.handler.ts
    └── org_config.handler.ts  (org.config.atualizado)
```

### 6.2 Identidade de Roteamento

**Separacão entre identidade de auditoria e identidade de roteamento:**

| Contexto | Roteamento (pasta no Storage) | Auditoria (envelope) |
|----------|-------------------------------|----------------------|
| Desktop | `setor_id` — estável, do usuário autenticado | `device_id` — UUID da instalação |
| Mobile  | `user_id` — do usuário autenticado | `device_id` — UUID da instalação |

Isso garante que uma reinstalação do app (novo `device_id`) **não** cria pasta órfã no Storage — o `setor_id` é estável e sobrevive à reinstalação.

**Paths no Supabase Storage (sync-bucket) — sistema ativo:**
| Path | Conteúdo |
|------|----------|
| `shared/org_config.json` | Configuração da organização — bootstrap (sem criptografia) |
| `orgs/{orgId}/manifests/manifest_{routingId}.json` | Manifesto individual por setor |
| `orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc` | Envelope criptografado (AES-256-GCM) |
| `orgs/{orgId}/eventos/{routingId}/lote_{id}.tgz.enc` | Lote compactado criptografado |

### 6.3 Ciclo de Sincronização

**Triggers**:
- Intervalo configurável (default 5 min)
- Evento `online` (navigator.onLine via `useOnlineStatus`)
- Evento `focus` na janela (após 60s de inatividade)
- Trigger manual via `syncNow(forcePush?)`

**Fluxo** (`SyncContext` → `EventSyncAdapter`):
1. **Push**: TransportService.pushPending() → envia envelopes pending
2. **Pull**: InboundService.pull(knownRoutingIds) → baixa e processa envelopes de outros setores
3. **Manifest**: Atualizado após push bem-sucedido com último seq

### 6.4 Sistema Offline

**OfflineQueue**: Eventos publicados via `EventBus.publish()` são persistidos em `sync_event_queue` no SQLite local com status `pending`. Quando online, o `TransportService.pushPending()` envia em ordem de seq. Em caso de falha, o evento é marcado como `failed` e o contador de tentativas é incrementado.

### 6.5 Bootstrap Automático do Storage

O `StorageBootstrapService` é executado automaticamente no primeiro mount do `SyncContext` (quando online). Ele garante que a infraestrutura do bucket exista sem intervenção manual:

```
SyncContext.mount()
  → StorageBootstrapService.bootstrapIfNeeded()
    → SupabaseFileStorage.ensureBucket('sync-bucket')   ← tenta criar o bucket se não existir
    → storage.download('shared/org_config.json')
        ├── sucesso → cacheia localmente
        └── 404/erro → cria config default + upload
            └── falha (bucket sem permissão) → usa config local (modo offline)
```

**Pré-requisito de infraestrutura (uma vez, via SQL Editor do Supabase):**

Os scripts completos estão em:
- `desktop/supabase/migrations/01-storage-rls-v2.sql` — políticas RLS dual-auth (authenticated + anon)
- `desktop/supabase/migrations/02-public-profiles.sql` — tabela `public.profiles` + triggers (Fase 5)
- `desktop/supabase-storage-setup.sql` — script de setup inicial (legado, substituído pelo v2)

O `org_config.json` tem o seguinte formato:
```json
{
  "org_id": "ecoforms-org-001",
  "org_nome": "Secretaria de Meio Ambiente",
  "setores": [
    { "id": "setor-coleta", "nome": "Coleta de Resíduos", "ativo": true },
    { "id": "setor-fiscalizacao", "nome": "Fiscalização Ambiental", "ativo": true }
  ],
  "updated_at": "2026-04-28T10:00:00Z"
}
```

Sem este arquivo (e sem o bucket), o pull de eventos de outros setores não funciona — apenas push local.

---

## 7. Segurança e Controle de Acesso

### 7.1 Perfis de Acesso

| Nível | Perfil | Descrição |
|-------|--------|-----------|
| 0 | admin | Administrador total |
| 1 | gerente | Gerente de operações |
| 2 | coordenador | Coordenador de equipe |
| 3 | encarregado | Encarregado de campo |
| 4 | operador | Operador de campo |
| 4 | campo | Execução de campo |

**Tabelas dinâmicas:** `tbl_perfis`, `tbl_role_hierarchy`, `tbl_permissions` — seedeadas no boot.

### 7.2 Sessão no Rust (`SessionState`)

`AuthContext` chama `invoke('set_session')` no login. O backend armazena `user_id` + `perfil` em memória e re-valida `ativo = 1` no banco a cada comando protegido.

### 7.3 Commands Dedicados

Mutações sensíveis usam commands Rust com validação de sessão + permissão:
- `suite_approve`, `suite_reject` → requer `data.edit_all`
- `demanda_aceitar`, `demanda_encerrar` → requer `activities.manage`
- `ecoponto_agendar_remocao` → requer `activities.manage`

### 7.4 Sanitização de Commands Genéricos

- `db_query`: bloqueia leitura de `password_hash`
- `db_execute`: bloqueia mutations em `tbl_usuarios`, `tbl_perfis`, `tbl_role_hierarchy`, `tbl_permissions` para não-admin

### 7.5 Regras RBAC

- **Admin**: sempre
- **Gerente**: até 72h após criação
- **Coordenador**: até 48h (próprios registros)
- **Operador/Campo**: até 24h (próprios registros)

### 7.6 Auditoria

- `tbl_audit_log` — log de segurança (commands Rust)
- Evento `audit.registro` na `sync_event_queue` → envio criptografado à nuvem
- `action_log` — log operacional do ActionRegistry (mantido separado)

### 7.7 Filtros de Acesso

| Função | Retorno |
|--------|---------|
| `getAccessiblePerfis(perfil)` | Perfis acessíveis |
| `isAdmin(perfil)` | Boolean |
| `buildTaskAccessFilter(userId, perfil)` | `{ clause, params }` |
| `buildRecordAccessFilter(userId, perfil)` | `{ clause, params }` |

**Componentes de guarda:** `PermissionGuards.tsx` fornece `RequirePermission`, `RequireAnyPermission`, `RequireAllPermissions`, `ShowForPermission`, `HideForPermission`, `ShowForAdmin`, `ShowForManager`, `ProtectedPage`.

Consulte `modules.md` §3.9, `hooks.md` §10, `data-system.md` §8, `security.md`.

---

## 8. Fluxo de Inicialização

### 8.1 Startup Sequence

```
1. Loading Screen
       │
       ▼
2. Auth Check (AuthContext)
       │
       ├── Token existe? ──▶ NÃO ──▶ /login
       │
       └── verifyPassword() via Tauri
              │
              ├── Login local bem-sucedido
              │
              └── syncSupabaseAuth() [background, non-fatal]
                    ├── signInWithPassword(email, password)
                    └── signUp() se usuário não existe no Supabase Auth
              │
              ▼
3. DB Init (getContainerAsync)
       │
       ├── ensureColumnsIfNeeded() — scripts/ensure-columns.ts
       └── Lazy-init do EventSyncAdapter (lazy-sync.ts)
       │
       ▼
4. Dashboard
```

Consulte `ui-flow.md` §5.

### 8.2 Dual Query Layer

O projeto opera com **duas formas de consultar SQLite**:

| Hook | Caminho | Uso |
|------|---------|-----|
| `useTauriQuery` | `invoke('db_query')` → Rust | Bypass direto, sem contexto React |
| `useSQLiteQuery` | `useSqlite` context | Wrapper reativo com cache |

Consulte `modules.md` §12 (Notas de Arquitetura).

---

## Resumo

| Aspecto | Implementação |
|---------|---------------|
| **Arquitetura** | Clean Architecture (4 camadas) |
| **Frontend** | Next.js 14 + React + TypeScript |
| **Desktop** | Tauri (Rust) + SQLite local |
| **Mobile** | Capacitor + IndexedDB |
| **Sync** | Supabase Storage (JSON.gz + SHA-256) |
| **DB Tables** | ~22 tabelas principais (ver `database.md`) |
| **Hooks** | ~61 hooks em `src/interface/hooks/` (ver `hooks.md`) |
| **Perfis** | 6 perfis RBAC com ~25 permissões |
| **Padrão Suite** | Append-only (versões, nunca UPDATE) |
| **Offline** | IndexedDB queue com max 3 retries |
