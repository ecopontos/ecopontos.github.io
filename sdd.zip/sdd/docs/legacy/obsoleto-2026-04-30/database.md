# Banco de Dados — EcoForms Desktop

> **Fonte de verdade:** este documento reflete o schema real em `src-tauri/src/database.rs` (schema base + migrations Rust) e `scripts/ensure-columns.ts` (migrações runtime web/PWA fallback).

---

## Visão Geral da Arquitetura

O sistema utiliza uma **arquitetura de banco de dados dual**:

| Tipo | Tecnologia | Uso |
|------|------------|-----|
| Local | SQLite (Tauri/Rust) | Armazenamento primário (Desktop) |
| Local | IndexedDB (web/PWA fallback) | Armazenamento primário (Browser) |
| Remoto | Supabase Storage | Sincronização de eventos criptografados (`.enc`) |

> **IMPORTANTE**: O trânsito de dados operacionais ocorre exclusivamente via **Supabase Storage** (arquivos criptografados no bucket `sync-bucket`). Apenas `public.profiles` (tabela PostgreSQL) é usada como espelho de `auth.users` para sync de usuários (Fase 5).

A sincronização entre bancos locais ocorre via **Event-Driven Sync** (EventSyncAdapter): envelopes JSON criptografados com AES-256-GCM são enviados para `orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc`.

---

## Tabelas Principais

### Projetos e Tarefas

#### `tbl_projetos`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| nome | TEXT | Nome do projeto |
| descricao | TEXT | Descrição |
| cor | TEXT | Cor de identificação (hex) |
| criado_por | TEXT | UUID do criador |
| arquivado | INTEGER | 0=ativo, 1=arquivado |
| created_at | TEXT | Timestamp ISO |
| updated_at | TEXT | Timestamp ISO |

#### `tbl_tarefas`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| projeto_id | TEXT | FK para tbl_projetos |
| titulo | TEXT | Título da tarefa |
| status | TEXT | a_fazer, em_progresso, concluido, cancelado |
| prioridade | TEXT | baixa, media, alta, critica |
| ordem | INTEGER | Posição no quadro Kanban |
| atribuido_para | TEXT | UUID do usuário atribuído |
| criado_por | TEXT | UUID do criador |
| prazo | TEXT | Data/hora prazo (ISO) |
| form_registry_id | TEXT | FK para form_registry |
| tbl_suite_id | TEXT | Referência ao pacote de formulários |
| parent_task_id | TEXT | Tarefa pai (subtarefas) |
| container_task_id | TEXT | Agrupador de tarefas |
| cycle_id | TEXT | ID do ciclo (tarefas recorrentes) |
| depends_on_task_id | TEXT | Dependência de outra tarefa |
| snap_version | TEXT | Versão do snapshot |
| snap_hash | TEXT | Hash SHA-256 do snapshot |
| snap_frozen_at | TEXT | Timestamp do snapshot congelado |
| setor_id | TEXT | Setor responsável |
| demanda_id | TEXT | FK para tbl_demandas |
| location | TEXT | Localização (GPS) |
| payload | TEXT | JSON com dados extras |
| tags | TEXT | JSON com tags |
| recorrencia | TEXT | Configuração de recorrência |
| prazo_fim | TEXT | Prazo final (ISO) |
| tipo_prazo | TEXT | unico, periodo, recorrente |
| deletado_em | TEXT | Soft delete timestamp |
| deletado_por | TEXT | UUID de quem deletou |
| arquivado | INTEGER | 0=ativo, 1=arquivado |
| created_at | TEXT | Timestamp ISO |
| updated_at | TEXT | Timestamp ISO |

#### `tbl_tarefas_anexos`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| tarefa_id | TEXT | FK para tbl_tarefas |
| usuario_id | TEXT | UUID do uploader |
| nome_arquivo | TEXT | Nome original |
| url_storage | TEXT | Caminho no Supabase Storage |
| tipo_mime | TEXT | MIME type |
| tamanho_bytes | INTEGER | Tamanho do arquivo |

#### `tbl_tarefas_comentarios`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| tarefa_id | TEXT | FK para tbl_tarefas |
| usuario_id | TEXT | UUID do autor |
| comentario | TEXT | Conteúdo do comentário |

#### `tbl_tarefas_eventos`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| tarefa_id | TEXT | FK para tbl_tarefas |
| evento | TEXT | Tipo do evento |
| usuario_id | TEXT | UUID do responsável |
| detalhes | TEXT | JSON com detalhes |
| criado_em | TEXT | Timestamp ISO |

#### `tbl_tarefas_interessados`
Relacionamento N:N entre tarefas e usuários interessados.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| tarefa_id | TEXT | FK para tbl_tarefas |
| usuario_id | TEXT | FK para tbl_usuarios |

#### `tbl_projetos_interessados`
Relacionamento N:N entre projetos e stakeholders.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| projeto_id | TEXT | FK para tbl_projetos |
| usuario_id | TEXT | FK para tbl_usuarios |

---

### Formulários (Suite Packages)

#### `tbl_suite`
Pacotes de formulários (padrão append-only — nunca atualizar, criar nova versão).

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| projeto_id | TEXT | FK para projeto |
| dados | TEXT | JSON legado com dados do pacote |
| status | TEXT | draft, current, edit, locked, dispatched, pending_review, refuted, superseded, closed |
| formulario_id | TEXT | FK para form_registry |
| package_id | TEXT | UUID do pacote (agrupador de versões) |
| version_no | INTEGER | Número da versão (DEFAULT 1) |
| is_current | INTEGER | 1=versão atual, 0=histórico (DEFAULT 1) |
| module_type | TEXT | Tipo do módulo |
| resource_type | TEXT | Tipo do recurso |
| payload_json | TEXT | JSON com conteúdo do pacote |
| owner_id | TEXT | UUID do proprietário |
| task_id | TEXT | FK para tarefa vinculada |
| submitted_at | TEXT | Timestamp de submissão |
| locked_by | TEXT | UUID do usuário que bloqueou |
| locked_at | TEXT | Timestamp do bloqueio |
| ref_package_id | TEXT | Pacote de referência (audit trail) |
| entity_id | TEXT | FK para entidade do Entity Registry (AD-017) |
| entity_type | TEXT | Tipo da entidade: 'pj', 'pf', 'ecoponto' (AD-017) |
| created_at | TEXT | Timestamp ISO |
| updated_at | TEXT | Timestamp ISO |
| closed_at | TEXT | Timestamp de encerramento |
| ref_package_ver | INTEGER | Versão do pacote referenciado |

Índice: `idx_suite_entity ON (entity_type, entity_id)` — queries por entidade sem `JSON_EXTRACT`.

#### `tbl_suite_historico`
Histórico de transições de status.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| registro_id | TEXT | UUID do pacote |
| status_anterior | TEXT | Status anterior |
| status_novo | TEXT | Status novo |
| alterado_por | TEXT | UUID do usuário |
| alterado_em | TEXT | Timestamp ISO (DEFAULT datetime('now')) |
| motivo | TEXT | Motivo da alteração |
| transfer_type | TEXT | Tipo de transferência: 'share' (encaminhar) ou 'transfer' (reencaminhar) — AD-016 |

> Nota: a tabela `tbl_suite_history` (documentada em versões anteriores) **não existe** no schema atual.

---

### Form Registry

#### `form_registry`
Templates de formulários.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| form_id | TEXT | UUID primário |
| slug | TEXT | Slug único (URL) |
| titulo | TEXT | Título do formulário |
| conteudo | TEXT | JSON com estrutura dos campos |
| versao | INTEGER | Versão atual |
| ativo | INTEGER | 0=inativo, 1=ativo (DEFAULT 1) |
| autor | TEXT | UUID do autor |
| situacao | TEXT | Estado do formulário |
| auto_aprovacao | INTEGER | 1=aprovação automática |
| ad_hoc | INTEGER | 1=formulário ad-hoc (DEFAULT 0) |
| criado_em | TEXT | Timestamp ISO |
| atualizado_em | TEXT | Timestamp ISO |

#### `data_registry`
Dados de referência.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| tipo | TEXT | Tipo do registro |
| chave | TEXT | Chave única |
| conteudo | TEXT | JSON com conteúdo |
| versao | INTEGER | Versão |
| criado_em | TEXT | Timestamp ISO |
| atualizado_em | TEXT | Timestamp ISO |

#### `view_registry` (AD-011)
Configuração de dashboards e painéis (4 tipos iniciais: `record_view`, `record_list`, `kpi_card`, `status_board`).

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| titulo | TEXT | Título do dashboard |
| perfis | TEXT | JSON com perfis que podem visualizar |
| layout | TEXT | Layout grid: grid-1, grid-2, grid-3, grid-4 (DEFAULT 'grid-2') |
| widgets | TEXT | JSON com array de widgets configurados |
| module_type | TEXT | Filtro opcional por módulo |
| ativo | INTEGER | 0=inativo, 1=ativo (DEFAULT 1) |
| criado_em | TEXT | Timestamp ISO |
| atualizado_em | TEXT | Timestamp ISO |

Renderer: `ViewRenderer.tsx` interpreta o JSON de widgets e renderiza via `@/components/dashboard/ViewRenderer`.

#### `decision_registry` (AD-012)
Configuração de fluxos de decisão.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| target_type | TEXT | Tipo alvo: ecoponto, suite, demanda, etc. |
| action | TEXT | Ação universal (ver `UNIVERSAL_ACTIONS`) |
| perfis | TEXT | JSON com perfis que podem executar |
| enabled_when | TEXT | JSON com condições de visibilidade |
| steps | TEXT | JSON com passos da decisão |
| params | TEXT | JSON com parâmetros da ação |
| consequence_type | TEXT | terminal ou generator (DEFAULT 'terminal') |
| consequence_pattern | TEXT | Padrão da consequência (ex: 'derive') |
| consequence_config | TEXT | JSON com configuração da consequência |
| ativo | INTEGER | 0=inativo, 1=ativo (DEFAULT 1) |
| criado_em | TEXT | Timestamp ISO |
| atualizado_em | TEXT | Timestamp ISO |

---

### Usuários e Setores

#### `tbl_usuarios`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| username | TEXT | Nome de usuário (UNIQUE, NOT NULL) |
| password_hash | TEXT | Hash bcrypt da senha |
| nome | TEXT | Nome completo (NOT NULL) |
| email | TEXT | E-mail |
| perfil | TEXT | Nível de acesso (DEFAULT 'operador') |
| formularios_permitidos | TEXT | JSON com IDs permitidos |
| ativo | INTEGER | 0=inativo, 1=ativo (DEFAULT 1) |
| setor | TEXT | Setor padrão do usuário |
| setores | TEXT | JSON com setores permitidos |
| org_id | TEXT | ID da organização (Fase 5) |
| sync_salt | TEXT | Salt PBKDF2 de 32 bytes (hex) por usuário — AD-022 |
| criado_em | TEXT | Timestamp ISO |
| atualizado_em | TEXT | Timestamp ISO |

**Perfis válidos (TEXT)**: `admin`, `gerente`, `coordenador`, `encarregado`, `operador`, `campo`

> **Primeiro admin**: Em instalações limpas, o `FirstRunSetupModal` na tela de login permite ao usuário criar o primeiro administrador via `invoke('create_first_admin')`. O `sync_salt` é gerado automaticamente (32 bytes aleatórios em hex) tanto pelo Rust (`setup.rs`) quanto pelo TypeScript (`SqliteUserRepository.ts`).
>
> **AD-022 — Migration retroativa:** Usuários existentes sem `sync_salt` recebem um valor aleatório via `UPDATE tbl_usuarios SET sync_salt = lower(hex(randomblob(32))) WHERE sync_salt IS NULL` durante o `ensureColumns()`.

#### `tbl_setores`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| nome | TEXT | Nome do setor (NOT NULL) |
| descricao | TEXT | Descrição |
| ativo | INTEGER | 0=inativo, 1=ativo (DEFAULT 1) |
| criado_em | TEXT | Timestamp ISO |
| atualizado_em | TEXT | Timestamp ISO |

#### `tbl_usuarios_setores`
Relacionamento N:N entre usuários e setores.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| usuario_id | TEXT | FK para tbl_usuarios |
| setor_id | TEXT | FK para tbl_setores |

---

### CRM — Clientes e Rotas

#### `tblPJuridicas`
Pessoas Jurídicas (clientes).

| Campo | Tipo | Descrição |
|-------|------|-----------|
| idPJ | TEXT | UUID primário |
| Cliente | TEXT | Nome/Razão social |
| CNPJ | TEXT | CNPJ |
| CEP | TEXT | CEP |
| telefone | TEXT | Telefone |
| numero | TEXT | Número do endereço |
| complemento | TEXT | Complemento |

#### `tblPFisicas`
Pessoas Físicas (contatos).

| Campo | Tipo | Descrição |
|-------|------|-----------|
| idPF | TEXT | UUID primário |
| Nome | TEXT | Nome completo |
| Telefone1 | TEXT | Telefone principal |
| CEP | TEXT | CEP |
| Numero | TEXT | Número |

#### `tblContatos`
Vinculação entre clientes e contatos.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| idContato | TEXT | UUID primário |
| idPF | TEXT | FK para tblPFisicas |
| idPJ | TEXT | FK para tblPJuridicas |
| TipoContato | TEXT | Tipo do contato |

#### `tblCEP`
Base de dados de CEPs.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| CEP | TEXT | CEP (PK) |
| logradouro | TEXT | Logradouro |
| bairro | TEXT | Bairro |
| cidade | TEXT | Cidade |
| estado | TEXT | UF |

---

### Roteirização

#### `tblRoteiros`
Definições de roteiro.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| idRoteiro | TEXT | UUID primário |
| Roteiro | TEXT | Nome do roteiro |
| Tipo de Resíduo | TEXT | Tipo de resíduo coletado |
| Periodicidade | TEXT | Frequência |
| Turno | TEXT | Manhã/Tarde/Noite |
| Base | TEXT | Base operacional |

#### `tblRotas`
Vinculação de clientes a roteiros.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| idRota | TEXT | UUID primário |
| idPJ | TEXT | FK para tblPJuridicas |
| idRoteiro | TEXT | FK para tblRoteiros |
| Ordem | INTEGER | Ordem no roteiro |
| Inativo | INTEGER | 0=ativo, 1=inativo |

#### `tblColetas` (LEGADO — AD-015)
Registros de coletas. **Substituído por `tbl_suite` com `module_type='coleta'`.** A tabela existe para compatibilidade com dados antigos. Novos registros usam `tbl_suite`.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| idColeta | TEXT | UUID primário |
| idRoteiro | TEXT | FK para tblRoteiros |
| Data | TEXT | Data da coleta |
| idPJ | TEXT | FK para tblPJuridicas |
| Status | TEXT | Status da coleta |
| Observacao | TEXT | Observações |

#### `tblDetalhesSatelite` (LEGADO — AD-015)
Detalhes das coletas. **Substituído por `payload_json` no registro `tbl_suite`.**

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| idColeta | TEXT | FK para tblColetas |
| contentores | TEXT | Quantidade de contentores |
| problema | TEXT | Tipo de problema |
| rejeito | TEXT | Quantidade rejeitada |
| sacolas | TEXT | Quantidade de sacolas |

---

### Ouvidoria (LEGADO — AD-014)

> **AD-014:** Todas as tabelas abaixo são legado. O módulo de Ouvidoria foi migrado para `tbl_suite` (`module_type='ouvidoria'`) + `data_registry` (`ouvidoria_assuntos`, `ouvidoria_subtemas`, `mensagens_template`).

#### `tblProtocolo`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| idProtocolo | TEXT | UUID primário |
| Telefone | TEXT | Telefone do solicitante |
| PJ | TEXT | Cliente relacionado |
| Status | TEXT | Status do protocolo |
| UsuarioID | TEXT | UUID do atendente |
| CriadoEm | TEXT | Timestamp de criação |

#### `tblProtocoloEventos`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| idEvento | TEXT | UUID primário |
| idProtocolo | TEXT | FK para tblProtocolo |
| Detalhe | TEXT | Descrição do evento |
| Setor | TEXT | Setor responsável |
| Motivo | TEXT | Motivo |
| Resposta | TEXT | Resposta enviada |
| Carimbo | TEXT | Timestamp da resposta |

#### `Atendimento`
Registros de atendimento.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| Código | TEXT | UUID primário |
| idProtocolo | TEXT | FK para tblProtocolo |
| Solicitação do Cliente | TEXT | Descrição da solicitação |
| Encaminhamento | TEXT | Destino do encaminhamento |

---

### Demandas

> Módulo presente no código (`src/domain/demanda/`) mas ausente da documentação anterior.

#### `tbl_demandas`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| origem_tipo | TEXT | ouvidoria, interno, proprio (NOT NULL) |
| origem_id | TEXT | ID da origem |
| solicitante_id | TEXT | UUID do solicitante (NOT NULL) |
| destinatario_id | TEXT | UUID do destinatário (NOT NULL) |
| tipo_acao | TEXT | Tipo de ação |
| descricao | TEXT | Descrição |
| status | TEXT | aberta, aceita, em_campo, concluida (DEFAULT 'aberta') |
| politica_conclusao | TEXT | todas, declarado (DEFAULT 'declarado') |
| auto_aceite | INTEGER | 1=auto-aceite (DEFAULT 0) |
| aceito_por | TEXT | UUID de quem aceitou |
| aceito_em | TEXT | Timestamp de aceite |
| encerrado_por | TEXT | UUID de quem encerrou |
| encerrado_em | TEXT | Timestamp de encerramento |
| criada_em | TEXT | Timestamp de criação (NOT NULL) |
| arquivada_em | TEXT | Timestamp de arquivamento |
| arquivo_path | TEXT | Caminho do arquivo |
| archive_status | TEXT | Status do arquivo |
| created_at | TEXT | Timestamp ISO (DEFAULT datetime('now')) |
| updated_at | TEXT | Timestamp ISO (DEFAULT datetime('now')) |

#### `tbl_demanda_eventos`
Eventos do ciclo de vida da demanda.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| demanda_id | TEXT | FK para tbl_demandas (NOT NULL) |
| type | TEXT | Tipo do evento (NOT NULL) |
| correlation_id | TEXT | ID de correlação |
| causation_id | TEXT | ID de causação |
| payload | TEXT | JSON com dados (NOT NULL) |
| device_id | TEXT | ID do dispositivo |
| user_id | TEXT | UUID do usuário |
| created_at | TEXT | Timestamp ISO (DEFAULT datetime('now')) |

#### `tbl_tarefa_formularios`
Formulários vinculados a tarefas da demanda.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| tarefa_id | TEXT | FK para tbl_tarefas (NOT NULL) |
| form_registry_id | TEXT | FK para form_registry (NOT NULL) |
| form_version | INTEGER | Versão do formulário (DEFAULT 1) |
| form_snapshot | TEXT | JSON com snapshot (NOT NULL) |
| ordem | INTEGER | Ordem (DEFAULT 0) |
| obrigatorio | INTEGER | 1=obrigatório (DEFAULT 1) |
| concluido | INTEGER | 1=concluído (DEFAULT 0) |
| concluido_em | TEXT | Timestamp de conclusão |
| created_at | TEXT | Timestamp ISO (DEFAULT datetime('now')) |

#### `tbl_anexos`
Anexos vinculados a demandas ou tarefas.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| demanda_id | TEXT | FK para tbl_demandas |
| tarefa_id | TEXT | FK para tbl_tarefas |
| blob_preview | BLOB | Preview em blob |
| storage_path | TEXT | Caminho no Storage |
| storage_checksum | TEXT | Checksum SHA-256 |
| mime_type | TEXT | MIME type |
| nome_arquivo | TEXT | Nome do arquivo |
| sincronizado | INTEGER | 1=sincronizado (DEFAULT 0) |
| created_at | TEXT | Timestamp ISO (DEFAULT datetime('now')) |

---

### Auditoria de Ações

#### `action_log`

Registro de todas as ações executadas via ActionRegistry (sucesso e erro). Referência loose a qualquer tabela via `target_type` + `target_id`.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| action_id | TEXT | ID da ação (ex: `demanda_aceitar`) |
| target_type | TEXT | Tipo do alvo (`task`, `demand`, `suite_package`, `ecoponto`) |
| target_id | TEXT | UUID do objeto alvo |
| user_id | TEXT | UUID do usuário que executou |
| resultado | TEXT | JSON com resultado (quando sucesso) |
| erro | TEXT | Mensagem de erro (quando falha) |
| created_at | TEXT | Timestamp ISO (DEFAULT datetime('now')) |

**Índices:**
- `idx_action_log_target` — `(target_type, target_id)`
- `idx_action_log_user` — `(user_id)`

**Notas:**
- Sem Foreign Keys — `target_type` + `target_id` referenciam qualquer tabela de forma loose.
- Populada pelos handlers de ações built-in (`demanda_aceitar`, `ecoponto_encaminhar_remocao`, etc.).

---

### Sincronização (Event-Driven)

#### `sync_event_queue`
Fila de eventos para push ao Storage.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| type | TEXT | Tipo do evento (NOT NULL) |
| payload | TEXT | JSON do evento (NOT NULL) |
| aggregate_type | TEXT | Tipo do agregado |
| aggregate_id | TEXT | ID do agregado |
| correlation_id | TEXT | ID de correlação |
| causation_id | TEXT | ID de causação |
| seq | INTEGER | Sequência |
| status | TEXT | pending, sent, failed (DEFAULT 'pending') |
| attempts | INTEGER | Tentativas (DEFAULT 0) |
| created_at | TEXT | Timestamp ISO (DEFAULT datetime('now')) |
| sent_at | TEXT | Timestamp de envio |

#### `sync_device_log`
Log de sequências por dispositivo.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| device_id | TEXT | ID do dispositivo (PK) |
| seq | INTEGER | Sequência (PK) |
| event_id | TEXT | ID do evento (NOT NULL) |
| pushed_at | TEXT | Timestamp de push |
| acked | INTEGER | 1=acknowledged (DEFAULT 0) |

#### `sync_gap_log` (AD-021)
Registro de gaps de sequência no sync e tentativas de recovery.

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | TEXT | UUID primário |
| routing_id | TEXT | Routing ID do stream |
| missing_seq | INTEGER | Número da sequência faltante (UNIQUE com routing_id) |
| detected_at | TEXT | Timestamp da detecção |
| resolved_at | TEXT | Timestamp da resolução (nullable) |
| status | TEXT | pending, resolved, unresolvable (DEFAULT 'pending') |
| attempts | INTEGER | Número de tentativas de recovery (DEFAULT 0) |

---

### Sistema (Legacy)

#### `sync_status`
Controle de sincronização legado (não usado pelo EventSyncAdapter ativo).

| Campo | Tipo | Descrição |
|-------|------|-----------|
| table_name | TEXT | Nome da tabela (PK) |
| last_sync | TEXT | Timestamp da última sincronização |
| status | TEXT | Status atual |
| records_synced | INTEGER | Quantidade de registros |

---

## Relacionamentos

```
tbl_projetos 1──∞ tbl_tarefas
tbl_tarefas 1──∞ tbl_tarefas (parent_task_id - auto-relacionamento)
tbl_tarefas ∞──∞ tbl_usuarios (interessados)
tbl_tarefas 1──∞ tbl_suite (via tbl_suite_id)
tbl_suite 1──∞ tbl_suite_historico (via registro_id)
tbl_usuarios ∞──∞ tbl_setores
tbl_demandas 1──∞ tbl_demanda_eventos
tbl_demandas 1──∞ tbl_anexos
tbl_tarefas 1──∞ tbl_tarefa_formularios
tbl_tarefas 1──∞ tbl_anexos

tblPJuridicas 1──∞ tblRotas
tblPJuridicas 1──∞ tblContatos ∞──∞ tblPFisicas
tblRoteiros 1──∞ tblRotas
tblRoteiros 1──∞ tblColetas 1──∞ tblDetalhesSatelite

tblProtocolo 1──∞ tblProtocoloEventos
tblProtocolo 1──∞ Atendimento
```

---

## Máquinas de Estado

### Status de Tarefa
```
a_fazer ──────► em_progresso
    │                 │
    │                 ▼
    └───────► cancelado ◄────
                         │
                         ▼
                      concluido
```

### Status de Suite Package
```
draft ───► current ───► edit ───► current (loop)
    │           │            │
    │           ▼            ▼
    │        locked      pending_review
    │           │            │
    │           ▼            ▼
    │        current ◄──► refuted
    │           │
    │           ▼
    │      superseded (terminal)
    │
    ▼
dispatched ──► pending_review
    │
    ▼
closed (terminal)
```

### Status de Demanda
```
aberta ───► aceita ───► em_campo ───► concluida
    │           │
    │           ▼
    └──────► encerrada (cancelada)
```

---

## Perfis de Acesso

| Perfil | Nível | Descrição |
|--------|-------|-----------|
| admin | 0 | Administrador total |
| gerente | 1 | Gerente de operações |
| coordenador | 2 | Coordenador de equipe |
| encarregado | 3 | Encarregado de campo |
| operador | 4 | Operador de campo |
| campo | 4 | Operador de campo |

---

## Índices

| Índice | Tabela | Campos | Tipo |
|--------|--------|--------|------|
| idx_tbl_tarefas_suite_id_unique | tbl_tarefas | tbl_suite_id | UNIQUE (WHERE NOT NULL) |
| idx_form_registry_slug_unique | form_registry | slug | UNIQUE |
| idx_suite_historico_registro | tbl_suite_historico | registro_id | |
| idx_suite_historico_data | tbl_suite_historico | alterado_em | |
| idx_despacho_registros_despacho | tbl_despacho_registros | despacho_id | |
| idx_despacho_registros_registro | tbl_despacho_registros | registro_id | |
| idx_despacho_registros_token | tbl_despacho_registros | token | |
| idx_sync_event_queue_status | sync_event_queue | status | |
| idx_sync_device_log_device | sync_device_log | device_id | |
| idx_tarefas_demanda | tbl_tarefas | demanda_id | |
| idx_tbl_suite_package_version | tbl_suite | package_id, version_no | UNIQUE |
| idx_suite_entity | tbl_suite | entity_type, entity_id | (AD-017) |
| idx_sync_gap_log_routing | sync_gap_log | routing_id | (AD-021) |

---

## Padrão Append-Only (tbl_suite)

Para manter histórico completo:

1. **Nunca** utilizar UPDATE em registros existentes
2. Criar novo registro com `version_no` incrementado
3. Atualizar `is_current = 0` no registro anterior
4. Registrar transição em `tbl_suite_historico`

---

## Sincronização

| Componente | Detalhe |
|------------|---------|
| Push | Desktop → Supabase Storage (eventos criptografados `.enc`) |
| Pull | Supabase Storage → Desktop (eventos de outros setores) |
| Formato | Event Envelope v2 (JSON) criptografado com AES-256-GCM |
| Paths ativos | `orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc`, `orgs/{orgId}/manifests/manifest_{routingId}.json`, `shared/org_config.json` |
| Offline | Fila `sync_event_queue` (SQLite) com retentativas |

### Arquivos no Supabase Storage (sync-bucket)

| Path | Conteúdo | Direção |
|------|----------|---------|
| `shared/org_config.json` | Configuração da organização (setores) | Bootstrap |
| `orgs/{orgId}/manifests/manifest_{routingId}.json` | Manifesto de sequência por setor | Push/Pull |
| `orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc` | Evento criptografado (AES-256-GCM) | Push |
| `orgs/{orgId}/eventos/{routingId}/lote_{id}.tgz.enc` | Lote compactado criptografado | Push (batch) |

### Fluxo de Sincronização

```
┌─────────────────┐     ┌─────────────────────┐     ┌─────────────────┐
│  SQLite         │────▶│  EventSyncAdapter   │────▶│  Supabase       │
│  (Desktop)      │     │  (EventBus +        │     │  Storage        │
│  sync_event_queue│◄────│  TransportService)  │◄────│  sync-bucket    │
└─────────────────┘     └─────────────────────┘     └─────────────────┘
         │                        │
         ▼                        ▼
  ┌─────────────┐          ┌─────────────┐
  │ InboundService│        │ CryptoLayer │
  │ (pull + dispatch)│      │ (AES-256-GCM)│
  └─────────────┘          └─────────────┘
```

### Regras Importantes

1. **NUNCA** acessar tabelas PostgreSQL para trânsito de dados operacionais (exceção: `public.profiles` para sync de usuários)
2. **SEMPRE** usar Storage para trânsito de dados entre dispositivos
3. **SEMPRE** usar cache local (SQLite) como fonte primária de leitura
4. Eventos são sincronizados periodicamente (intervalo configurável, default 5 min)

---

## Migrações

### Rust (`src-tauri/src/database.rs`)
- Conexão SQLite via `db_connect()` — cria diretório e arquivo automaticamente em instalações limpas
- `PRAGMA foreign_keys = ON`
- `PRAGMA journal_mode = WAL`
- Sanitização de queries (`db_query`, `db_execute`, `db_execute_batch`)
- Commands dedicados para mutações sensíveis (não seed de admin)

### TypeScript (`scripts/ensure-columns.ts`)
- Fallback para web/PWA (quando não há Tauri)
- `CREATE TABLE IF NOT EXISTS` para tabelas principais incluindo:
  - `tbl_tarefas`, `tbl_suite`, `tbl_setores`, `tbl_projetos`, `form_registry`, `data_registry`
  - `tbl_usuarios` (criada via ensure-columns desde v4.2)
  - `tbl_tarefas_anexos`, `tbl_tarefas_comentarios`, `tbl_suite_historico`
  - `tbl_activities`, `tbl_projetos_interessados`
  - `tbl_perfis`, `tbl_role_hierarchy`, `tbl_permissions`, `tbl_audit_log`
- `ALTER TABLE ADD COLUMN` para colunas adicionadas após a criação inicial
- Criação de tabelas do módulo Demanda
- Criação de índices (`idx_tbl_suite_package_version`, `idx_tarefas_demanda`)

---

## Tabelas Removidas / Não Existentes

As seguintes tabelas foram documentadas em versões anteriores mas **não existem** no schema atual:

| Tabela | Status |
|--------|--------|
| `tbl_suite_history` | ❌ Documentada mas nunca criada (use `tbl_suite_historico`) |
| `form_field_registry` | ❌ Documentada mas nunca criada |
| `tbl_despacho_registros` | ⚠️ Criada condicionalmente apenas em migração legada de FK |
