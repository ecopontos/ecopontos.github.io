# Event Protocol — EcoForms Sync

**Versão:** 1.0
**Data:** 2026-04-29

---

## Visão Geral

O sistema de sincronização usa um modelo de **eventos imutáveis** criptografados via AES-256-GCM. Cada dispositivo mantém uma sequência local de eventos que são sincronizados bidirecionalmente através do Supabase Storage.

## Terminologia

| Termo | Definição |
|-------|-----------|
| **Envelope** | Objeto JSON contendo o evento completo com metadados, dados echecksum |
| **routingId** | Identificador do "stream" de eventos (ex: `orgId_setorId`) |
| **seq** | Número sequencial inteiro em um routingId |
| **checksum** | SHA-256 do campo `data` (via stableStringify) |
| **nonce** | 12 bytes aleatórios para AES-GCM |

## Estrutura do Envelope (v2)

```typescript
interface EventEnvelope {
  v: 2;                          // versão do formato
  id: string;                    // UUID do evento
  type: string;                  // tipo do evento (ex: "demanda.criada")
  source: {
    device_id: string;           // ID do dispositivo
    routing_id: string;          // stream de destino
    routing_type: 'setor' | 'user';
    module: string;             // 'desktop' ou 'ecoforms-mobile'
    app_version: string;
  };
  aggregate: {
    type: string;                // entidade (ex: "demanda")
    id: string;                  // ID da entidade
  };
  time: string;                  // ISO 8601
  schema_version: number;
  seq: number;                   // posição no routingId
  prev_event_id: string | null; // encadeamento causal
  correlation_id: string | null;
  causation_id: string | null;
  data: Record<string, unknown>;
  checksum: string;              // "sha256:..." do campo data
}
```

## Tipos de Evento

| Tipo | Agregado | Descrição |
|------|----------|-----------|
| `usuario.criado` | usuario | Novo usuário criado |
| `usuario.atualizado` | usuario | Dados do usuário alterados |
| `demanda.criada` | demanda | Demanda criada |
| `demanda.aceita` | demanda | Demanda aceita por destinatário |
| `demanda.encerrada` | demanda | Demanda concluída |
| `demanda.encaminhada` | demanda | Compartilhamento para setor destino com cópia do registro (AD-024) |
| `demanda.reencaminhada` | demanda | Transferência completa para setor destino (AD-024) |
| `demanda.tarefa.criada` | demanda | Tarefa criada para demanda |
| `demanda.tarefa.concluida` | tarefa | Tarefa marcada como concluída |
| `suite.aprovada` | suite | Suite aprovada |
| `suite.rejeitada` | suite | Suite rejeitada |
| `org.config.atualizado` | org | Configuração organizacional atualizada |
| `ecoforms.registro.criado` | registro | Formulário submetido |

## Criptografia

### PBKDF2 Key Derivation (AD-022)

```
Salt:        sync_salt do usuário em tbl_usuarios (32 bytes hex, aleatório por usuário)
             Fallback: "ecoforms-sync-salt-v1" (fixo, para usuários sem salt)
Iterações:   100.000
Hash:        SHA-256
Output:      32 bytes (AES-256)
```

O salt PBKDF2 é **por usuário**, gerado aleatoriamente (32 bytes) e armazenado em `tbl_usuarios.sync_salt`. Usuários existentes recebem salt automático via migration retroativa. O password do usuário é derivado numa chave a cada login. A chave **nunca é persistida**.

### AES-256-GCM

1. Gerar nonce de 12 bytes aleatórios
2. Cifrar JSON.stringify(data) com AES-GCM
3. Concatenar nonce + ciphertext → blob

## Armazenamento

### Caminhos no Supabase Storage

```
# Eventos criptografados (org-scoped — path novo)
orgs/{orgId}/eventos/{routingId}/evt_{seq}_{id}.enc

# Eventos criptografados (path legado — dual-read)
eventos/{routingId}/evt_{seq}_{id}.enc

# Manifestos (índice de eventos por routingId)
orgs/{orgId}/manifests/manifest_{routingId}.json
# Fallback legado: shared/manifests/manifest_{routingId}.json

# Configuração organizacional
shared/org_config.json
```

### Estrutura do Manifesto

```json
{
  "routing_id": "ecoforms-org-001_setor-coleta",
  "routing_type": "setor",
  "seq": 42,
  "last_event_id": "uuid-aqui",
  "updated_at": "2026-04-29T12:00:00Z"
}
```

## Fluxo de Sincronização

### Push (local → remote)

1. EventBus.publish(type, data) → gera envelope com seq
2. Envelope salvo em sync_event_queue (pending)
3. TransportService.pushPending() → encrypt → upload
4. EventBus.markAsSent() → atualiza status + syncDeviceLog
5. Manifest.update() → atualiza manifesto local

### Pull (remote → local)

1. InboundService.pull(knownRoutingIds)
2. Para cada routingId, verificar manifesto remoto
3. Se seq remoto > seq local: baixar eventos novos
4. Para cada evento: decrypt → EventBus.dispatch()
5. Handlers processam e gravam em tbl_* (IndexedDB)
6. syncDeviceLog atualizado com acked=1

## Handlers

| Evento | Action no Desktop | Action no Mobile |
|--------|-------------------|------------------|
| usuario.criado | INSERT tbl_usuarios | put tbl_usuarios (IndexedDB) |
| demanda.criada | INSERT tbl_demandas | put tbl_demandas |
| demanda.aceita | UPDATE status='aceita' | update tbl_demandas |
| demanda.encerrada | UPDATE status='concluida' | update tbl_demandas |
| demanda.encaminhada | Copia tbl_suite → setor destino + ghost task via `ref_package_id` (AD-024) | — |
| demanda.reencaminhada | Copia tbl_suite → setor destino + ghost task com histórico (AD-024) | — |
| suite.aprovada | UPDATE status='approved' | update tbl_suite |
| suite.rejeitada | UPDATE status='refuted' | update tbl_suite |
| org.config.atualizado | INSERT data_registry | put data_registry |
| ~~ouvidoria.protocolo.aberto~~ | ~~INSERT tblProtocolo~~ → removido (AD-014). Ouvidoria usa eventos genéricos de `tbl_suite`. | — |
| ~~ouvidoria.evento.adicionado~~ | ~~INSERT tblProtocoloEventos~~ → removido (AD-014) | — |

> **AD-014:** Os 4 eventos de ouvidoria foram removidos do `EcoFormsEventType`. O módulo agora usa os eventos genéricos de `tbl_suite` (`ecoforms.registro.criado`) via EventSyncAdapter.

## Idempotência

- syncDeviceLog usa (device_id, seq) como key
- dispatch() verifica se event_id já existe antes de processar
- Duplicate events são ignorados silenciosamente

## Gap Detection & Recovery (AD-021)

Quando `envelope.seq !== localSeq + 1`, o `InboundService` **não interrompe mais o pull**. Em vez disso:

1. Para cada seq faltante, busca o arquivo `evt_{seq}_*.enc` no Storage (path org-scoped e fallback legado)
2. Se encontrado: baixa, descriptografa e processa normalmente
3. Se não encontrado: registra em `sync_gap_log` e incrementa `attempts`
4. Após `MAX_GAP_ATTEMPTS = 3`, marca como `unresolvable` e **continua sem bloquear** — handlers são idempotentes (`INSERT OR IGNORE`)

A tabela `sync_gap_log` registra todas as ocorrências para diagnóstico de problemas de rede.

## Referências

- Desktop: `desktop/src/infrastructure/sync/`
- Mobile: `www/js/sync/`
- Schema SQLite: `src-tauri/src/database.rs` (sync_event_queue, sync_device_log)