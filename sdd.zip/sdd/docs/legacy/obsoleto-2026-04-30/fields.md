# Sistema de Campos — Referência Completa

> **Contexto:** Este documento detalha os **campos individuais**. Para a **orquestração** (como o JSON do `form_registry.conteudo` se torna um formulário completo no DOM, como dados são enriquecidos via `dataSource`, e como o FieldFactory resolve tipos), veja [form-builder.md](form-builder.md).

## Visão Geral

O sistema de campos do ecoforms0 é composto por:

- **BaseField** (`www/js/fields/types/BaseField.js`) — classe base que todos os campos herdam
- **FieldFactory v2** (`www/js/fields/FieldFactory.v2.js`) — cria instâncias de campos modernizados
- **FieldFactory legacy** (`www/js/fields/FieldFactory.js`) — fallbacks de compatibilidade
- **defaults.js** (`www/js/fields/defaults.js`) — centraliza valores default e formatação de data/hora
- **presenceHelpers.js** (`www/js/fields/utils/presenceHelpers.js`) — helpers para PresenceField

---

## BaseField — Classe Base

### Parâmetros aceitos no `config`

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `id` | `string` | *(obrigatório)* | Identificador único do campo |
| `name` | `string` | `sanitizeId(id)` | Nome do campo no formData |
| `label` | `string` | `''` | Rótulo exibido acima do input |
| `placeholder` | `string` | `''` | Placeholder HTML |
| `required` | `boolean` | `false` | Torna o campo obrigatório |
| `description` | `string` | `''` | Texto auxiliar abaixo do campo |
| `helpText` | `string` | `''` | Texto de ajuda (ícone ℹ️) |
| `validation` | `object` | `{}` | Validadores (ver abaixo) |
| `attributes` | `object` | `{}` | Atributos HTML extras |
| `value` | `any` | *ver defaults* | Valor inicial explícito |
| `defaultValue` | `any` | *ver defaults* | Valor default quando vazio |
| `defaultToNow` | `boolean` | `false` | Para date/time: preenche com data/hora atual (Brasil) |
| `type` | `string` | `'text'` | Tipo do campo |
| `Alpine` | `Alpine` | `window.Alpine` | Instância Alpine para registro |
| `...config` | `any` | — | Qualquer propriedade extra é copiada para `this.config` |

### Objeto `validation`

```javascript
{
  minLength: number,        // Comprimento mínimo de string
  maxLength: number,        // Comprimento máximo de string
  pattern: RegExp | string, // Regex para validação
  patternMessage: string,  // Mensagem quando pattern falha
  custom: Function,         // fn(value, config) => string|null de erro
  email: boolean            // Validação de formato email (automático se type='email')
}
```

### getValue()

Retorna `this.value` — o valor brutonão processado.

```javascript
getValue() {
  return this.value;
}
```

Para campos v2 (que usam Alpine stores), o valor é lido/escrito no store:

```javascript
Alpine.store('form').getFieldValue(fieldId)  // leitura
Alpine.store('form').setFieldValue(fieldId, value)  // escrita
```

### setValue(value)

1. Armazena o valor em `this.value`
2. Marca `isDirty = true` se o valor mudou
3. Atualiza `this.$root.formData[this.id]` se `$root` existir
4. Se `isTouched`, executa `validate()`
5. Dispara `onValueChange(newValue, oldValue)`

```javascript
setValue(value) {
  const oldValue = this.value;
  this.value = value;
  this.isDirty = oldValue !== value;

  if (this.$root && this.$root.formData) {
    this.$root.formData[this.config.id] = value;
  }

  if (this.isTouched) {
    this.validate(value);
  }
  this.onValueChange(value, oldValue);
}
```

### Compatibilidade backwards: `config.config`

Se o formulário agrupar propriedades em `campo.config.dataSource`, elas são elevadas (`hoisted`) para o nível superior de `this.config`.

---

## Tipos de Campo

### 1. TextInputField (`text`)

**Classe:** `TextInputFieldV2` em `FieldFactory.v2.js`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `id` | `string` | — |
| `type` | `'text'` | — |
| `label` | `string` | — |
| `placeholder` | `string` | — |
| `required` | `boolean` | `false` |
| `maxlength` | `number` | — |
| `pattern` | `string` | — |
| `dataSource` | `string` | — | Habilita modo autocomplete |
| `source` | `string` | — | Alias para `dataSource` |

#### getValue()

```javascript
Alpine.store('form').getFieldValue(fieldId)  // => string
```

#### setValue(value)

```javascript
Alpine.store('form').setFieldValue(fieldId, value)  // string
```

#### Variantes

- **Simples** — input text padrão
- **Autocomplete** — quando `dataSource` ou `source` está definido, usa `window.useFieldOptions(field)` para carregar opções e filtra client-side

---

### 2. TextareaField (`textarea`)

**Classe:** `TextareaFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `rows` | `number` | `4` |
| `maxlength` | `number` | — |
| `placeholder` | `string` | — |
| `autoResize` | `boolean` | — | Auto-ajusta altura pelo conteúdo |
| `showCounter` | `boolean` | `true` se `maxlength` setado |

#### getValue() → `string`
#### setValue(value) → `string`

---

### 3. NumberInputField (`number`)

**Classe:** `NumberInputFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `min` | `number` | — |
| `max` | `number` | — |
| `step` | `string` | `'any'` |
| `placeholder` | `string` | — |

#### getValue() → `number`
#### setValue(value) → `number`

Validação via atributos HTML `min`/`max`/`step`.

---

### 4. SelectField (`select`)

**Classe:** `SelectFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `multiple` | `boolean` | `false` | Habilita seleção múltipla |
| `emptyOptionLabel` | `string` | `'Selecione...'` | Label da opção vazia |
| Opções | — | Via `window.useFieldOptions(field)` | Carrega opções assincronamente |

#### getValue()

| Modo | Retorno |
|------|---------|
| `multiple: false` | `string` (valor único) |
| `multiple: true` | `string[]` (array de valores) |

#### setValue(value)

Mesmos formatos acima.

---

### 5. RadioField (`radio`)

**Classe:** `RadioFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `layout` | `'vertical'` \| `'horizontal'` | `'vertical'` |

Opções via `window.useFieldOptions(field)`.

#### getValue() → `string` (valor selecionado)
#### setValue(value) → `string`

---

### 6. CheckboxField (`checkbox`)

**Classe:** `CheckboxFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `multiple` | `boolean` | `true` | `false` = checkbox único booleano |
| `layout` | `'vertical'` \| `'horizontal'` | `'vertical'` |
| `description` | `string` | — | Exibida abaixo do label (checkbox único) |

#### getValue()

| Modo | Retorno |
|------|---------|
| `multiple: false` | `boolean` |
| `multiple: true` | `string[]` (valores marcados) |

#### setValue(value)

Mesmos formatos.

---

### 7. ChipsField (`chips`)

**Classe:** `ChipsFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `multiple` | `boolean` | `true` |
| Opções | — | Via `window.useFieldOptions(field)` |

#### getValue()

| Modo | Retorno |
|------|---------|
| `multiple: true` | `string[]` |
| `multiple: false` | `string \| null` |

#### setValue(value) → `string[]` ou `string`

#### Variantes

- **multiple: true** — chipes selecionáveis com botão de remover; opções disponíveis filtram chips já selecionados
- **multiple: false** — um chip selecionado por vez

---

### 8. DateField (`date`)

**Classe:** `DateFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `min` | `string` (`YYYY-MM-DD`) | — |
| `max` | `string` (`YYYY-MM-DD`) | — |
| `autoCurrent` | `boolean` | — | Alias para `defaultToNow` |
| `defaultToNow` | `boolean` | `false` | Preenche data atual se vazio |

#### getValue() → `string` formato `YYYY-MM-DD`
#### setValue(value) → `string` (`YYYY-MM-DD`)

#### autoCurrent / defaultToNow

Se `true` **e** o campo estiver vazio na inicialização, preenche com a data atual no fuso `America/Sao_Paulo`.

---

### 9. TimeField (`time`)

**Classe:** `TimeFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `min` | `string` (`HH:MM`) | — |
| `max` | `string` (`HH:MM`) | — |
| `step` | `number` | — | Segundos |
| `autoCurrent` | `boolean` | — | Alias para `defaultToNow` |
| `defaultToNow` | `boolean` | `false` | Atualiza a cada 60s se vazio |

#### getValue() → `string` formato `HH:MM`
#### setValue(value) → `string` (`HH:MM`)

#### autoCurrent behavior

- Na inicialização: se vazio, preenche com hora atual
- A cada 60 segundos: repreenche **somente se** o usuário não modificou manualmente (`inputEl.dataset.modified !== 'true'`)
- O flag `modified` é setado no primeiro `input` do usuário

---

### 10. GPSField (`gps`)

**Classe:** `GPSFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `autoCapture` | `boolean` | `false` | Captura automática ao carregar |
| `enableHighAccuracy` | `boolean` | `false` | `enableHighAccuracy` da API Geolocation |

#### getValue() → `object`

```javascript
{
  latitude: string,   // ex: "-23.123456"
  longitude: string,  // ex: "-46.123456"
  accuracy: number,   // metros
  timestamp: string   // ISO 8601
}
```

#### setValue(value) → `object`

Lê `value.latitude`, `value.longitude`, `value.accuracy` e atualiza o estado local.

#### Erros de geolocalização

| code | Condição |
|------|----------|
| 1 | Permissão negada |
| 2 | Posição indisponível |
| 3 | Timeout (10s) |

---

### 11. CameraField (`camera` / `photo`)

**Classe:** `CameraFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `maxWidth` | `number` | `1920` |
| `maxHeight` | `number` | `1080` |
| `quality` | `number` | `0.8` (JPEG) |

#### getValue() → `object`

```javascript
{
  dataUrl: string,    // base64 da imagem
  size: string,       // ex: "123.4 KB" ou "1.2 MB"
  timestamp: string,  // ISO 8601
  filename: string    // nome original do arquivo
}
```

#### setValue(value) → `object`

Lê `value.dataUrl` e `value.size` para exibir preview.

#### Métodos de captura

- **Câmera mobile:** `<input capture="environment">` para câmera traseira
- **Galeria:** `<input type="file">` normal para escolher arquivo

Imagem é redimensionada automaticamente mantendo aspect ratio.

---

### 12. GalleryField (`gallery`)

**Classe:** `GalleryFieldV2`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `maxWidth` | `number` | `1920` |
| `maxHeight` | `number` | `1080` |
| `quality` | `number` | `0.8` |

#### getValue() → `object[]`

```javascript
[
  { dataUrl, size, timestamp, filename },
  { dataUrl, size, timestamp, filename }
]
```

#### setValue(value) → `object[]`

---

### 13. GroupField (`group`)

**Classe:** `GroupField` (legado)

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `campos` | `array` | — | Array de configs de subcampos |

#### getValue() → `object`

```javascript
{
  fieldId1: value1,
  fieldId2: value2
  // Apenas campos com valor não-vazio
}
```

#### setValue(value) → `object`

Itera os subcampos e chama `field.setValue(value[fieldId])` quando presente.

#### Estrutura

Renderiza como `<fieldset>` com `<legend>`. Subcampos são criados via `FieldFactory.create()` com o mesmo `formData` e `Alpine`.

---

### 14. RepeatableGroupField (`repeatable_group` / `repeatable`)

**Classe:** `RepeatableGroupField`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `campos` | `array` | — | Schema de subcampos para cada item |
| `config.minItems` | `number` | `0` | Mínimo de itens |
| `config.maxItems` | `number` | `Infinity` | Máximo de itens |
| `config.addButtonLabel` | `string` | `'Adicionar Item'` | |
| `config.removeButtonLabel` | `string` | `'Remover'` | |
| `config.itemLabel` | `string` | `'Item'` | Label por item |
| `sourceMode` | `'manual'` \| `'seed-on-init'` | *ver lógica abaixo* | |
| `rawData` | `array` | — | Dados inline para seed |
| `dataSource` | `string` | — | Caminho/ID para dados externos |
| `prefillMapping` | `array \| object` | — | Mapeamento source → target |
| `formData` | `object` | — | Referência compartilhada do formData |

#### sourceMode — Lógica de decisão

```
Se config.sourceMode = 'manual' ou 'seed-on-init'  → usa o configurado
Se rawData.length > 0 ou dataSource existe         → 'seed-on-init'
Caso contrário                                        → 'manual'
```

#### getValue() → `array`

```javascript
[
  { fieldId1: value1, fieldId2: value2 },
  { fieldId1: value3, fieldId2: value4 }
]
```

#### setValue(value) → `array`

`value` **deve** ser um array. Normaliza e reconstrói todas as instâncias de item.

#### ID das instâncias

Formato: `${groupId}_${index}_${fieldConfig.id}`
Exemplo: `equipe_0_nome`, `equipe_1_nome`

Isso garante unicidade no formData mesmo com múltiplas instâncias.

#### Prefill Mappings

```javascript
// Array形式
[{ source: 'externalField', target: 'internalField' }]

// Object形式 (invertido)
{ target: 'source' }
```

Se não especificado, faz correspondência direta por `fieldConfig.id`.

#### Data Loading Priority

1. `rawData` (inline)
2. `window.rawDataSources[dataSource]`
3. `window.smartCache.loadDataSource(dataSource)`
4. `window.smartCache.fetchLocalData(dataSource)`
5. `fetch(data/${dataSource}.json)`

#### syncFormData()

A cada alteração (input/change nos subcampos), sincroniza `formData[groupId]` com o valor serializado dos itens.

---

### 15. PresenceField (`presence`)

**Classe:** `PresenceField`

#### Config

| Parâmetro | Tipo | Default |
|-----------|------|---------|
| `variant` | `'compact'` \| `'selector'` \| `'list'` | *auto-detectado* |
| `participants` | `array` | — | Array de pessoas |
| `rawData` | `array` | — | Alias para `participants` |
| `groupField` | `string` | `'nome_galpao'` | Campo que filtra participantes |
| `groupKey` | `string` | `'galpao'` | Chave no participant object |
| `hideUntilGroup` | `boolean` | `false` | Só mostra quando `groupField` tem valor |
| `participantLabelKey` | `string` | `'nome'` | Chave do nome no participant |
| `columns` | `1` \| `2` | `1` | Colunas no variant `compact` |
| `statusSequence` | `string[]` | `['presente','ausente','desligado']` | |
| `statusColors` | `object` | `{}` | Mapeamento status → cor hex |
| `statusLabels` | `object` | `{}` | Mapeamento status → label |
| `defaultStatus` | `string` | — | Status inicial |
| `useSmartFilters` | `boolean` | — | Para variant `selector` |
| `filterOptions` | `array` | — | Opções de filtro |

#### getValue() → `object`

```javascript
{
  statuses: { participantId: 'presente', participantId2: 'ausente' },
  summary: { presente: 5, ausente: 2, desligado: 1 },
  timestamp: string  // ISO 8601 da última alteração
}
```

#### setValue(value) → `object`

Restaura `value.statuses`.

#### groupField / hideUntilGroup

```
hideUntilGroup = true
  → participants = participants.filter(p => getGroupValue(formData, groupField) === p[groupKey])

hideUntilGroup = false ou groupField vazio
  → mostra todos os participants
```

**getGroupValue** primeiro tenta `formData[groupField]`, depois fallback para DOM (`[name="${groupField}"]` ou `#${groupField}`).

#### Sentinel values

Se o valor do groupField for `__none__`, `__null__`, `__empty__` ou `null/undefined/''`, `isSentinel()` retorna `true` e o campo fica oculto quando `hideUntilGroup=true`.

#### Variants

| Variant | Descrição |
|---------|-----------|
| `compact` | Grid 1 ou 2 colunas com botões toggle de status, chips de filtro, resumo |
| `selector` | Grid paginado com filtros smart e lista de selecionados |
| `list` | Linhas com radio buttons, resumo ao final |

---

## Defaults — computeDefaultValue

Centraliza o valor default de todos os campos. Usa fuso `America/Sao_Paulo`.

| Tipo | Quando `value` null/undefined | Comportamento |
|------|-------------------------------|---------------|
| `datetime-local` / `datetime` | `defaultToNow: true` | `YYYY-MM-DDTHH:MM` |
| `date` | `defaultToNow: true` | `YYYY-MM-DD` |
| `time` | `defaultToNow: true` | `HH:MM` |
| `number` | sempre | `0` |
| `checkbox` | sempre | `false` |
| `chips` / `chipsmultiple` | sempre | `[]` |
| `select` / `radio` | sem `defaultValue` | `multiple ? [] : ''` |
| `file` | sempre | `null` |
| `text` / outro | sem `defaultValue` | `''` |

Se `config.value` está definido, **ignora todos os defaults** e usa esse valor.

---

## Dependências Entre Campos

### groupField / hideUntilGroup

Usado **somente** em `PresenceField`. Ver documentação do PresenceField acima.

### parentGroupId / itemIndex (RepeatableGroup)

Subcampos dentro de um `RepeatableGroupField` recebem:

- `parentGroupId` — ID do grupo repetível pai
- `itemIndex` — índice numérico da instância do item

---

### 16. EntityPickerRenderer (`entity_picker`) — AD-010/AD-017

**Desktop apenas.** Renderizado por `EntityPickerRenderer.tsx` em `FormFieldRenderer`.

#### Config

```json
{
  "type": "entity_picker",
  "config": {
    "entityType": "pj",
    "searchFields": ["nome", "documento"],
    "displayTemplate": "{nome} — {documento}"
  },
  "label": "Cliente",
  "required": true
}
```

| Propriedade | Tipo | Obrigatório | Descrição |
|-------------|------|-------------|-----------|
| `config.entityType` | `"pj" \| "pf" \| "ecoponto" \| "cooperativa" \| "galpao"` | Sim | Qual tabela do Entity Registry consultar |
| `config.searchFields` | `string[]` | Não | Campos usados na busca textual (atualmente hardcoded: nome/documento) |
| `config.displayTemplate` | `string` | Não | Template de exibição do item selecionado (atualmente hardcoded: `{nome} — {documento}`) |

> **Simplificação atual:** `searchFields` e `displayTemplate` são hardcoded baseados no `entityType`. Isso é suficiente para os três tipos atuais (pj, pf, ecoponto). Serão reintroduzidos como campos configuráveis quando o ModuleBuilder (Sprint 6) precisar de entity_pickers com exibição customizada.

#### Funcionamento

1. Ao montar, carrega a lista de entidades via `loadCrmDataSource(dataSourceName)` — mapeia `entityType` → nome do resolver em `crm-datasources.ts`:
   - `pj` → `clientes_crm` (tblPJuridicas ativas)
   - `pf` → `pessoas_fisicas_crm` (tblPFisicas ativas)
   - `ecoponto` → `ecopontos_crm` (tbl_ecopontos ativos)
   - `cooperativa` → `cooperativas_crm`
   - `galpao` → `galpoes_crm`
2. Input de texto filtra a lista client-side por nome/documento
3. Dropdown mostra resultados com match highlighting
4. Ao selecionar: armazena o `id` da entidade como `string`
5. `SubmitSuiteUseCase` extrai `entity_picker.value` e popula `entity_id` + `entity_type` em `tbl_suite` automaticamente

#### Read Only

No `ReadOnlyFormRenderer`, exibe o ID da entidade selecionada em badge monoespaçado.

#### getValue / setValue

| `getValue()` | `setValue(valor)` |
|---|---|
| `string` (ID da entidade) | `string` (ID da entidade) |
- `originalId` — ID original do campo no schema

Isso permite que o campo saiba sua posição na hierarquia e que o `RepeatableGroupField` possa sincronizar corretamente com `formData`.

### Alpine Store Integration (campos v2)

Todos os campos v2 usam `Alpine.store('form')`:

```javascript
// Leitura
Alpine.store('form').getFieldValue(fieldId)
// ou diretamente
$store.form.data[fieldId]

// Escrita
Alpine.store('form').setFieldValue(fieldId, value)
```

Cada campo expõe `getAlpineData()` retornando um objeto com:
- Estado reativo (`options`, `loading`, `error`, etc.)
- `init()` — carrega valor inicial do store
- Métodos helpers que chamam `setFieldValue()` ao alterar

---

## Resumo — getValue() por tipo

| Tipo | Retorno | Exemplo |
|------|---------|---------|
| `text` | `string` | `"João Silva"` |
| `textarea` | `string` | `"Descrição..."` |
| `number` | `number` | `42` |
| `select` (single) | `string` | `"opcao1"` |
| `select` (multiple) | `string[]` | `["op1","op2"]` |
| `radio` | `string` | `"op1"` |
| `checkbox` (single) | `boolean` | `true` |
| `checkbox` (multiple) | `string[]` | `["a","b"]` |
| `chips` (multiple) | `string[]` | `["chip1","chip2"]` |
| `chips` (single) | `string \| null` | `"chip1"` |
| `date` | `string` | `"2026-04-28"` |
| `time` | `string` | `"14:30"` |
| `gps` | `{latitude, longitude, accuracy, timestamp}` | `{-23.123,-46.456,10,"ISO"}` |
| `camera` | `{dataUrl, size, timestamp, filename}` | dados da foto |
| `gallery` | `object[]` | array de fotos |
| `group` | `{fieldId: value, ...}` | subcampos |
| `repeatable_group` | `[{...}, {...}]` | array de itens |
| `presence` | `{statuses: {}, summary: {}, timestamp}` | presenças |
| `entity_picker` | `string` (ID da entidade) | desktop apenas — seleciona entidade do Entity Registry |

---

## Resumo — setValue() por tipo

| Tipo | Aceita | Notas |
|------|--------|-------|
| `text`, `textarea`, `number` | valor primitivo | string ou number |
| `select`, `radio` | `string` | valor único |
| `select` (multiple), `checkbox` (multiple), `chips` | `array` | array de strings |
| `checkbox` (single) | `boolean` | |
| `date`, `time` | `string` | formato ISO ou `YYYY-MM-DD`/`HH:MM` |
| `gps` | `object` com `latitude`, `longitude`, `accuracy` | |
| `camera` | `object` com `dataUrl`, `size` | para preview |
| `gallery` | `object[]` | array de objetos de foto |
| `group` | `object` | mapa de fieldId → valor |
| `repeatable_group` | `array` | **deve ser array** |
| `presence` | `object` com `statuses` | |
| `entity_picker` | `string` | ID da entidade |

---

## Notas de Implementação

- Todas as coordenadas de GPS são negativas no Brasil (hemisfério sul)
- `getBrazilDateTimeParts()` usa `Intl.DateTimeFormat` com `timeZone: 'America/Sao_Paulo'`
- IDs de campo são normalizados via `sanitizeId()` — espaços/hífens se tornam underscores
- O sistema de validação é **síncrono** — validadores customizados `validation.custom` são fns diretas, não promessas
- RepeatableGroupField sincroniza subcampos para o `formData` de dois jeitos: via `x-model` no hidden input e via `syncFormData()` no Alpine data
