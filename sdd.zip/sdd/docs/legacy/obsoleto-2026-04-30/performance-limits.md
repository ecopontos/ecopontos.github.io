# Performance & Limits — EcoForms Desktop

Este documento define os limites de tamanho,吞吐量, e benchmarks de performance do sistema EcoForms Desktop.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `arquitetura.md` | Visão geral da arquitetura e sync |
| `error-handling.md` | Retry logic e dead letter queue |
| `api-contract.md` | Formatos de payload e storage messages |
| `adr.md` | AD-007: JSON puro para sync |

---

## Índice

1. [Limites de Storage](#1-limites-de-storage)
2. [Limites de Payload](#2-limites-de-payload)
3. [Limites de Sync](#3-limites-de-sync)
4. [Benchmarks de Compressão](#4-benchmarks-de-compressão)
5. [SLAs e Timeout Limits](#5-slas-e-timeout-limits)
6. [Cálculo de Custos](#6-cálculo-de-custos)

---

## 1. Limites de Storage

### 1.1 Supabase Storage (Free Tier)

| Recurso | Limite | Aplicação |
|---------|--------|-----------|
| Storage total | 1 GB | Snapshots JSON.gz, avatares, assets |
| Transfer mensal | 2 GB | Downloads/uploads de snapshots |
| Largura de banda | 4 Mbps | Taxa de transferência sustentada |
| Tamanho máximo por arquivo | 50 MB | Snapshots individuais |
| Requests simultâneos | 10 | Conexões simultâneas ao Storage |

### 1.2 SQLite Local

| Recurso | Limite Prático | Notas |
|---------|---------------|-------|
| Tamanho máximo do banco | 100 GB | Limitação teórica do SQLite |
| Tabela única | 1 TB | Page size 4KB, max 2^63 pages |
| ROWID máximo | 2^63 | Praticamente ilimitado |
| Query timeout | 30s | Para queries complexas com JOINs |

### 1.3 IndexedDB (Offline Queue)

| Recurso | Limite | Notas |
|---------|--------|-------|
| Storage por origem | 50 MB | Chrome/Firefox limit |
| Storage total | 100 MB | Browsers mais recentes |
| Transações simultâneas | 5 | Conexões simultâneas |
| Tamanho máximo por item | 10 MB | Para mutações grandes |

---

## 2. Limites de Payload

### 2.1 Supabase Storage Upload

| Parâmetro | Limite | Implementação |
|-----------|--------|---------------|
| Upload máximo | 50 MB | Limite do Supabase Storage |
| Headers HTTP | 8 KB | Inclui auth token |
| Query string | 2 KB | URLs de download |

### 2.2 Payload do Snapshot (JSON)

```ts
interface SyncSnapshot {
    version: string;              // "2.0"
    timestamp: number;            // Unix timestamp (ms)
    device_id: string;            // Identificador do dispositivo
    metadata: {
        checksum: string;         // SHA-256 do data
        record_count: number;
        file_size_bytes: number;  // Tamanho do arquivo
    };
    data: any[];                  // Array de registros
}
```

### 2.3 Tamanho Estimado por Registro

| Tipo de Registro | Tamanho JSON (bytes) | Notas |
|-----------------|---------------------|-------|
| `tbl_suite` | 2,000 - 10,000 | Depende do número de campos |
| `form_registry` | 500 - 2,000 | Metadados do formulário |
| `form_field_registry` | 1,000 - 5,000 | Campos dos formulários |
| `data_registry` | 1,000 - 50,000 | Dados variáveis por form |
| `tbl_usuarios` | 300 - 1,000 | Perfil do usuário |
| `ecoponto_caixas` | 5,000 - 20,000 | Dados de ocupação das caixas |

### 2.4 Limites de Campos por Tabela

| Tabela | Colunas | Limite de Campo | Notas |
|--------|---------|-----------------|-------|
| `tbl_suite` | 30 | Text: 1 MB | JSON storage para dados variáveis |
| `form_registry` | 25 | Text: 10 MB | Schema e UI config |
| `data_registry` | 20 | Text: 50 MB | Respostas grandes |
| `tbl_tarefas` | 35 | Text: 1 MB | Histórico de transições |
| `tbl_clientes` | 40 | Text: 500 KB | Dados diversos |
| `tbl_usuarios` | 25 | Blob: 5 MB | Avatar |

### 2.5 Limites de Dados por Formulário

| Tipo de Dados | Limite | Notas |
|---------------|--------|-------|
| Texto simples | 1 MB | Campo único |
| Texto longo (textarea) | 10 MB | Descrições, observações |
| JSON estruturado | 1 MB | Dados ad hoc |
| Anexos (校外) | 50 MB | Limite do Supabase Storage |
| Imagens inline (base64) | 5 MB | Não recomendado - usar URL |

---

## 3. Limites de Sync

### 3.1 Tamanho de Batch

| Operação | Limite | Configurável |
|----------|--------|--------------|
| Registros por sync batch | 500 | `SYNC_BATCH_SIZE` |
| Registros por upsert chunk | 100 | `UPSERT_CHUNK_SIZE` |
| Arquivos por listing | 100 | `STORAGE_LIST_LIMIT` |
| Mutações na offline queue | Unlimited | IndexedDB |

### 3.2 Configurações de Sync

```ts
// lib/config/sync-config.ts

export const SYNC_CONFIG = {
    // Batch processing
    BATCH_SIZE: 500,                    // Registros por batch
    UPSERT_CHUNK_SIZE: 100,             // Chunk size para upserts
    STORAGE_LIST_LIMIT: 100,            // Limite por listing

    // Timeouts (ms)
    PUSH_TIMEOUT: 30000,                // 30s para push
    PULL_TIMEOUT: 60000,                // 60s para pull
    VALIDATION_TIMEOUT: 10000,          // 10s para validação

    // Retry
    MAX_RETRIES: 3,
    RETRY_INITIAL_DELAY: 1000,          // 1s
    RETRY_MAX_DELAY: 30000,             // 30s
    RETRY_BACKOFF_FACTOR: 2,

    // Archive
    ARCHIVE_RETENTION_DAYS: 90,         // Manter snapshots por 90 dias
    ARCHIVE_BATCH_SIZE: 50,             // Arquivos por limpeza
};
```

### 3.3 Limites por Tipo de Operações

| Operações | Limite/Batch | Frequência Máxima |
|-----------|-------------|------------------|
| Push `tbl_suite` | 500 registros | A cada sync |
| Push `form_registry` | 200 registros | A cada sync |
| Push `form_field_registry` | 200 registros | A cada sync |
| Push `data_registry` | 200 registros | A cada sync |
| Push `users` | 100 usuários | A cada sync |
| Pull snapshots | 100 arquivos | A cada sync |
| Process inbox | 50 snapshots | A cada sync |

### 3.4 Throughput Estimado

| Cenário | Throughput | Notas |
|---------|-----------|-------|
| Push 500 `tbl_suite` | ~2-5 MB/min | Depende de latência de rede |
| Push 200 `form_registry` | ~1-2 MB/min | JSON leve |
| Pull 50 snapshots | ~5-10 MB/min | Downloads paralelos |
| Sync completo (500 registros) | ~30-60s | Ciclo completo |

---

## 4. Benchmarks de Performance

### 4.1 Tamanhos de Dados Típicos

| Tipo de Dado | Tamanho Médio | Exemplo |
|--------------|--------------|---------|
| JSON estruturado (tbl_suite) | 2-10 KB | Registro de formulário |
| JSON com texto longo | 10-50 KB | Formulário com observações |
| JSON repetitivo (arrays) | 5-20 KB | Lista de registros |
| Dados uniformes | 1-5 KB | Configurações |

### 4.2 Testes de Compressão

```
Dataset: 500 registros tbl_suite (casos típicos)
─────────────────────────────────────────────────
JSON raw size:        1.2 MB
Gzip (level 6):      125 KB
Ratio:                9.6x
Tempo compressão:    ~50ms (Node.js/pako)

Dataset: 100 registros form_registry
─────────────────────────────────────────────────
JSON raw size:        80 KB
Gzip (level 6):      15 KB
Ratio:                5.3x
Tempo compressão:    ~10ms

Dataset: 50 registros data_registry (dados mistos)
─────────────────────────────────────────────────
JSON raw size:        5 MB
Gzip (level 6):      800 KB
Ratio:                6.25x
Tempo compressão:    ~100ms
```

### 4.3 Performance de Decompressão

```
Dispositivo: Notebook Windows (Intel i5, 8GB RAM)
──────────────────────────────────────────────────
Decompressão 1MB JSON:     ~10-20ms
Decompressão 5MB JSON:     ~50-80ms
Decompressão 10MB JSON:    ~100-200ms

Dispositivo: Desktop velho (4GB RAM)
──────────────────────────────────────────────────
Decompressão 1MB JSON:     ~20-40ms
Decompressão 5MB JSON:     ~100-150ms
Decompressão 10MB JSON:    ~200-350ms
```

### 4.4 Comparativo de Tamanho de Snapshot

| Componentes | JSON (KB) | Notas |
|-------------|-----------|-------|
| 100 `tbl_suite` | 200 | Registros de formulários |
| 50 `form_registry` | 50 | Metadados de formulários |
| 100 `data_registry` | 500 | Dados de referência |
| 20 `tbl_usuarios` | 10 | Perfis de usuários |
| 10 `ecoponto_caixas` | 100 | Dados de ocupação |
| **Total** | **860** | Snapshot completo |

---

## 5. SLAs e Timeout Limits

### 5.1 Timeouts Globais

| Timeout | Valor | Aplicação |
|---------|-------|-----------|
| HTTP Request | 30s | Upload/download básico |
| Upload grande (>5MB) | 60s | Com chunking |
| Pull completo | 120s | Sync cycle completo |
| Query SQLite | 30s | Queries complexas |
| Validação Snapshot | 10s | Parse + checksum |

### 5.2 Retry Schedule

```
Attempt 0: immediate (ou delay inicial de 1000ms)
Attempt 1: delay = 1000ms  (1s)
Attempt 2: delay = 2000ms  (2s)
Attempt 3: delay = 4000ms  (4s)
Attempt 4: delay = 8000ms  (8s)  ← última tentativa
Attempt 5: N/A — max retries reached
```

### 5.3 Latência de Rede

| Cenário | Latência Típica | Notas |
|---------|----------------|-------|
| Local (mesma rede) | 1-5ms | WiFi rápido |
| Internet Brasil (SP→EUA) | 100-200ms | Rotas variáveis |
| Supabase (EUA) | 150-250ms | Latênciaida + return |
| CDN (assets) | 20-50ms | CloudFront |

### 5.4 Estimativa de Tempo de Sync

| Tamanho Total | Latência | Tempo Estimado |
|---------------|----------|----------------|
| 100 KB payload | 200ms | 0.5-2s |
| 1 MB payload | 200ms | 3-8s |
| 5 MB payload | 200ms | 15-40s |
| 10 MB payload | 200ms | 30-80s |
| 50 MB payload | 200ms | 2-5min (chunked) |

**Fórmula:** `tempo = compress_time + (latência × chunks) + decompress_time`

### 5.5 Limites de Rate Limiting

| Endpoint | Limite | Janela | Ação em Excesso |
|----------|--------|--------|-----------------|
| Storage Upload | 100 requests | por minuto | 429 + retry após 60s |
| Storage Download | 200 requests | por minuto | 429 + retry após 30s |
| Auth Refresh | 10 requests | por minuto | 429 + cache token |

### 5.6 SLAs de Uptime

| Serviço | Uptime | Notes |
|---------|--------|-------|
| Supabase Storage | 99.9% | SLA oficial |
| Supabase Auth | 99.9% | MFA redundancy |
| EcoForms Desktop | N/A | Offline-first, não depende de serviços externos |

---

## 6. Cálculo de Custos

### 6.1 Cenário: 10 Usuários, 100 Formulários/Mês

| Recurso | Uso Mensal | Limite Livre | Custo |
|---------|------------|--------------|-------|
| Storage | 50 MB | 1 GB | $0 |
| Transfer | 500 MB | 2 GB | $0 |
| Auth | 5,000 requests | Ilimitado | $0 |
| **Total** | | | **$0/mês** |

### 6.2 Cenário: 50 Usuários, 1,000 Formulários/Mês

| Recurso | Uso Mensal | Limite Livre | Custo |
|---------|------------|--------------|-------|
| Storage | 300 MB | 1 GB | $0 |
| Transfer | 5 GB | 2 GB | ~$3 (por GB extra) |
| Auth | 25,000 requests | Ilimitado | $0 |
| **Total** | | | **~$9/mês** |

### 6.3 Cenário: 100 Usuários, 5,000 Formulários/Mês

| Recurso | Uso Mensal | Limite Livre | Custo |
|---------|------------|--------------|-------|
| Storage | 1.5 GB | 1 GB | $2.50 (~$0.02/GB) |
| Transfer | 25 GB | 2 GB | ~$46 (por GB extra) |
| Auth | 100,000 requests | Ilimitado | $0 |
| **Total** | | | **~$50/mês** |

### 6.4 Otimizações de Custo

| Técnica | Redução | Implementação |
|---------|---------|---------------|
| JSON puro | Compatibilidade universal | Sem compressão |
| Incremental sync | 10-50x | SHA-256 hash cache |
| Batch uploads | 3-5x |减少 requests HTTP |
| Archive cleanup | 50% | Remove snapshots > 90 dias |
| Delta updates | 5-15x | Apenas mudanças |

### 6.5 Projeção de Crescimento

| Usuários | Storage/Mês | Transfer/Mês | Custo Estimado |
|----------|-------------|--------------|----------------|
| 10 | 50 MB | 500 MB | $0 |
| 25 | 150 MB | 2 GB | ~$5 |
| 50 | 400 MB | 8 GB | ~$15 |
| 100 | 1 GB | 25 GB | ~$50 |
| 250 | 3 GB | 80 GB | ~$150 |
| 500 | 8 GB | 200 GB | ~$400 |

---

## Resumo de Limites

| Categoria | Limite | Notas |
|-----------|--------|-------|
| Upload arquivo | 50 MB | Supabase Storage |
| Snapshot (JSON) | 10-50 MB | Depende do tipo |
| Registros por batch | 500 | Configurável |
| Retry attempts | 3 | Com backoff exponencial |
| Offline queue | Unlimited | IndexedDB |
| Storage Supabase | 1 GB | Free tier |
| Transfer mensal | 2 GB | Free tier |
| Row size SQLite | 1 MB | Prático |
| DB size SQLite | 100 GB | Prático |

---

## Recomendações de Performance

1. **Manter snapshots pequenos**: Ideal < 5 MB
2. **Usar sync incremental**: Apenas registros modificados
3. **Limpar archive regularmente**: Manter < 100 MB em uso
4. **Usar JSON puro**: Sem compressão para compatibilidade
5. **Batchar mutações**: Agrupar em batches de 100-500
6. **Monitorar latência**: Alertas quando > 500ms