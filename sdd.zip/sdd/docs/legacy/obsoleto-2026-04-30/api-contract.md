# Contrato de API — EcoForms Desktop

Este documento descreve o contrato de API público do sistema EcoForms Desktop, incluindo interfaces de use cases e o formato exato das mensagens de sincronização no Supabase Storage.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `arquitetura.md` | Visão geral da arquitetura |
| `database.md` | Esquema de banco de dados |
| `data-system.md` | Tipos canônicos, portas, serviços de sync |
| `modules.md` | Inventário de módulos, repositories |
| `adr.md` | Decisões arquiteturais (AD-002: Pure Storage Mode) |

---

## Índice

1. [Use Cases — Contrato Público](#1-use-cases--contrato-público)
2. [Storage Messages — Formato Exato](#2-storage-messages--formato-exato)
3. [Storage Messages — Event Envelope v2 (Evolução)](#3-storage-messages--event-envelope-v2-evolução)
4. [Ports (Interfaces de Infraestrutura)](#4-ports-interfaces-de-infraestrutura)
5. [Erros e Exceções](#5-erros-e-exceções)

---

## 1. Use Cases — Contrato Público

### 1.1 Task Use Cases

#### `CreateTaskUseCase`

```ts
// Arquivo: desktop/src/application/task/CreateTaskUseCase.ts
// Container: getContainer().tasks.create

interface CreateTaskInput {
    titulo: string;                    // Obrigatório
    criadoPor: string;                  // UUID do usuário
    projetoId?: string | null;
    descricao?: string;
    prioridade?: 'baixa' | 'media' | 'alta';  // default: 'media'
    atribuidoPara?: string | null;
    prazo?: string | null;             // ISO timestamp
    prazoFim?: string | null;
    tipoPrazo?: 'unico' | 'periodo' | 'recorrente' | null;
    formRegistryId?: string | null;
    parentTaskId?: string | null;
}

interface TaskDto {
    id: string;
    titulo: string;
    status: 'a_fazer' | 'em_progresso' | 'concluido' | 'cancelado';
    prioridade: 'baixa' | 'media' | 'alta';
    ordem: number;
    criadoPor: string;
    projetoId: string | null;
    descricao?: string;
    atribuidoPara: string | null;
    prazo: string | null;
    prazoFim: string | null;
    tipoPrazo: 'unico' | 'periodo' | 'recorrente' | null;
    formRegistryId: string | null;
    tblSuiteId: number | string | null;
    parentTaskId: string | null;
    arquivado: boolean;
    criadoEm?: string;
    atualizadoEm?: string;
}

class CreateTaskUseCase {
    execute(input: CreateTaskInput): Promise<TaskDto>
}
```

#### `MoveTaskUseCase`

```ts
// Container: getContainer().tasks.move

interface MoveTaskInput {
    id: string;                        // UUID da tarefa
    to: TaskStatus;                    // Novo status
    ordem?: number;                    // Nova posição (opcional)
}

class MoveTaskUseCase {
    execute(input: MoveTaskInput): Promise<TaskDto>
}
```

#### `AssignTaskUseCase`

```ts
// Container: getContainer().tasks.assign

interface AssignTaskInput {
    id: string;
    atribuidoPara: string | null;      // UUID ou null para desasignar
}

class AssignTaskUseCase {
    execute(input: AssignTaskInput): Promise<TaskDto>
}
```

#### `ArchiveTaskUseCase`

```ts
// Container: getContainer().tasks.archive

class ArchiveTaskUseCase {
    execute(id: string): Promise<TaskDto>
}
```

#### `DeleteTaskUseCase`

```ts
// Container: getContainer().tasks.delete
// Soft-delete: define deletado_em ao invés de remover

class DeleteTaskUseCase {
    execute(id: string): Promise<void>
}
```

#### `ListTasksByProjectUseCase`

```ts
// Container: getContainer().tasks.listByProject

interface ListTasksByProjectInput {
    projectId: string | null;          // null = todas
    includeArchived?: boolean;         // default: false
}

class ListTasksByProjectUseCase {
    execute(input: ListTasksByProjectInput): Promise<TaskDto[]>
}
```

---

### 1.2 Suite Use Cases

#### `SubmitSuiteUseCase`

```ts
// Arquivo: desktop/src/application/suite/SubmitSuiteUseCase.ts
// Container: getContainer().suites.submit

interface SubmitSuiteInput {
    moduleType: string;                // Ex: 'ecopontoCaixasForm'
    resourceType: string;             // Ex: 'form'
    ownerId: string;                  // UUID do proprietário
    payload: unknown;                  // Dados do formulário
    refPackageId?: string;            // ID do pacote de referência
    refPackageVer?: number;           // Versão do pacote de referência
}

interface SuiteDto {
    packageId: string;
    versionNo: number;
    moduleType: string;
    resourceType: string;
    status: SuiteStatus;              // 'draft' | 'current' | 'edit' | 'locked' | ...
    ownerId: string | null;
    isCurrent: boolean;
    lockedBy: string | null;
    lockedAt: string | null;
    refPackageId: string | null;
    refPackageVer: number | null;
    payload: unknown;
    createdAt: string;
    closedAt: string | null;
}

class SubmitSuiteUseCase {
    execute(input: SubmitSuiteInput): Promise<SuiteDto>
}
```

#### `EditSuiteUseCase`

```ts
// Container: getContainer().suites.edit

interface EditSuiteInput {
    packageId: string;
    editorId: string;
    payload: unknown;
}

class EditSuiteUseCase {
    execute(input: EditSuiteInput): Promise<SuiteDto>
}
```

#### `ReviewSuiteUseCase`

```ts
// Container: getContainer().suites.review

interface ReviewSuiteInput {
    packageId: string;
    reviewerId: string;
    approve: boolean;                  // true = locked, false = refuted
    motivo?: string;
}

class ReviewSuiteUseCase {
    execute(input: ReviewSuiteInput): Promise<SuiteDto>
}
```

#### `ListInboxUseCase`

```ts
// Container: getContainer().suites.listInbox

class ListInboxUseCase {
    execute(filter?: {
        status?: SuiteStatus;
        ownerId?: string;
        moduleType?: string;
    }): Promise<SuiteDto[]>
}
```

---

### 1.3 Client Use Cases

```ts
// Container: getContainer().clients

interface ClientDto {
    idPJ: number;
    nome: string;
    cnpj?: string;
    telefone?: string;
    telefone2?: string;
    email?: string;
    cep?: string;
    endereco?: string;
    numero?: string;
    bairro?: string;
    cidade?: string;
    estado?: string;
    inativo: boolean;
    idPJtipo?: number;
    tipoNome?: string;
    criadoEm?: string;
    atualizadoEm?: string;
}

interface CreateClientInput {
    nome: string;
    cnpj?: string;
    telefone?: string;
    telefone2?: string;
    email?: string;
    cep?: string;
    endereco?: string;
    numero?: string;
    bairro?: string;
    cidade?: string;
    estado?: string;
    idPJtipo?: number;
}

interface ListClientsInput {
    ativoOnly?: boolean;              // default: true
}

class ListClientsUseCase {
    execute(input?: ListClientsInput): Promise<ClientDto[]>
}

class GetClientByIdUseCase {
    execute(idPJ: number): Promise<ClientDto | null>
}

class ListClientContactsUseCase {
    execute(idPJ: number): Promise<ClientContactDto[]>
}

class ListClientTypesUseCase {
    execute(): Promise<ClientTypeDto[]>
}

class CreateClientUseCase {
    execute(input: CreateClientInput): Promise<ClientDto>
}
```

---

### 1.4 User Use Cases

```ts
// Container: getContainer().users

interface UserDto {
    id: string;
    nome: string;
    username: string;
    email: string;
    perfil: number;                    // 0=admin, 1=gerente, 2=coordenador, 3=encarregado, 4=operador
    ativo: boolean;
    setores: string[];
    criadoEm?: string;
    atualizadoEm?: string;
}

interface CreateUserInput {
    nome: string;
    username: string;
    email: string;
    perfil: number;
    setores?: string[];
}

interface UpdateUserInput {
    id: string;
    nome: string;
    username: string;
    email: string;
    perfil: number;
    ativo: boolean;
    setores?: string[];
}

class ListUsersUseCase {
    execute(): Promise<UserDto[]>
}

class CreateUserUseCase {
    execute(input: CreateUserInput): Promise<UserDto>
}

class UpdateUserUseCase {
    execute(input: UpdateUserInput): Promise<UserDto>
}

class ToggleUserStatusUseCase {
    execute(id: string): Promise<UserDto>
}
```

---

### 1.5 Data Registry Use Cases

```ts
// Container: getContainer().dataRegistry

interface DataRegistryDto {
    id: string;
    tipo: string;
    conteudo: unknown;                 // JSON
    criadoEm?: string;
    atualizadoEm?: string;
}

interface CreateDataRegistryInput {
    tipo: string;
    conteudo: unknown;
}

class ListItemsUseCase {
    execute(): Promise<DataRegistryDto[]>
}

class ListByTypeUseCase {
    execute(tipo: string): Promise<DataRegistryDto[]>
}

class ListTypesUseCase {
    execute(): Promise<string[]>
}

class CreateDataRegistryUseCase {
    execute(input: CreateDataRegistryInput): Promise<DataRegistryDto>
}

class DeleteDataRegistryUseCase {
    execute(id: string): Promise<void>
}
```

---

### 1.6 CRM Use Cases

```ts
// Container: getContainer().crm

interface RoteiroDto {
    idRoteiro: number;
    roteiro: string;
    tipoResiduo: string;
    periodicidade: string;
    turno: string;
    base: string;
}

interface RotaDto {
    idRota: number;
    idPJ: number;
    idRoteiro: number;
    ordem: number;
    inativo: boolean;
}

interface ColetaDto {
    idColeta: number;
    idRoteiro: number;
    data: string;
    idPJ: number;
    status: string;
    observacao?: string;
}

interface CreateRotaInput {
    idPJ: number;
    idRoteiro: number;
    ordem: number;
}

class ListRoteirosUseCase {
    execute(): Promise<RoteiroDto[]>
}

class ListRotasByClientUseCase {
    execute(idPJ: number): Promise<RotaDto[]>
}

class ListColetasByRoteiroUseCase {
    execute(idRoteiro: number): Promise<ColetaDto[]>
}

class CreateRotaUseCase {
    execute(input: CreateRotaInput): Promise<RotaDto>
}

class UpdateRotaOrdemUseCase {
    execute(idRota: number, ordem: number): Promise<void>
}

class DeleteRotaUseCase {
    execute(idRota: number): Promise<void>
}
```

---

### 1.7 Ouvidoria Use Cases

```ts
// Container: getContainer().ouvidoria

interface ProtocoloDto {
    idProtocolo: number;
    telefone: string;
    pJ: string;
    status: string;
    usuarioID: string;
    criadoEm: string;
}

interface ProtocoloEventoDto {
    idEvento: number;
    idProtocolo: number;
    detalhe: string;
    setor: string;
    motivo: string;
    resposta?: string;
    carimbo?: string;
}

interface CreateProtocoloInput {
    telefone: string;
    pJ?: string;
    usuarioID: string;
}

interface AddEventoInput {
    idProtocolo: number;
    detalhe: string;
    setor: string;
    motivo?: string;
    resposta?: string;
}

class ListProtocolosUseCase {
    execute(filter?: { status?: string }): Promise<ProtocoloDto[]>
}

class GetProtocoloUseCase {
    execute(idProtocolo: number): Promise<ProtocoloDto | null>
}

class ListEventosUseCase {
    execute(idProtocolo: number): Promise<ProtocoloEventoDto[]>
}

class CreateProtocoloUseCase {
    execute(input: CreateProtocoloInput): Promise<ProtocoloDto>
}

class UpdateProtocoloStatusUseCase {
    execute(idProtocolo: number, status: string): Promise<void>
}

class AddProtocoloEventoUseCase {
    execute(input: AddEventoInput): Promise<ProtocoloEventoDto>
}
```

---

### 1.8 Sync Use Cases

```ts
// Container: getContainer().sync

interface SyncResult {
    success: boolean;
    synced: {
        form_registry: number;
        data_registry: number;
        tbl_suite_push: number;
        tbl_suite_pull: number;
        tbl_usuarios: number;
        projects_push: number;
        projects_pull: number;
        tasks_push: number;
        tasks_pull: number;
        task_snaps_push: number;
        ecoponto_state_push: number;
    };
    errors: string[];
}

class EventSyncAdapter implements SyncPort {
    syncAll(options?: { forcePush?: boolean }): Promise<SyncResult>
    pushPending(): Promise<void>
    pull(knownRoutingIds: string[]): Promise<void>
    getOfflineQueueSize(): number
    processOfflineQueue(): Promise<{ processed: number; failed: number }>
}
```

---

## 2. Storage Messages — Formato Exato (Legado)

> **Nota:** o formato Snapshot v1 documentado nesta seção pertence ao sistema legado `StorageSync` e **não é usado pelo sync ativo**. O sistema atual usa **Event Envelope v2** (seção 3) com criptografia AES-256-GCM (arquivos `.enc`). Esta seção é mantida para referência de integrações futuras (sync mobile).

### 2.1 Formato Geral do Snapshot

Todos os arquivos no Supabase Storage seguem o formato `SyncSnapshot`:

```json
{
    "version": "1.0",
    "timestamp": "2024-01-15T10:30:00.000Z",
    "device_id": "device-uuid-123",
    "origin_device": "device-uuid-123",
    "sync_type": "incremental | full",
    "data": {
        "tbl_suite": [...],
        "form_registry": [...],
        "data_registry": [...],
        "tbl_usuarios": [...],
        "tbl_projetos": [...],
        "tbl_tarefas": [...],
        "task": {...},
        "form": {...},
        "activity_snap": {...}
    },
    "metadata": {
        "checksum": "sha256:abc123...",
        "record_count": {
            "tbl_suite": 5,
            "form_registry": 10,
            "data_registry": 25,
            "tbl_usuarios": 8,
            "tbl_projetos": 3,
            "tbl_tarefas": 15,
            "task": 1,
            "form": 1
        },
        "compressed": true,
        "file_size_bytes": 45231
    }
}
```

**Encoding:** O snapshot é serializado como JSON (sem compressão).

**Checksum:** SHA-256 do JSON raw.

---

### 2.2 Paths e Tipos de Arquivo

> **IMPORTANTE**: O sistema NÃO utiliza tabelas PostgreSQL no Supabase. Todo o trânsito de dados ocorre exclusivamente via **Supabase Storage** (arquivos JSON no bucket `sync-bucket`).

| Path | Tipo | Direção | Conteúdo |
|------|------|---------|----------|
| `shared/form_registry.json` | Snapshot | Push | Templates de formulário |
| `shared/form_field_registry.json` | Snapshot | Push | Campos dos formulários |
| `shared/data_registry.json` | Snapshot | Push | Dados de referência |
| `shared/users.json` | Snapshot | Push | Lista de usuários |
| `shared/tbl_suite.json` | Snapshot | Push/Pull | Submissões de formulários |
| `shared/ecoponto_caixas.json` | Snapshot | Push/Pull | Dados de ocupação das caixas |
| `users/{deviceId}/outbox/` | Snapshot | Push | Dados do desktop para cloud |
| `users/{deviceId}/inbox/` | Snapshot | Pull | Dados do mobile para desktop |
| `archive/YYYY-MM/` | Snapshot | Retention | Arquivo mensal (90 dias) |

**Regras de Acesso:**
1. **NUNCA** acessar tabelas PostgreSQL diretamente via `supabase.from()`
2. **SEMPRE** usar Storage para trânsito de dados entre dispositivos
3. **SEMPRE** usar cache local (IndexedDB/localStorage) como fonte primária de leitura

---

### 2.3 Exemplo: tbl_suite (Push)

**Path:** `shared/tbl_suite.json`

```json
{
    "version": "1.0",
    "timestamp": "2024-01-15T10:30:00.000Z",
    "device_id": "device-uuid-123",
    "origin_device": "device-uuid-123",
    "sync_type": "incremental",
    "data": [
        {
            "package_id": "550e8400-e29b-41d4-a716-446655440001",
            "version_no": 1,
            "module_type": "ecopontoCaixasForm",
            "resource_type": "form",
            "status": "current",
            "owner_id": "user-uuid-456",
            "is_current": 1,
            "locked_by": null,
            "locked_at": null,
            "ref_package_id": null,
            "ref_package_ver": null,
            "payload_json": "{\"ecoponto\":\"ECO-001\",\"caixas_list\":{\"ocupacao\":{\"c1\":80,\"c2\":45}}}",
            "created_at": "2024-01-15T10:30:00.000Z",
            "closed_at": null
        }
    ],
    "metadata": {
        "checksum": "sha256:d7a8f9e2c3b4a5...",
        "record_count": 1,
        "file_size_bytes": 1847
    }
}
```

---

### 2.4 Exemplo: Shared Data (Push)

**Path:** `shared/form_registry.json`

```json
{
    "version": "1.0",
    "timestamp": "2024-01-15T10:30:00.000Z",
    "device_id": "device-uuid-123",
    "origin_device": "device-uuid-123",
    "sync_type": "incremental",
    "data": {
        "form_registry": [
            {
                "form_id": "form-uuid-001",
                "slug": "ecoponto-caixas",
                "titulo": "Ecoponto - Caixas",
                "conteudo": {
                    "id": "form-uuid-001",
                    "titulo": "Ecoponto - Caixas",
                    "campos": [
                        {
                            "type": "text",
                            "name": "ecoponto",
                            "label": "Código do Ecoponto"
                        },
                        {
                            "type": "number",
                            "name": "caixas_list.ocupacao.c1",
                            "label": "Caixa 1 (%)"
                        }
                    ]
                },
                "versao": 3,
                "ativo": 1,
                "autor": "user-uuid-456",
                "situacao": "published",
                "auto_aprovacao": 0,
                "ad_hoc": 0,
                "criado_em": "2024-01-01T00:00:00.000Z",
                "atualizado_em": "2024-01-15T10:00:00.000Z"
            }
        ]
    },
    "metadata": {
        "checksum": "sha256:abc123def456...",
        "record_count": {
            "form_registry": 1
        },
        "compressed": true,
        "file_size_bytes": 2341
    }
}
```

---

### 2.5 Exemplo: Task Snap (Push)

**Path:** `users/{userId}/inbox/{taskId}/snapshot.json`

```json
{
    "version": "1.0",
    "timestamp": "2024-01-15T10:30:00.000Z",
    "device_id": "device-uuid-123",
    "origin_device": "device-uuid-123",
    "sync_type": "full",
    "data": {
        "task": {
            "id": "task-uuid-789",
            "titulo": "Coleta Ecoponto Norte",
            "status": "em_progresso",
            "prioridade": "alta",
            "projeto_nome": "Roteiro Janeiro",
            "atribuido_para": "operator-uuid-001"
        },
        "form": {
            "id": "form-uuid-001",
            "titulo": "Ecoponto - Caixas",
            "campos": [...]
        },
        "activity_snap": {
            "task_id": "task-uuid-789",
            "filled_data": {
                "ecoponto": "ECO-001",
                "caixas_list": {
                    "ocupacao": {"c1": 80, "c2": 45}
                }
            }
        }
    },
    "metadata": {
        "checksum": "sha256:xyz789...",
        "record_count": {
            "task": 1,
            "form": 1
        },
        "compressed": true,
        "file_size_bytes": 3456
    }
}
```

---

### 2.6 Exemplo: Ecoponto State (Push)

**Path:** `shared/ecoponto_state`

```json
{
    "ecoponto_latest_state": {
        "ECO-001": {
            "ocupacao": {"c1": 80, "c2": 45, "c3": 20, "c4": 100},
            "removidas": {"c1": 0, "c2": 1, "c3": 0, "c4": 2},
            "timestamp": "2024-01-15T10:30:00.000Z"
        },
        "ECO-002": {
            "ocupacao": {"c1": 30, "c2": 60, "c3": 90, "c4": 15},
            "removidas": {"c1": 0, "c2": 0, "c3": 1, "c4": 0},
            "timestamp": "2024-01-15T10:30:00.000Z"
        }
    }
}
```

**Nota:** Este arquivo NÃO é um SyncSnapshot — é JSON puro.

---

### 2.7 Exemplo: Task Status Update (Pull)

**Path:** `shared/inbox/task_status_{taskId}.json`

```json
{
    "task_id": "task-uuid-789",
    "status": "concluido",
    "updated_by": "operator-uuid-001",
    "updated_at": "2024-01-15T11:00:00.000Z"
}
```

---

## 3. Storage Messages — Event Envelope v2 (Evolucao)

> Veja `event-envelope-v2.md` para a proposta completa. Esta secao resume o impacto no contrato.

### 3.1 Motivacao

O envelope Snapshot v1 (documentado em §2) e funcional mas carece de:
- Identidade do evento (`id`, `type`)
- Rastreabilidade causal (`correlation_id`, `causation_id`)
- Schema evolution (`schema.version`)
- Payload nativo (objeto JSON, nao string escapada)
- Estado de sync (`sync.state`)

### 3.2 Formato v2 (Resumo)

```json
{
    "specversion": "2.0",
    "id": "evt_abc123",
    "type": "ecoforms.snapshot.incremental",
    "source": "desktop/device-uuid-123",
    "subject": "aggregate:tbl_suite:pkg-uuid-456",
    "time": "2024-01-15T10:30:00.000Z",
    "ecoforms": {
        "schema": { "version": 2, "compat": [1, 2] },
        "trace": {
            "trace_id": "trace_xyz789",
            "correlation_id": "case_eco_00077",
            "causation_id": "evt_previous_456"
        },
        "producer": { "module": "task-sync", "device_id": "...", "user_id": "..." },
        "sync": { "state": "QUEUED_UPLOAD", "retry_count": 0 },
        "sequence": { "stream": "device-uuid-123/tbl_suite", "position": 47 }
    },
    "data": { "tbl_suite": [{ "package_id": "...", "payload": { ... } }] },
    "metadata": { "checksum": "sha256:...", "schema_ref": "tbl_suite/v2" }
}
```

### 3.3 Mudancas no Contrato

| Aspecto | v1 (Atual) | v2 (Proposto) |
|---------|-----------|---------------|
| Envelope | Snapshot flat | Event envelope com header/body |
| Identidade | Apenas `device_id` | `id` (evento), `source`, `subject` |
| Semantica | `sync_type`: incremental/full | `type`: ecoforms.snapshot.*, ecoforms.task.* |
| Rastreabilidade | Nenhuma | `correlation_id`, `causation_id`, `trace_id` |
| Schema | `version`: "1.0" | `ecoforms.schema.version` + `compat` |
| Payload | `payload_json` (string) | `payload` (objeto JSON nativo) |
| Sync state | N/A | `ecoforms.sync.state`: QUEUED, SENT, ACK, ERROR |

### 3.4 Backward Compatibility

- v1 continua funcionando (leitor aceita ambos)
- v2 e opt-in via flag `useV2Envelope`
- Migration path em 4 fases documentado em `event-envelope-v2.md`

### 3.5 Referencias

- `docs/event-envelope-v2.md` — Documentacao completa
- `adr.md` §AD-008 — Decisao arquitetural
- `plans/refatorar.md` — Proposta original

---

## 4. Ports (Interfaces de Infraestrutura)

### 3.1 SqlitePort

```ts
// Arquivo: desktop/src/application/ports/SqlitePort.ts

interface SqlitePort {
    query<T>(sql: string, params?: unknown[]): Promise<T[]>
    execute(sql: string, params?: unknown[]): Promise<void>
    transaction<T>(callback: () => Promise<T>): Promise<T>
}
```

### 3.2 StorageSyncPort

```ts
// Arquivo: desktop/src/application/ports/StorageSyncPort.ts

interface PulledSnapshot {
    snapshot: SyncSnapshot;
    filename: string;
    path: string;
}

interface StoredFileEntry {
    name: string;
}

interface StorageSyncPort {
    push(
        data: Record<string, unknown>,
        syncType: 'incremental' | 'full',
        filenameBase?: string,
        folder?: string,
        compress?: boolean,
    ): Promise<void>;

    pull(customPath?: string): Promise<PulledSnapshot[]>;

    downloadFile(path: string): Promise<Blob | null>;

    listFiles(prefix: string): Promise<StoredFileEntry[]>;

    moveToArchive(filename: string, sourcePath?: string): Promise<void>;

    movePath(fromPath: string, toPath: string): Promise<void>;

    validateSnapshot(
        blob: Blob,
        options?: { skipChecksum?: boolean; skipCount?: boolean }
    ): Promise<SyncSnapshot>;
}
```

### 3.3 FileStoragePort

```ts
// Arquivo: desktop/src/application/ports/FileStoragePort.ts

interface StoredFile {
    name: string;
    url: string;
}

interface FileStoragePort {
    upload(
        bucket: string,
        path: string,
        data: Blob | string,
        contentType?: string
    ): Promise<StoredFile>;

    download(bucket: string, path: string): Promise<Blob>;

    remove(bucket: string, paths: string[]): Promise<void>;

    list(bucket: string, prefix?: string): Promise<string[]>;

    getPublicUrl(bucket: string, path: string): string;
}
```

### 3.4 SyncPort

```ts
// Arquivo: desktop/src/application/ports/SyncPort.ts

interface SyncResult {
    success: boolean;
    synced: {
        form_registry: number;
        data_registry: number;
        tbl_suite_push: number;
        tbl_suite_pull: number;
        tbl_usuarios: number;
        projects_push: number;
        projects_pull: number;
        tasks_push: number;
        tasks_pull: number;
        task_snaps_push: number;
        ecoponto_state_push: number;
    };
    errors: string[];
}

interface SyncPort {
    syncAll(options?: { forcePush?: boolean }): Promise<SyncResult>;
    pushTasks(): Promise<void>;
    pullTasks(): Promise<void>;
    getOfflineQueueSize(): Promise<number>;
    processOfflineQueue(): Promise<{ processed: number; failed: number }>;
}
```

### 3.5 ClockPort e LoggerPort

```ts
// Arquivo: desktop/src/application/ports/ClockPort.ts

interface ClockPort {
    nowIso(): string;
    now(): Date;
}

// Arquivo: desktop/src/application/ports/LoggerPort.ts

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LoggerPort {
    debug(message: string, ...args: unknown[]): void;
    info(message: string, ...args: unknown[]): void;
    warn(message: string, ...args: unknown[]): void;
    error(message: string, ...args: unknown[]): void;
    log(level: LogLevel, message: string, ...args: unknown[]): void;
}
```

---

## 5. Erros e Exceções

### 4.1 Exceções de Domínio

```ts
// Arquivo: desktop/src/domain/shared/errors.ts

export class NotFoundError extends Error {
    constructor(entity: string, id: string | number) {
        super(`${entity} not found: ${id}`);
        this.name = 'NotFoundError';
    }
}

export class InvalidTransitionError extends Error {
    constructor(
        currentStatus: string,
        targetStatus: string,
        entity: string
    ) {
        super(
            `Invalid transition: ${entity} cannot transition from ${currentStatus} to ${targetStatus}`
        );
        this.name = 'InvalidTransitionError';
    }
}
```

### 4.2 Validações de Use Cases

| Use Case | Validação | Erro |
|----------|----------|------|
| `CreateTaskUseCase` | `titulo` não pode ser vazio | `Error: Título da tarefa é obrigatório.` |
| `MoveTaskUseCase` | Tarefa deve existir | `NotFoundError: Task {id}` |
| `MoveTaskUseCase` | Transição deve ser válida | `InvalidTransitionError` |
| `CreateClientUseCase` | `nome` não pode ser vazio | `Error: Nome é obrigatório.` |
| `ReviewSuiteUseCase` | Pacote deve existir | `NotFoundError: Suite {packageId}` |

### 4.3 Erros de Sync

```ts
// Erro de checksum mismatch
new Error('Checksum mismatch! File may be corrupted.')

// Erro de contagem de registros
new Error(`Record count mismatch! Expected ${expected}, got ${actual}`)

// Erro de storage
new Error(`Failed to push snapshot: ${error.message}`)
```

### 4.4 Códigos de Erro HTTP (Supabase)

| Código | Significado | Ação |
|--------|-------------|------|
| `NoSuchKey` | Arquivo não encontrado | Ignorar, continuar |
| `404` | Resource não encontrado | Retry com backoff |
| `413` | Payload too large | Chunking ou compressão |
| `500` | Erro interno Supabase | Retry com backoff |

---

## Resumo

### Estrutura de Chamada

```
UI (React) ──▶ useCase.execute(input) ──▶ Repository ──▶ SqlitePort ──▶ SQLite
                     │
                     └─▶ SyncPort ──▶ StorageSyncPort ──▶ Supabase Storage
```

### Acesso via Hooks

```ts
// Via hooks legacy (useSync, etc.)
const { syncNow } = useSync();

// Via container DI (Clean Architecture)
const { tasks } = getContainer();
await tasks.create({ titulo: 'Nova Tarefa', criadoPor: userId });
```

### Formato de Arquivo

```
SyncSnapshot (JSON) ──▶ Supabase Storage (.json)
     │
     ├── version: "1.0"
     ├── timestamp: ISO 8601
     ├── device_id: UUID
     ├── origin_device: UUID
     ├── sync_type: "incremental" | "full"
     ├── data: [ ... ] (array de registros)
     └── metadata: { checksum, record_count, file_size_bytes }
```
