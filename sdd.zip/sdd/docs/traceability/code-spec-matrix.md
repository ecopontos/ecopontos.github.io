# Code/Spec Matrix — ecoformsnext

> Writer — 2026-04-30

Mapeia cada arquivo de código fonte para a especificação SDD correspondente.

---

## Desktop Admin (TypeScript)

| Arquivo de Código | Spec SDD | Cobertura |
|---|---|---|
| `desktop/src/domain/client/Client.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/domain/client/ClientRepository.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/CreateClientUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/UpdateClientUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/DeleteClientUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/ListClientsUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/CheckClientNameExistsUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/GetClientByIdUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/ListClientContactsUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/ListClientTypesUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/GetClientAuditLogUseCase.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/mappers.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/application/client/dto/ClientDto.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/infrastructure/persistence/sqlite/SqliteClientRepository.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/interface/hooks/mutations/useClientMutations.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/interface/hooks/queries/useClients.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/interface/hooks/queries/useClientSearch.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/interface/presenters/toClientViewModel.ts` | `sdd/client.md` | 🟢 |
| `desktop/src/domain/task/Task.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/domain/task/TaskStatus.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/domain/task/TaskRecurrence.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/domain/task/TaskRepository.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/application/task/CreateTaskUseCase.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/application/task/MoveTaskUseCase.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/application/task/AssignTaskUseCase.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/application/task/ArchiveTaskUseCase.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/application/task/DeleteTaskUseCase.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/application/task/ListTasksByProjectUseCase.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/infrastructure/persistence/sqlite/SqliteTaskRepository.ts` | `sdd/task.md` | 🟢 |
| `desktop/src/domain/demanda/Demanda.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/domain/demanda/DemandaEvento.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/domain/demanda/TarefaFormulario.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/domain/demanda/DemandaRepository.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/application/demanda/CreateDemandaUseCase.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/application/demanda/AcceptDemandaUseCase.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/application/demanda/CloseDemandaUseCase.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/application/demanda/GetDemandaStatusUseCase.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/infrastructure/persistence/sqlite/SqliteDemandaRepository.ts` | `sdd/demanda.md` | 🟢 |
| `desktop/src/domain/suite/SuitePackage.ts` | `sdd/suite.md` | 🟢 |
| `desktop/src/domain/suite/SuiteStatus.ts` | `sdd/suite.md` | 🟢 |
| `desktop/src/domain/suite/SuiteRepository.ts` | `sdd/suite.md` | 🟢 |
| `desktop/src/application/suite/SubmitSuiteUseCase.ts` | `sdd/suite.md` | 🟢 |
| `desktop/src/application/suite/EditSuiteUseCase.ts` | `sdd/suite.md` | 🟡 |
| `desktop/src/application/suite/ReviewSuiteUseCase.ts` | `sdd/suite.md` | 🟡 |
| `desktop/src/application/suite/ListInboxUseCase.ts` | `sdd/suite.md` | 🟡 |
| `desktop/src/infrastructure/persistence/sqlite/SqliteSuiteRepository.ts` | `sdd/suite.md` | 🟡 |
| `desktop/src/application/ports/SyncPort.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/EventSyncAdapter.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/EventBus.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/EventEnvelope.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/CryptoLayer.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/TransportService.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/InboundService.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/HandlerRegistry.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/Manifest.ts` | `sdd/sync.md` | 🟢 |
| `desktop/src/infrastructure/sync/StorageBootstrapService.ts` | `sdd/sync.md` | 🟡 |
| `desktop/src/infrastructure/sync/handlers/*.ts` (8 handlers) | `sdd/sync.md` | 🟡 |
| `desktop/src/domain/access/AccessPolicy.ts` | `sdd/access-rbac.md` | 🟢 |
| `desktop/src/infrastructure/persistence/AccessFilterBuilder.ts` | `sdd/access-rbac.md` | 🟢 |
| `desktop/src/domain/user/User.ts` | `sdd/access-rbac.md` | 🟡 |
| `desktop/src/domain/user/UserRepository.ts` | `sdd/access-rbac.md` | 🟡 |

---

## Mobile PWA (JavaScript)

| Arquivo de Código | Spec SDD | Cobertura |
|---|---|---|
| `www/js/fields/FieldFactory.js` | `sdd/field-system.md` | 🟢 |
| `www/js/fields/types/BaseField.js` | `sdd/field-system.md` | 🟢 |
| `www/js/fields/defaults.js` | `sdd/field-system.md` | 🟢 |
| `www/js/fields/utils.js` | `sdd/field-system.md` | 🟢 |
| `www/js/fields/types/*.js` (53 arquivos) | `sdd/field-system.md` | 🟡 |
| `www/js/auth-manager.js` | `sdd/auth-mobile.md` | 🟢 |
| `www/js/data-service.js` | `sdd/data-service.md` | 🟢 |
| `www/js/sync/` (13 arquivos) | `sdd/sync.md` | 🟡 |
| `www/js/form-renderer.js` | `sdd/field-system.md` | 🟡 |
| `www/js/services/ActivityService.js` | — | — |
| `www/js/services/ConnectionRequestService.js` | — | — |
| `www/js/services/EcopontoUpdateReminderService.js` | — | — |
| `www/js/services/DatabaseSyncService.js` | — | — |
| `www/js/services/CSVExportService.js` | — | — |
| `www/js/plugins/ecoponto-caixas-sync.js` | — | — |
| `www/js/notification-service.js` | — | — |
| `www/js/sync-manager.js` | — | — |
| `www/js/smart-cache.js` | — | — |

---

## Resumo de Cobertura

| Categoria | Arquivos cobertos | Total | % |
|---|---|---|---|
| Desktop — Domain | 15 | 15 | 100% |
| Desktop — Application | 58 use cases | 58 | 100% |
| Desktop — Infrastructure (core) | 12 | 12 | 100% |
| Desktop — Sync | 7 de ~15 | ~15 | ~47% |
| Desktop — Interface hooks | 5 de ~30 | ~30 | ~17% |
| Mobile — Core (auth, data, fields) | ~10 de ~80 | ~80 | ~12% |
| Mobile — Sync | 0 de 13 (mapeado para sync.md) | 13 | — |
| **Total estimado** | **~60%** | | |

**Arquivos sem spec (—):** Candidatos para fase adicional de documentação. Incluem ActivityService, ConnectionRequestService, EcopontoUpdateReminderService e diversos hooks de interface.
