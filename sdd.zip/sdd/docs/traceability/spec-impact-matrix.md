# Spec Impact Matrix — ecoformsnext

> Architect — 2026-04-30 | 🟡 INFERIDO

Mapeia qual componente de código impacta cada área funcional.

---

| Domínio/Feature | Domain | Application | Infra (SQLite) | Sync Engine | Mobile (www/js) | UI (React) |
|---|---|---|---|---|---|---|
| **Clientes PJ** | Client.ts, ClientRepository | 9 Use Cases | SqliteClientRepository | — | — | useClientMutations, useClients |
| **Tarefas Kanban** | Task.ts, TaskStatus.ts | 7 Use Cases | SqliteTaskRepository | tasks_push/pull | — | useKanban, useTaskUseCases |
| **Demandas** | Demanda.ts, DemandaEvento.ts | 4 Use Cases | SqliteDemandaRepository | demanda.handler | — | useDemandas |
| **Ouvidoria** | Protocolo.ts, Atendimento.ts | 13 Use Cases | (Supabase direto) | — | — | useOuvidoriaQueries |
| **CRM (Rotas)** | Rota.ts, Roteiro.ts | 5 Use Cases | SqliteCRMRepository | crm.handler | — | useCRMUseCases |
| **Suite (Formulários)** | SuitePackage.ts, SuiteStatus.ts | 4 Use Cases | SqliteSuiteRepository | suite.handler | DataService (tbl_suite) | useInbox, useSuiteUseCases |
| **Data Registry** | DataRegistryItem.ts | 5 Use Cases | SqliteDataRegistryRepository | data_registry.handler | — | useDataRegistry |
| **Usuários** | User.ts | 5 Use Cases | SqliteUserRepository | usuario.handler | AuthManager | useUsers |
| **RBAC** | AccessPolicy.ts | — | AccessFilterBuilder | — | auth-manager.js (perfil) | usePermissions |
| **Formulários (Campo)** | — | — | — | form_registry.handler | FieldFactory, 53+ fields | — |
| **Auth (Mobile)** | — | — | — | — | AuthManager (1520 lines) | — |
| **Data Offline** | — | — | — | — | DataService (2378 lines) | — |
| **Sync** | — | SyncPort | EventSyncAdapter | 15+ files | 13 files espelhados | useSync, useSyncSettings |
| **Exportação** | — | — | excel-exporter, pdf-exporter | — | — | useClientExport |

---

## Matriz de Dependência entre Módulos

| Módulo | Depende de |
|---|---|
| **demanda** | task, task (TaskRepository injetado) |
| **task** | demanda (FK demanda_id) |
| **suite** | — (independente) |
| **crm** | client (FK idPJ) |
| **ouvidoria** | — (usa Supabase direto) |
| **sync** | todos os handlers registrados |
| **access** | user (perfil do usuário atual) |

---

## Impacto por Camada

| Camada | Arquivos (~) | Impacto em mudanças |
|---|---|---|
| **Domain** | 15 | Alto — qualquer mudança de regra afeta todos os use cases |
| **Application** | 58 Use Cases | Alto — orquestração de workflows |
| **Infrastructure** | 40+ | Médio — adaptadores concretos, substituíveis |
| **Interface (hooks)** | 30+ | Médio — acoplado ao React/TanStack Query |
| **Sync Engine** | 30+ | Alto — duplicado entre desktop e mobile |
| **Mobile Core** | 5+ (grandes) | Alto — AuthManager e DataService são ~4000 linhas totais |
