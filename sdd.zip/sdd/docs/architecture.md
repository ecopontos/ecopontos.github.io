# Arquitetura — ecoformsnext

> Architect — 2026-04-30 | 🟢 CONFIRMADO

---

## Visão Geral

EcoSuite é um sistema de formulários ecológicos _offline-first_ composto por duas aplicações:

| Aplicação | Descrição | Stack |
|---|---|---|
| **Mobile PWA** | App de campo para fiscais/operadores | Vanilla JS + Alpine.js + Capacitor |
| **Desktop Admin** | App de gestão para gerentes/admin | Next.js 16 + React 19 + Tauri 2 |

Ambos compartilham **Supabase** como backend cloud e utilizam **SQLite/IndexedDB** como banco local.

---

## Padrões Arquiteturais

| Padrão | Onde | Observação |
|---|---|---|
| **Clean Architecture** | Desktop Admin | Domain → Application → Infrastructure → Interface |
| **DDD (Domain-Driven Design)** | Desktop Admin | Entidades com fromProps/toProps, repositórios por agregação |
| **Event Sourcing (Lite)** | Demanda, Sync | Eventos imutáveis com correlationId/causationId |
| **Offline-First** | Mobile + Desktop | IndexedDB/SQLite local → Supabase sync |
| **CQRS (leve)** | Desktop | useSQLiteQuery (read) separado de useMutations (write) |
| **RBAC Hierárquico** | Ambos | Perfis com níveis e filtros SQL gerados dinamicamente |
| **Repository Pattern** | Desktop | Interfaces no domain, implementações concretas na infra |
| **Dependency Injection** | Desktop | Container (buildContainer) com overrides para testes |

---

## Containers do Sistema

```
┌──────────────┐    ┌──────────────┐    ┌──────────────────┐
│ Mobile PWA   │    │ Desktop Admin│    │  Supabase Cloud  │
│ (Alpine.js + │    │ (Next.js +   │    │  ┌─────────────┐ │
│  Capacitor)  │    │  Tauri 2)    │    │  │ PostgreSQL  │ │
│              │    │              │    │  ├─────────────┤ │
│ IndexedDB    │    │ SQLite       │    │  │ Auth        │ │
│              │    │ (rusqlite)   │    │  ├─────────────┤ │
└──────┬───────┘    └──────┬───────┘    │  │ Storage     │ │
       │                   │            │  │ (sync-bucket)│ │
       │   JSON via        │  REST/     │  ├─────────────┤ │
       │   Storage API     │  SDK       │  │ Realtime    │ │
       └───────────────────┴────────────│  └─────────────┘ │
                                        └──────────────────┘
```

---

## Fluxo de Dados

1. **Campo (mobile):** Usuário preenche formulário offline → salvo no IndexedDB (DataService) → sincronizado quando online via Supabase Storage (`shared/inbox/%`)
2. **Desktop (admin):** Lê do Supabase Storage + SQLite local → revisa, aprova, cria demandas → eventos push de volta ao Storage
3. **Sincronização bidirecional:** EventBus com handlers registrados (demanda, suite, ecoponto, crm, form_registry, data_registry, usuario, org_config)

---

## Dívidas Técnicas Identificadas

| Dívida | Severidade | Evidência |
|---|---|---|
| Código de sync duplicado (TS/infra + JS/www/sync) | Alta | 13 arquivos JS espelhando 15+ TS |
| Estratégia de ID inconsistente (Date.now vs UUID) | Média | Client usa timestamp, Task usa UUID |
| Stubs não implementados no useClientMutations | Baixa | createPF, updatePF, linkContact, unlinkContact lançam Error |
| Tailwind duplicado (v3 mobile + v4 desktop) | Média | Duas versões do Tailwind em uso |
| Sem testes para AuthManager e DataService | Alta | 1520+2378 linhas sem cobertura |
| Ouvidoria usa queries diretas ao Supabase (não SQLite) | Média | Diferente do padrão dos outros módulos |
| Sem CI/CD configurado | Média | Nenhum workflow GitHub Actions |
| Sem Docker/containerização | Baixa | Todo deploy manual |
