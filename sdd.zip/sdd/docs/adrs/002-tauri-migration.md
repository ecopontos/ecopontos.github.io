# ADR-002: Migração Electron → Tauri

> Detective — retroativo via Git — 2026-04-30 | Confiança: 🟢

## Status
Aceito (implementado)

## Contexto
O desktop app original usava Electron como shell, o que resultava em binários grandes (~150MB+), alto consumo de memória e complexidade de build.

## Decisão
Migrar para Tauri 2.x (Rust backend + webview nativa), mantendo o frontend Next.js/React.

## Evidência
- Commit `7d05687`: "pre remocao do electron"
- `desktop/src-tauri/Cargo.toml`: Tauri 2.9.5 como dependência principal
- `desktop/package.json`: `@tauri-apps/api` 2.9.1, `@tauri-apps/cli` 2.9.6
- `desktop/next.config.ts`: `output: 'export'` (SSG, compatível com Tauri)

## Consequências
- Binário menor (~5-10MB vs 150MB+)
- Menor consumo de memória
- Acesso nativo a SQLite via rusqlite (bundled)
- Plugins nativos: dialog, fs, shell, store
- Build mais rápido (Rust compile vs Node packing)
