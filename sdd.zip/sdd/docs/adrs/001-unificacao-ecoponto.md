# ADR-001: Unificação EcoForms + Ecoponto App

> Detective — retroativo via Git — 2026-04-30 | Confiança: 🟢

## Status
Aceito (implementado)

## Contexto
O projeto originalmente bifurcou em dois apps: EcoForms (formulários gerais) e Ecoponto App (especializado em ecopontos). Havia duplicação de código, manutenção dupla e confusão de builds.

## Decisão
Unificar os dois apps em um único código-base (`ecoformsnext`), com modos de operação controlados por configuração e perfil de usuário.

## Evidência
- Commit `16725a3`: "refactor: unify project - remove bifurcation, single EcoForms app"
- Commit `99f5240`: "feat: merge ecoponto app features into unified app"
- Commit `b577155`: "cleanup: remove ecoponto-specific files after unification"
- Arquivo `ecoponto-config.json` na raiz ainda existe como vestígio de configuração

## Consequências
- Código-base único simplifica manutenção
- Features de ecoponto (caixas, lembretes, dashboard) integradas ao app principal
- Build único para Android (Capacitor) em vez de dois APKs
