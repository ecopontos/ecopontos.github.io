# ADR-003: Sincronização Offline-First via Supabase Storage (Fases)

> Detective — retroativo via Git — 2026-04-30 | Confiança: 🟢

## Status
Aceito (implementado em 5 fases)

## Contexto
O sistema precisava funcionar offline em campo (mobile) e sincronizar quando online. A abordagem inicial usava o Supabase Realtime diretamente, mas falhava em cenários offline e causava perda de dados.

## Decisão
Implementar sincronização offline-first baseada em arquivos JSON no Supabase Storage (bucket `sync-bucket`), evoluindo em 5 fases incrementais:

1. **Fase 1** (commit `6b0d89c`): JSON seguro, idempotência ativa (uuid), checksums confiáveis
2. **Fase 2** (commit `0ccc4af`): Lock de concorrência, batches sequenciais, SyncManager depreciado
3. **Fase 3** (commit `dae5ca2`): TTL unificado, deadlock protegido, onOnline consolidado
4. **Fase 4** (commit `c152451`): Resolução de conflitos LWW+hash, atomicidade ecoponto_ocupacao
5. **Fase 5** (commit `538d463`): Deep-clone em upload, EcopontoCaixasSync em IndexedDB, cache atômico

## Evidência
- 5 commits sequenciais documentando cada fase
- `desktop/src/infrastructure/sync/` com 15+ arquivos
- `www/js/sync/` com 13 arquivos (implementação mobile espelhada)

## Consequências
- Dados nunca são perdidos no campo (IndexedDB local)
- Conflitos resolvidos deterministicamente (LWW + hash)
- Concorrência controlada (lock), sem corrupção
- Upload idempotente (uuid), sem duplicação
