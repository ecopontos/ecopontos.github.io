# Dependências — ecoformsnext

> Gerado pelo Scout em 2026-04-30
> Pacotes principais e versões críticas

---

## 1. Projeto Raiz (`package.json`)

**Nome:** ecoforms v1.0.1 | **Tipo:** module

### Dependências de Produção

| Pacote | Versão | Propósito |
|---|---|---|
| `@capacitor/android` | ^8.0.2 | Build Android nativo |
| `@capacitor/camera` | ^8.0.2 | Acesso à câmera no Android |
| `@capacitor/cli` | ^8.0.2 | CLI do Capacitor |
| `@capacitor/core` | ^8.0.2 | Core do Capacitor |
| `@ionic/pwa-elements` | ^3.3.0 | Componentes PWA (câmera, etc.) |
| `@radix-ui/react-collapsible` | ^1.1.12 | Collapsible para mobile (usado pontualmente) |
| `@supabase/supabase-js` | ^2.58.0 | Cliente Supabase JS |
| `bcryptjs` | ^3.0.2 | Hash de senhas (client-side) |
| `cors` | ^2.8.5 | Middleware CORS (Express) |
| `dotenv` | ^17.2.2 | Variáveis de ambiente |
| `duckdb` | ^1.4.4 | Banco analítico para scripts |
| `exceljs` | ^4.4.0 | Geração de Excel |
| `express` | ^5.2.1 | Servidor web (dev server) |
| `jsdom` | ^27.0.0 | DOM simulation (scripts) |
| `sqlite` | ^5.1.1 | SQLite para Node.js |
| `sqlite3` | ^6.0.1 | SQLite bindings nativos |

### Dependências de Desenvolvimento

| Pacote | Versão | Propósito |
|---|---|---|
| `@vitest/coverage-v8` | ^3.2.4 | Cobertura via V8 |
| `@vitest/ui` | ^3.2.4 | UI do Vitest |
| `autoprefixer` | ^10.4.21 | Prefixos CSS |
| `concurrently` | ^9.2.1 | Execução paralela de scripts |
| `happy-dom` | ^20.0.2 | DOM para testes |
| `http-server` | ^14.1.1 | Servidor HTTP estático |
| `playwright` | ^1.41.1 | Testes E2E |
| `postcss` | ^8.5.6 | Processamento CSS |
| `serve` | ^14.2.5 | Servidor estático alternativo |
| `tailwindcss` | ^3.4.17 | CSS utilitário (mobile) |
| `vitest` | ^3.2.4 | Test runner |

---

## 2. Desktop Admin (`desktop/package.json`)

**Nome:** ecosuite-desktop v0.1.8 | **Tipo:** privado

### Dependências de Produção

| Pacote | Versão | Propósito |
|---|---|---|
| `@dnd-kit/core` | ^6.3.1 | Drag and drop core |
| `@dnd-kit/sortable` | ^10.0.0 | Listas ordenáveis |
| `@dnd-kit/utilities` | ^3.2.2 | Utilitários dnd-kit |
| `@radix-ui/react-accordion` | ^1.2.12 | Accordion acessível |
| `@radix-ui/react-aspect-ratio` | ^1.1.8 | Ratio container |
| `@radix-ui/react-checkbox` | ^1.3.3 | Checkbox acessível |
| `@radix-ui/react-dialog` | ^1.1.15 | Modal acessível |
| `@radix-ui/react-dropdown-menu` | ^2.1.16 | Dropdown menu |
| `@radix-ui/react-label` | ^2.1.8 | Label acessível |
| `@radix-ui/react-radio-group` | ^1.3.8 | Radio group |
| `@radix-ui/react-scroll-area` | ^1.2.10 | Scroll area |
| `@radix-ui/react-select` | ^2.2.6 | Select acessível |
| `@radix-ui/react-separator` | ^1.1.8 | Separador |
| `@radix-ui/react-slot` | ^1.2.4 | Slot composition |
| `@radix-ui/react-switch` | ^1.2.6 | Switch toggle |
| `@radix-ui/react-tabs` | ^1.1.13 | Tabs acessíveis |
| `@radix-ui/react-tooltip` | ^1.2.8 | Tooltip |
| `@supabase/supabase-js` | ^2.89.0 | Cliente Supabase |
| `@tanstack/react-query` | ^5.90.16 | Gerenciamento de queries |
| `@tauri-apps/api` | ^2.9.1 | API Tauri JS |
| `@tauri-apps/plugin-dialog` | ^2.6.0 | Diálogos nativos |
| `@tauri-apps/plugin-fs` | ^2.4.5 | File system nativo |
| `@tauri-apps/plugin-shell` | ^2.3.4 | Shell commands |
| `@tauri-apps/plugin-store` | ^2.4.2 | Key-value store |
| `@types/bcryptjs` | ^2.4.6 | Tipos bcryptjs |
| `bcryptjs` | ^3.0.3 | Hash de senhas |
| `class-variance-authority` | ^0.7.1 | Variantes de classe CSS |
| `clsx` | ^2.1.1 | Utilitário de classes |
| `date-fns` | ^4.1.0 | Manipulação de datas |
| `exceljs` | ^4.4.0 | Geração de Excel |
| `jspdf` | ^2.5.2 | Geração de PDF |
| `jspdf-autotable` | ^3.8.4 | Tabelas em PDF |
| `lucide-react` | ^0.562.0 | Ícones |
| `next` | ^16.2.4 | Framework React |
| `pako` | ^2.1.0 | Compressão gzip |
| `react` | 19.2.3 | UI library |
| `react-dom` | 19.2.3 | React DOM |
| `sonner` | ^1.7.3 | Toast notifications |
| `tailwind-merge` | ^3.4.0 | Merge de classes Tailwind |
| `tailwindcss-animate` | ^1.0.7 | Animações Tailwind |
| `uuid` | ^14.0.0 | IDs únicos |

### Dependências de Desenvolvimento

| Pacote | Versão | Propósito |
|---|---|---|
| `@tailwindcss/postcss` | ^4 | PostCSS plugin Tailwind 4 |
| `@tauri-apps/cli` | ^2.9.6 | CLI Tauri |
| `@types/node` | ^20 | Tipos Node.js |
| `@types/pako` | ^2.0.4 | Tipos pako |
| `@types/react` | ^19 | Tipos React |
| `@types/react-dom` | ^19 | Tipos React DOM |
| `eslint` | ^9 | Linter |
| `eslint-config-next` | 16.1.1 | Config ESLint Next.js |
| `tailwindcss` | ^4 | CSS utilitário |
| `typescript` | ^5 | Compilador TypeScript |

---

## 3. Backend Tauri (`desktop/src-tauri/Cargo.toml`)

**Nome:** app v0.1.8 | **Rust edition:** 2021 | **MSRV:** 1.77.2

### Dependências Rust

| Crate | Versão | Propósito |
|---|---|---|
| `tauri` | 2.9.5 | Framework desktop |
| `tauri-build` | 2.5.3 | Build scripts |
| `tauri-plugin-log` | 2 | Logging nativo |
| `tauri-plugin-shell` | 2 | Shell commands |
| `tauri-plugin-dialog` | 2 | Diálogos nativos |
| `tauri-plugin-fs` | 2 | File system |
| `rusqlite` | 0.32 | SQLite (bundled, column_decltype) |
| `serde` | 1.0 | Serialização |
| `serde_json` | 1.0 | JSON |
| `log` | 0.4 | Logging facade |
| `anyhow` | 1.0 | Error handling |
| `base64` | 0.22 | Codificação Base64 |
| `bcrypt` | 0.16 | Hash de senhas |
| `sha2` | 0.10 | SHA-256 hashing |
| `hex` | 0.4 | Codificação hexadecimal |
| `chrono` | 0.4 | Datas e horas |
| `aes-gcm` | 0.10 | Criptografia AES-GCM |
| `rand` | 0.8 | Geração de números aleatórios |
| `ureq` | 2.12 | HTTP client |

---

## 4. Serviços Externos

| Serviço | Versão/Plano | Uso |
|---|---|---|
| **Supabase** | nuvem (`vnnimekczkxkpckrydnc.supabase.co`) | Auth, PostgreSQL, Storage, Realtime |
| **ViaCEP** | API pública | Consulta de CEP brasileiro |

---

## 5. Resumo de Versões Críticas

| Tecnologia | Versão |
|---|---|
| Node.js (requerido) | >= 18 (Tauri/Rust requer >= 18) |
| Rust | >= 1.77.2 (Tauri) |
| Next.js | 16.2.4 |
| React | 19.2.3 |
| Tauri | 2.9.x |
| Capacitor | 8.0.x |
| Tailwind CSS | 3.4 (mobile) / 4 (desktop) |
| TypeScript | 5.x |
| Vitest | 3.2.x |
| Supabase JS | 2.58 (mobile) / 2.89 (desktop) |
