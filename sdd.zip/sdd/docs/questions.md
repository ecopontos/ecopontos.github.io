# Perguntas para Validação — ecoformsnext

> Gerado pelo Revisor em 2026-04-30

---

## Pergunta 1 ✅ Respondida

**Contexto:** `CloseDemandaUseCase` — política `declarado`
**Spec afetada:** `_reversa_sdd/sdd/demanda.md`
**Pergunta:** A política "declarado" permite encerrar demanda sem verificar tarefas. É intencional (confiança no declarante)?
**Impacto:** Define se a spec deve documentar verificação adicional.
**Resposta:** Confiança no declarante, mas o gerente poderá revisar posteriormente.

---

## Pergunta 2 ✅ Respondida

**Contexto:** `Client.toggleActive()` existe no domínio mas sem use case exposto
**Spec afetada:** `_reversa_sdd/sdd/client.md`
**Pergunta:** A reativação de cliente inativo é feita manualmente no banco ou deveria existir rota na UI?
**Impacto:** Define se `toggleActive` deve ser exposto como use case.
**Resposta:** Deveria existir rota na UI. É uma lacuna a ser implementada.

---

## Pergunta 3 ✅ Respondida

**Contexto:** Client usa `Date.now()`, Task/Demanda usam `crypto.randomUUID()`
**Spec afetada:** `domain.md`
**Pergunta:** A inconsistência de estratégia de ID é intencional ou débito técnico?
**Impacto:** Define necessidade de migração de IDs.
**Resposta:** É um erro legado ainda não arrumado. É necessário planejar a correção.

---

## Pergunta 4 ✅ Respondida

**Contexto:** `TransportService` sem controle de taxa visível
**Spec afetada:** `_reversa_sdd/sdd/sync.md`
**Pergunta:** Existe rate limiting do lado do Supabase ou confia-se no sync sem throttling?
**Impacto:** Define se a spec deve incluir rate limiting como requisito.
**Resposta:** Não existe rate limit definido. A confiança é desconhecida.

---

## Pergunta 5 ✅ Respondida

**Contexto:** Commit `9bedc83` menciona `tasks.reassign` para "encarregado"
**Spec afetada:** `_reversa_sdd/permissions.md`
**Pergunta:** Quais perfis têm permissão de reassign de tarefas?
**Impacto:** Completa a matriz de permissões RBAC.
**Resposta:** O perfil "encarregado" tem permissão de reassign.

---

## Pergunta 6 ✅ Respondida

**Contexto:** Eventos salvos no SQLite sem mecanismo de limpeza
**Spec afetada:** `domain.md`
**Pergunta:** Existe mecanismo de expurgo ou limite de retenção para eventos do outbox?
**Impacto:** Define se a spec deve incluir política de retenção de eventos.
**Resposta:** Não existe mecanismo de expurgo ainda. É necessário implementar.
