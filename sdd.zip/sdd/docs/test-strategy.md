# Test Strategy — EcoForms Desktop

Este documento define a estratégia de testes do sistema EcoForms Desktop, incluindo unit tests, integration tests, e2e tests, e testes específicos para funcionalidades offline e sync.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `arquitetura.md` | Visão geral da arquitetura e stack |
| `api-contract.md` | Contrato de API e use cases |
| `error-handling.md` | Retry logic e tratamento de erros |
| `deployment.md` | CI/CD pipeline |

---

## Índice

1. [Visão Geral](#1-visão-geral)
2. [Testes Unitários](#2-testes-unitários)
3. [Testes de Integração](#3-testes-de-integração)
4. [Testes End-to-End](#4-testes-end-to-end)
5. [Testes de Sync](#5-testes-de-sync)
6. [Testes Offline](#6-testes-offline)
7. [Testes de Performance](#7-testes-de-performance)
8. [Ferramentas e Configuração](#8-ferramentas-e-configuração)
9. [CI/CD](#9-cicd)
10. [Cobertura de Código](#10-cobertura-de-código)

---

## 1. Visão Geral

### 1.1 Pirâmide de Testes

```
                    ▲
                   / \
                  / e2e \              10% — Playwright
                 /─────────\            (fluxos críticos)
                /           \
               / integration  \         30% — Jest + React Testing Library
              /─────────────────\       (use cases, repositories)
             /                   \
            /     unit tests      \     60% — Jest
           /─────────────────────────\   (entities, utilities, helpers)
```

### 1.2 Categorias de Teste

| Tipo | Escopo | Ferramenta | Frequência |
|------|--------|-----------|------------|
| **Unit** | Funções puras, entities, utilities | Jest | A cada commit |
| **Integration** | Use cases, repositories, services | Jest + SQLite in-memory | A cada commit |
| **Component** | React components isolados | React Testing Library | A cada commit |
| **E2E** | Fluxos completos do usuário | Playwright | Nightly / PR |
| **Sync** | Ciclos de sync, conflitos | Jest + mock Supabase | Nightly |
| **Offline** | Comportamento sem rede | Jest + network stubs | Nightly |
| **Performance** | Tempo de sync, compressão | Benchmark scripts | Semanal |

### 1.3 O que Testar

| Prioridade | Componente | Razão |
|------------|-----------|-------|
| 🔴 Alta | Use cases (Task, Suite, Sync) | Regras de negócio críticas |
| 🔴 Alta | Sync engine (push/pull) | Core do produto |
| 🔴 Alta | Offline queue | Dados não podem ser perdidos |
| 🟡 Média | React components (forms, lists) | UX crítica |
| 🟡 Média | Validation schemas | Prevenção de bugs |
| 🟢 Baixa | UI components simples | Cobertura visual |
| 🟢 Baixa | Build scripts | Raremente quebram |

---

## 2. Testes Unitários

### 2.1 Entities (Domain Layer)

```ts
// src/domain/entities/__tests__/Task.test.ts

import { Task, TaskStatus } from '../Task';

describe('Task Entity', () => {
    describe('create', () => {
        it('should create a task with valid data', () => {
            const task = Task.create({
                titulo: 'Fiscalização Rio Pinheiros',
                tipo: 'fiscalizacao',
                prioridade: 'alta',
                responsavel_id: 'user-123',
            });

            expect(task.titulo).toBe('Fiscalização Rio Pinheiros');
            expect(task.status).toBe('nao_iniciada');
            expect(task.data_criacao).toBeInstanceOf(Date);
        });

        it('should throw if title is empty', () => {
            expect(() =>
                Task.create({
                    titulo: '',
                    tipo: 'fiscalizacao',
                    prioridade: 'alta',
                    responsavel_id: 'user-123',
                })
            ).toThrow('Título da tarefa é obrigatório');
        });

        it('should throw if tipo is invalid', () => {
            expect(() =>
                Task.create({
                    titulo: 'Test',
                    tipo: 'invalido' as any,
                    prioridade: 'alta',
                    responsavel_id: 'user-123',
                })
            ).toThrow('Invalid task type');
        });
    });

    describe('status transitions', () => {
        it('should allow nao_iniciada → em_progresso', () => {
            const task = Task.create({
                titulo: 'Test',
                tipo: 'fiscalizacao',
                prioridade: 'alta',
                responsavel_id: 'user-123',
            });

            task.updateStatus('em_progresso');
            expect(task.status).toBe('em_progresso');
        });

        it('should NOT allow nao_iniciada → cancelada (must go through em_progresso)', () => {
            const task = Task.create({
                titulo: 'Test',
                tipo: 'fiscalizacao',
                prioridade: 'alta',
                responsavel_id: 'user-123',
            });

            expect(() => task.updateStatus('cancelada')).toThrow('InvalidTransitionError');
        });

        it('should record status history', () => {
            const task = Task.create({
                titulo: 'Test',
                tipo: 'fiscalizacao',
                prioridade: 'alta',
                responsavel_id: 'user-123',
            });

            task.updateStatus('em_progresso');
            task.updateStatus('concluida');

            expect(task.status_history).toHaveLength(2);
            expect(task.status_history[0].from).toBe('nao_iniciada');
            expect(task.status_history[0].to).toBe('em_progresso');
        });
    });

    describe('isOverdue', () => {
        it('should return true if prazo is in the past', () => {
            const task = Task.create({
                titulo: 'Test',
                tipo: 'fiscalizacao',
                prioridade: 'alta',
                responsavel_id: 'user-123',
                prazo: new Date(Date.now() - 86400000), // yesterday
            });

            expect(task.isOverdue()).toBe(true);
        });

        it('should return false if prazo is in the future', () => {
            const task = Task.create({
                titulo: 'Test',
                tipo: 'fiscalizacao',
                prioridade: 'alta',
                responsavel_id: 'user-123',
                prazo: new Date(Date.now() + 86400000), // tomorrow
            });

            expect(task.isOverdue()).toBe(false);
        });

        it('should return false if no prazo', () => {
            const task = Task.create({
                titulo: 'Test',
                tipo: 'fiscalizacao',
                prioridade: 'alta',
                responsavel_id: 'user-123',
            });

            expect(task.isOverdue()).toBe(false);
        });
    });
});
```

### 2.2 Validation Schemas

```ts
// src/domain/shared/__tests__/validation.test.ts

import { CreateTaskSchema, CreateUserSchema } from '../validation';

describe('Validation Schemas', () => {
    describe('CreateTaskSchema', () => {
        it('should validate correct task data', () => {
            const result = CreateTaskSchema.safeParse({
                titulo: 'Valid Title',
                prioridade: 'alta',
                tipo: 'fiscalizacao',
                responsavel_id: '550e8400-e29b-41d4-a716-446655440000',
            });

            expect(result.success).toBe(true);
        });

        it('should reject empty title', () => {
            const result = CreateTaskSchema.safeParse({
                titulo: '',
                prioridade: 'alta',
                tipo: 'fiscalizacao',
                responsavel_id: '550e8400-e29b-41d4-a716-446655440000',
            });

            expect(result.success).toBe(false);
            if (!result.success) {
                expect(result.error.errors[0].message).toContain('required');
            }
        });

        it('should reject invalid UUID', () => {
            const result = CreateTaskSchema.safeParse({
                titulo: 'Valid',
                prioridade: 'alta',
                tipo: 'fiscalizacao',
                responsavel_id: 'not-a-uuid',
            });

            expect(result.success).toBe(false);
        });
    });

    describe('CreateUserSchema', () => {
        it('should reject weak password', () => {
            const result = CreateUserSchema.safeParse({
                email: 'test@example.com',
                password: '123',
                nome: 'Test',
                role: 'tecnico',
            });

            expect(result.success).toBe(false);
            if (!result.success) {
                expect(result.error.errors[0].message).toContain('8 characters');
            }
        });

        it('should reject invalid email', () => {
            const result = CreateUserSchema.safeParse({
                email: 'not-an-email',
                password: 'secure123!',
                nome: 'Test',
                role: 'tecnico',
            });

            expect(result.success).toBe(false);
        });
    });
});
```

### 2.3 Utilities

```ts
// lib/sync/__tests__/retry-logic.test.ts

import { retryWithBackoff, isRetryableError } from '../retry-logic';

describe('retryWithBackoff', () => {
    beforeEach(() => {
        jest.useFakeTimers();
    });

    afterEach(() => {
        jest.useRealTimers();
    });

    it('should succeed on first attempt', async () => {
        const fn = jest.fn().mockResolvedValue('success');

        const result = await retryWithBackoff(fn);

        expect(result).toBe('success');
        expect(fn).toHaveBeenCalledTimes(1);
    });

    it('should retry on recoverable error', async () => {
        const fn = jest.fn()
            .mockRejectedValueOnce(new Error('network timeout'))
            .mockResolvedValue('success');

        const promise = retryWithBackoff(fn, { maxRetries: 3, initialDelay: 1000 });

        // Fast-forward past retry delay
        jest.advanceTimersByTime(1000);

        const result = await promise;

        expect(result).toBe('success');
        expect(fn).toHaveBeenCalledTimes(2);
    });

    it('should throw after max retries', async () => {
        const fn = jest.fn().mockRejectedValue(new Error('network timeout'));

        const promise = retryWithBackoff(fn, { maxRetries: 2, initialDelay: 100 });

        jest.advanceTimersByTime(100);
        jest.advanceTimersByTime(200);

        await expect(promise).rejects.toThrow('network timeout');
        expect(fn).toHaveBeenCalledTimes(3); // initial + 2 retries
    });

    it('should not retry non-retryable errors', async () => {
        const fn = jest.fn().mockRejectedValue(new Error('bad request'));

        await expect(retryWithBackoff(fn)).rejects.toThrow('bad request');
        expect(fn).toHaveBeenCalledTimes(1);
    });
});

describe('isRetryableError', () => {
    it('should identify network errors as retryable', () => {
        expect(isRetryableError(new Error('network error'))).toBe(true);
        expect(isRetryableError(new Error('fetch failed'))).toBe(true);
        expect(isRetryableError(new Error('timeout'))).toBe(true);
    });

    it('should identify 5xx errors as retryable', () => {
        const error = new Error('server error');
        (error as any).status = 500;
        expect(isRetryableError(error)).toBe(true);
    });

    it('should identify 429 as retryable', () => {
        const error = new Error('rate limit');
        (error as any).status = 429;
        expect(isRetryableError(error)).toBe(true);
    });

    it('should identify 4xx errors as non-retryable', () => {
        const error = new Error('not found');
        (error as any).status = 404;
        expect(isRetryableError(error)).toBe(false);
    });
});
```

---

## 3. Testes de Integração

### 3.1 Use Cases

```ts
// src/application/use-cases/__tests__/TaskUseCases.test.ts

import { CreateTaskUseCase } from '../CreateTaskUseCase';
import { MoveTaskUseCase } from '../MoveTaskUseCase';
import { SQLiteTaskRepository } from '../../infrastructure/repositories/SQLiteTaskRepository';
import { getTestDatabase } from '../../../test-utils/db';

describe('Task Use Cases', () => {
    let db: Database;
    let taskRepo: SQLiteTaskRepository;
    let createTask: CreateTaskUseCase;
    let moveTask: MoveTaskUseCase;

    beforeEach(async () => {
        db = await getTestDatabase();
        taskRepo = new SQLiteTaskRepository(db);
        createTask = new CreateTaskUseCase(taskRepo);
        moveTask = new MoveTaskUseCase(taskRepo);
    });

    afterEach(async () => {
        await db.close();
    });

    describe('CreateTaskUseCase', () => {
        it('should create task and persist to database', async () => {
            const result = await createTask.execute({
                titulo: 'New Task',
                tipo: 'fiscalizacao',
                prioridade: 'media',
                responsavel_id: 'user-123',
            });

            expect(result.id).toBeDefined();
            expect(result.titulo).toBe('New Task');

            // Verify in database
            const fromDb = await taskRepo.findById(result.id);
            expect(fromDb).toBeDefined();
            expect(fromDb?.titulo).toBe('New Task');
        });

        it('should assign sequential order within project', async () => {
            const projectId = 'proj-123';

            const task1 = await createTask.execute({
                titulo: 'Task 1',
                tipo: 'fiscalizacao',
                prioridade: 'media',
                responsavel_id: 'user-123',
                projeto_id: projectId,
            });

            const task2 = await createTask.execute({
                titulo: 'Task 2',
                tipo: 'fiscalizacao',
                prioridade: 'media',
                responsavel_id: 'user-123',
                projeto_id: projectId,
            });

            expect(task1.ordem).toBe(1);
            expect(task2.ordem).toBe(2);
        });
    });

    describe('MoveTaskUseCase', () => {
        it('should move task between projects', async () => {
            const task = await createTask.execute({
                titulo: 'Task to Move',
                tipo: 'fiscalizacao',
                prioridade: 'media',
                responsavel_id: 'user-123',
                projeto_id: 'proj-a',
            });

            await moveTask.execute({
                taskId: task.id,
                targetProjectId: 'proj-b',
            });

            const updated = await taskRepo.findById(task.id);
            expect(updated?.projeto_id).toBe('proj-b');
            expect(updated?.ordem).toBe(1); // First in new project
        });

        it('should reorder tasks in source project', async () => {
            const projectId = 'proj-123';

            const task1 = await createTask.execute({
                titulo: 'Task 1',
                tipo: 'fiscalizacao',
                prioridade: 'media',
                responsavel_id: 'user-123',
                projeto_id: projectId,
            });

            const task2 = await createTask.execute({
                titulo: 'Task 2',
                tipo: 'fiscalizacao',
                prioridade: 'media',
                responsavel_id: 'user-123',
                projeto_id: projectId,
            });

            await moveTask.execute({
                taskId: task1.id,
                targetProjectId: 'proj-other',
            });

            const remaining = await taskRepo.findByProjectId(projectId);
            expect(remaining[0].id).toBe(task2.id);
            expect(remaining[0].ordem).toBe(1); // Reordered
        });
    });
});
```

### 3.2 Repositories

```ts
// src/infrastructure/repositories/__tests__/SQLiteTaskRepository.test.ts

import { SQLiteTaskRepository } from '../SQLiteTaskRepository';
import { getTestDatabase } from '../../../test-utils/db';

describe('SQLiteTaskRepository', () => {
    let db: Database;
    let repo: SQLiteTaskRepository;

    beforeEach(async () => {
        db = await getTestDatabase();
        repo = new SQLiteTaskRepository(db);
    });

    afterEach(async () => {
        await db.close();
    });

    describe('findByProjectId', () => {
        it('should return tasks ordered by ordem', async () => {
            // Insert test data
            await db.execute(`
                INSERT INTO tbl_tarefas (id, titulo, tipo, prioridade, responsavel_id, projeto_id, ordem)
                VALUES 
                    ('t3', 'Task 3', 'fiscalizacao', 'media', 'u1', 'p1', 3),
                    ('t1', 'Task 1', 'fiscalizacao', 'media', 'u1', 'p1', 1),
                    ('t2', 'Task 2', 'fiscalizacao', 'media', 'u1', 'p1', 2)
            `);

            const tasks = await repo.findByProjectId('p1');

            expect(tasks).toHaveLength(3);
            expect(tasks[0].id).toBe('t1');
            expect(tasks[1].id).toBe('t2');
            expect(tasks[2].id).toBe('t3');
        });

        it('should return empty array for non-existent project', async () => {
            const tasks = await repo.findByProjectId('non-existent');
            expect(tasks).toEqual([]);
        });
    });

    describe('upsert', () => {
        it('should insert new task', async () => {
            const task = {
                id: 'new-task',
                titulo: 'New',
                tipo: 'fiscalizacao',
                status: 'nao_iniciada',
                prioridade: 'baixa',
                responsavel_id: 'u1',
            };

            await repo.upsert(task);

            const found = await repo.findById('new-task');
            expect(found).toBeDefined();
            expect(found?.titulo).toBe('New');
        });

        it('should update existing task', async () => {
            await db.execute(`
                INSERT INTO tbl_tarefas (id, titulo, tipo, status, prioridade, responsavel_id)
                VALUES ('existing', 'Old Title', 'fiscalizacao', 'nao_iniciada', 'baixa', 'u1')
            `);

            await repo.upsert({
                id: 'existing',
                titulo: 'New Title',
                tipo: 'fiscalizacao',
                status: 'nao_iniciada',
                prioridade: 'baixa',
                responsavel_id: 'u1',
            });

            const found = await repo.findById('existing');
            expect(found?.titulo).toBe('New Title');
        });
    });
});
```

### 3.3 Database Helper

```ts
// test-utils/db.ts

import Database from 'tauri-plugin-sql-api';

let testDb: Database | null = null;

export async function getTestDatabase(): Promise<Database> {
    if (testDb) {
        await testDb.execute('ROLLBACK');
        await testDb.execute('BEGIN TRANSACTION');
        return testDb;
    }

    // Use in-memory database for tests
    testDb = await Database.load('sqlite::memory:');

    // Run migrations
    const migrations = await loadMigrations();
    for (const migration of migrations) {
        await testDb.execute(migration);
    }

    await testDb.execute('BEGIN TRANSACTION');
    return testDb;
}

export async function closeTestDatabase(): Promise<void> {
    if (testDb) {
        await testDb.execute('ROLLBACK');
        await testDb.close();
        testDb = null;
    }
}

// jest setup
afterAll(async () => {
    await closeTestDatabase();
});
```

---

## 4. Testes End-to-End

### 4.1 Configuração do Playwright

```ts
// playwright.config.ts

import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
    testDir: './e2e',
    fullyParallel: true,
    forbidOnly: !!process.env.CI,
    retries: process.env.CI ? 2 : 0,
    workers: process.env.CI ? 1 : undefined,
    reporter: 'html',
    use: {
        baseURL: 'http://localhost:3000',
        trace: 'on-first-retry',
        screenshot: 'only-on-failure',
    },

    projects: [
        {
            name: 'chromium',
            use: { ...devices['Desktop Chrome'] },
        },
    ],

    webServer: {
        command: 'npm run dev',
        url: 'http://localhost:3000',
        reuseExistingServer: !process.env.CI,
    },
});
```

### 4.2 Fluxos Críticos

```ts
// e2e/auth.spec.ts

import { test, expect } from '@playwright/test';

test.describe('Authentication', () => {
    test('should login with valid credentials', async ({ page }) => {
        await page.goto('/login');

        await page.fill('[data-testid="email-input"]', 'test@ecoforms.com');
        await page.fill('[data-testid="password-input"]', 'password123');
        await page.click('[data-testid="login-button"]');

        await expect(page).toHaveURL('/dashboard');
        await expect(page.locator('[data-testid="user-name"]')).toContainText('Test User');
    });

    test('should show error for invalid credentials', async ({ page }) => {
        await page.goto('/login');

        await page.fill('[data-testid="email-input"]', 'wrong@ecoforms.com');
        await page.fill('[data-testid="password-input"]', 'wrong');
        await page.click('[data-testid="login-button"]');

        await expect(page.locator('[data-testid="error-message"]')).toContainText('Invalid credentials');
    });
});
```

```ts
// e2e/tasks.spec.ts

import { test, expect } from '@playwright/test';

test.describe('Task Management', () => {
    test.beforeEach(async ({ page }) => {
        // Login
        await page.goto('/login');
        await page.fill('[data-testid="email-input"]', 'test@ecoforms.com');
        await page.fill('[data-testid="password-input"]', 'password123');
        await page.click('[data-testid="login-button"]');
        await page.waitForURL('/dashboard');
    });

    test('should create a new task', async ({ page }) => {
        await page.click('[data-testid="new-task-button"]');

        await page.fill('[data-testid="task-title"]', 'E2E Test Task');
        await page.selectOption('[data-testid="task-type"]', 'fiscalizacao');
        await page.selectOption('[data-testid="task-priority"]', 'alta');
        await page.click('[data-testid="save-task-button"]');

        await expect(page.locator('[data-testid="task-list"]')).toContainText('E2E Test Task');
    });

    test('should move task between projects', async ({ page }) => {
        // Create task in Project A
        await page.click('[data-testid="new-task-button"]');
        await page.fill('[data-testid="task-title"]', 'Task to Move');
        await page.selectOption('[data-testid="task-project"]', 'project-a');
        await page.click('[data-testid="save-task-button"]');

        // Move to Project B
        await page.click('[data-testid="task-more-options"]');
        await page.click('[data-testid="move-task-option"]');
        await page.selectOption('[data-testid="target-project"]', 'project-b');
        await page.click('[data-testid="confirm-move"]');

        // Verify in Project B
        await page.click('[data-testid="project-b-tab"]');
        await expect(page.locator('[data-testid="task-list"]')).toContainText('Task to Move');
    });

    test('should fill and submit a form', async ({ page }) => {
        // Navigate to task with form
        await page.click('[data-testid="task-with-form"]');
        await page.click('[data-testid="open-form-button"]');

        // Fill form fields
        await page.fill('[data-testid="field-nome"]', 'John Doe');
        await page.fill('[data-testid="field-email"]', 'john@example.com');
        await page.click('[data-testid="submit-form-button"]');

        // Verify success
        await expect(page.locator('[data-testid="success-message"]')).toContainText('Form submitted successfully');
    });
});
```

---

## 5. Testes de Sync

### 5.1 Mock de Supabase Storage

```ts
// test-utils/mock-supabase.ts

export class MockSupabaseStorage {
    private files: Map<string, { data: Uint8Array; metadata: any }> = new Map();

    async upload(path: string, data: Blob | File): Promise<{ data: any; error: null }> {
        const arrayBuffer = await data.arrayBuffer();
        this.files.set(path, {
            data: new Uint8Array(arrayBuffer),
            metadata: { createdAt: new Date().toISOString() },
        });
        return { data: { path }, error: null };
    }

    async download(path: string): Promise<{ data: Blob; error: null }> {
        const file = this.files.get(path);
        if (!file) {
            return { data: null as any, error: { message: 'File not found' } as any };
        }
        return { data: new Blob([file.data]), error: null };
    }

    async list(path: string): Promise<{ data: any[]; error: null }> {
        const files = Array.from(this.files.keys())
            .filter(f => f.startsWith(path))
            .map(f => ({
                name: f.split('/').pop(),
                metadata: this.files.get(f)?.metadata,
            }));
        return { data: files, error: null };
    }

    async remove(paths: string[]): Promise<{ data: any; error: null }> {
        for (const path of paths) {
            this.files.delete(path);
        }
        return { data: null, error: null };
    }

    clear(): void {
        this.files.clear();
    }
}

export function createMockSupabaseClient(storage: MockSupabaseStorage) {
    return {
        storage: {
            from: () => ({
                upload: storage.upload.bind(storage),
                download: storage.download.bind(storage),
                list: storage.list.bind(storage),
                remove: storage.remove.bind(storage),
            }),
        },
        auth: {
            getSession: jest.fn().mockResolvedValue({
                data: { session: { user: { id: 'test-user' } } },
            }),
        },
    };
}
```

### 5.2 Testes de Sync Cycle

```ts
// lib/sync/__tests__/storage-sync.test.ts

import { StorageSync } from '../storage-sync';
import { MockSupabaseStorage, createMockSupabaseClient } from '../../../test-utils/mock-supabase';

describe('StorageSync', () => {
    let mockStorage: MockSupabaseStorage;
    let supabase: any;
    let sync: StorageSync;

    beforeEach(() => {
        mockStorage = new MockSupabaseStorage();
        supabase = createMockSupabaseClient(mockStorage);
        sync = new StorageSync(supabase, 'test-device');
    });

    describe('push', () => {
        it('should push data and create snapshot', async () => {
            const data = {
                tbl_suite: [
                    { package_id: 'pkg-1', status: 'current', data: { test: true } },
                ],
            };

            const result = await sync.push(data, 'incremental');

            expect(result.success).toBe(true);
            expect(result.filename).toMatch(/snapshot-\d+\.json\.gz/);

            // Verify file exists in mock storage
            const files = await mockStorage.list('users/test-device/inbox/');
            expect(files.data).toHaveLength(1);
        });

        it('should calculate checksum correctly', async () => {
            const data = { test: 'data' };

            const result = await sync.push(data, 'incremental');
            expect(result.checksum).toBeDefined();
            expect(result.checksum).toHaveLength(64); // SHA-256 hex
        });
    });

    describe('pull', () => {
        it('should pull and validate snapshots', async () => {
            // Push first
            const pushData = {
                tbl_suite: [{ package_id: 'pkg-1', status: 'current' }],
            };
            await sync.push(pushData, 'incremental');

            // Move to inbox for pull
            const files = await mockStorage.list('users/test-device/inbox/');
            const filename = files.data[0].name;

            // Pull
            const results = await sync.pull();

            expect(results).toHaveLength(1);
            expect(results[0].data.tbl_suite).toHaveLength(1);
        });

        it('should handle corrupted snapshot', async () => {
            // Inject corrupted file
            const corruptedData = new TextEncoder().encode('corrupted data');
            await mockStorage.upload('users/test-device/inbox/corrupted.json', new Blob([corruptedData]));

            const results = await sync.pull();

            // Should skip corrupted file and continue
            expect(results).toHaveLength(0);
        });
    });

    describe('snapshot validation', () => {
        it('should detect checksum mismatch', async () => {
            const data = { test: 'data' };
            const result = await sync.push(data, 'incremental');

            // Corrupt the file
            const files = await mockStorage.list('users/test-device/inbox/');
            const filename = files.data[0].name;
            const path = `users/test-device/inbox/${filename}`;

            const { data: blob } = await mockStorage.download(path);
            const corrupted = new Uint8Array(await blob.arrayBuffer());
            corrupted[10] = corrupted[10] ^ 0xFF; // Flip a bit

            await mockStorage.upload(path, new Blob([corrupted]));

            // Pull should attempt recovery
            const results = await sync.pull();
            // Depending on recovery strategy, might still work or skip
        });
    });
});
```

---

## 6. Testes Offline

### 6.1 Network Stubbing

```ts
// lib/offline-queue/__tests__/offline-queue.test.ts

import { OfflineQueue } from '../offline-queue';
import { openDB } from 'idb';

describe('OfflineQueue', () => {
    let queue: OfflineQueue;
    let mockDb: any;

    beforeEach(async () => {
        // Use mock IndexedDB
        mockDb = await openDB('test-queue', 1, {
            upgrade(db) {
                db.createObjectStore('mutations', { keyPath: 'id' });
            },
        });
        queue = new OfflineQueue(mockDb);
    });

    afterEach(async () => {
        await mockDb.clear('mutations');
        await mockDb.close();
    });

    describe('enqueue', () => {
        it('should store mutation in IndexedDB', async () => {
            await queue.enqueue(
                'UPDATE tbl_tarefas SET status = ? WHERE id = ?',
                ['em_progresso', 'task-123'],
                'Move task to em_progresso'
            );

            const mutations = await mockDb.getAll('mutations');
            expect(mutations).toHaveLength(1);
            expect(mutations[0].sql).toContain('UPDATE tbl_tarefas');
        });

        it('should assign unique ID and timestamp', async () => {
            await queue.enqueue('SQL 1', [], 'Label 1');
            await queue.enqueue('SQL 2', [], 'Label 2');

            const mutations = await mockDb.getAll('mutations');
            expect(mutations[0].id).not.toBe(mutations[1].id);
            expect(mutations[0].timestamp).toBeLessThan(mutations[1].timestamp);
        });
    });

    describe('processAll', () => {
        it('should process mutations in FIFO order', async () => {
            const processed: string[] = [];

            await queue.enqueue('SQL 1', [], 'First');
            await queue.enqueue('SQL 2', [], 'Second');
            await queue.enqueue('SQL 3', [], 'Third');

            await queue.processAll(async (sql) => {
                processed.push(sql);
            });

            expect(processed).toEqual(['SQL 1', 'SQL 2', 'SQL 3']);
        });

        it('should retry failed mutations up to max retries', async () => {
            let attempts = 0;

            await queue.enqueue('FAILING SQL', [], 'Will fail');

            const result = await queue.processAll(async () => {
                attempts++;
                throw new Error('Database error');
            });

            expect(attempts).toBe(3); // Max retries
            expect(result.failed).toHaveLength(1);
        });

        it('should stop processing on failure and resume later', async () => {
            const processed: string[] = [];

            await queue.enqueue('SQL 1', [], 'First');
            await queue.enqueue('SQL 2', [], 'Second');

            // First process — fail on second
            await queue.processAll(async (sql) => {
                if (sql === 'SQL 2') throw new Error('Fail');
                processed.push(sql);
            });

            expect(processed).toEqual(['SQL 1']);

            // Second process — should retry SQL 2
            processed.length = 0;
            await queue.processAll(async (sql) => {
                processed.push(sql);
            });

            expect(processed).toEqual(['SQL 2']);
        });

        it('should discard mutations after max retries', async () => {
            await queue.enqueue('ALWAYS FAILS', [], 'Doomed');

            // Process 3 times (initial + 2 retries)
            for (let i = 0; i < 3; i++) {
                await queue.processAll(async () => {
                    throw new Error('Always fails');
                });
            }

            // Should be discarded
            const mutations = await mockDb.getAll('mutations');
            expect(mutations).toHaveLength(0);
        });
    });
});
```

### 6.2 Testes de Comportamento Offline

```ts
// lib/sync/__tests__/offline-behavior.test.ts

import { SyncService } from '../../../src/infrastructure/sync/SyncService';
import { MockSupabaseStorage } from '../../../test-utils/mock-supabase';

describe('Offline Behavior', () => {
    let syncService: SyncService;
    let mockStorage: MockSupabaseStorage;

    beforeEach(() => {
        mockStorage = new MockSupabaseStorage();
        syncService = new SyncService(/* inject repos e usecases */);
    });

    it('should queue mutations when offline', async () => {
        // Simulate offline
        jest.spyOn(navigator, 'onLine', 'get').mockReturnValue(false);

        const result = await syncService.syncAll();

        // Should not fail, but queue operations
        expect(result.success).toBe(true); // Offline is not a failure
    });

    it('should sync when coming back online', async () => {
        // Start offline
        jest.spyOn(navigator, 'onLine', 'get').mockReturnValue(false);

        // Perform operation while offline
        // ... (would queue mutation)

        // Come back online
        jest.spyOn(navigator, 'onLine', 'get').mockReturnValue(true);

        // Trigger sync
        const result = await syncService.syncAll();

        expect(result.synced.tasks_push).toBeGreaterThan(0);
    });
});
```

---

## 7. Testes de Performance

### 7.1 Benchmark de Compressão

```ts
// benchmarks/compression.bench.ts

import { compressSnapshot, decompressSnapshot } from '../lib/sync/compression';

describe('Compression Benchmark', () => {
    const sizes = [100, 500, 1000, 5000];

    for (const size of sizes) {
        it(`should compress ${size} records under 100ms`, async () => {
            const data = generateTestData(size);
            const json = JSON.stringify(data);

            const start = performance.now();
            const compressed = await compressSnapshot(json);
            const end = performance.now();

            expect(end - start).toBeLessThan(100);

            const ratio = json.length / compressed.length;
            expect(ratio).toBeGreaterThan(3); // At least 3x compression
        });

        it(`should decompress ${size} records under 50ms`, async () => {
            const data = generateTestData(size);
            const json = JSON.stringify(data);
            const compressed = await compressSnapshot(json);

            const start = performance.now();
            const decompressed = await decompressSnapshot(compressed);
            const end = performance.now();

            expect(end - start).toBeLessThan(50);
            expect(JSON.parse(decompressed)).toEqual(data);
        });
    }
});

function generateTestData(count: number) {
    return {
        tbl_suite: Array.from({ length: count }, (_, i) => ({
            package_id: `pkg-${i}`,
            status: 'current',
            data: {
                field1: `value-${i}`,
                field2: Math.random(),
                field3: Array.from({ length: 10 }, () => Math.random()),
            },
        })),
    };
}
```

### 7.2 Benchmark de Sync

```ts
// benchmarks/sync.bench.ts

import { SyncService } from '../src/infrastructure/sync/SyncService';

describe('Sync Benchmark', () => {
    it('should sync 500 records under 5 seconds', async () => {
        const service = new SyncService(/* inject repos e usecases */);

        // Insert 500 test records
        await seedDatabase(500);

        const start = performance.now();
        const result = await service.syncAll();
        const end = performance.now();

        expect(end - start).toBeLessThan(5000);
        expect(result.synced.tbl_suite_push).toBe(500);
    });

    it('should handle incremental sync efficiently', async () => {
        const service = new SyncService(/* inject repos e usecases */);

        // Full sync first
        await seedDatabase(1000);
        await service.syncAll();

        // Modify only 10 records
        await modifyRecords(10);

        const start = performance.now();
        const result = await service.syncAll();
        const end = performance.now();

        // Incremental should be much faster
        expect(end - start).toBeLessThan(1000);
        expect(result.synced.tbl_suite_push).toBe(10);
    });
});
```

---

## 8. Ferramentas e Configuração

### 8.1 Stack de Testes

| Ferramenta | Uso | Versão |
|------------|-----|--------|
| **Jest** | Unit + Integration tests | ^29.0 |
| **React Testing Library** | Component tests | ^14.0 |
| **Playwright** | E2E tests | ^1.40 |
| **MSW** | Mock Service Worker (API mocking) | ^2.0 |
| **jest-sqlite** | SQLite in-memory para tests | ^1.0 |
| **Benchmark.js** | Performance benchmarks | ^2.1 |

### 8.2 Configuração do Jest

```ts
// jest.config.ts

import type { Config } from 'jest';

const config: Config = {
    preset: 'ts-jest',
    testEnvironment: 'node',
    roots: ['<rootDir>/src', '<rootDir>/lib'],
    testMatch: ['**/__tests__/**/*.test.ts'],
    moduleNameMapper: {
        '^@/(.*)$': '<rootDir>/src/$1',
        '^@lib/(.*)$': '<rootDir>/lib/$1',
    },
    setupFilesAfterEnv: ['<rootDir>/test-utils/setup.ts'],
    coverageDirectory: 'coverage',
    coverageReporters: ['text', 'lcov', 'html'],
    collectCoverageFrom: [
        'src/**/*.{ts,tsx}',
        'lib/**/*.{ts,tsx}',
        '!src/**/*.d.ts',
        '!src/**/__tests__/**',
        '!src/**/*.stories.{ts,tsx}',
    ],
    coverageThreshold: {
        global: {
            branches: 70,
            functions: 70,
            lines: 70,
            statements: 70,
        },
    },
    // Handle Tauri APIs in tests
    moduleNameMapper: {
        '^@tauri-apps/api/(.*)$': '<rootDir>/test-utils/mocks/tauri-$1.ts',
    },
};

export default config;
```

### 8.3 Mocks

```ts
// test-utils/mocks/tauri-fs.ts

export const readTextFile = jest.fn();
export const writeTextFile = jest.fn();
export const readDir = jest.fn();
export const createDir = jest.fn();
export const removeFile = jest.fn();
export const copyFile = jest.fn();
export const BaseDirectory = {
    AppData: 1,
    Document: 2,
};
```

```ts
// test-utils/mocks/tauri-process.ts

export const relaunch = jest.fn();
export const exit = jest.fn();
```

```ts
// test-utils/setup.ts

// Mock IndexedDB
import 'fake-indexeddb/auto';

// Mock Tauri APIs
jest.mock('@tauri-apps/api/fs', () => require('./mocks/tauri-fs'));
jest.mock('@tauri-apps/api/process', () => require('./mocks/tauri-process'));
jest.mock('@tauri-apps/api/notification', () => ({
    isPermissionGranted: jest.fn().mockResolvedValue(true),
    sendNotification: jest.fn(),
}));

// Global test utilities
global.structuredClone = (val: any) => JSON.parse(JSON.stringify(val));

// Cleanup after each test
afterEach(() => {
    jest.clearAllMocks();
});
```

---

## 9. CI/CD

### 9.1 Pipeline de Testes

```yaml
# .github/workflows/test.yml
name: Tests

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

jobs:
  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 18
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Run unit tests
        run: npm run test -- --coverage

      - name: Upload coverage
        uses: codecov/codecov-action@v3
        with:
          files: ./coverage/lcov.info

  integration-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 18

      - name: Install dependencies
        run: npm ci

      - name: Run integration tests
        run: npm run test:integration

  e2e-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 18

      - name: Install dependencies
        run: npm ci

      - name: Install Playwright
        run: npx playwright install --with-deps

      - name: Run E2E tests
        run: npm run test:e2e

      - name: Upload test results
        uses: actions/upload-artifact@v3
        if: always()
        with:
          name: playwright-report
          path: playwright-report/

  performance-tests:
    runs-on: ubuntu-latest
    if: github.event_name == 'schedule' # Nightly only
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 18

      - name: Install dependencies
        run: npm ci

      - name: Run benchmarks
        run: npm run benchmark

      - name: Upload benchmark results
        uses: actions/upload-artifact@v3
        with:
          name: benchmark-results
          path: benchmark-results/
```

---

## 10. Cobertura de Código

### 10.1 Metas de Cobertura

| Componente | Meta | Mínimo |
|------------|------|--------|
| Domain (entities, value objects) | 90% | 85% |
| Application (use cases) | 85% | 80% |
| Infrastructure (repositories) | 80% | 70% |
| UI Components (critical paths) | 70% | 60% |
| Sync Engine | 85% | 80% |
| **Global** | **75%** | **70%** |

### 10.2 Relatório de Cobertura

```
Coverage summary
─────────────────
Statements   : 78.45% ( 2345/2989 )
Branches     : 72.30% ( 890/1231 )
Functions    : 75.80% ( 456/601 )
Lines        : 79.12% ( 2103/2658 )

Uncovered files:
  src/components/ui/Button.tsx (45%)
  src/components/ui/Modal.tsx (52%)
  src/hooks/useForm.ts (60%)
  lib/sync/retry-logic.ts (85%)
```

### 10.3 Ignorar em Cobertura

```ts
// jest.config.ts
{
    coveragePathIgnorePatterns: [
        '/node_modules/',
        '/test-utils/',
        '/__tests__/',
        '/stories/',
        '/migrations/',
        '\\.d\\.ts$',
    ],
}
```

---

## Resumo

| Tipo | Frequência | Tempo | Responsável |
|------|-----------|-------|-------------|
| Unit Tests | A cada commit | < 30s | Dev |
| Integration Tests | A cada commit | < 2min | Dev |
| Component Tests | A cada commit | < 1min | Dev |
| E2E Tests | Nightly / PR | < 10min | CI |
| Sync Tests | Nightly | < 5min | CI |
| Offline Tests | Nightly | < 3min | CI |
| Performance | Semanal | < 15min | CI |
| Coverage Report | A cada commit | N/A | CI |

---

## Checklist de Qualidade

- [ ] Todos os use cases têm testes de integração
- [ ] Todas as entities têm testes unitários
- [ ] Fluxos críticos têm testes E2E
- [ ] Sync engine tem testes de conflito
- [ ] Offline queue tem testes de recovery
- [ ] Cobertura global > 70%
- [ ] Nightly build passa (incluindo E2E)
- [ ] Performance benchmarks não regrediram