# Code Analysis — Módulo `client`

> Archaeologist — 2026-04-30 | Confiança: 🟢 CONFIRMADO (extraído do código fonte)

---

## 1. Arquitetura do Módulo

O módulo `client` segue Clean Architecture com 4 camadas bem definidas:

```
Domain (entidade + interface de repositório)
  └─ Client.ts              — Entidade com props imutáveis via fromProps/toProps
  └─ ClientRepository.ts    — Contrato de persistência

Application (casos de uso)
  └─ CreateClientUseCase    — Criação com validação de duplicidade indireta
  └─ UpdateClientUseCase    — Atualização parcial com merge de campos
  └─ DeleteClientUseCase    — Deleção lógica (soft-delete)
  └─ ListClientsUseCase     — Listagem com filtro ativoOnly (default true)
  └─ GetClientByIdUseCase   — Busca por ID
  └─ CheckClientNameExistsUseCase — Validação de nome único
  └─ ListClientContactsUseCase     — Lista contatos vinculados
  └─ ListClientTypesUseCase        — Lista tipos de PJ
  └─ GetClientAuditLogUseCase      — Histórico de alterações
  └─ DTOs (ClientDto, ClientContactDto, etc.) + mappers

Infrastructure (implementação concreta)
  └─ SqliteClientRepository — Persistência em SQLite

Interface (React hooks + presenters)
  └─ useClientUseCases      — DI via container
  └─ useClientMutations     — Hook de mutações (create/update/delete)
  └─ useClients / useClientById / useClientQueries / useClientSearch
  └─ toClientViewModel      — Formatação para UI
```

---

## 2. Fluxo de Controle

### 2.1 Criação de Cliente (`CreateClientUseCase`)

```
1. Recebe CreateClientInput { nome*, cnpj?, telefone?, ... }
2. Gera idPJ via Date.now() (timestamp milissegundos)
3. Cria Client.fromProps() com inativo=false, timestamps preenchidos
4. Persiste via repo.save(client) → SqliteClientRepository.save()
5. Retorna ClientDto formatado via toClientDto()
```

**Particularidades:**
- A validação de nome duplicado NÃO é feita dentro do UseCase — é responsabilidade da camada de interface chamar `CheckClientNameExistsUseCase` antes.
- O ID é int64 (timestamp), não UUID nem autoincrement.

### 2.2 Atualização de Cliente (`UpdateClientUseCase`)

```
1. Busca cliente existente via repo.findById(idPJ)
2. Se não encontrado, lança Error
3. Chama existing.update(partialProps) — merge via Object.assign
4. Atualiza atualizadoEm para timestamp atual
5. Persiste via repo.save()
```

### 2.3 Deleção de Cliente (`DeleteClientUseCase`)

```
1. Recebe idPJ
2. Delega para repo.delete(idPJ)
   → SQL: UPDATE tblPJuridicas SET Inativo = 1 WHERE id_legacy = ?
```

**Importante:** É soft-delete. O registro permanece no banco, apenas marcado como inativo.

### 2.4 Listagem de Clientes (`ListClientsUseCase`)

```
1. Recebe input opcional { ativoOnly?: boolean }
2. Default: ativoOnly = true (mostra apenas ativos)
3. Consulta SQL com LEFT JOIN em tblPJtipo para nome do tipo
4. Filtro WHERE: Inativo IS NULL OR Inativo = 0 OR Inativo = ''
5. Ordenação: ORDER BY Cliente ASC
```

### 2.5 Save (Upsert) no SqliteClientRepository

```
1. Verifica existência: SELECT id_legacy FROM tblPJuridicas WHERE id_legacy = ? LIMIT 1
2. Se não encontrado: INSERT com 14 colunas
3. Se encontrado: UPDATE com 13 colunas + WHERE id_legacy = ?
```

---

## 3. Algoritmos e Lógica

### 3.1 Mapeamento Row → Client

O método `rowToClient()` converte da nomenclatura do banco (legado) para o domínio:

| Coluna SQL | Campo Client | Transformação |
|---|---|---|
| `id_legacy` | `idPJ` | alias direto |
| `Cliente` | `nome` | rename |
| `CNPJ` | `cnpj` | `?? undefined` |
| `Inativo` | `inativo` | `!!row.Inativo && row.Inativo !== 0 && row.Inativo !== ''` |
| `tipo_nome` | `tipoNome` | `?? undefined` |
| `criado_em` | `criadoEm` | `?? undefined` |

A lógica de `inativo` é tolerante: aceita 0, '', null, undefined como "ativo".

### 3.2 Validação de Nome Duplicado

```
SELECT COUNT(*) AS count FROM tblPJuridicas WHERE Cliente = ?
-- (com excludeId: AND id_legacy != ?)
```

Permite que um registro mantenha o mesmo nome durante update.

### 3.3 Busca FTS5 (useClientSearch)

Prepara query full-text search quebrando o termo em palavras, adicionando sufixo `*` (prefix matching) e unindo com `OR`:

```
'termo busca' → 'termo* OR busca*'
```

Mínimo de 2 caracteres para ativar a busca. Limite de 50 resultados.

---

## 4. Estruturas de Dados

### 4.1 Banco de Dados — `tblPJuridicas`

| Coluna | Tipo | Obrigatório | Mapeamento |
|---|---|---|---|
| `id_legacy` | INTEGER | PK | idPJ |
| `Cliente` | TEXT | Sim | nome |
| `CNPJ` | TEXT | Não | cnpj |
| `Telefone` | TEXT | Não | telefone |
| `Telefone2` | TEXT | Não | telefone2 |
| `Email` | TEXT | Não | email |
| `CEP` | TEXT | Não | cep |
| `Endereco` | TEXT | Não | endereco |
| `Numero` | TEXT | Não | numero |
| `Bairro` | TEXT | Não | bairro |
| `Cidade` | TEXT | Não | cidade |
| `Estado` | TEXT | Não | estado |
| `Inativo` | INTEGER/TEXT | Não | inativo (tolerante a tipos) |
| `idPJtipo` | INTEGER | Não | FK → tblPJtipo |

### 4.2 Tabelas Relacionadas

| Tabela | Propósito | Joins |
|---|---|---|
| `tblPJtipo` | Tipos de pessoa jurídica | `LEFT JOIN ON p.idPJtipo = t.idPJtipo` |
| `tblContatos` | Vínculo PJ ↔ PF | `INNER JOIN tblPFisicas ON c.idPF = pf.idPF` |
| `tblPFisicas` | Pessoas físicas (contatos) | JOIN via tblContatos |
| `tblCEP` | Dados de endereço por CEP | `LEFT JOIN ON p.CEP = c.CEP` |
| `tblPJuridicas_history` | Histórico de alterações | `WHERE id_legacy = ?` |
| `tbl_pjuridicas_fts` | Índice FTS5 para busca textual | `WHERE tbl_pjuridicas_fts MATCH ?` |

---

## 5. Diagrama de Sequência — Create Client

```mermaid
sequenceDiagram
    participant UI as React Component
    participant Mut as useClientMutations
    participant UC as CreateClientUseCase
    participant Repo as SqliteClientRepository
    participant DB as SQLite

    UI->>Mut: createPJ(formData)
    Mut->>UC: uc.nameExists.execute(nome)
    UC->>Repo: nameExists(nome)
    Repo->>DB: SELECT COUNT(*) WHERE Cliente = ?
    DB-->>Repo: { count: 0 }
    Repo-->>UC: false
    UC-->>Mut: false (nome disponível)

    Mut->>UC: uc.create.execute(input)
    UC->>UC: Client.fromProps({...input, inativo:false, criadoEm:now})
    UC->>Repo: save(client)
    Repo->>DB: SELECT id_legacy WHERE = ?
    DB-->>Repo: [] (não existe)
    Repo->>DB: INSERT INTO tblPJuridicas (...)
    Repo-->>UC: void
    UC-->>Mut: ClientDto
    Mut-->>UI: sucesso
```

---

## 6. Métricas do Módulo

| Métrica | Valor |
|---|---|
| Use Cases | 9 |
| Entidades de domínio | 1 (Client) + 3 interfaces auxiliares |
| Arquivos de código | 14 (excluindo testes) |
| Testes | 2 (Create + List) |
| Complexidade ciclomática estimada | Baixa (CRUD padrão) |
| Tabelas SQL envolvidas | 7 |
| Integrações externas | Nenhuma (SQLite local) |

---

## 7. Observações

- O módulo usa nomenclatura de banco legado (colunas em português com espaços: `[Tipo de PJ]`), com camada de mapeamento no repositório.
- A geração de ID via `Date.now()` pode causar colisões em cenários de alta concorrência — não há mecanismo de retry.
- O hook `useClientMutations` contém stubs não implementados (`createPF`, `updatePF`, `linkContact`, `unlinkContact`) que lançam erro.
- O `delete` (soft-delete) não distingue entre "excluir" e "inativar" — não há método para reativar explicitamente via UseCase (embora `Client.toggleActive()` exista no domínio).
- O módulo Client é o único que implementa FTS5 para busca textual completa (outros módulos usam queries diretas).

---

# Code Analysis — Módulo `task`

> Archaeologist — 2026-04-30 | Confiança: 🟢 CONFIRMADO

---

## 1. Arquitetura do Módulo

```
Domain (entidade + máquina de estados + repositório)
  └─ Task.ts              — Entidade com state machine embutida
  └─ TaskStatus.ts        — Máquina de estados (4 estados, transições definidas)
  └─ TaskRecurrence.ts    — Cálculo de recorrência + normalização de status
  └─ TaskRepository.ts    — Contrato de persistência + query builder

Application (casos de uso)
  └─ CreateTaskUseCase    — Criação (UUID, nextOrder, status inicial a_fazer)
  └─ MoveTaskUseCase      — Transição de status + reordenação
  └─ AssignTaskUseCase    — Atribuição de responsável
  └─ ArchiveTaskUseCase   — Arquivamento lógico
  └─ DeleteTaskUseCase    — Soft-delete (deletado_em)
  └─ ListTasksByProjectUseCase — Listagem por projeto/backlog
  └─ DTOs + mappers

Infrastructure
  └─ SqliteTaskRepository — Persistência SQLite (tabela tbl_tarefas)

Interface
  └─ useTaskUseCases, useKanban, hooks de query/mutation
```

---

## 2. Fluxo de Controle

### 2.1 Criação de Tarefa

```
1. Recebe CreateTaskInput { titulo*, criadoPor*, projetoId?, ... }
2. Gera UUID via crypto.randomUUID()
3. Calcula nextOrder (MAX + 1000) por projeto + status a_fazer
4. Status inicial: 'a_fazer', prioridade default: 'media'
5. Valida título não vazio após trim
6. Persiste via repo.save()
```

### 2.2 Transição de Status (Move)

```
1. Busca task por ID (NotFoundError se ausente)
2. Chama task.transitionTo(newStatus) — valida transição
3. Se ordem fornecida, reordena
4. Persiste
```

**Transições válidas:**
```
a_fazer     → em_progresso, cancelado
em_progresso → a_fazer, concluido, cancelado
concluido   → (terminal)
cancelado   → (terminal)
```

### 2.3 Delete (Soft-Delete)

Diferente de Client que usa flag `Inativo`, task marca `deletado_em = datetime('now')` e filtra via `WHERE deletado_em IS NULL`.

---

## 3. Algoritmos e Lógica

### 3.1 Máquina de Estados

Definida em `TaskStatus.ts` como um mapa de transições permitidas. Terminal states não aceitam transições. Erros tipados via `InvalidTransitionError`.

### 3.2 Cálculo de Recorrência (`TaskRecurrence.ts`)

Suporta 4 frequências com intervalo configurável:

| Frequência | Cálculo |
|---|---|
| `diaria` | `current + intervalo` dias |
| `semanal` | Próximo dia entre `dias_semana` ou `+ 7 * intervalo` |
| `mensal` | `current + intervalo` meses |
| `anual` | `current + intervalo` anos |

Respeita `fim_recorrencia` (data limite inclusiva).

### 3.3 Ordem com Gap (nextOrder)

Retorna `MAX(ordem) + 1000` para o par (projeto, status). O gap de 1000 permite inserir tarefas entre existentes sem reordenar todas.

### 3.4 Normalização de Status

Função `normalizeStatus()` mapeia status de solicitações para formato canônico:
`pendente/pending → submitted`, `aprovado → approved`, `rejeitado → rejected`, `concluido → processed`.

---

## 4. Estruturas de Dados

### 4.1 Tabela SQLite — `tbl_tarefas`

| Coluna | Tipo | Descrição |
|---|---|---|
| `id` | TEXT PK | UUID |
| `projeto_id` | TEXT NULL | FK para projeto |
| `titulo` | TEXT | Título da tarefa |
| `descricao` | TEXT NULL | Descrição |
| `status` | TEXT | a_fazer, em_progresso, concluido, cancelado |
| `prioridade` | TEXT | baixa, media, alta |
| `atribuido_para` | TEXT NULL | User ID |
| `criado_por` | TEXT | User ID do criador |
| `prazo` | TEXT NULL | Data de prazo (único) |
| `prazo_fim` | TEXT NULL | Data fim (período) |
| `tipo_prazo` | TEXT NULL | unico, periodo, recorrente |
| `recorrencia` | TEXT NULL | Config JSON de recorrência |
| `ordem` | INTEGER | Posição (MAX + 1000) |
| `arquivado` | INTEGER | 0 ou 1 |
| `form_registry_id` | TEXT NULL | FK form registry |
| `tbl_suite_id` | TEXT/NUM NULL | FK suite |
| `demanda_id` | TEXT NULL | FK demanda |
| `deletado_em` | TEXT NULL | Soft-delete timestamp |
| `created_at` | TEXT | ISO datetime |
| `updated_at` | TEXT | ISO datetime |

---

## 5. Diagrama da Máquina de Estados

```mermaid
stateDiagram-v2
    [*] --> a_fazer: CreateTask
    a_fazer --> em_progresso: transitionTo()
    a_fazer --> cancelado: transitionTo()
    em_progresso --> a_fazer: transitionTo()
    em_progresso --> concluido: transitionTo()
    em_progresso --> cancelado: transitionTo()
    concluido --> [*]
    cancelado --> [*]
```

---

## 6. Métricas

| Métrica | Valor |
|---|---|
| Use Cases | 7 |
| Estados da máquina | 4 |
| Transições possíveis | 6 |
| Frequências de recorrência | 4 |
| Arquivos de código | 8 (excluindo testes) |
| Complexidade | Média (state machine + recorrência) |

---

# Code Analysis — Módulo `demanda`

> Archaeologist — 2026-04-30 | Confiança: 🟢 CONFIRMADO

---

## 1. Arquitetura

Domain: Demanda, DemandaEvento (event sourcing lite), TarefaFormulario, DemandaRepository (c/ transações).
Application: Create, Accept (transacional), Close (c/ política), GetStatus (agregação).
Infra: SqliteDemandaRepository (3 tabelas: tbl_demandas, tbl_demanda_eventos, tbl_tarefa_formularios).

---

## 2. Workflow

```
aberta ──(accept)──► aceita ──► em_campo ──► concluida
  │                                              ▲
  └──── (auto-aceite origem='proprio') ──────────┘
```

**Auto-aceite**: demanda com `origemTipo === 'proprio'` nasce direto como `aceita`.

---

## 3. Políticas de Conclusão

| Política | Verificação |
|---|---|
| `todas` | `allTarefasObrigatoriasConcluidasParaDemanda()` |
| `declarado` | Sem verificação |

---

## 4. AcceptDemanda (Transacional)

Operação mais complexa — atômica via `repo.transaction()`:
1. Atualiza status → `aceita`
2. Cria Tasks (UUID, nextOrder, prioridade)
3. Cria TarefaFormularios (form_registry_id, snapshot, obrigatorio)
4. Registra evento `demanda.tarefa.criada` por tarefa
5. Registra evento `demanda.aceita`

---

## 5. Event Sourcing Lite

4 eventos imutáveis: `demanda.criada`, `demanda.aceita`, `demanda.tarefa.criada`, `demanda.encerrada`. Campos de correlação (correlationId, causationId).

---

## 6. Métricas

| Métrica | Valor |
|---|---|
| Use Cases | 4 |
| Estados | 4 |
| Tabelas | 3 (+ tbl_tarefas FK) |
| Complexidade | Média (transações + workflow + event sourcing) |

---

# Code Analysis — Módulo `ouvidoria`

> Archaeologist — 2026-04-30 | Confiança: 🟢 CONFIRMADO

Entidades: **Protocolo** (ticket com status), **ProtocoloEvento** (eventos encadeados), **Atendimento** (registro de atendimento vinculado). 13 use cases. IDs numéricos (legado). Queries ao Supabase (não SQLite local como os demais). Operações: listar, criar, buscar, atualizar status, encerrar, upsert atendimento, contagem de abertos, assuntos, subtemas, mensagens.

Sem máquina de estados formal — status é string livre. Sem transações explícitas. Complexidade: baixa.

---

# Code Analysis — Módulo `crm`

2 entidades: **Rota** (posição de cliente em roteiro), **Roteiro** (template de coleta). + **Coleta** (registro de coleta realizada). 5 use cases: listar roteiros, rotas por cliente, coletas por roteiro, criar rota, atualizar ordem, deletar. IDs numéricos. Complexidade: baixa.

---

# Code Analysis — Módulo `suite`

**Entidade mais sofisticada do sistema.** 11-status state machine (`draft→current→edit/locked/pending_review→superseded/closed`). Versionamento (versionNo). Lock/unlock. createNewVersion (incrementa versão + novo payload). parsePayload genérico. Histórico de transições (SuiteHistoryEntry). 4 use cases: submit (cria/versiona), edit, review, listInbox. Persiste em `tbl_suite`. Complexidade: alta.

---

# Code Analysis — Módulo `data-registry`

**Registro genérico tipado.** Entidade DataRegistryItem: id (string), tipo (classificação), conteudo (unknown). Repositório com queries: findByTipo, findAllTypes, bulk insert, aggregate, count. 5+ use cases. Usado como store de propósito geral para dados categorizados. Complexidade: baixa.

---

# Code Analysis — Módulo `user`

Entidade User: id, nome, username, email, perfil (RBAC), ativo, setores (string[]). 5 use cases CRUD + toggleStatus. Complexidade: baixa.

---

# Code Analysis — Módulo `access` (RBAC)

Hierarquia: admin(0) > gerente(1) > coordenador(2) > encarregado(3) > operador/campo(4). Funções puras em AccessPolicy.ts: isAdmin, isManagerOrAbove, getAccessiblePerfis, canAccessUserData. Infra: AccessFilterBuilder gera cláusulas SQL por perfil — admin vê tudo; gerente vê subordinados+dept; operador vê próprias tarefas. Complexidade: média.

---

# Code Analysis — Módulo `sync`

**Offline-first via Supabase Storage.** 8 handlers (demanda, suite, ecoponto, crm, form_registry, data_registry, usuario, org_config). EventBus + Envelope + CryptoLayer. pushPending → Supabase / pull → handlers inbound. Bootstrap inicial. Implementado em duplicata: desktop (TS/infra) e mobile (JS/www/js/sync/). Complexidade: alta.

---

# Code Analysis — Módulo `field-system` (Mobile)

**53+ tipos de campo.** BaseField (ciclo: constructor→init→getDefaultValue→render→validate). FieldFactory (type map + aliases). Tipos: TextField, SelectField, CameraField, GalleryField, ChecklistField, VistoriaChecklistField, GeolocationField, RepeatableGroupField, CaixasAvancadoField, etc. computeDefaultValue com suporte a defaultToNow. Alpine.js integration. Complexidade: alta.

---

# Code Analysis — Módulo `auth` + `data-service` (Mobile Core)

**AuthManager** (1520 linhas): Supabase Auth + fallback JSON. bcrypt, session heartbeat, sync periódica de usuários. **DataService** (2378 linhas): IndexedDB v3 com uuid para deduplicação. Sync lock para concorrência. tbl_suite Supabase. Compressão de imagens. Ambos singletons globais. Complexidade: alta.
