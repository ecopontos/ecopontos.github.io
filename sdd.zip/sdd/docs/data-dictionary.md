# Dicionário de Dados — Módulo `client`

> Archaeologist — 2026-04-30 | Confiança: 🟢 CONFIRMADO

---

## Tabela: `tblPJuridicas` (Pessoas Jurídicas / Clientes)

| Campo Lógico | Coluna SQL | Tipo SQL | Obrigatório | Default | Descrição |
|---|---|---|---|---|---|---|
| `idPJ` | `uuid` | TEXT | Sim | — | UUID v4 — identificador canônico (substitui `id_legacy` para novas operações) |
| *(legado)* | `id_legacy` | INTEGER | Não | NULL | Identificador numérico legado (timestamp na criação); preservado para compatibilidade com FK em `tblRotas`, `tblContatos`, `tblPJuridicas_history` |
| `nome` | `Cliente` | TEXT | Sim | — | Nome/Razão social do cliente |
| `cnpj` | `CNPJ` | TEXT | Não | NULL | CNPJ (14 dígitos, armazenado sem formatação) |
| `telefone` | `Telefone` | TEXT | Não | NULL | Telefone principal |
| `telefone2` | `Telefone2` | TEXT | Não | NULL | Telefone secundário |
| `email` | `Email` | TEXT | Não | NULL | Endereço de email |
| `cep` | `CEP` | TEXT | Não | NULL | CEP (8 dígitos) — FK implícita para tblCEP |
| `endereco` | `Endereco` | TEXT | Não | NULL | Logradouro |
| `numero` | `Numero` | TEXT | Não | NULL | Número do endereço |
| `bairro` | `Bairro` | TEXT | Não | NULL | Bairro |
| `cidade` | `Cidade` | TEXT | Não | NULL | Cidade |
| `estado` | `Estado` | TEXT | Não | NULL | UF (2 letras) |
| `inativo` | `Inativo` | INTEGER/TEXT (tolerante) | Não | 0 (ativo) | Flag de inativação: 0/''/NULL = ativo; 1 = inativo |
| `idPJtipo` | `idPJtipo` | INTEGER | Não | NULL | FK → tblPJtipo.idPJtipo |
| `criadoEm` | `criado_em` | TEXT (ISO) | Não | NULL | Timestamp de criação |
| `atualizadoEm` | `atualizado_em` | TEXT (ISO) | Não | NULL | Timestamp de última atualização |

---

## Tabela: `tblPJtipo` (Tipos de Pessoa Jurídica)

| Campo Lógico | Coluna SQL | Tipo SQL | Obrigatório | Descrição |
|---|---|---|---|---|
| `idPJtipo` | `idPJtipo` (ou `id_legacy` legado) | INTEGER | Sim (PK) | Identificador do tipo |
| `tipo` | `[Tipo de PJ]` | TEXT | Sim | Nome do tipo (ex: "Empresa", "Orgão Público") |

⚠️ O código suporta dois esquemas: coluna `idPJtipo` (novo) ou `id_legacy` (legado), detectado dinamicamente via `useSQLiteColumnExists`.

---

## Tabela: `tblContatos` (Vínculo PJ ↔ PF)

| Campo Lógico | Coluna SQL | Tipo SQL | Obrigatório | Descrição |
|---|---|---|---|---|
| `idContato` | `idContato` | INTEGER | Sim (PK) | Identificador do vínculo |
| `idPF` | `idPF` | INTEGER | Sim | FK → tblPFisicas.idPF |
| `idPJ` | `idPJ` | INTEGER | Sim | FK → tblPJuridicas.id_legacy (legado) / uuid (fase 2) |
| `nome` | `Nome` (da PF via JOIN) | TEXT | Não | Nome da pessoa física |
| `telefone` | `Telefone` (da PF via JOIN) | TEXT | Não | Telefone da PF |
| `email` | `Email` (da PF via JOIN) | TEXT | Não | Email da PF |
| `cargo` | `Cargo` | TEXT | Não | Cargo na empresa |

---

## Tabela: `tblPFisicas` (Pessoas Físicas)

Referenciada via JOIN em `tblContatos`. Campos usados:
- `idPF` (INTEGER PK)
- `Nome` (TEXT)
- `Telefone` (TEXT)
- `Email` (TEXT)

---

## Tabela: `tblCEP` (Base de CEPs)

| Campo Lógico | Coluna SQL | Tipo SQL | Descrição |
|---|---|---|---|
| `cep` | `CEP` | TEXT | Código postal (8 dígitos) |
| `logradouro` | `logradouro` | TEXT | Nome da rua/avenida |
| `bairro` | `bairro` | TEXT | Bairro do CEP |
| `complemento` | `complemento` | TEXT | Complemento do CEP |

---

## Tabela: `tblPJuridicas_history` (Auditoria)

| Campo Lógico | Coluna SQL | Tipo SQL | Descrição |
|---|---|---|---|
| `id` | `id` | INTEGER | PK do registro de auditoria |
| `idPJ` | `id_legacy` | INTEGER | FK → tblPJuridicas.id_legacy |
| `campo` | `campo` | TEXT | Nome do campo alterado |
| `valorAntigo` | `valor_antigo` | TEXT | Valor antes da alteração |
| `valorNovo` | `valor_novo` | TEXT | Valor após a alteração |
| `alteradoPor` | `alterado_por` | TEXT | Usuário que fez a alteração |
| `changedAt` | `changed_at` | TEXT (ISO) | Timestamp da alteração |

---

## Tabela: `tbl_pjuridicas_fts` (FTS5 — Full-Text Search)

Índice virtual FTS5 para busca textual em clientes. Criado com `CREATE VIRTUAL TABLE ... USING fts5(...)`.

- Coluna de busca: `tbl_pjuridicas_fts` (provavelmente indexa nome, CNPJ, etc.)
- Coluna de rank: `rank` (built-in FTS5)

---

## DTOs da Camada de Aplicação

### `CreateClientInput`
| Campo | Tipo | Obrigatório |
|---|---|---|
| `nome` | string | Sim |
| `cnpj` | string | Não |
| `telefone` | string | Não |
| `telefone2` | string | Não |
| `email` | string | Não |
| `cep` | string | Não |
| `endereco` | string | Não |
| `numero` | string | Não |
| `bairro` | string | Não |
| `cidade` | string | Não |
| `estado` | string | Não |
| `idPJtipo` | number | Não |

### `ClientDto`
Idêntico a `ClientProps` com 2 campos adicionais: `tipoNome` e timestamps.

### `ClientFormData` (Interface — formulário React)
Mapeia para nomes de coluna legados (ex: `Cliente`, `Endereço`, `Número`) para compatibilidade com formulários existentes no frontend.

---

# Dicionário de Dados — Módulo `task`

> Archaeologist — 2026-04-30 | Confiança: 🟢 CONFIRMADO

---

## Tabela: `tbl_tarefas`

| Campo Lógico | Coluna SQL | Tipo SQL | Obrigatório | Default | Descrição |
|---|---|---|---|---|---|
| `id` | `id` | TEXT | Sim (PK) | — | UUID via crypto.randomUUID() |
| `projetoId` | `projeto_id` | TEXT | Não | NULL | FK para projeto (backlog quando NULL) |
| `titulo` | `titulo` | TEXT | Sim | — | Título (validado não vazio) |
| `descricao` | `descricao` | TEXT | Não | NULL | Descrição detalhada |
| `status` | `status` | TEXT | Sim | a_fazer | a_fazer, em_progresso, concluido, cancelado |
| `prioridade` | `prioridade` | TEXT | Sim | media | baixa, media, alta |
| `atribuidoPara` | `atribuido_para` | TEXT | Não | NULL | User ID do responsável |
| `criadoPor` | `criado_por` | TEXT | Sim | — | User ID do criador |
| `prazo` | `prazo` | TEXT | Não | NULL | Data de prazo (tipo unico) |
| `prazoFim` | `prazo_fim` | TEXT | Não | NULL | Data fim (tipo periodo) |
| `tipoPrazo` | `tipo_prazo` | TEXT | Não | unico | unico, periodo, recorrente |
| `recorrencia` | `recorrencia` | TEXT | Não | NULL | JSON com config de recorrência |
| `ordem` | `ordem` | INTEGER | Sim | MAX+1000 | Ordem kanban (gap de 1000) |
| `arquivado` | `arquivado` | INTEGER | Sim | 0 | 0 = não, 1 = sim |
| `formRegistryId` | `form_registry_id` | TEXT | Não | NULL | FK form registry |
| `tblSuiteId` | `tbl_suite_id` | TEXT/NUM | Não | NULL | FK suite/formulário submetido |
| `demandaId` | `demanda_id` | TEXT | Não | NULL | FK demanda |
| `deletadoEm` | `deletado_em` | TEXT | Não | NULL | Soft-delete timestamp (NULL = ativo) |
| `criadoEm` | `created_at` | TEXT | Não | datetime() | ISO timestamp criação |
| `atualizadoEm` | `updated_at` | TEXT | Não | datetime() | ISO timestamp última alteração |

---

## Enumeração: `TaskStatus`

| Valor | Label | Terminal |
|---|---|---|
| `a_fazer` | A Fazer | Não |
| `em_progresso` | Em Progresso | Não |
| `concluido` | Concluído | Sim |
| `cancelado` | Cancelado | Sim |

**Transições permitidas:**
- `a_fazer` → `em_progresso`, `cancelado`
- `em_progresso` → `a_fazer`, `concluido`, `cancelado`
- `concluido` → (nenhuma)
- `cancelado` → (nenhuma)

---

## Enumeração: `TaskPriority`

| Valor | Descrição |
|---|---|
| `baixa` | Prioridade baixa |
| `media` | Prioridade média (default) |
| `alta` | Prioridade alta |

---

## Tipo: `TaskDateConfig.recorrencia` (JSON)

Armazenado como string JSON na coluna `recorrencia`.

| Campo | Tipo | Obrigatório | Descrição |
|---|---|---|---|
| `frequencia` | string | Sim | diaria, semanal, mensal, anual |
| `intervalo` | number | Não (default 1) | Intervalo entre recorrências |
| `dias_semana` | number[] | Não | Dias da semana (0=dom, 6=sáb) para semanal |
| `fim_recorrencia` | string (ISO) | Não | Data limite da recorrência |

---

## DTO: `CreateTaskInput`

| Campo | Tipo | Obrigatório |
|---|---|---|
| `titulo` | string | Sim |
| `criadoPor` | string | Sim |
| `projetoId` | string \| null | Não |
| `descricao` | string | Não |
| `prioridade` | TaskPriority | Não (default media) |
| `atribuidoPara` | string \| null | Não |
| `prazo` | string \| null | Não |
| `prazoFim` | string \| null | Não |
| `tipoPrazo` | 'unico' \| 'periodo' \| 'recorrente' \| null | Não |
| `formRegistryId` | string \| null | Não |
| `parentTaskId` | string \| null | Não |
| `demandaId` | string \| null | Não |

## DTO: `MoveTaskInput`

| Campo | Tipo | Obrigatório |
|---|---|---|
| `id` | string | Sim |
| `to` | TaskStatus | Sim |
| `ordem` | number | Não |

## DTO: `AssignTaskInput`

| Campo | Tipo | Obrigatório |
|---|---|---|
| `id` | string | Sim |
| `atribuidoPara` | string \| null | Sim (null = desatribuir) |

---

# Dicionário de Dados — Módulo `demanda`

## Tabela: `tbl_demandas`

| Campo | Coluna SQL | Tipo | Descrição |
|---|---|---|---|
| id | id | TEXT PK | UUID |
| origemTipo | origem_tipo | TEXT | ouvidoria, interno, proprio |
| origemId | origem_id | TEXT NULL | FK origem |
| solicitanteId | solicitante_id | TEXT | User ID |
| destinatarioId | destinatario_id | TEXT | User/setor ID |
| tipoAcao | tipo_acao | TEXT NULL | Tipo de ação |
| descricao | descricao | TEXT NULL | Descrição |
| status | status | TEXT | aberta, aceita, em_campo, concluida |
| politicaConclusao | politica_conclusao | TEXT | todas, declarado |
| autoAceite | auto_aceite | INTEGER | 0/1 |
| aceitoPor | aceito_por | TEXT NULL | User ID |
| aceitoEm | aceito_em | TEXT NULL | ISO timestamp |
| encerradoPor | encerrado_por | TEXT NULL | User ID |
| encerradoEm | encerrado_em | TEXT NULL | ISO timestamp |
| criadaEm | criada_em | TEXT | ISO timestamp |
| arquivadaEm | arquivada_em | TEXT NULL | ISO timestamp |
| arquivoPath | arquivo_path | TEXT NULL | Caminho do arquivo |
| archiveStatus | archive_status | TEXT NULL | pending, completed, failed |

## Tabela: `tbl_demanda_eventos`

| Campo | Coluna SQL | Tipo | Descrição |
|---|---|---|---|
| id | id | TEXT PK | UUID |
| demandaId | demanda_id | TEXT | FK tbl_demandas |
| type | type | TEXT | Tipo do evento (demanda.criada, etc.) |
| correlationId | correlation_id | TEXT NULL | ID de correlação (demandaId) |
| causationId | causation_id | TEXT NULL | Evento anterior |
| payload | payload | TEXT | JSON |
| deviceId | device_id | TEXT NULL | Dispositivo |
| userId | user_id | TEXT NULL | Usuário |
| createdAt | created_at | TEXT | ISO timestamp |

## Tabela: `tbl_tarefa_formularios`

| Campo | Coluna SQL | Tipo | Descrição |
|---|---|---|---|
| id | id | TEXT PK | UUID |
| tarefaId | tarefa_id | TEXT | FK tbl_tarefas |
| formRegistryId | form_registry_id | TEXT | ID do formulário no registry |
| formVersion | form_version | INTEGER | Versão do formulário |
| formSnapshot | form_snapshot | TEXT (JSON) | Snapshot do schema no momento |
| ordem | ordem | INTEGER | Ordem de preenchimento |
| obrigatorio | obrigatorio | INTEGER | 0/1 |
| concluido | concluido | INTEGER | 0/1 |
| concluidoEm | concluido_em | TEXT NULL | ISO timestamp |
