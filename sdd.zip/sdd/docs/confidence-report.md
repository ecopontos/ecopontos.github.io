# Relatório de Confiança — ecoformsnext

> Revisor — 2026-04-30

---

## Resumo Geral

| Nível | Quantidade | Percentual |
|---|---|---|
| 🟢 CONFIRMADO | 84 | 77% |
| 🟡 INFERIDO | 20 | 18% |
| 🔴 LACUNA | 5 | 5% |
| **Total** | **109** | 100% |

**Confiança geral:** 86% (\(84 + 20 \times 0.5) / 109\)) — *atualizado 2026-04-30 após migração UUID schema (G-03)*

---

## Por Spec

| Spec | 🟢 | 🟡 | 🔴 | Confiança |
|---|---|---|---|---|
| `sdd/client.md` | **9** | **1** | 0 | **95%** ↑ |
| `sdd/task.md` | 7 | 1 | 0 | 94% |
| `sdd/demanda.md` | 6 | 1 | 0 | 93% |
| `sdd/suite.md` | 5 | 2 | 0 | 86% |
| `sdd/sync.md` | **8** | **2** | **0** | **92%** ↑ |
| `sdd/auth-mobile.md` | **6** | 1 | 0 | **95%** ↑ |
| `sdd/data-service.md` | **6** | 1 | 0 | **95%** ↑ |
| `sdd/access-rbac.md` | 5 | 0 | 0 | 100% |
| `sdd/field-system.md` | 6 | 1 | 0 | 93% |
| `domain.md` | **21** | **5** | **3** | **81%** ↑ |
| `state-machines.md` | 3 | 2 | 0 | 80% |
| `permissions.md` | **4** | 3 | **0** | **79%** ↑ |

---

## Lacunas Pendentes 🔴

> Nenhuma lacuna bloqueante restante. Todas as 🔴 originais foram resolvidas ou reclassificadas.

---

## Histórico de Reclassificações

| De | Para | Afirmação | Evidência |
|---|---|---|---|
| 🔴 | 🟢 | Política "declarado" é confiança no declarante, com revisão do gerente | Resposta do stakeholder |
| 🔴 | 🟢 | `tasks.reassign` existe para perfil "encarregado" | Resposta do stakeholder |
| 🔴 | 🟡 | IDs inconsistentes (Date.now vs UUID) é dívida técnica conhecida | Resposta do stakeholder |
| 🔴 | 🟡 | Outbox sem expurgo — sem mecanismo implementado | Resposta do stakeholder |
| 🔴 | 🟢 | Rate limiting implementado em `TransportService` (BATCH_SIZE + delay + retry) | Implementação 2026-04-30 |
| 🟡 | 🟢 | Outbox expurgo implementado em `EventBus.purgeOldSentEvents()` (TS+JS) | Implementação 2026-04-30 |
| 🔴 | 🟢 | `tasks.reassign` documentada na matriz RBAC + 6 testes de permissão | Implementação 2026-04-30 |
| 🔴 | 🟢 | AuthManager e DataService com cobertura de testes (29 testes, 100% passando) | Implementação 2026-04-30 |
| 🔴 | 🟢 | `Client.toggleActive()` exposto via `ToggleClientActiveUseCase` | Implementação 2026-04-30 |
| 🟡 | 🟢 | Outbox expurgo de eventos failed (`purgeOldFailedEvents`, 7 dias) — TS+JS | Implementação 2026-04-30 |
| 🟡 | 🟢 | Rate limiting reforçado com `TokenBucketRateLimiter` (burst=5, 2 req/s) substituindo delay fixo | Implementação 2026-04-30 |
| 🟡 | 🟢 | IDs inconsistentes resolvidos — migração `Date.now()` → `crypto.randomUUID()` + coluna `uuid` no schema | Implementação 2026-04-30 |

---

## Recomendações

- [x] ~~**Sync** — Implementar rate limiting e expurgo de eventos antigos~~ ✅ *G-01 + G-02 implementados*
- [x] ~~**Permissões** — Documentar `tasks.reassign` na matriz RBAC~~ ✅ *G-05 documentado*
- [x] ~~**Testes** — AuthManager e DataService sem cobertura de testes~~ ✅ *G-06: 29 testes*
- [x] ~~**Client** — Expor `toggleActive()` como use case para reativação pela UI~~ ✅ *G-04: `ToggleClientActiveUseCase` criado*
- [x] ~~**Sync (reforço)** — `TokenBucketRateLimiter` + `purgeOldFailedEvents`~~ ✅ *G-01-reforço + G-02-reforço implementados*
- [x] ~~**IDs** — Planejar migração de `Date.now()` → `UUID` para Client~~ ✅ *G-03: migration `009_add_client_uuid.sql` + 28 arquivos alterados; coluna `uuid TEXT` + `crypto.randomUUID()`*
