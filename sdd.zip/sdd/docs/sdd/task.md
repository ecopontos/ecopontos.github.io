# Task (Tarefas Kanban)

## Visão Geral
Módulo de gestão de tarefas com máquina de estados, suporte a recorrência, atribuição de responsáveis e ordenação kanban por projeto. Tarefas são vinculáveis a demandas, formulários e suites.

## Responsabilidades
- Criar tarefas com UUID, status inicial `a_fazer`, prioridade default `media` 🟢
- Transição de status com máquina de estados validada (4 estados, 2 terminais) 🟢
- Atribuir/desatribuir responsável 🟢
- Arquivar/desarquivar tarefas 🟢
- Soft-delete via coluna `deletado_em` 🟢
- Ordenação kanban com gap de 1000 🟢
- Cálculo de próxima ocorrência para tarefas recorrentes 🟢

## Interface

### Entrada: `CreateTaskInput`
`titulo` (string, obrigatório), `criadoPor` (string, obrigatório), `projetoId?`, `descricao?`, `prioridade?` (baixa|media|alta), `atribuidoPara?`, `prazo?`, `prazoFim?`, `tipoPrazo?` (unico|periodo|recorrente), `formRegistryId?`, `parentTaskId?`, `demandaId?`

### Movimento: `MoveTaskInput`
`id` (string), `to` (TaskStatus), `ordem?` (number)

### Atribuição: `AssignTaskInput`
`id` (string), `atribuidoPara` (string|null)

## Regras de Negócio
- Título obrigatório e validado com trim 🟢
- Status inicial sempre `a_fazer` 🟢
- Transições: `a_fazer→em_progresso,cancelado`; `em_progresso→a_fazer,concluido,cancelado`; `concluido/cancelado` são terminais 🟢
- Prioridade default `media` 🟢
- Ordem = `MAX(ordem) + 1000` por (projeto, status) 🟢
- ID via `crypto.randomUUID()` 🟢
- Recorrência: diária/semanal/mensal/anual com intervalo e data limite 🟢
- Delete marca `deletado_em = datetime('now')`; queries filtram `WHERE deletado_em IS NULL` 🟢

## Fluxo Principal

1. Usuário cria tarefa informando título e projeto (opcional)
2. Sistema gera UUID, calcula `nextOrder`, define status `a_fazer`
3. Tarefa aparece no kanban na coluna "A Fazer"
4. Usuário arrasta para "Em Progresso" → `transitionTo('em_progresso')` validado
5. Ao concluir, move para "Concluído" → status terminal

## Fluxos Alternativos
- **Cancelar:** Move para `cancelado` (terminal, de qualquer estado não-terminal)
- **Reabrir:** De `em_progresso` volta para `a_fazer`
- **Recorrência:** `calculateNextOccurrence()` calcula próxima data baseado em frequência+intervalo; retorna null se exceder `fim_recorrencia`

## Dependências
- `tbl_tarefas` (SQLite) — tabela principal
- `ClockPort` — timestamps
- `errors.ts` — `NotFoundError`, `InvalidTransitionError`

## Requisitos Não Funcionais

| Tipo | Requisito | Evidência | Confiança |
|---|---|---|---|
| Consistência | Transição de status validada antes de persistir | `TaskStatus.ts:17` | 🟢 |
| Disponibilidade | Soft-delete preserva dados | `SqliteTaskRepository.ts:149` | 🟢 |
| Performance | Gap de 1000 evita reordenação massiva | `SqliteTaskRepository.ts:168` | 🟢 |

## Critérios de Aceitação

```gherkin
Dado que não há tarefas no projeto "X"
Quando crio uma tarefa com título "Nova tarefa" no projeto "X"
Então a tarefa tem status "a_fazer", ordem 1000, prioridade "media" e UUID gerado

Dado que uma tarefa está com status "a_fazer"
Quando tento mover diretamente para "concluido"
Então o sistema rejeita com InvalidTransitionError

Dado que uma tarefa recorrente diária com intervalo=1 foi concluída
Quando calculo a próxima ocorrência
Então retorna a data de amanhã
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| CRUD de tarefas + state machine | Must | Core do kanban |
| Ordenação kanban | Must | Essencial para UI drag-drop |
| Atribuição | Must | Workflow de responsabilidade |
| Recorrência | Should | Importante mas não bloqueante |
| Arquivamento | Could | Organizacional |

## Rastreabilidade

| Arquivo | Função/Classe | Cobertura |
|---|---|---|
| `desktop/src/domain/task/Task.ts` | `Task` | 🟢 |
| `desktop/src/domain/task/TaskStatus.ts` | Máquina de estados | 🟢 |
| `desktop/src/domain/task/TaskRecurrence.ts` | `calculateNextOccurrence` | 🟢 |
| `desktop/src/application/task/CreateTaskUseCase.ts` | `CreateTaskUseCase` | 🟢 |
| `desktop/src/application/task/MoveTaskUseCase.ts` | `MoveTaskUseCase` | 🟢 |
| `desktop/src/application/task/AssignTaskUseCase.ts` | `AssignTaskUseCase` | 🟢 |
| `desktop/src/application/task/ArchiveTaskUseCase.ts` | `ArchiveTaskUseCase` | 🟢 |
| `desktop/src/application/task/DeleteTaskUseCase.ts` | `DeleteTaskUseCase` | 🟢 |
| `desktop/src/infrastructure/persistence/sqlite/SqliteTaskRepository.ts` | `SqliteTaskRepository` | 🟢 |
