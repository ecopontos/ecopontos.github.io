# Sync Engine (Sincronização Offline-First)

## Visão Geral
Sistema de sincronização offline-first que utiliza Supabase Storage (bucket `sync-bucket`) como canal de transporte. Baseado em eventos (EventBus + EventEnvelope), com 8 handlers registrados cobrindo todos os domínios. Implementado em duplicata: TypeScript (desktop/infra) e JavaScript (mobile/www/js/sync/).

## Responsabilidades
- Push: eventos locais → Supabase Storage como arquivos JSON 🟢
- Pull: arquivos remotos → processamento inbound via handlers 🟢
- Criptografia de envelope (CryptoLayer) 🟢
- Resolução de conflitos LWW + hash 🟢
- Lock de concorrência (um sync por vez) 🟢
- Idempotência via uuid + checksums 🟢
- Deep-clone em upload para evitar mutação 🟢
- Bootstrap inicial do storage 🟢
- Retry com backoff em falhas 🟢
- Rate limiting (batch cap + throttle entre uploads) 🟢
- Expurgo automático de eventos antigos do outbox 🟢

## Interface

### `SyncPort` (aplicação)
`syncAll()`, `pushTasks()`, `pullTasks()`, `getOfflineQueueSize()`, `processOfflineQueue()`

### `SyncResult`
`success: boolean`, `synced: { form_registry, data_registry, tbl_suite_push/pull, tbl_usuarios, projects_push/pull, tasks_push/pull, task_snaps_push, ecoponto_state_push }`, `errors: string[]`

## Regras de Negócio
- Eventos locais são envelopados com CryptoLayer antes do upload 🟢
- Pull processa eventos inbound via handlers registrados (8 domínios) 🟢
- Resolução de conflitos: Last-Write-Wins com hash comparison 🟢
- Upload usa deep-clone para evitar mutação de dados durante envio 🟢
- Idempotência: uuid único por evento, checksum para detecção de duplicata 🟢
- Sync lock previne múltiplos syncs simultâneos 🟢
- RLS dual-auth no Storage: anon (mobile) lê/escreve paths limitados; authenticated (desktop) acessa paths org-scoped 🟢
- **Rate limiting:** `pushPending()` utiliza `TokenBucketRateLimiter` (burst=5 tokens, recarga 2/s) para controle de rajadas; processa no máximo 50 eventos por ciclo (`BATCH_SIZE`); falhas transitórias são retentadas 2× com backoff exponencial (300ms → 600ms); erros não-recuperáveis (4xx) abortam imediatamente via `isRetryableError` 🟢
- **Expurgo do outbox:** após cada push bem-sucedido, `EventBus.purgeOldSentEvents(30)` remove eventos `sent` >30 dias; `purgeOldFailedEvents(7)` remove eventos `failed` >7 dias; implementado em SQLite (TS) e IndexedDB (JS); falha silenciosa para não bloquear o ciclo principal 🟢

## Fluxo Principal

1. Usuário faz alteração offline → evento criado no EventBus local
2. Quando online, `TransportService.pushPending()` envia eventos pendentes ao Supabase Storage
3. Cada evento vira um arquivo JSON no path `orgs/{orgId}/eventos/{eventId}.json`
4. `InboundService.pull()` baixa eventos remotos de outros dispositivos
5. HandlerRegistry despacha cada evento para o handler do domínio correspondente
6. Handler aplica a mudança no SQLite/IndexedDB local

## Dependências
- `EventBus` — barramento de eventos local
- `EventEnvelope` — estrutura do envelope criptografado
- `CryptoLayer` — criptografia AES-GCM (desktop) / equivalente (mobile)
- `TransportService` — upload/download Supabase Storage
- `InboundService` — processamento de eventos inbound
- `HandlerRegistry` — 8 handlers (demanda, suite, ecoponto, crm, form_registry, data_registry, usuario, org_config)
- `Supabase Storage` (bucket `sync-bucket`)

## Requisitos Não Funcionais

| Tipo | Requisito | Evidência | Confiança |
|---|---|---|---|
| Disponibilidade | Offline-first: dados nunca perdidos | IndexedDB/SQLite local | 🟢 |
| Consistência | Resolução determinística LWW+hash | commit `c152451` | 🟢 |
| Segurança | CryptoLayer + RLS dual-auth | `CryptoLayer.ts`, `01-storage-rls-v2.sql` | 🟢 |
| Confiabilidade | Idempotência via uuid + checksum | commit `6b0d89c` | 🟢 |
| Performance | Deep-clone previne corrupção por mutação | commit `538d463` | 🟢 |
| Estabilidade | Rate limiting ≤50 eventos/ciclo, 100ms inter-upload | `TransportService.ts` BATCH_SIZE + INTER_UPLOAD_DELAY_MS | 🟢 |
| Sustentabilidade | Expurgo automático de eventos >30 dias | `EventBus.purgeOldSentEvents()` (TS+JS) | 🟢 |

## Critérios de Aceitação

```gherkin
Dado que o dispositivo está offline e 3 formulários foram submetidos
Quando o dispositivo fica online
Então os 3 eventos são enviados ao Supabase Storage sem duplicação

Dado que dois dispositivos editaram o mesmo registro
Quando ambos sincronizam
Então o conflito é resolvido por LWW+hash deterministicamente

Dado que um sync está em andamento
Quando outro sync é disparado
Então o segundo aguarda o lock ser liberado (sem execução paralela)
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| Push/Pull de eventos | Must | Core do funcionamento offline |
| Resolução de conflitos | Must | Essencial em ambiente multi-dispositivo |
| Criptografia | Must | Dados sensíveis em storage público |
| Idempotência | Must | Previne duplicação de dados |
| Deep-clone upload | Should | Previne bugs de mutação |
| Retry com backoff | Could | Melhora resiliência |
| Rate limiting (batch + throttle) | Should | Evita rejeição por Supabase em rajadas |
| Expurgo do outbox | Should | Previne crescimento indefinido do SQLite/IndexedDB |

## Rastreabilidade

| Arquivo | Função/Classe | Cobertura |
|---|---|---|
| `desktop/src/application/ports/SyncPort.ts` | `SyncPort` | 🟢 |
| `desktop/src/infrastructure/sync/EventSyncAdapter.ts` | `EventSyncAdapter` | 🟢 |
| `desktop/src/infrastructure/sync/EventBus.ts` | `EventBus` | 🟢 |
| `desktop/src/infrastructure/sync/EventEnvelope.ts` | `EventEnvelope` | 🟢 |
| `desktop/src/infrastructure/sync/CryptoLayer.ts` | `CryptoLayer` | 🟢 |
| `desktop/src/infrastructure/sync/TransportService.ts` | `TransportService` | 🟢 |
| `desktop/src/infrastructure/sync/InboundService.ts` | `InboundService` | 🟢 |
| `desktop/src/infrastructure/sync/HandlerRegistry.ts` | `registerAllHandlers` | 🟢 |
| `www/js/sync/` (13 arquivos) | Implementação mobile | 🟢 |
