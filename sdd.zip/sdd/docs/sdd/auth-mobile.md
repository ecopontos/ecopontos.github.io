# Auth Manager (Mobile — Autenticação)

## Visão Geral
Sistema de autenticação do mobile PWA com dupla estratégia: Supabase Auth como primário e JSON local como fallback offline. Gerencia sessão com heartbeat, sincronização periódica de usuários e integração com permissões de formulário.

## Responsabilidades
- Login com Supabase Auth (email/senha) ou fallback JSON local 🟢
- Hash de senhas com bcrypt (salt rounds = 10) 🟢
- Session heartbeat: renovação automática a cada interação (>1min throttle) 🟢
- Sincronização periódica de lista de usuários 🟢
- Carregamento de sessão persistida (localStorage) 🟢
- Integração com SystemConfig para providers de autenticação 🟢

## Interface

`AuthManager.login(usuario, senha)`, `AuthManager.logout()`, `AuthManager.isLoggedIn()`, `AuthManager.getCurrentUser()`, `AuthManager.init(supabaseClient?)`

### Sessão persistida: `localStorage['ecoforms_auth_session']`
`{ userId, nome, perfil, setores, token, expiresAt }`

## Regras de Negócio
- Se Supabase disponível e online, usa Supabase Auth 🟢
- Se offline ou Supabase indisponível, fallback para `data/usuarios.json` com bcrypt 🟢
- Sessão expira após inatividade (renovada por heartbeat em interações) 🟢
- Heartbeat throttle: máximo 1 renovação por minuto 🟢
- Sincronização de usuários dispara ao iniciar e periodicamente 🟢
- Listener de conectividade ajusta modo online/offline 🟢

## Fluxo Principal

1. App inicia → AuthManager.init() → tenta carregar sessão do localStorage
2. Se sessão válida, usuário autenticado automaticamente
3. Se não, mostra tela de login
4. Login: tenta Supabase primeiro; se falhar, fallback JSON local
5. Após login, heartbeat monitora interações e renova sessão
6. Sincronização periódica mantém lista de usuários atualizada

## Dependências
- `window.globalSupabaseClient` — cliente Supabase singleton
- `data/usuarios.json` — fallback offline
- `bcrypt.js` — hash de senhas
- `window.systemConfig` — integração opcional

## Requisitos Não Funcionais

| Tipo | Requisito | Evidência | Confiança |
|---|---|---|---|
| Segurança | bcrypt com salt rounds = 10 | `auth-manager.js:14` | 🟢 |
| Disponibilidade | Fallback offline mantém acesso | `auth-manager.js:10` | 🟢 |
| Performance | Heartbeat throttle 60s | `auth-manager.js:79` | 🟢 |

## Critérios de Aceitação

```gherkin
Dado que estou online e tenho credenciais válidas no Supabase
Quando faço login
Então sou autenticado e a sessão é persistida no localStorage

Dado que estou offline
Quando faço login com credenciais do JSON local
Então sou autenticado via bcrypt e posso usar o app offline

Dado que estou logado e interajo com o app
Quando o heartbeat detecta atividade após >1 minuto da última renovação
Então a sessão é renovada silenciosamente
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| Login Supabase + fallback | Must | Essencial para acesso |
| Session heartbeat | Must | Mantém sessão ativa sem re-login |
| Sincronização de usuários | Should | Mantém lista atualizada |
| SystemConfig integration | Could | Flexibilidade de configuração |

## Rastreabilidade

| Arquivo | Função/Classe | Cobertura |
|---|---|---|
| `www/js/auth-manager.js` | `AuthManager` (1520 linhas) | 🟢 |
