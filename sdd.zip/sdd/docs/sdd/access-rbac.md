# Access Control / RBAC

## Visão Geral
Sistema de controle de acesso baseado em perfis hierárquicos (RBAC). Define 6 níveis (admin > gerente > coordenador > encarregado > operador/campo), funções puras de verificação no domínio e geração de filtros SQL na infraestrutura.

## Responsabilidades
- Definir hierarquia de perfis com níveis numéricos 🟢
- Verificar perfil conhecido (`isKnownPerfil`) 🟢
- Calcular nível de acesso (`roleLevel`) 🟢
- Listar perfis acessíveis e subordinados 🟢
- Verificar se pode acessar dados de outro perfil 🟢
- Gerar filtros SQL dinâmicos por perfil (tasks, records, inbox) 🟢

## Interface

### Funções de Domínio (`AccessPolicy.ts`)
`isAdmin(perfil)`, `isManagerOrAbove(perfil)`, `getAccessiblePerfis(userPerfil)`, `getSubordinatePerfis(userPerfil)`, `canAccessUserData(currentPerfil, targetPerfil)`

### Filtros SQL (`AccessFilterBuilder.ts`)
`buildTaskAccessFilter(userId, userPerfil): SqlFilter`, `buildRecordAccessFilter(userId, userPerfil): SqlFilter`, `buildInboxAccessFilter(userId, userPerfil): SqlFilter`

## Regras de Negócio
| Perfil | Nível | Acesso |
|---|---|---|
| admin | 0 | Tudo (`1=1`) |
| gerente | 1 | Próprio + subordinados + mesmo departamento |
| coordenador | 2 | Próprio + subordinados |
| encarregado | 3 | Próprio + subordinados |
| operador | 4 | Apenas próprio + atribuído |
| campo | 4 | Apenas próprio + atribuído |

- `canAccessUserData`: só acessa perfil de nível ≥ próprio (hierarquia igual ou inferior) 🟢
- Admin vê tudo (cláusula `1=1`) 🟢
- Gerente no inbox vê: próprios + mesmo departamento + atribuídos + criados + interessados 🟢
- Demais perfis no inbox veem: próprios + atribuídos + criados + interessados 🟢

## Dependências
- `domain/access/AccessPolicy.ts` — regras puras
- `infrastructure/persistence/AccessFilterBuilder.ts` — tradução para SQL

## Critérios de Aceitação

```gherkin
Dado que sou admin
Quando consulto tarefas
Então vejo todas as tarefas do sistema (filtro "1=1")

Dado que sou gerente do setor X
Quando consulto o inbox
Então vejo registros próprios, do meu departamento, atribuídos a mim e onde sou interessado

Dado que sou operador
Quando tento acessar dados de um gerente
Então `canAccessUserData("operador", "gerente")` retorna false
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| Hierarquia de perfis | Must | Base de toda segurança |
| Filtros SQL dinâmicos | Must | Essencial para isolamento de dados |
| Acesso condicional no inbox | Must | Regra de negócio central |

## Rastreabilidade

| Arquivo | Função/Classe | Cobertura |
|---|---|---|
| `desktop/src/domain/access/AccessPolicy.ts` | `AccessPolicy` | 🟢 |
| `desktop/src/infrastructure/persistence/AccessFilterBuilder.ts` | `buildTaskAccessFilter`, `buildInboxAccessFilter` | 🟢 |
