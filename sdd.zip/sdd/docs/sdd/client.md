# Client (Gestão de Clientes PJ)

## Visão Geral
Módulo de cadastro e gestão de pessoas jurídicas (clientes) com CRUD completo, validação de duplicidade de nome, auditoria de alterações e busca full-text (FTS5). Clientes são a base para CRM (rotas/roteiros) e formulários.

## Responsabilidades
- Cadastrar, editar e listar clientes PJ
- Validar unicidade de nome antes de criar/atualizar 🟢
- Soft-delete (marcar como inativo) sem remoção física 🟢
- Reativar cliente inativo via `toggleActive()` 🟢
- Listar contatos vinculados (PF) e tipos de PJ 🟢
- Registrar histórico de alterações (audit log) 🟢
- Busca textual rápida via FTS5 🟢
- Formatar dados para exibição (CNPJ, endereço, status) 🟢

## Interface

### Entrada: `CreateClientInput`
| Campo | Tipo | Obrigatório |
|---|---|---|
| nome | string | Sim |
| cnpj | string | Não |
| telefone | string | Não |
| telefone2 | string | Não |
| email | string | Não |
| cep | string | Não |
| endereco | string | Não |
| numero | string | Não |
| bairro | string | Não |
| cidade | string | Não |
| estado | string | Não |
| idPJtipo | number | Não |

### Saída: `ClientDto`
Mesmo que input + `idPJ: number`, `inativo: boolean`, `tipoNome?: string`, `criadoEm?: string`, `atualizadoEm?: string`

## Regras de Negócio
- Nome do cliente é único — validado antes de INSERT/UPDATE 🟢
- Delete é lógico (Inativo=1), registro permanece no banco 🟢
- Listagem padrão filtra apenas ativos (`ativoOnly = true`) 🟢
- Ordenação padrão alfabética por nome 🟢
- ID gerado via `crypto.randomUUID()` (UUID v4) — coluna `uuid` no schema 🟢
- CNPJ formatado automaticamente (XX.XXX.XXX/XXXX-XX) no ViewModel 🟢
- Reativação de cliente inativo via `ToggleClientActiveUseCase` 🟢
- Auditoria registra campo, valor antigo, valor novo, usuário e timestamp 🟢
- Nome duplicado aceita exclusão do próprio ID (update mantendo mesmo nome) 🟢
- Upsert: INSERT se não existe, UPDATE se existe 🟢
- 🟢 A reativação de cliente inativo é feita via `ToggleClientActiveUseCase`

## Fluxo Principal

1. Usuário preenche formulário com dados do cliente
2. Sistema valida se nome já existe via `CheckClientNameExistsUseCase`
3. Se duplicado, exibe erro "Cliente já cadastrado"
4. Se válido, `CreateClientUseCase` gera ID via `crypto.randomUUID()`, define `inativo=false`, preenche timestamps
5. `SqliteClientRepository.save()` faz upsert condicional (SELECT → INSERT ou UPDATE)
6. Retorna `ClientDto` formatado

## Fluxos Alternativos
- **Update:** Busca cliente existente por ID, faz merge parcial via `Object.assign`, atualiza `atualizadoEm`, persiste
- **Delete:** Executa `UPDATE tblPJuridicas SET Inativo = 1 WHERE id_legacy = ?`
- **Listagem com inativos:** Passa `ativoOnly: false` — remove cláusula WHERE Inativo
- **Busca FTS5:** Termo ≥ 2 caracteres → quebra em palavras → `termo* OR busca*` → LIMIT 50

## Dependências
- `tblPJuridicas` (SQLite) — tabela principal
- `tblPJtipo` — LEFT JOIN para nome do tipo
- `tblContatos` + `tblPFisicas` — JOIN para contatos vinculados
- `tblCEP` — LEFT JOIN para dados de endereço
- `tblPJuridicas_history` — auditoria
- `tbl_pjuridicas_fts` — índice FTS5 para busca textual

## Requisitos Não Funcionais

| Tipo | Requisito inferido | Evidência | Confiança |
|---|---|---|---|
| Performance | FTS5 para busca textual sub-100ms | `useClientSearch.ts:30` | 🟢 |
| Disponibilidade | Soft-delete preserva dados | `SqliteClientRepository.ts:155` | 🟢 |
| Consistência | Upsert garante idempotência | `SqliteClientRepository.ts:120-152` | 🟢 |

## Critérios de Aceitação

```gherkin
Dado que o nome "Empresa X" não está cadastrado
Quando crio um cliente com nome "Empresa X", telefone "(11) 1234-5678" e email "contato@x.com"
Então o cliente é salvo com inativo=false e ID numérico gerado

Dado que "Empresa X" já está cadastrada
Quando tento criar outro cliente com nome "Empresa X"
Então o sistema rejeita com mensagem "Cliente 'Empresa X' já está cadastrado"

Dado que o cliente ID=123 existe e está ativo
Quando executo a exclusão lógica
Então o registro persiste com Inativo=1 e não aparece na listagem padrão
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| Create/Read/Update de clientes | Must | Caminho crítico — base para CRM e formulários |
| Validação de nome único | Must | Regra de negócio sem fallback |
| Soft-delete | Must | Preserva integridade referencial |
| Auditoria de alterações | Should | Importante para rastreabilidade, mas sistema funciona sem |
| Busca FTS5 | Should | Melhora UX, mas listagem paginada já cobre |
| Contatos e tipos | Could | Funcionalidade acessória |

## Rastreabilidade de Código

| Arquivo | Função / Classe | Cobertura |
|---|---|---|
| `desktop/src/domain/client/Client.ts` | `Client` (entidade) | 🟢 |
| `desktop/src/domain/client/ClientRepository.ts` | `ClientRepository` (interface) | 🟢 |
| `desktop/src/application/client/CreateClientUseCase.ts` | `CreateClientUseCase` | 🟢 |
| `desktop/src/application/client/UpdateClientUseCase.ts` | `UpdateClientUseCase` | 🟢 |
| `desktop/src/application/client/DeleteClientUseCase.ts` | `DeleteClientUseCase` | 🟢 |
| `desktop/src/application/client/ToggleClientActiveUseCase.ts` | `ToggleClientActiveUseCase` | 🟢 |
| `desktop/src/application/client/ListClientsUseCase.ts` | `ListClientsUseCase` | 🟢 |
| `desktop/src/application/client/CheckClientNameExistsUseCase.ts` | `CheckClientNameExistsUseCase` | 🟢 |
| `desktop/src/application/client/dto/ClientDto.ts` | DTOs | 🟢 |
| `desktop/src/application/client/mappers.ts` | `toClientDto` | 🟢 |
| `desktop/src/infrastructure/persistence/sqlite/SqliteClientRepository.ts` | `SqliteClientRepository` | 🟢 |
| `desktop/src/interface/hooks/mutations/useClientMutations.ts` | `useClientMutations` | 🟢 |
| `desktop/src/interface/hooks/queries/useClients.ts` | `useClients` | 🟢 |
| `desktop/src/interface/hooks/queries/useClientSearch.ts` | `useClientSearch` (FTS5) | 🟢 |
| `desktop/src/interface/presenters/toClientViewModel.ts` | `toClientViewModel` | 🟢 |
| `desktop/src/test/fakes/InMemoryClientRepository.ts` | Fake para testes | 🟢 |
