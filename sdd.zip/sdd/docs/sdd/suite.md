# Suite Package (Formulários Submetidos)

## Visão Geral
Entidade central de versionamento e workflow de formulários submetidos. Cada `SuitePackage` representa uma submissão de formulário com 11 estados possíveis, versionamento semântico, lock/unlock e histórico de transições.

## Responsabilidades
- Criar/versionar pacotes de formulário submetido 🟢
- Gerenciar transições de status com máquina de 11 estados 🟢
- Lock/unlock para edição exclusiva 🟢
- Criar nova versão com payload atualizado 🟢
- Manter histórico de transições (SuiteHistoryEntry) 🟢

## Interface

### `SuitePackageProps`
`packageId` (string), `versionNo` (number), `moduleType`, `resourceType`, `status` (SuiteStatus), `ownerId`, `isCurrent` (boolean), `lockedBy`, `lockedAt`, `refPackageId`, `refPackageVer`, `entityId`, `entityType`, `payloadJson` (string), `createdAt`, `closedAt`

## Regras de Negócio
- 11 estados: `draft → current → edit/locked/dispatched/pending_review → superseded/closed` 🟢
- 2 estados terminais: `superseded`, `closed` 🟢
- `approved`/`rejected` são legado v1, ainda aceitos mas não alvo de transições novas 🟡
- Lock define `lockedBy` + `lockedAt`; só desbloqueia via `unlock()` 🟢
- `createNewVersion()` incrementa `versionNo`, reseta lock, marca `isCurrent=true` 🟢
- `getPayload<T>()` faz parse genérico do JSON com fallback `{}` 🟢
- `close()` marca `closedAt`, `isCurrent=false` 🟢

## Fluxo Principal (Review de Formulário)

1. Formulário submetido do mobile → `tbl_suite` com status `dispatched`
2. Revisor no desktop vê no inbox
3. Revisor pode: aprovar (`pending_review → current`), refutar (`pending_review → refuted`), ou fechar
4. Se refutado, editor corrige (`refuted → edit → pending_review`)
5. Aprovado torna-se `current` (versão atual)
6. Nova edição cria versão incrementada

## Fluxos Alternativos
- **Edição direta:** `current → edit → current`
- **Lock:** `current → locked → current` (bloqueio para edição exclusiva)
- **Substituição:** `current/edit → superseded` (terminal)

## Dependências
- `tbl_suite` (SQLite) — tabela principal
- `tbl_suite_history` — histórico de transições
- `SuiteRepository` — interface de persistência

## Requisitos Não Funcionais

| Tipo | Requisito | Evidência | Confiança |
|---|---|---|---|
| Consistência | Máquina de estados previne transições inválidas | `SuiteStatus.ts:33` | 🟢 |
| Auditabilidade | Histórico registra cada transição | `SuiteHistoryEntry` | 🟢 |

## Critérios de Aceitação

```gherkin
Dado um SuitePackage com status "draft"
Quando publico (transitionTo "current")
Então status muda para "current" e isCurrent = true

Dado um SuitePackage "current" com usuário X
Quando X faz lock
Então status muda para "locked", lockedBy = X, lockedAt preenchido

Dado um SuitePackage "edit" com versionNo 2
Quando crio nova versão com payload atualizado
Então versionNo = 3, isCurrent = true, lock limpo
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| State machine + transições | Must | Core do fluxo de revisão |
| Versionamento | Must | Integridade de dados |
| Lock/unlock | Should | Previne conflitos de edição |
| Histórico | Could | Auditabilidade |

## Rastreabilidade

| Arquivo | Função/Classe | Cobertura |
|---|---|---|
| `desktop/src/domain/suite/SuitePackage.ts` | `SuitePackage` | 🟢 |
| `desktop/src/domain/suite/SuiteStatus.ts` | Máquina de estados | 🟢 |
| `desktop/src/domain/suite/SuiteRepository.ts` | `SuiteRepository` | 🟢 |
| `desktop/src/application/suite/SubmitSuiteUseCase.ts` | `SubmitSuiteUseCase` | 🟢 |
| `desktop/src/application/suite/EditSuiteUseCase.ts` | `EditSuiteUseCase` | 🟢 |
| `desktop/src/application/suite/ReviewSuiteUseCase.ts` | `ReviewSuiteUseCase` | 🟢 |
| `desktop/src/infrastructure/persistence/sqlite/SqliteSuiteRepository.ts` | `SqliteSuiteRepository` | 🟢 |
