# Demanda (Workflow de Solicitações)

## Visão Geral
Módulo de gestão de demandas entre setores/usuários. Uma demanda é uma solicitação de trabalho que, ao ser aceita, gera tarefas com formulários vinculados. Suporta auto-aceite, políticas de conclusão e event sourcing lite.

## Responsabilidades
- Criar demandas com auto-aceite quando origem = "próprio" 🟢
- Aceitar demandas com criação atômica de tarefas + formulários + eventos 🟢
- Encerrar demandas respeitando política de conclusão 🟢
- Consultar status agregado (tarefas, formulários, progresso) 🟢
- Registrar eventos imutáveis de cada ação 🟢

## Interface

### `CreateDemandaInput`
`origemTipo` (ouvidoria|interno|proprio), `solicitanteId`, `destinatarioId`, `tipoAcao?`, `descricao?`, `politicaConclusao` (todas|declarado)

### `AcceptDemandaInput`
`demandaId`, `aceitoPor`, `tarefas[]` (cada: `titulo`, `descricao?`, `atribuidoPara?`, `prazo?`, `prioridade?`, `formularios[]` com `formRegistryId`, `formSnapshot`, `formVersion?`, `ordem`, `obrigatorio`)

### `CloseDemandaInput`
`demandaId`, `encerradoPor`, `motivo?`

## Regras de Negócio
- `origemTipo === 'proprio'` → status inicial `aceita`; demais → `aberta` 🟢
- Aceite só permitido quando status === `aberta` 🟢
- Aceite é transacional: atualiza status + cria N tarefas + N×M formulários + eventos, tudo ou nada 🟢
- Política `todas`: encerramento bloqueado se houver tarefas com status ≠ `concluido` 🟢
- Política `declarado`: encerramento sem verificação 🟢
- Cada ação gera `DemandaEvento` (criada, aceita, tarefa.criada, encerrada) 🟢

## Fluxo Principal

1. Setor A cria demanda para Setor B (`origemTipo = 'ouvidoria'`)
2. Demanda nasce com status `aberta`
3. Setor B aceita: fornece lista de tarefas com formulários
4. Sistema, em transação atômica: atualiza status→`aceita`, cria tasks, cria TarefaFormularios, registra eventos
5. Tarefas são executadas em campo
6. Quando todas concluídas, Setor B encerra (política `todas` verifica)
7. Sistema atualiza status→`concluida`, registra evento `demanda.encerrada`

## Fluxos Alternativos
- **Auto-aceite:** Se origem = `proprio`, status já nasce `aceita`, sem passo 3-4
- **Política declarado:** Encerramento não verifica tarefas
- **Recusa de aceite:** Se status ≠ `aberta`, erro "Demanda não pode ser aceita"

## Dependências
- `DemandaRepository` — persistência + transações
- `TaskRepository` — criação de tarefas vinculadas
- `ClockPort` — timestamps
- `tbl_demandas`, `tbl_demanda_eventos`, `tbl_tarefa_formularios`, `tbl_tarefas`

## Requisitos Não Funcionais

| Tipo | Requisito | Evidência | Confiança |
|---|---|---|---|
| Consistência | Transação SQLite garante atomicidade no AcceptDemanda | `AcceptDemandaUseCase.ts:48` | 🟢 |
| Auditabilidade | Event sourcing registra todas as ações | `DemandaEvento.ts` | 🟢 |

## Critérios de Aceitação

```gherkin
Dado que crio uma demanda do tipo "ouvidoria" do setor A para o setor B
Quando a demanda é criada
Então status é "aberta" e evento "demanda.criada" é registrado

Dado que uma demanda "aberta" existe
Quando o setor B a aceita com 2 tarefas, cada uma com 1 formulário
Então status muda para "aceita", 2 tarefas são criadas, 2 formulários vinculados e eventos registrados — tudo em uma transação

Dado que uma demanda com política "todas" tem 1 tarefa não concluída
Quando tento encerrar
Então o sistema rejeita com erro "há tarefas pendentes"
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| Criação + aceite com transação | Must | Core do workflow |
| Política de conclusão | Must | Regra de negócio central |
| Event sourcing | Should | Auditabilidade importante |
| Auto-aceite | Should | Conveniência para demandas próprias |

## Rastreabilidade

| Arquivo | Função/Classe | Cobertura |
|---|---|---|
| `desktop/src/domain/demanda/Demanda.ts` | `Demanda` | 🟢 |
| `desktop/src/domain/demanda/DemandaEvento.ts` | `DemandaEvento` | 🟢 |
| `desktop/src/domain/demanda/TarefaFormulario.ts` | `TarefaFormulario` | 🟢 |
| `desktop/src/application/demanda/CreateDemandaUseCase.ts` | `CreateDemandaUseCase` | 🟢 |
| `desktop/src/application/demanda/AcceptDemandaUseCase.ts` | `AcceptDemandaUseCase` | 🟢 |
| `desktop/src/application/demanda/CloseDemandaUseCase.ts` | `CloseDemandaUseCase` | 🟢 |
| `desktop/src/application/demanda/GetDemandaStatusUseCase.ts` | `GetDemandaStatusUseCase` | 🟢 |
| `desktop/src/infrastructure/persistence/sqlite/SqliteDemandaRepository.ts` | `SqliteDemandaRepository` | 🟢 |
