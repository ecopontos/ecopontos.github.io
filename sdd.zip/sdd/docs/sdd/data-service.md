# Data Service (Mobile — Persistência Offline)

## Visão Geral
Camada de persistência offline do mobile PWA baseada em IndexedDB. Armazena submissões de formulários localmente, gerencia sincronização com Supabase (`tbl_suite`), comprime imagens automaticamente e garante idempotência via UUID.

## Responsabilidades
- Armazenar submissões no IndexedDB (store `formSubmissions`, v3) 🟢
- Sincronizar submissões locais → Supabase `tbl_suite` 🟢
- Deduplicação via índice UUID único 🟢
- Compressão automática de imagens (>1MB, qualidade 0.8, max 1920px) 🟢
- Sync lock: um sync por vez, fila de espera 🟢
- Configuração de upload (max 5MB, compressão on/off) 🟢

## Interface

`DataService.configureSupabase(url, key, userId?)`, `DataService.saveSubmission(data)`, `DataService.getSubmissions(filter?)`, `DataService.syncPendingSubmissions()`, `DataService.getSubmissionByUUID(uuid)`

## Regras de Negócio
- IndexedDB store `formSubmissions` v3 com índice único em `uuid` 🟢
- Sync lock: `_acquireSyncLock()` enfileira requisições concorrentes 🟢
- Imagens > 1MB são comprimidas automaticamente (qualidade JPEG 0.8, max largura 1920px) 🟢
- Upload máximo 5MB por submissão 🟢
- User ID usado na submissão (default: zero-UUID) 🟢

## Fluxo Principal

1. Usuário submete formulário → `saveSubmission()` persiste no IndexedDB
2. Se online, `syncPendingSubmissions()` envia ao Supabase `tbl_suite`
3. Se offline, permanece na fila local
4. Ao reconectar, sync automático envia pendentes
5. Deduplicação: submissões com mesmo UUID são ignoradas no reenvio

## Dependências
- IndexedDB (browser API)
- Supabase JS client → `tbl_suite`
- `window.globalSupabaseClient`

## Requisitos Não Funcionais

| Tipo | Requisito | Evidência | Confiança |
|---|---|---|---|
| Performance | Compressão de imagem reduz tráfego | `data-service.js:29-31` | 🟢 |
| Disponibilidade | IndexedDB funciona offline | `data-service.js:13-18` | 🟢 |
| Consistência | Sync lock previne concorrência | `data-service.js:46-67` | 🟢 |
| Confiabilidade | UUID único previne duplicação | commit `6b0d89c` | 🟢 |

## Critérios de Aceitação

```gherkin
Dado que o dispositivo está offline
Quando submeto um formulário com fotos
Então a submissão é salva no IndexedDB e imagens >1MB são comprimidas

Dado que há 3 submissões pendentes e o dispositivo fica online
Quando o sync é disparado
Então as 3 são enviadas em sequência (lock) sem duplicação

Dado que uma submissão com UUID "abc-123" já foi sincronizada
Quando o sync é executado novamente
Então "abc-123" é ignorado (idempotente)
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| IndexedDB persist | Must | Core offline |
| Sync Supabase | Must | Essencial para consolidação |
| Compressão de imagem | Should | Importante para performance mobile |
| Sync lock | Should | Previne corrupção |

## Rastreabilidade

| Arquivo | Função/Classe | Cobertura |
|---|---|---|
| `www/js/data-service.js` | `DataService` (2378 linhas) | 🟢 |
