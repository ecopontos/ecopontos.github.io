# Field System (Mobile — Sistema de Campos)

## Visão Geral
Sistema de renderização dinâmica de campos de formulário no mobile PWA. 53+ tipos de campo com FieldFactory para instanciação por tipo, BaseField com ciclo de vida padronizado e integração Alpine.js.

## Responsabilidades
- Instanciar campo correto baseado no tipo declarado no schema do formulário 🟢
- Gerenciar ciclo de vida: constructor → init → getDefaultValue → render → validate 🟢
- Calcular valor padrão (defaultToNow, etc.) via `computeDefaultValue` 🟢
- Sanitizar IDs de campo 🟢
- Validar campos conforme configuração 🟢
- Suportar aliases de tipo (ex: `photo` → `CameraField`, `gps` → `GeolocationField`) 🟢

## Interface

### `BaseField(config)`
Ciclo de vida: `constructor` → `init()` → `getDefaultValue()` → `render()` → `validate()`. Estado: `value`, `errors`, `isValid`, `isDirty`, `isTouched`.

### `FieldFactory.createField(config)`
Mapeia `config.type` → classe concreta via `FIELD_TYPE_MAP`. Fallback: `FieldSkeleton`.

## Tipos de Campo (53+)

| Categoria | Campos |
|---|---|
| **Texto** | TextField, TextAreaField, PasswordField, HiddenField |
| **Número** | NumberField, NumberInputField.v2 |
| **Seleção** | SelectField, RadioField, CardsRadioField, ChipsField, SelectorModalField, CheckboxField, DynamicToggleListField |
| **Data/Hora** | DateTimeField, DateField.v2, TimeField.v2 |
| **Mídia** | CameraField, GalleryField, FileField |
| **Geolocalização** | GeolocationField, GPSField.v2 |
| **Presença** | PresenceField (unificado para todos os aliases) |
| **Checklist** | ChecklistField, VistoriaChecklistField |
| **Grupo** | GroupField, RepeatableGroupField |
| **Especiais** | OccupationField, CaixasAvancadoField, InputFieldBase |

## Regras de Negócio
- Campo com `required: true` exibe indicador visual e valida não-vazio 🟢
- `defaultToNow`: campos com essa config atualizam valor em tempo real 🟢
- IDs sanitizados via `sanitizeId()` (remove caracteres inválidos) 🟢
- Config aninhada (`config.config`) é hoisted para o nível principal (backwards-compat) 🟢
- Presença unificada: todos os aliases (`presence`, `presence-list`, `presence_compact`, etc.) → `PresenceField` 🟢
- Fallback: tipo desconhecido → `FieldSkeleton` 🟢

## Fluxo Principal

1. `FormRenderer` lê schema do formulário com array de `campos[]`
2. Para cada campo, chama `FieldFactory.createField(config)`
3. FieldFactory consulta `FIELD_TYPE_MAP[config.type]`
4. Se encontrado, instancia classe concreta (ex: `new CameraField(config)`)
5. Se não encontrado, usa `FieldSkeleton`
6. Campo segue ciclo: `init()` → `getDefaultValue()` → `render(container)` → `validate()`

## Dependências
- `BaseField` — classe base
- `FieldFactory` — factory + `FIELD_TYPE_MAP`
- `computeDefaultValue` (`defaults.js`) — valores padrão
- `sanitizeId` (`utils.js`) — sanitização de IDs
- Alpine.js — reatividade e data-binding

## Requisitos Não Funcionais

| Tipo | Requisito | Evidência | Confiança |
|---|---|---|---|
| Extensibilidade | Sistema de plugins via FieldFactory + type map | `FieldFactory.js:29-80` | 🟢 |
| Compatibilidade | Aliases e backwards-compat (config.config nesting) | `BaseField.js:25-38` | 🟢 |
| Segurança | XSS protection no FormRenderer | commit `8978252` | 🟢 |

## Critérios de Aceitação

```gherkin
Dado um schema com campo tipo "camera" e label "Foto do Local"
Quando o FieldFactory processa esse campo
Então uma instância de CameraField é criada e renderizada

Dado um schema com tipo desconhecido "custom-widget"
Quando o FieldFactory processa
Então um FieldSkeleton é usado como fallback

Dado um campo com defaultToNow = true
Quando o formulário é carregado
Então o valor do campo é a data/hora atual
```

## Prioridade

| Requisito | MoSCoW | Justificativa |
|---|---|---|
| FieldFactory + types básicos (text, select, number) | Must | Essencial para qualquer formulário |
| Camera/Gallery/File | Must | Core da aplicação de campo |
| Geolocalização | Must | Essencial para fiscais |
| Checklist/Vistoria | Should | Específico de ecopontos |
| RepeatableGroup | Could | Caso de uso avançado |

## Rastreabilidade

| Arquivo | Função/Classe | Cobertura |
|---|---|---|
| `www/js/fields/FieldFactory.js` | `FieldFactory`, `FIELD_TYPE_MAP` | 🟢 |
| `www/js/fields/types/BaseField.js` | `BaseField` | 🟢 |
| `www/js/fields/defaults.js` | `computeDefaultValue` | 🟢 |
| `www/js/fields/utils.js` | `sanitizeId` | 🟢 |
| `www/js/fields/types/` (53 arquivos) | Todos os tipos de campo | 🟢 |
| `www/js/form-renderer.js` | `FormRenderer` | 🟢 |
