# Glossário e Regras de Domínio — ecoformsnext

> Detective — 2026-04-30

---

## Glossário de Negócio

| Termo | Definição | Confiança |
|---|---|---|
| **EcoSuite / EcoForms** | Sistema de formulários ecológicos para Prefeitura de Florianópolis | 🟢 |
| **Ecoponto** | Local de coleta/descarte de resíduos gerenciado pelo sistema | 🟢 |
| **PJ (Pessoa Jurídica)** | Cliente empresa/órgão público cadastrado | 🟢 |
| **PF (Pessoa Física)** | Pessoa física vinculada como contato de uma PJ | 🟢 |
| **Demanda** | Solicitação de trabalho entre setores/usuários com workflow de aprovação | 🟢 |
| **Tarefa (Task)** | Unidade de trabalho kanban, vinculada a projeto ou demanda | 🟢 |
| **Protocolo (Ouvidoria)** | Ticket de atendimento ao cidadão com eventos encadeados | 🟢 |
| **Suite Package** | Formulário submetido versionado (tbl_suite), unidade central de dados | 🟢 |
| **Form Registry** | Catálogo de definições de formulários (schema, campos, versão) | 🟡 |
| **Data Registry** | Repositório genérico de dados tipados (não normalizado) | 🟢 |
| **Roteiro** | Template de rota de coleta (resíduos) com periodicidade e turno | 🟢 |
| **Rota** | Posição de um cliente em um roteiro de coleta | 🟢 |
| **Coleta** | Registro de coleta realizada em uma data específica | 🟢 |
| **Inbox** | Caixa de entrada — formulários submetidos pendentes de revisão | 🟢 |
| **Ad Hoc** | Registro espontâneo de formulário (não vinculado a demanda/tarefa) | 🟢 |
| **Sync Bucket** | Bucket Supabase Storage usado como canal de sincronização | 🟢 |
| **Evento (Event Sourcing)** | Registro imutável de ação no sistema (demanda, suite, ecoponto) | 🟢 |

---

## Regras de Negócio Identificadas

### 1. Gestão de Demandas

| Regra | Localização | Confiança |
|---|---|---|
| Demanda do tipo "próprio" é auto-aceita (pula status "aberta") | CreateDemandaUseCase.ts:23 | 🟢 |
| Aceite de demanda só permitido quando status = "aberta" | AcceptDemandaUseCase.ts:38 | 🟢 |
| Política "todas" bloqueia encerramento se houver tarefas pendentes | CloseDemandaUseCase.ts:26-35 | 🟢 |
| Aceite é transacional: status + tarefas + formulários + eventos | AcceptDemandaUseCase.ts:48 | 🟢 |
| Cada tarefa de demanda pode ter múltiplos formulários (obrigatórios ou não) | TarefaFormulario.ts | 🟢 |

### 2. Gestão de Tarefas

| Regra | Localização | Confiança |
|---|---|---|
| Título obrigatório e validado com trim | Task.ts:66 | 🟢 |
| Transições de status restritas: concluido e cancelado são terminais | TaskStatus.ts:3 | 🟢 |
| Ordem kanban usa gap de 1000 (MAX+1000) para inserção intercalada | SqliteTaskRepository.ts:168 | 🟢 |
| Prioridade default é "media" | CreateTaskUseCase.ts:23 | 🟢 |
| Soft-delete via deletado_em (não remove fisicamente) | SqliteTaskRepository.ts:149 | 🟢 |
| Tarefas são UUID v4 | CreateTaskUseCase.ts:20 | 🟢 |

### 3. Gestão de Clientes

| Regra | Localização | Confiança |
|---|---|---|
| Nome do cliente é validado como único antes de criar/atualizar | CheckClientNameExistsUseCase.ts:6 | 🟢 |
| Delete é soft-delete (Inativo=1) | SqliteClientRepository.ts:155 | 🟢 |
| Listagem padrão filtra apenas ativos | ListClientsUseCase.ts:13 | 🟢 |
| ID do cliente gerado via UUID v4 (`crypto.randomUUID()`) | CreateClientUseCase.ts:12 | 🟢 |
| Reativação de cliente inativo via toggleActive() | ToggleClientActiveUseCase.ts | 🟢 |

### 4. Sincronização

| Regra | Localização (Git/Code) | Confiança |
|---|---|---|
| Resolução de conflitos LWW + hash (Last-Write-Wins com checksum) | commit c152451 | 🟢 |
| Upload usa deep-clone para evitar mutação durante envio | commit 538d463 | 🟢 |
| Idempotência ativa via uuid + checksums confiáveis | commit 6b0d89c | 🟢 |
| Sincronização usa lock de concorrência (um sync por vez) | DataService._syncLock | 🟢 |
| Supabase Storage RLS dual-auth: anon (mobile) + authenticated (desktop) | 01-storage-rls-v2.sql | 🟢 |
| Service role key isolada no backend Tauri (nunca no frontend) | commit 2a011af | 🟢 |

### 5. Segurança e Autenticação

| Regra | Localização | Confiança |
|---|---|---|
| Session heartbeat renova sessão a cada interação do usuário (>1min throttle) | auth-manager.js:70-80 | 🟢 |
| Senhas hasheadas com bcrypt (salt rounds=10) | auth-manager.js:14 | 🟢 |
| Fallback JSON local quando Supabase indisponível | auth-manager.js:10 | 🟢 |
| Perfis de acesso: admin > gerente > coordenador > encarregado > operador/campo | AccessPolicy.ts:8-15 | 🟢 |

### 6. Formulários e Campos

| Regra | Localização | Confiança |
|---|---|---|
| Campos com defaultToNow atualizam valor em tempo real | commit a1bd9a3 | 🟢 |
| XSS protection no FormRenderer | commit 8978252 | 🟢 |
| Form versioning com migration, UI e table mapping | commit 53452f3 | 🟢 |
| Imagens comprimidas automaticamente (>1MB, qualidade 0.8, max 1920px) | data-service.js:29-31 | 🟢 |

---

## Decisões Arquiteturais Identificadas (via Git)

| Decisão | Evidência | Confiança |
|---|---|---|
| Unificação EcoForms + Ecoponto em app único | commit 16725a3 "unify project - remove bifurcation" | 🟢 |
| Remoção do Electron em favor do Tauri | commit 7d05687 "pre remocao do electron" | 🟢 |
| Ouvidoria migrada para handlers genéricos de suite (AD-014) | commit 2f7ee1a + HandlerRegistry.ts | 🟢 |
| Clean Architecture documentada como padrão | commit e2119e0 "Fase 6.3" | 🟢 |
| Sincronização por fases (Fase 1→5): JSON seguro → locks → TTL → LWW → deep-clone | commits 6b0d89c → 538d463 | 🟢 |
| Service role key movida do frontend para Tauri backend | commit 2a011af | 🟢 |
| Dashboard removido do menu mobile, mantido apenas admin | commit 3342659 | 🟢 |

---

## Lacunas Identificadas 🔴

| Lacuna | Contexto | Status |
|---|---|---|
| Política "declarado" do CloseDemanda — não há validação; o que impede encerramento prematuro? | CloseDemandaUseCase não verifica nada quando política = "declarado" | 🟢 Stakeholder confirmou: confiança no declarante + revisão do gerente |

## Lacunas Resolvidas ✅

| Lacuna | Resolução | Data |
|---|---|---|
| Conflito de ID: client usa Date.now(), task usa crypto.randomUUID() | Migration `009_add_client_uuid.sql`: coluna `uuid TEXT` + backfill; `CreateClientUseCase` usa `crypto.randomUUID()`; 28 arquivos alterados | 2026-04-30 |
| Não há mecanismo de reativação de cliente (soft-delete irreversível via use case) | `ToggleClientActiveUseCase` criado; `Client.toggleActive()` exposto | 2026-04-30 |
| Outbox pattern implícito — eventos sem garantia de entrega ou expurgo | `purgeOldSentEvents(30d)` + `purgeOldFailedEvents(7d)` implementados TS+JS | 2026-04-30 |
| Sem rate limiting ou throttling visível nos endpoints de sync | `TokenBucketRateLimiter` (burst=5, 2 req/s) integrado ao `TransportService` TS+JS | 2026-04-30 |
