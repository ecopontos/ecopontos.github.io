# Matriz de Permissões (RBAC) — ecoformsnext

> Detective — 2026-04-30 | 🟢 CONFIRMADO (código + ACL)

---

## 1. Hierarquia de Perfis

```
admin(0) > gerente(1) > coordenador(2) > encarregado(3) > operador(4) = campo(4)
```

Código: `desktop/src/domain/access/AccessPolicy.ts:8-15`

---

## 2. Matriz de Permissões por Perfil

| Funcionalidade | admin | gerente | coordenador | encarregado | operador | campo |
|---|---|---|---|---|---|---|
| **Ver todos os usuários** | ✅ | ✅ (org) | ❌ | ❌ | ❌ | ❌ |
| **Criar/editar usuários** | ✅ | ✅ (subordinados) | ❌ | ❌ | ❌ | ❌ |
| **Ver todas as tarefas** | ✅ | ✅ (subordinados + dept) | ✅ (subordinados) | ✅ (subordinados) | ❌ (próprias) | ❌ (próprias) |
| **Criar tarefas** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Atribuir tarefas** | ✅ | ✅ | ✅ (subordinados) | ✅ (subordinados) | ❌ | ❌ |
| **Reatribuir tarefas** (`tasks.reassign`) | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ |
| **Mover tarefas (kanban)** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Ver inbox (formulários)** | ✅ (todos) | ✅ (dept + atribuídos + criados) | ✅ (próprios + atribuídos + interessados) | ✅ (próprios + atribuídos + interessados) | ✅ (próprios + atribuídos + interessados) | ✅ (próprios + atribuídos + interessados) |
| **Dashboard estratégico** | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Dashboard operacional** | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Métricas por ecoponto** | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Gerenciar clientes PJ** | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| **Criar demandas** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Aceitar demandas** | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| **Encerrar demandas** | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| **Exportar dados (CSV/Excel/PDF)** | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Gerenciar formulários (registry)** | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Acessar setup do dispositivo** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Ver dados do Supabase** | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |

---

## 3. Regras de Filtro SQL por Perfil

### `buildTaskAccessFilter(userId, perfil)`

| Perfil | Cláusula SQL | Vê |
|---|---|---|
| admin | `1=1` | Todas as tarefas |
| gerente | `t.criado_por = ? OR t.atribuido_para = ? OR u_criador.perfil IN (subordinados)` | Próprias + atribuídas + subordinados |
| coordenador | `t.criado_por = ? OR t.atribuido_para = ? OR u_criador.perfil IN (subordinados)` | Próprias + atribuídas + subordinados |
| encarregado | `t.criado_por = ? OR t.atribuido_para = ? OR u_criador.perfil IN (subordinados)` | Próprias + atribuídas + subordinados |
| operador/campo | `t.criado_por = ? OR t.atribuido_para = ?` | Apenas próprias + atribuídas |

### `buildInboxAccessFilter(userId, perfil)`

| Perfil | Escopo |
|---|---|
| admin | Todos os registros |
| gerente | Próprios + mesmo departamento + atribuídos + criados + interessados |
| Outros | Próprios + atribuídos + criados + interessados |

---

## 4. Regras de Acesso a Dados de Usuário

| Função | Regra |
|---|---|
| `canAccessUserData(currentPerfil, targetPerfil)` | targetLevel >= currentLevel (só acessa hierarquia igual ou inferior) |
| `getAccessiblePerfis(perfil)` | Retorna próprio perfil + todos subordinados |
| `getSubordinatePerfis(perfil)` | Retorna apenas subordinados (nível > próprio) |

---

## 5. Perfis e Seus Subordinados

| Perfil | Pode gerenciar |
|---|---|
| **admin** | admin, gerente, coordenador, encarregado, operador, campo |
| **gerente** | gerente, coordenador, encarregado, operador, campo |
| **coordenador** | coordenador, encarregado, operador, campo |
| **encarregado** | encarregado, operador, campo |
| **operador** | operador |
| **campo** | campo |

---

## 6. Supabase RLS (Bucket Storage)

### Authenticated (Desktop Admin)
- **Leitura/Escrita:** paths org-scoped (`orgs/%/eventos/%`, `orgs/%/manifests/%`, `shared/org_config.json`, `eventos/%`, `shared/manifests/%`, `shared/.bootstrap_marker`)

### Anon (Mobile PWA)
- **Leitura:** `shared/users.json`, `shared/form_%`, `shared/data_%`, `shared/tasks.json`, `shared/ecoponto_%`, `shared/app-version.json`, `shared/inbox/%`, `shared/adhoc/%`, `users/%/images/%`, `users/%`, `archive/%`, `forms/%`, `data/%`
- **Escrita:** `shared/inbox/%`, `users/%/images/%`, `archive/%`

