# User Stories — Principais Fluxos

> Writer — 2026-04-30 | 🟡 INFERIDO (baseado na análise de código e fluxos)

---

## US-01: Fiscal preenche formulário em campo (offline)

**Como** fiscal de campo,
**Quero** preencher um formulário de vistoria no meu smartphone, mesmo sem internet,
**Para** registrar dados do ecoponto durante a fiscalização.

**Critérios de aceitação:**
- Abrir formulário da lista de formulários ad hoc disponíveis
- Preencher todos os campos (texto, seleção, câmera, geolocalização)
- Câmera captura foto e comprime automaticamente se >1MB
- Submeter formulário → salvo no IndexedDB local
- Se offline, formulário fica na fila de sincronização
- Ao reconectar, formulário é enviado automaticamente ao Supabase

**Componentes:** FieldFactory, DataService, CameraField, SyncManager
**Status:** 🟢 Implementado

---

## US-02: Gerente revisa formulários submetidos (inbox)

**Como** gerente,
**Quero** revisar formulários submetidos pelos fiscais no inbox do desktop,
**Para** aprovar, solicitar correção ou arquivar registros.

**Critérios de aceitação:**
- Ver lista de submissões pendentes no inbox
- Filtrar por status, tipo de formulário, data
- Abrir detalhes de uma submissão (todos os campos e fotos)
- Aprovar submissão (status → `current`)
- Refutar submissão com justificativa (status → `refuted`)
- Criar demanda a partir de submissão para ação corretiva

**Componentes:** SuitePackage, useInbox, ReviewSuiteUseCase, CreateDemandaUseCase
**Status:** 🟢 Implementado

---

## US-03: Gerente cria demanda e atribui tarefas

**Como** gerente,
**Quero** criar uma demanda para um setor com tarefas e formulários vinculados,
**Para** delegar trabalho de fiscalização ou correção.

**Critérios de aceitação:**
- Criar demanda informando setor destinatário, tipo de ação e descrição
- Definir política de conclusão (todas as tarefas ou declaração)
- Destinatário recebe notificação da demanda
- Destinatário aceita a demanda e define tarefas com formulários
- Cada tarefa aparece no kanban do responsável
- Ao concluir todas as tarefas, demanda pode ser encerrada

**Componentes:** CreateDemandaUseCase, AcceptDemandaUseCase, CloseDemandaUseCase, Task
**Status:** 🟢 Implementado

---

## US-04: Operador gerencia tarefas no kanban

**Como** operador,
**Quero** visualizar e mover minhas tarefas em um quadro kanban,
**Para** acompanhar o progresso do meu trabalho.

**Critérios de aceitação:**
- Ver tarefas organizadas por colunas: A Fazer, Em Progresso, Concluído
- Arrastar tarefa entre colunas (transição de status validada)
- Criar nova tarefa avulsa (não vinculada a demanda)
- Atribuir tarefa a outro operador do mesmo setor
- Ver prazo e prioridade de cada tarefa

**Componentes:** Task, TaskStatus (state machine), useKanban, MoveTaskUseCase
**Status:** 🟢 Implementado

---

## US-05: Admin gerencia usuários e permissões

**Como** admin,
**Quero** cadastrar, editar e desativar usuários do sistema,
**Para** controlar quem tem acesso a quais funcionalidades.

**Critérios de aceitação:**
- Listar todos os usuários com filtro por perfil e setor
- Criar novo usuário com nome, email, perfil e setores
- Editar perfil e setores de usuário existente
- Ativar/desativar usuário (soft-toggle)
- Visualizar apenas usuários de nível hierárquico igual ou inferior

**Componentes:** User, AccessPolicy, useUsers, CreateUserUseCase, ToggleUserStatusUseCase
**Status:** 🟢 Implementado

---

## US-06: Sincronização automática entre dispositivos

**Como** operador de campo,
**Quero** que meus dados sincronizem automaticamente quando houver internet,
**Para** não perder informações e manter todos os dispositivos atualizados.

**Critérios de aceitação:**
- Dados submetidos offline são enviados ao reconectar
- Dados de outros dispositivos são baixados automaticamente
- Conflitos resolvidos deterministicamente (LWW + hash)
- Nenhuma duplicação de registros (idempotência por UUID)
- Indicador visual de status de sincronização

**Componentes:** Sync Engine, EventSyncAdapter, TransportService, CryptoLayer
**Status:** 🟢 Implementado

---

## US-07: Cidadão abre protocolo na ouvidoria

**Como** cidadão,
**Quero** registrar uma reclamação ou solicitação via ouvidoria,
**Para** reportar problemas relacionados a ecopontos e resíduos.

**Critérios de aceitação:**
- Informar telefone, nome e descrição do problema
- Sistema gera número de protocolo
- Protocolo pode ser encaminhado como demanda para setor responsável
- Cidadão pode consultar status do protocolo

**Componentes:** Protocolo, CreateProtocoloUseCase, EncerrarProtocoloUseCase
**Status:** 🟡 Parcialmente implementado (usa Supabase direto, sem SQLite local)

---

## Resumo de Cobertura

| US | Status | Complexidade |
|---|---|---|
| US-01 Campo offline | 🟢 Implementado | Alta |
| US-02 Revisão inbox | 🟢 Implementado | Média |
| US-03 Demanda + tarefas | 🟢 Implementado | Alta |
| US-04 Kanban | 🟢 Implementado | Média |
| US-05 Gestão usuários | 🟢 Implementado | Baixa |
| US-06 Sincronização | 🟢 Implementado | Alta |
| US-07 Ouvidoria | 🟡 Parcial | Média |
