# Auditoria de Código Legado — ecoformsnext

> 2026-04-30 — Cruzamento entre `adr-evolucao-plataforma.md` e o código real

---

## Resumo

| Severidade | Categorias | Concluídas | Pendentes | Arquivos afetados (~) |
|---|---|---|---|---|---|
| 🔴 Crítica | 2 | 2 | 0 | ~22 → ~0 |
| 🟠 Alta | 4 | 2 | 2 | ~30 → ~2 |
| 🟡 Média | 5 | 3 | 2 | ~45 → ~20 |
| 🟢 Baixa | 7 | 4 | 3 | ~36 → ~22 |
| **Total** | **18** | **11** | **7** | **~120 → ~44** |

---

## 🔴 Críticas

### 1. ~~Ouvidoria — 20 arquivos mortos (AD-014)~~ ✅ CONCLUÍDO (2026-04-30)

`domain/ouvidoria/` e `application/ouvidoria/` deletados. `useOuvidoriaQueries.ts` usa `tbl_suite` com `module_type='ouvidoria'`. Typecheck passou sem erros.

### 2. ~~Salt PBKDF2 hardcoded (AD-022)~~ ✅ CONCLUÍDO (2026-04-30)

Desktop: `AuthContext.tsx:117-125` lê `sync_salt` de `tbl_usuarios` e passa para `CryptoLayer.deriveAndStoreKey()` — já estava wired.
Mobile: `CryptoLayer.js` recebe `userSalt?`, `SyncAdapter.js` passa `user.sync_salt` de `AuthManager`.

---

## 🟠 Altas

### 3. ~~device_id vs routing_id (AD-021)~~ ✅ PARCIAL (2026-04-30)

EventEnvelope: `device_id` tornado opcional em ambos TS/JS. `sync-settings.ts` migrou localStorage key. `FormRenderer.tsx` usa `user.setor` ao invés de hardcoded. `device-setup.js` key renomeada. IndexedDB `syncDeviceLog` requer migração de schema (pendente).

### 4. CRM escreve em tblRotas (AD-015) — ⏳ PENDENTE

Requer refatoração de use cases (`CreateRotaUseCase` → `SuiteRepository`). Escopo de feature, não limpeza.

### 5. ~~8 arquivos de sync duplicados~~ ✅ CONCLUÍDO (2026-04-30)

Headers de espelhamento adicionados nos 8 JS mobile. Teste de contrato (`tests/sync-contract.test.ts`) criado com 6 testes validando equivalência JS↔TS para `stableStringify`, `buildChecksum` e `createEnvelope`.

### 6. ~~sync-manager.js — 521 linhas mortas (AD-021)~~ ✅ CONCLUÍDO (2026-04-30)

Arquivo deletado. Tags `<script>` removidas de `www/index.html` e `www/dashboard.html`.

---

## 🟡 Médias

### 7. 15 marcadores @deprecated

Em `data-service.js`, `ActivityService.js`, `types/index.ts`, `useSolicitacoesList.ts`. Métodos ainda existem mas redirecionam para novos.

### 8. ~~19 arquivos .bak~~ ✅ CONCLUÍDO (2026-04-30)

Todos os 19 arquivos `.bak` deletados (9 desktop + 10 www).

### 9. ~~4 stubs "não implementado"~~ ✅ CONCLUÍDO (2026-04-30)

`createPF`, `updatePF`, `linkContact`, `unlinkContact` removidos de `useClientMutations.ts`. Nenhum caller externo.

### 10. CRM lê tblColetas diretamente

`useCRMQueries.ts:102-108` com comentário "AD-015: leitura legado para compatibilidade". Transicional, mas sem timeline.

### 11. ~~6 stubs Supabase em FormVersionManager~~ ✅ CONCLUÍDO (2026-04-30)

6 métodos Supabase stub removidos. Branches `else` nos callers simplificados para chamar apenas IndexedDB.

---

## 🟢 Baixas

- ~~3 `.old`, 3 `.OBSOLETE`, 2 `-old.html` dashboards~~ ✅ CONCLUÍDO (2026-04-30)
- ~~5 imports comentados `// import { supabase }`~~ ✅ CONCLUÍDO (2026-04-30)
- Schema dumps com tabelas legadas
- 22 docs obsoletos em `legacy/obsoleto-2026-04-30/`
- Electron migration: ✅ completa

---

## Ordem recomendada de limpeza

1. ~~Deletar 20 arquivos ouvidoria + 19 `.bak` + `sync-manager.js`~~ ✅ Onda 1
2. ~~Wire `CryptoLayer` ao salt por usuário~~ ✅ Onda 2.1
3. ~~Canonicalizar `routing_id` sobre `device_id`~~ ✅ Parcial (Onda 3.1)
4. Migrar `SqliteCRMRepository` writes para `tbl_suite` — ⏳ requer refatoração de use cases
5. ~~Extrair sync core duplicado~~ ✅ Onda 3.3
6. ~~Deletar `.old`/`.OBSOLETE`/comentários/dashboards -old~~ ✅ Onda 1
7. ~~Remover stubs não implementados (`useClientMutations`, `FormVersionManager`, `data-service.js`)~~ ✅ Onda 2
