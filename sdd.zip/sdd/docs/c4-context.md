# C4 — Diagrama de Contexto (Nível 1)

> Architect — 2026-04-30 | 🟢 CONFIRMADO

```mermaid
C4Context
    title Diagrama de Contexto — EcoSuite (ecoformsnext)

    Person(fiscal, "Fiscal de Campo", "Operador em campo usando smartphone")
    Person(gerente, "Gerente/Admin", "Gestor no desktop que revisa formulários e gerencia operações")
    Person(cidadao, "Cidadão", "Usuário da ouvidoria, reporta problemas")

    System(ecosuite, "EcoSuite", "Sistema de formulários ecológicos offline-first para gestão de ecopontos e resíduos")

    System_Ext(supabase, "Supabase", "Backend cloud: PostgreSQL, Auth, Storage, Realtime")
    System_Ext(viacep, "ViaCEP", "API pública de consulta de CEP")

    Rel(fiscal, ecosuite, "Preenche formulários offline, sincroniza quando online", "PWA/Android")
    Rel(gerente, ecosuite, "Revisa submissões, cria demandas, gerencia usuários e dashboards", "Desktop App")
    Rel(cidadao, ecosuite, "Abre protocolos na ouvidoria", "Web")

    Rel(ecosuite, supabase, "Auth, Storage (sync-bucket), Realtime", "HTTPS/REST")
    Rel(ecosuite, viacep, "Consulta endereço por CEP", "HTTPS/REST")
```
