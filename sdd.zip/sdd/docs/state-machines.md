# Máquinas de Estado — ecoformsnext

> Detective — 2026-04-30 | 🟢 CONFIRMADO (extraído do código)

---

## 1. Task (Tarefa Kanban)

**4 estados, 6 transições, 2 terminais**

```mermaid
stateDiagram-v2
    [*] --> a_fazer
    a_fazer --> em_progresso: Iniciar
    a_fazer --> cancelado: Cancelar
    em_progresso --> a_fazer: Reabrir
    em_progresso --> concluido: Concluir
    em_progresso --> cancelado: Cancelar
    concluido --> [*]
    cancelado --> [*]
```

| Estado | Significado | Terminal? |
|---|---|---|
| `a_fazer` | Pendente, aguardando início | Não |
| `em_progresso` | Em execução | Não |
| `concluido` | Finalizada com sucesso | Sim |
| `cancelado` | Cancelada/abortada | Sim |

**Código:** `TaskStatus.ts:3-8`

---

## 2. Suite Package (Formulário Submetido)

**11 estados, ~22 transições, 2 terminais**

```mermaid
stateDiagram-v2
    [*] --> draft
    draft --> current: Publicar
    draft --> dispatched: Despachar
    draft --> closed: Fechar
    current --> edit: Editar
    current --> locked: Bloquear
    current --> superseded: Substituir
    current --> pending_review: Enviar p/ Revisão
    current --> closed: Fechar
    edit --> current: Salvar
    edit --> pending_review: Enviar p/ Revisão
    edit --> superseded: Substituir
    locked --> current: Desbloquear
    dispatched --> pending_review: Revisar
    dispatched --> closed: Fechar
    pending_review --> current: Aprovar
    pending_review --> refuted: Refutar
    pending_review --> closed: Fechar
    refuted --> edit: Corrigir
    refuted --> closed: Fechar
    superseded --> [*]
    closed --> [*]
```

| Estado | Significado |
|---|---|
| `draft` | Rascunho inicial |
| `current` | Versão atual/publicada |
| `edit` | Em edição (versão nova) |
| `locked` | Bloqueado por usuário |
| `dispatched` | Despachado (aguardando ação) |
| `pending_review` | Aguardando revisão |
| `refuted` | Revisão recusada |
| `superseded` | Substituído por versão mais nova (terminal) |
| `closed` | Fechado/encerrado (terminal) |
| `approved` | Legado v1 |
| `rejected` | Legado v1 |

**Código:** `SuiteStatus.ts:19-31`

---

## 3. Demanda (Workflow de Solicitação)

**4 estados**

```mermaid
stateDiagram-v2
    [*] --> aberta: Criar (ouvidoria/interno)
    [*] --> aceita: Criar (origem própria)
    aberta --> aceita: Aceitar
    aceita --> em_campo: (implícito)
    em_campo --> concluida: Encerrar
    concluida --> [*]
```

| Estado | Significado |
|---|---|
| `aberta` | Aguardando aceite do destinatário |
| `aceita` | Aceita, tarefas criadas |
| `em_campo` | Em execução no campo |
| `concluida` | Finalizada |

**Regra especial:** `origemTipo === 'proprio'` → nasce como `aceita` (auto-aceite).

**Código:** `CreateDemandaUseCase.ts:23,34` / `AcceptDemandaUseCase.ts:38`

---

## 4. Resumo de Estados por Entidade

| Entidade | Estados | Transições | Terminais |
|---|---|---|---|
| **Task** | 4 | 6 | 2 (concluido, cancelado) |
| **Suite** | 11 | ~22 | 2 (superseded, closed) |
| **Demanda** | 4 | 4 | 1 (concluida) |
| **Client** | 2 (ativo/inativo) | 2 | Nenhum (reversível) |
| **Protocolo (Ouvidoria)** | Status livre (string) | N/A | N/D |

---

## 5. Diagrama de Workflow Integrado

```mermaid
flowchart LR
    O[Ouvidoria] -->|"cria Protocolo"| D[Demanda]
    D -->|"accept → cria"| T[Tasks]
    T -->|"cada task tem"| F[Formulários]
    F -->|"submit →"| S[Suite Package]
    S -->|"review →"| R{Revisão}
    R -->|"aprova"| C[Closed]
    R -->|"refuta"| E[Edit]
    E --> S
```

**Fluxo principal:** Ouvidoria → Demanda → Tasks → Formulários → Suite → Revisão → Fechamento.
