# C4 — Diagrama de Containers (Nível 2)

> Architect — 2026-04-30 | 🟢 CONFIRMADO

```mermaid
C4Container
    title Diagrama de Containers — EcoSuite

    Person(fiscal, "Fiscal de Campo", "Operador mobile")
    Person(gerente, "Gerente/Admin", "Desktop")

    System_Boundary(ecosuite, "EcoSuite") {
        Container(mobile, "Mobile PWA", "Vanilla JS, Alpine.js, Capacitor 8", "App de campo. Preenche formulários offline, sincroniza quando online.")
        Container(desktop, "Desktop Admin", "Next.js 16, React 19, Tauri 2", "Dashboard e gestão. Revisa formulários, cria demandas, gerencia usuários.")
        Container(tauri, "Tauri Backend", "Rust, rusqlite", "Shell nativo. SQLite local, file system, dialogs. Isola chaves sensíveis.")
        ContainerDb(indexeddb, "IndexedDB", "Browser Storage", "Armazena submissões offline no mobile. Store: formSubmissions v3.")
        ContainerDb(sqlite, "SQLite", "Arquivo local", "Banco do desktop. 12+ tabelas de domínio. Acessado via rusqlite.")
    }

    System_Ext(supabase, "Supabase Cloud", "PostgreSQL + Auth + Storage")
    SystemDb(supabase_db, "PostgreSQL", "Supabase", "Banco relacional cloud. auth.users, public.profiles, tbl_suite.")
    SystemDb(supabase_storage, "Storage Bucket", "Supabase", "Bucket 'sync-bucket' com RLS dual-auth. JSON de eventos, forms, dados.")

    Rel(mobile, supabase_storage, "Lê/escreve JSON via REST anon", "HTTPS")
    Rel(desktop, supabase_storage, "Lê/escreve JSON via REST authenticated", "HTTPS")
    Rel(desktop, supabase, "Auth + Realtime + Queries", "SDK JS")
    Rel(desktop, tauri, "Invoca comandos Rust", "IPC Tauri")
    Rel(tauri, sqlite, "Queries SQL", "FFI rusqlite")
    Rel(mobile, indexeddb, "Queries IndexedDB", "JS API")
    Rel(fiscal, mobile, "Usa", "PWA/APK Android")
    Rel(gerente, desktop, "Usa", "Desktop App")
```
