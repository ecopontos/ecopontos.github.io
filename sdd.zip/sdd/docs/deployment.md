# Deployment & Operations — EcoForms Desktop

Este documento descreve o processo de deployment, distribuição, atualizações, e operações do sistema EcoForms Desktop.

---

## Relação com Outros Documentos

| Este documento | Descreve |
|----------------|----------|
| `arquitetura.md` | Visão geral da stack e componentes |
| `security.md` | Autenticação, criptografia, secrets |
| `performance-limits.md` | Limites e benchmarks |
| `error-handling.md` | Retry logic e recovery |

---

## Índice

1. [Build Process](#1-build-process)
2. [Distribuição](#2-distribuição)
3. [Atualizações](#3-atualizações)
4. [Monitoramento](#4-monitoramento)
5. [Backup e Recovery](#5-backup-e-recovery)
6. [Troubleshooting](#6-troubleshooting)
7. [Operações de Rotina](#7-operações-de-rotina)

---

## 1. Build Process

### 1.1 Pré-requisitos

```
┌─────────────────────────────────────────────────────────────┐
│                     BUILD REQUIREMENTS                      │
├─────────────────────────────────────────────────────────────┤
│  Runtime: Node.js 18+                                       │
│  Package Manager: npm 9+ / yarn 1.22+ / pnpm 8+            │
│  Rust: 1.70+ (for Tauri)                                   │
│  OS Build Targets:                                          │
│    ├── Windows: Windows 10+ (MSVC or GNU toolchain)        │
│    ├── macOS: macOS 11+ (Xcode Command Line Tools)         │
│    └── Linux: Ubuntu 20.04+ (GCC, pkg-config)              │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Dependências do Sistema

**Windows:**
```powershell
# Instalar Rust
winget install Rustlang.Rustup

# Instalar Node.js
winget install OpenJS.NodeJS

# Visual Studio Build Tools (para MSVC)
winget install Microsoft.VisualStudio.2022.BuildTools
```

**macOS:**
```bash
# Instalar Homebrew (se não tiver)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar Rust
brew install rust

# Instalar Node.js
brew install node

# Xcode Command Line Tools
xcode-select --install
```

**Linux (Ubuntu/Debian):**
```bash
# Instalar Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Instalar Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Dependências do Tauri
sudo apt update
sudo apt install libwebkit2gtk-4.0-dev build-essential curl wget file libssl-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev
```

### 1.3 Build Steps

```bash
# 1. Clone do repositório
git clone https://github.com/ecoforms/desktop.git
cd desktop

# 2. Instalar dependências Node.js
npm install

# 3. Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com credenciais do Supabase

# 4. Build do Next.js (frontend)
npm run build

# 5. Build do Tauri (binário nativo)
npm run tauri build
```

### 1.4 Build Scripts

```json
// package.json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "export": "next export",
    "tauri": "tauri",
    "tauri:dev": "tauri dev",
    "tauri:build": "tauri build",
    "tauri:build:win": "tauri build --target x86_64-pc-windows-msvc",
    "tauri:build:mac": "tauri build --target x86_64-apple-darwin",
    "tauri:build:mac-arm": "tauri build --target aarch64-apple-darwin",
    "tauri:build:linux": "tauri build --target x86_64-unknown-linux-gnu",
    "lint": "next lint",
    "test": "jest",
    "test:e2e": "playwright test"
  }
}
```

### 1.5 Tauri Configuration

```json
// src-tauri/tauri.conf.json
{
  "build": {
    "beforeBuildCommand": "npm run build",
    "beforeDevCommand": "npm run dev",
    "devPath": "http://localhost:3000",
    "distDir": "../out"
  },
  "tauri": {
    "allowlist": {
      "all": false,
      "shell": {
        "all": false,
        "open": true
      },
      "dialog": {
        "all": true
      },
      "fs": {
        "all": false,
        "readFile": true,
        "writeFile": true,
        "readDir": true,
        "createDir": true
      },
      "http": {
        "all": true,
        "request": true
      },
      "notification": {
        "all": true
      },
      "os": {
        "all": true
      },
      "path": {
        "all": true
      },
      "process": {
        "all": false,
        "relaunch": true
      },
      "window": {
        "all": false,
        "close": true,
        "hide": true,
        "show": true,
        "maximize": true,
        "minimize": true,
        "unmaximize": true,
        "unminimize": true,
        "startDragging": true
      }
    },
    "bundle": {
      "active": true,
      "category": "Productivity",
      "copyright": "© 2024 EcoForms",
      "deb": {
        "depends": []
      },
      "externalBin": [],
      "icon": [
        "icons/32x32.png",
        "icons/128x128.png",
        "icons/128x128@2x.png",
        "icons/icon.icns",
        "icons/icon.ico"
      ],
      "identifier": "com.ecoforms.desktop",
      "longDescription": "EcoForms Desktop - Sistema de Gestão Ambiental",
      "macOS": {
        "entitlements": null,
        "exceptionDomain": "",
        "frameworks": [],
        "providerShortName": null,
        "signingIdentity": null
      },
      "resources": [],
      "shortDescription": "EcoForms Desktop",
      "targets": "all",
      "windows": {
        "certificateThumbprint": null,
        "digestAlgorithm": "sha256",
        "timestampUrl": ""
      }
    },
    "security": {
      "csp": "default-src 'self'; connect-src 'self' https://*.supabase.co; img-src 'self' data: https:; script-src 'self' 'unsafe-eval'; style-src 'self' 'unsafe-inline'"
    },
    "updater": {
      "active": true,
      "endpoints": [
        "https://api.ecoforms.com/updates/{{target}}/{{current_version}}"
      ],
      "dialog": true,
      "pubkey": "dW50cnVzdGVkIGNvbW1lbnQ6IG1pbmlzaWduIHB1YmxpYyBrZXk6ID..."
    },
    "windows": [
      {
        "fullscreen": false,
        "height": 800,
        "resizable": true,
        "title": "EcoForms Desktop",
        "width": 1200,
        "minWidth": 800,
        "minHeight": 600
      }
    ]
  }
}
```

### 1.6 CI/CD Pipeline

```yaml
# .github/workflows/release.yml
name: Release

on:
  push:
    tags:
      - 'v*'

jobs:
  build:
    strategy:
      fail-fast: false
      matrix:
        platform: [macos-latest, ubuntu-latest, windows-latest]
        include:
          - platform: macos-latest
            target: universal-apple-darwin
          - platform: ubuntu-latest
            target: x86_64-unknown-linux-gnu
          - platform: windows-latest
            target: x86_64-pc-windows-msvc

    runs-on: ${{ matrix.platform }}

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 18

      - name: Setup Rust
        uses: dtolnay/rust-action@stable
        with:
          targets: ${{ matrix.target }}

      - name: Install dependencies (Ubuntu)
        if: matrix.platform == 'ubuntu-latest'
        run: |
          sudo apt-get update
          sudo apt-get install -y libwebkit2gtk-4.0-dev libssl-dev libgtk-3-dev

      - name: Install Node dependencies
        run: npm ci

      - name: Build Tauri
        run: npm run tauri:build -- --target ${{ matrix.target }}

      - name: Upload artifacts
        uses: actions/upload-artifact@v3
        with:
          name: ecoforms-${{ matrix.target }}
          path: |
            src-tauri/target/${{ matrix.target }}/release/bundle/

  release:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - name: Download artifacts
        uses: actions/download-artifact@v3

      - name: Create Release
        uses: softprops/action-gh-release@v1
        with:
          files: ecoforms-*/**
          draft: true
```

---

## 2. Distribuição

### 2.1 Formatos de Distribuição

| Plataforma | Formato | Instalação |
|------------|---------|------------|
| Windows | `.msi` | Double-click, wizard de instalação |
| Windows | `.exe` (portable) | Sem instalação, roda de qualquer pasta |
| macOS | `.dmg` | Drag & drop para Applications |
| macOS | `.app` (unsigned) | Para testes internos |
| Linux | `.deb` (Debian/Ubuntu) | `dpkg -i ecoforms.deb` |
| Linux | `.AppImage` | Executável universal, sem instalação |
| Linux | `.rpm` (Fedora/RHEL) | `rpm -i ecoforms.rpm` |

### 2.2 Code Signing

| Plataforma | Certificado | Processo |
|------------|-------------|----------|
| Windows | EV Code Signing | Comprar certificado (DigiCert, Sectigo), sign com `signtool` |
| macOS | Apple Developer ID | Apple Developer Program ($99/ano), notarize com `altool` |
| Linux | GPG | Criar chave GPG, sign .deb/.rpm |

**Windows Code Signing:**
```powershell
# Sign .exe
signtool sign /f certificate.pfx /p password /tr http://timestamp.digicert.com /td sha256 /fd sha256 "EcoForms Desktop.exe"

# Sign .msi
signtool sign /f certificate.pfx /p password /tr http://timestamp.digicert.com /td sha256 /fd sha256 "EcoForms Desktop.msi"
```

**macOS Notarization:**
```bash
# Sign .app
codesign --force --options runtime --sign "Developer ID Application: EcoForms" EcoForms.app

# Create .dmg
create-dmg --volname "EcoForms" --window-pos 200 120 --window-size 800 400 --icon-size 100 --app-drop-link 600 185 EcoForms.dmg EcoForms.app

# Notarize
xcrun altool --notarize-app --primary-bundle-id "com.ecoforms.desktop" --username "dev@ecoforms.com" --password "@keychain:AC_PASSWORD" --file EcoForms.dmg
```

### 2.3 Distribution Channels

| Canal | Público | Frequência |
|-------|---------|------------|
| GitHub Releases | Geral | A cada tag `v*` |
| Website (ecoforms.com/download) | Geral | Manual ou auto-sync com GitHub |
| Microsoft Store | Windows users | Submissão manual |
| Mac App Store | macOS users | Submissão manual (mais restrito) |
| Winget (Windows) | Power users | `winget install EcoForms.Desktop` |
| Homebrew (macOS) | Power users | `brew install --cask ecoforms` |

---

## 3. Atualizações

### 3.1 Estratégia de Atualização

```
┌─────────────────────────────────────────────────────────────┐
│                   UPDATE STRATEGY                           │
├─────────────────────────────────────────────────────────────┤
│  1. CHECK: App verifica updates no startup (ou periodic)   │
│                                                              │
│  2. DOWNLOAD: Se disponível, download em background        │
│                                                              │
│  3. NOTIFY: Notificar usuário quando pronto para instalar  │
│                                                              │
│  4. INSTALL: Instalar no próximo restart (ou imediato)     │
│                                                              │
│  5. VERIFY: Verificar checksum da atualização              │
│                                                              │
│  6. ROLLBACK: Em caso de falha, reverter para versão     │
│               anterior (manter backup)                       │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Tauri Updater

```ts
// lib/updater.ts

import { checkUpdate, installUpdate, onUpdaterEvent } from '@tauri-apps/api/updater';
import { relaunch } from '@tauri-apps/api/process';

export async function checkForUpdates(): Promise<void> {
    try {
        const { shouldUpdate, manifest } = await checkUpdate();

        if (shouldUpdate) {
            console.log(`Update available: ${manifest?.version}`);

            // Download update
            await installUpdate();

            // Notify user
            notifyUser('Update downloaded. Restart to install.');
        }
    } catch (error) {
        console.error('Failed to check for updates:', error);
    }
}

// Listen for updater events
onUpdaterEvent(({ error, status }) => {
    if (error) {
        console.error('Updater error:', error);
    } else {
        console.log('Updater status:', status);
    }
});

// Manual restart to apply update
export async function restartAndUpdate(): Promise<void> {
    await relaunch();
}
```

### 3.3 Update Server

```json
// Resposta do endpoint de updates
{
  "version": "1.2.3",
  "notes": "Bug fixes and performance improvements",
  "pub_date": "2024-01-15T12:00:00Z",
  "signature": "dW50cnVzdGVkIGNvbW1lbnQ6...",
  "url": "https://github.com/ecoforms/desktop/releases/download/v1.2.3/ecoforms_1.2.3_x64.msi"
}
```

### 3.4 Forçar Atualização

```ts
// Verificar versão mínima no backend
async function checkMinimumVersion(): Promise<boolean> {
    const { data } = await supabase
        .from('app_config')
        .select('minimum_version')
        .single();

    const currentVersion = await getVersion();
    const minimumVersion = data?.minimum_version;

    if (minimumVersion && semver.lt(currentVersion, minimumVersion)) {
        // Forçar atualização
        showForceUpdateDialog();
        return false;
    }

    return true;
}
```

---

## 4. Monitoramento

### 4.1 Logging

| Nível | Destino | Rotação |
|-------|---------|---------|
| Error | Arquivo local + console | 7 dias |
| Warn | Arquivo local + console | 7 dias |
| Info | Console only | N/A |
| Debug | Console only (dev mode) | N/A |

```ts
// src/lib/logger.ts

import { trace, info, error, attachConsole } from 'tauri-plugin-log-api';

// Anexar console do Rust ao frontend
await attachConsole();

export const logger = {
    debug: (message: string, ...args: any[]) => {
        if (process.env.NODE_ENV === 'development') {
            trace(message, args);
        }
    },
    info: (message: string, ...args: any[]) => {
        info(message, args);
    },
    warn: (message: string, ...args: any[]) => {
        warn(message, args);
    },
    error: (message: string, ...args: any[]) => {
        error(message, args);
        // Enviar para telemetry (opt-in)
        if (telemetryEnabled) {
            sendToTelemetry('error', message, args);
        }
    },
};
```

### 4.2 Telemetry (Opt-in)

```ts
// lib/telemetry.ts

const TELEMETRY_ENDPOINT = 'https://telemetry.ecoforms.com/events';

export async function sendTelemetry(event: string, data: any): Promise<void> {
    if (!telemetryEnabled) return;

    try {
        await fetch(TELEMETRY_ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                event,
                data,
                timestamp: new Date().toISOString(),
                version: await getVersion(),
                platform: await os.platform(),
                sessionId: getSessionId(),
            }),
        });
    } catch {
        // Silently fail — telemetry não deve quebrar o app
    }
}
```

**Eventos Tracked:**
- App start / crash
- Sync completed / failed
- Feature usage (form submission, task creation)
- Performance metrics (sync duration, load time)
- Errors (anonymized)

### 4.3 Health Checks

```ts
// lib/health-check.ts

export interface HealthStatus {
    database: 'ok' | 'error';
    storage: 'ok' | 'error' | 'offline';
    auth: 'ok' | 'error';
    sync: 'ok' | 'error' | 'pending';
    lastSync: Date | null;
    version: string;
}

export async function checkHealth(): Promise<HealthStatus> {
    const status: HealthStatus = {
        database: 'ok',
        storage: 'ok',
        auth: 'ok',
        sync: 'ok',
        lastSync: null,
        version: await getVersion(),
    };

    // Check database
    try {
        await db.execute('SELECT 1');
    } catch {
        status.database = 'error';
    }

    // Check auth
    try {
        const { data } = await supabase.auth.getSession();
        if (!data.session) status.auth = 'error';
    } catch {
        status.auth = 'error';
    }

    // Check storage connectivity
    try {
        await supabase.storage.listBuckets();
    } catch {
        status.storage = 'offline';
    }

    return status;
}
```

---

## 5. Backup e Recovery

### 5.1 Estratégia de Backup

```
┌─────────────────────────────────────────────────────────────┐
│                    BACKUP STRATEGY                          │
├─────────────────────────────────────────────────────────────┤
│  Local (SQLite)                    │  Cloud (Supabase)      │
│  ─────────────────────────────────│  ─────────────────────  │
│  ├── Auto-backup on close         │  ├── Snapshots (JSON.gz)│
│  ├── Daily backup at 3 AM         │  ├── Archive 90 days    │
│  ├── Pre-sync backup              │  └── RLS protected      │
│  └── Store last 10 backups        │                         │
│                                                              │
│  Backup Location:                 │  Recovery:              │
│  ├── %APPDATA%/EcoForms/backups   │  ├── Re-sync from cloud │
│  ├── ~/.local/share/EcoForms/...  │  └── Import snapshot    │
│  └── ~/Library/Application Support│                         │
└─────────────────────────────────────────────────────────────┘
```

### 5.2 Backup Automático

```ts
// lib/backup.ts

import { BaseDirectory, copyFile, createDir } from '@tauri-apps/api/fs';

const MAX_BACKUPS = 10;

export async function createBackup(): Promise<string> {
    const dbPath = await getDatabasePath();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = 'backups';
    const backupPath = `${backupDir}/ecoforms-${timestamp}.db`;

    // Ensure backup directory exists
    try {
        await createDir(backupDir, { dir: BaseDirectory.AppData, recursive: true });
    } catch {
        // Directory might already exist
    }

    // Copy database
    await copyFile(dbPath, backupPath, { dir: BaseDirectory.AppData });

    // Cleanup old backups
    await cleanupOldBackups();

    return backupPath;
}

async function cleanupOldBackups(): Promise<void> {
    const backupDir = await readDir('backups', { dir: BaseDirectory.AppData });
    const backups = backupDir
        .filter(f => f.name?.startsWith('ecoforms-'))
        .sort((a, b) => (a.name || '').localeCompare(b.name || ''));

    if (backups.length > MAX_BACKUPS) {
        const toDelete = backups.slice(0, backups.length - MAX_BACKUPS);
        for (const file of toDelete) {
            await removeFile(`backups/${file.name}`, { dir: BaseDirectory.AppData });
        }
    }
}
```

### 5.3 Export/Import Manual

```ts
// lib/export-import.ts

export async function exportDatabase(): Promise<Uint8Array> {
    const dbPath = await getDatabasePath();
    const data = await readBinaryFile(dbPath);
    return data;
}

export async function importDatabase(data: Uint8Array): Promise<void> {
    // Validate before importing
    const tempPath = await saveTempFile(data);

    try {
        // Test open as SQLite
        const testDb = await Database.load(`sqlite:${tempPath}`);
        await testDb.execute('SELECT 1');
        await testDb.close();

        // If valid, replace current database
        const dbPath = await getDatabasePath();
        await writeBinaryFile(dbPath, data);

        // Restart app
        await relaunch();
    } catch (error) {
        throw new Error(`Invalid database file: ${error}`);
    } finally {
        await removeFile(tempPath);
    }
}
```

### 5.4 Recovery Scenarios

| Cenário | Causa | Solução |
|---------|-------|---------|
| DB corrompido | Crash durante write | Restaurar do backup mais recente |
| Sync falhou | Network error | Retry com backoff, ou re-sync manual |
| App não inicia | Update quebrado | Reinstalar versão anterior |
| Dados perdidos | Device lost | Re-sync do Supabase Storage |
| Senha esquecida | User error | Reset via email (perde acesso ao DB local) |

---

## 6. Troubleshooting

### 6.1 Problemas Comuns

**Primeiro login — instalação limpa:**
Em uma instalação nova, o Tauri cria automaticamente um administrador temporário na primeira inicialização (`database.rs: initialize_database()`). A senha temporária gerada aleatoriamente é exibida no stderr do processo e gravada no arquivo `first-login.txt` ao lado do banco SQLite. Altere a senha imediatamente após o primeiro acesso.

O banco SQLite fica em `%APPDATA%\EcoForms\` (Windows) ou `~/Library/Application Support/com.ecoforms.desktop/` (macOS).

**Primeiro boot com Supabase Storage:**
Execute o script `desktop/supabase-storage-setup.sql` no SQL Editor do Supabase uma única vez para criar o bucket `sync-bucket` e as 4 policies de acesso anon. Após isso, o app cria o `shared/org_config.json` automaticamente na primeira execução online.

**App não inicia:**
```bash
# Verificar logs
tail -f ~/Library/Logs/com.ecoforms.desktop/*.log  # macOS
# ou
%APPDATA%\EcoForms\logs\*.log  # Windows

# Verificar permissões
ls -la ~/Library/Application\ Support/com.ecoforms.desktop/  # macOS

# Resetar configurações
rm -rf ~/Library/Application\ Support/com.ecoforms.desktop/  # ⚠️ CUIDADO
```

**Sync falha repetidamente:**
```bash
# 1. Verificar conectividade
curl https://xyz.supabase.co/rest/v1/

# 2. Verificar storage
curl https://xyz.supabase.co/storage/v1/bucket

# 3. Resetar estado de sync
# (Deletar arquivos de estado em IndexedDB)
```

**DB bloqueado:**
```bash
# SQLite WAL mode pode deixar arquivos .wal/.shm
# Fechar app completamente e verificar:
ls -la *.db-wal *.db-shm

# Se persistir, fazer backup e reconstruir:
cp ecoforms.db ecoforms.db.backup
sqlite3 ecoforms.db "PRAGMA integrity_check;"
```

### 6.2 Diagnostic Commands

```ts
// Comandos de diagnóstico (menu de desenvolvimento)

// Ctrl+Shift+D (dev mode) — abre DevTools

// Console commands disponíveis:
window.__ECOFORMS__.checkHealth()     // Health check
window.__ECOFORMS__.getSyncStatus()   // Estado do sync
window.__ECOFORMS__.getDbStats()      // Estatísticas do DB
window.__ECOFORMS__.forceSync()       // Forçar sync manual
window.__ECOFORMS__.clearCache()      // Limpar cache
window.__ECOFORMS__.exportLogs()      // Exportar logs
```

### 6.3 Debug Mode

```ts
// Habilitar debug mode via arquivo de configuração
// %APPDATA%/EcoForms/config.json

{
  "debug": true,
  "logLevel": "debug",
  "skipUpdateCheck": false,
  "forceOffline": false,
  "simulateLatency": 0,
  "mockSupabase": false
}
```

---

## 7. Operações de Rotina

### 7.1 Checklist Diário

- [ ] Verificar logs de erro
- [ ] Confirmar que backups foram criados
- [ ] Checar métricas de sync (sucesso/falha ratio)
- [ ] Monitorar uso de storage (Supabase)

### 7.2 Checklist Semanal

- [ ] Analisar telemetry data (feature usage, errors)
- [ ] Revisar dead letter queue
- [ ] Limpar archive antigo (> 90 dias)
- [ ] Verificar performance metrics

### 7.3 Checklist Mensal

- [ ] Update de dependências (`npm audit`, `cargo audit`)
- [ ] Revisar RLS policies
- [ ] Testar recovery de backup
- [ ] Revisar e rotacionar secrets
- [ ] Analisar custos (Supabase)

### 7.4 Comandos Úteis

```bash
# Build para todas as plataformas
npm run tauri:build

# Build para plataforma específica
npm run tauri:build:win
npm run tauri:build:mac
npm run tauri:build:linux

# Dev mode com hot reload
npm run tauri:dev

# Lint e testes
npm run lint
npm run test
npm run test:e2e

# Audit de segurança
npm audit
 cargo audit  # (no diretório src-tauri)

# Limpar build artifacts
npm run tauri:clean
```

---

## Resumo de Operações

| Tarefa | Frequência | Responsável |
|--------|-----------|-------------|
| Build e release | Sob demanda | DevOps |
| Monitorar logs | Diário | Suporte |
| Backup test | Mensal | DevOps |
| Update dependencies | Mensal | Dev |
| Security audit | Trimestral | Security |
| Revisar custos | Mensal | Gestão |
| User support | Contínuo | Suporte |