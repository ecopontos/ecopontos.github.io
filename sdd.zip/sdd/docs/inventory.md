# Inventário do Projeto — ecoformsnext

> Gerado pelo Scout em 2026-04-30
> Nível de documentação: completo

---

## 1. Visão Geral

**EcoSuite** (ecoformsnext) é um sistema completo de formulários ecológicos composto por dois aplicativos:

| Aplicativo | Tipo | Tecnologia | Público |
|---|---|---|---|
| **Mobile PWA** | Progressive Web App + Android APK | Vanilla JS + Alpine.js + Capacitor | Operadores de campo / fiscais |
| **Desktop Admin** | Aplicativo desktop + web | Next.js 16 + React 19 + Tauri 2 | Gerentes / administradores |

Ambos compartilham o **Supabase** como backend (auth, storage, realtime) e utilizam **SQLite** como banco local offline-first.

---

## 2. Estrutura de Diretórios (top-level)

```
ecoformsnext/
├── www/                      # Mobile PWA (principal)
│   ├── index.html            # Entry point mobile
│   ├── css/                  # Estilos (design-system, fields, pages)
│   ├── js/                   # JavaScript app
│   │   ├── core/             # Módulos core (validação, renderização, permissões)
│   │   ├── fields/           # Sistema de campos de formulário
│   │   │   └── types/        # 53+ tipos de campo
│   │   ├── services/         # Serviços (sync, atividades, lembretes)
│   │   ├── plugins/          # Plugins (ecoponto-caixas-sync)
│   │   ├── sync/             # Sistema de sincronização offline
│   │   ├── stores/           # Gerenciamento de estado
│   │   ├── utils/            # Utilitários
│   │   ├── vendor/           # Bibliotecas third-party locais
│   │   └── hooks/            # Hooks
│   ├── forms/                # Configurações de formulários (JSON)
│   ├── data/                 # Dados estáticos
│   └── docs/                 # Documentação
│
├── desktop/                  # Desktop Admin (Next.js + Tauri)
│   ├── src/
│   │   ├── application/      # Casos de uso (Clean Architecture)
│   │   │   ├── client/       # Gestão de clientes
│   │   │   ├── task/         # Gestão de tarefas
│   │   │   ├── demanda/      # Gestão de demandas
│   │   │   ├── crm/          # CRM (rotas, roteiros)
│   │   │   ├── suite/        # Formulários submetidos
│   │   │   ├── data-registry/# Registro de dados tipados
│   │   │   ├── user/         # Gestão de usuários
│   │   │   ├── actions/      # Ações de workflow
│   │   │   └── widgets/      # Widgets do dashboard
│   │   ├── domain/           # Entidades e repositórios (DDD)
│   │   ├── infrastructure/   # Persistência, sync, export/import
│   │   ├── interface/        # React hooks, presenters
│   │   └── lib/              # Utilitários
│   ├── src-tauri/            # Backend Rust (Tauri)
│   └── supabase/             # Migrações Supabase
│
├── supabase/                 # Migrações SQL e configurações Supabase
├── tests/                    # Testes (Vitest)
├── js/                       # Scripts Node.js auxiliares
├── scripts/                  # Scripts de build e manutenção
├── styles/                   # Tailwind CSS (input/saída)
├── docs/                     # Documentação de arquitetura/legado
├── legado_backend/           # Código legado backend
├── legado_docs/              # Documentos legados
├── meu-supabase-mcp/         # MCP Server para Supabase
├── android/                  # Projeto Android (Capacitor)
├── src/                      # Scripts adicionais (application, build)
└── scratch/                  # Arquivos temporários/experimentais
```

---

## 3. Linguagens de Programação

| Linguagem | Extensões | Arquivos (~) | Uso Principal |
|---|---|---|---|
| **TypeScript** | `.ts`, `.tsx` | ~747 | Desktop Admin (React/Next.js) |
| **JavaScript** | `.js`, `.mjs`, `.cjs` | ~893 | Mobile PWA, scripts |
| **CSS** | `.css` | ~160 | Estilização |
| **Rust** | `.rs` | ~21 | Backend Tauri |
| **Python** | `.py`, `.pyc` | ~816 | Scripts legados, automação |
| **SQL** | `.sql` | ~69 | Migrações, consultas |
| **HTML** | `.html` | ~134 | Templates, páginas estáticas |

**Linguagem primária:** TypeScript/JavaScript (full-stack)

---

## 4. Frameworks e Tecnologias Principais

### Frontend Mobile (PWA)
- **Alpine.js** — Reatividade declarativa (sem build step)
- **PWA Elements** — Componentes web para Capacitor (câmera, etc.)
- **Capacitor 8.0** — Bridge nativo Android
- **Tailwind CSS 3.4** — Estilização utilitária
- **IndexedDB** — Armazenamento local offline

### Frontend Desktop (Admin)
- **Next.js 16.2** — Framework React (SSG com `output: 'export'`)
- **React 19.2** — UI library
- **Radix UI** — 15+ componentes acessíveis (accordion, dialog, tabs, etc.)
- **@dnd-kit** — Drag and drop
- **Tailwind CSS 4** — Estilização utilitária
- **TanStack React Query 5** — Gerenciamento de dados assíncronos
- **Lucide React** — Ícones
- **jspdf / jspdf-autotable** — Geração de PDF

### Backend / Desktop Shell
- **Tauri 2.9** — Shell desktop nativo (Rust)
- **Rusqlite 0.32** — SQLite para Tauri (bundled)
- **Tauri Plugins**: dialog, fs, shell, log, store

### Backend Cloud
- **Supabase JS 2.x** — Auth, Storage, Realtime
- **Supabase Auth** — Email/senha, RLS
- **PostgreSQL** — Banco cloud (via Supabase)

### Utilitários
- **ExcelJS 4.4** — Exportação Excel
- **bcryptjs / bcrypt** — Hash de senhas
- **pako** — Compressão gzip
- **uuid** — IDs únicos
- **date-fns 4** — Manipulação de datas

### Testes
- **Vitest 3.2** — Test runner
- **@vitest/ui** — Interface visual
- **@vitest/coverage-v8** — Cobertura
- **happy-dom** — DOM simulado
- **Playwright** — Testes E2E

---

## 5. Pontos de Entrada

### Mobile PWA
| Arquivo | Tipo | Descrição |
|---|---|---|
| `www/index.html` | app_entry | Entry point Alpine.js + Supabase init |
| `www/js/app.js` | app_main | Função principal `formApp()` (Alpine x-data) |
| `www/js/data-service.js` | data_layer | DataService — camada de dados local (IndexedDB) |
| `www/js/auth-manager.js` | auth | AuthManager — autenticação local + Supabase |
| `www/js/form-renderer.js` | renderer | Renderização dinâmica de formulários |
| `server.js` | dev_server | Servidor Express para dev |
| `dev-server.js` | dev_server | Servidor HTTP simples alternativo |

### Desktop Admin
| Arquivo | Tipo | Descrição |
|---|---|---|
| `desktop/package.json` → `next dev -p 3001` | dev_entry | Next.js dev server |
| `desktop/src-tauri/src/main.rs` | tauri_main | Entry point Rust/Tauri |
| `desktop/src/infrastructure/container.ts` | di_container | Container de injeção de dependências |

### Scripts de Build
| Comando | Descrição |
|---|---|
| `npm start` | Inicia mobile (serve) + admin (Next.js) via concurrently |
| `npm run build` | Build CSS + concat + sync-field-css |
| `npm run install-debug` | Build Android APK debug e instala via adb |
| `cd desktop && npm run tauri` | Comandos Tauri (dev, build) |

---

## 6. Sistema de Sincronização

O projeto implementa um sofisticado sistema de sincronização offline-first com Supabase Storage:

```
Mobile (www/js/sync/)          Desktop (desktop/src/infrastructure/sync/)
├── CryptoLayer.js             ├── CryptoLayer.ts
├── EventBus.js                ├── EventBus.ts
├── EventEnvelope.js           ├── EventEnvelope.ts
├── HandlerRegistry.js         ├── HandlerRegistry.ts
├── InboundService.js          ├── InboundService.ts
├── Manifest.js                ├── Manifest.ts
├── SupabaseStorage.js         ├── TransportService.ts
├── SyncAdapter.js             ├── EventSyncAdapter.ts
├── SyncBootstrap.js           ├── StorageBootstrapService.ts
├── SyncEventDB.js             ├── SupabaseUserSyncService.ts
├── TransportService.js        ├── handlers/
└── index.js                   │   ├── crm.handler.ts
                               │   ├── data_registry.handler.ts
                               │   ├── demanda.handler.ts
                               │   ├── ecoponto.handler.ts
                               │   ├── form_registry.handler.ts
                               │   ├── org_config.handler.ts
                               │   ├── suite.handler.ts
                               │   └── usuario.handler.ts
                               └── sync-settings.ts
```

---

## 7. Módulos Identificados

### Domínios de Negócio (Clean Architecture — Desktop)

| Módulo | Descrição | Domain | Application | Infra |
|---|---|---|---|---|
| **Client** | Cadastro e gestão de clientes/empresas | Client.ts | 10 use cases | SqliteClientRepository |
| **Task** | Tarefas com recorrência e workflow | Task.ts | 7 use cases | SqliteTaskRepository |
| **Demanda** | Demandas com eventos e formulários vinculados | Demanda.ts | 4 use cases | SqliteDemandaRepository |
| **Ouvidoria** | Protocolos via tbl_suite | Protocolo.ts | ⚰️ removido | (tbl_suite direto) |
| **CRM** | Rotas, roteiros e coletas | Rota.ts | 5 use cases | SqliteCRMRepository |
| **Suite** | Formulários submetidos (inbox/review) | SuitePackage.ts | 4 use cases | SqliteSuiteRepository |
| **Data Registry** | Registro de dados tipados genéricos | DataRegistryItem.ts | 5 use cases | SqliteDataRegistryRepository |
| **User** | Gestão de usuários e perfis | User.ts | 5 use cases | SqliteUserRepository |
| **Access** | Políticas de acesso/filtros | AccessPolicy.ts | — | AccessFilterBuilder |

### Módulos Frontend (Mobile PWA)

| Módulo | Descrição | Arquivos-chave |
|---|---|---|
| **Form Renderer** | Renderização dinâmica de formulários | `www/js/form-renderer.js` |
| **Field System** | 53+ tipos de campo (BaseField, FieldFactory) | `www/js/fields/` |
| **Auth** | Autenticação local + Supabase Auth | `www/js/auth-manager.js` |
| **Data Service** | Camada de dados com IndexedDB | `www/js/data-service.js` |
| **Sync** | Sincronização offline → Supabase Storage | `www/js/sync/` |
| **Activities** | Hub de atividades/tarefas do usuário | `www/js/services/ActivityService.js` |
| **Notifications** | Serviço de notificações | `www/js/notification-service.js` |
| **Ecoponto** | Lembretes de atualização de ecopontos | `www/js/services/EcopontoUpdateReminderService.js` |
| **Connection Requests** | Solicitações de conexão entre usuários | `www/js/services/ConnectionRequestService.js` |

---

## 8. Banco de Dados

### Supabase (PostgreSQL)
- **Auth**: `auth.users` + trigger → `public.profiles`
- **Storage**: bucket `sync-bucket` com RLS dual-auth (anon + authenticated)
- Migrações: `desktop/supabase/migrations/` + `supabase/migrations/`
- Schema complementar em `supabase-views/`

### SQLite (Local)
- **Desktop (Tauri)**: `rusqlite` com schema gerenciado por `ColumnSchemaManager`
- **Mobile (Browser)**: IndexedDB via DataService (não SQLite direto)
- **Node.js scripts**: `sqlite3` + `duckdb` para análise de dados

---

## 9. Testes

| Framework | Config | Cobertura-alvo |
|---|---|---|
| **Vitest** | `vitest.config.js` | 80% lines, 80% functions, 75% branches |
| Ambiente | `happy-dom` | Foco em `www/js/core/**/*.js` |

Arquivos de teste (~14 encontrados):
- `desktop/src/application/*/__tests__/*.test.ts` — 8 testes de use cases
- `tests/*.test.js` — 3 testes de data service/safe-json
- `test/*.test.js` — 1 teste de auth
- `www/test/*.test.js` — 1 teste rápido

---

## 10. CI/CD

- **Não detectado**: Sem workflows GitHub Actions, GitLab CI ou Jenkins configurados.
- Scripts manuais de build em `scripts/`, `build-debug.ps1`, `build-debug-mobile.ps1`

---

## 11. Docker

- **Não detectado**: Sem `Dockerfile` ou `docker-compose.yml`.

---

## 12. Integrações Externas

| Serviço | Tipo | Configuração |
|---|---|---|
| **Supabase** | Backend-as-a-Service | `.env` / meta tags HTML (`vnnimekczkxkpckrydnc.supabase.co`) |
| **ViaCEP** | API de CEP (Brasil) | `useCEP.ts` hook |
| **Google Maps** | Geolocalização | `GeolocationField.js`, `GPSField.v2.js` |

---

## Resumo Estatístico

| Métrica | Valor |
|---|---|
| Total de arquivos (excluindo build artifacts, node_modules) | ~2.500+ |
| Linguagem primária | TypeScript/JavaScript |
| Framework principal (mobile) | Alpine.js + Capacitor |
| Framework principal (desktop) | Next.js 16 + React 19 + Tauri 2 |
| Módulos de negócio (domain) | 9 |
| Tipos de campo de formulário | 53+ |
| Use cases documentados (desktop) | ~58 |
| Backend cloud | Supabase (PostgreSQL + Auth + Storage) |
| Banco local | SQLite (Tauri) / IndexedDB (Browser) |
| Test runner | Vitest |
| Nível de documentação configurado | completo |
